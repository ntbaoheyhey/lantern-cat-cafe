from pathlib import Path
import datetime,gzip,hashlib,json,os,subprocess,sys,time
root=Path.cwd();folder=root/'reports/v4-ship/S11';assert not (root/'STOP-V4SHIP').exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
git=lambda *args:subprocess.check_output(['git',*args],cwd=root)
load=lambda p:json.loads(gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes())
ref=lambda p:{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}
assert git('branch','--show-current').decode().strip()=='codex/v4-ship-2026-11-16'
textout=folder/'history-supplement-7.json';scopeout=folder/'history-gzip-supplement-scope-4.json.gz';gzout=folder/'history-gzip-supplement-4.json.gz'
assert not any(p.exists() for p in [textout,scopeout,gzout])
base=folder/'history-batches-1/scope.json';baseScope=load(base);commitFile=folder/'history-batches-1/commits.txt.gz';assert sha(commitFile.read_bytes())==baseScope['commitListSha256'];covered=set(gzip.decompress(commitFile.read_bytes()).decode().splitlines())
prior=[folder/f'history-supplement-{i}.json' for i in range(1,7)]
for p in prior:
 d=load(p);assert d['supplementPass'] and not d['unresolved'];assert not covered.intersection(d['commits']);covered.update(d['commits'])
tips=sorted(set(git('for-each-ref','--format=%(objectname)').decode().splitlines()));reachable=git('rev-list','--topo-order',*tips).decode().splitlines();commits=[c for c in reachable if c not in covered]
assert commits and set(git('rev-list','--no-walk=unsorted',*commits).decode().splitlines())==set(commits)
flags=['--no-banner','--no-color','--redact=100','--log-level=fatal','--report-format=json','--report-path=-','--ignore-gitleaks-allow'];start=time.monotonic()
process=subprocess.run(['gitleaks','git','--log-opts='+' '.join(['-m','--root','--no-walk=unsorted',*commits]),str(root),*flags],cwd=root,capture_output=True,env={**os.environ,'GOMAXPROCS':'1'})
assert process.returncode in [0,1],'Text scanner error; raw output suppressed'
findings=[]
for row in json.loads(process.stdout or b'[]'):
 assert row.get('Commit') in commits
 findings.append({'file':row.get('File','').removeprefix(str(root)+'/'),'line':row.get('StartLine'),'endLine':row.get('EndLine'),'commit':row.get('Commit'),'type':row.get('RuleID'),'classification':'unresolved'})
textreport={'at':now(),'scope':'Exact newly reachable commits beyond original text scope and supplements1-6. Root/per-parent merge textual patches only; binary/gzip and later refs remain separate.','baseScope':ref(base),'previousSupplements':[ref(p) for p in prior],'head':git('rev-parse','HEAD').decode().strip(),'referenceTips':tips,'commits':commits,'count':len(commits),'logOptions':['-m','--root','--no-walk=unsorted'],'seconds':round(time.monotonic()-start,3),'scanner':subprocess.check_output(['gitleaks','version'],text=True).strip(),'scannerExitCode':process.returncode,'findings':findings,'unresolved':len(findings),'supplementPass':not findings,'fullHistoryPass':False,'learn':['reports/v4-ship/LEARN/S11-history.md','reports/v4-ship/LEARN/S11-history-gzip.md']}
textout.write_text(json.dumps(textreport,indent=2)+'\n');print(json.dumps({'textCommits':len(commits),'findings':len(findings)}),flush=True)
oldscope=folder/'history-gzip-supplement-scope-3.json.gz';olds=load(oldscope);oldReachable=set(git('rev-list',*olds['referenceTips']).decode().splitlines());newCommits=[c for c in reachable if c not in oldReachable]
known={row['oid'] for row in load(folder/'history-gzip-1/inventory.json.gz')}|{row['oid'] for i in range(1,4) for row in load(folder/f'history-gzip-supplement-scope-{i}.json.gz')['inventory']}
metadata=[];changes=[];deletions=0;inventory={};checks=0
for commit in newCommits:
 raw=git('diff-tree','--root','-m','--no-commit-id','--raw','-r','-z','--no-abbrev','--no-renames',commit,'--',':(icase)*.gz');metadata.append(raw);parts=raw.split(b'\0');i=0
 while i<len(parts)-1:
  header=parts[i];path=os.fsdecode(parts[i+1]);i+=2
  fields=header.decode().split();assert len(fields)==5 and fields[0].startswith(':');mode,oid,status=fields[1],fields[3],fields[4]
  if status=='D':deletions+=1;continue
  assert git('rev-parse',commit+':'+path).decode().strip()==oid
  assert git('cat-file','-t',oid).strip()==b'blob';checks+=1
  changes.append({'commit':commit,'path':path,'mode':mode,'oid':oid,'inEarlierInventory':oid in known})
  if oid in known:continue
  item=inventory.setdefault(oid,{'oid':oid,'paths':[],'exemplar':{'commit':commit,'path':path,'mode':mode},'compressedBytes':int(git('cat-file','-s',oid))})
  if path not in item['paths']:item['paths'].append(path)
items=sorted(inventory.values(),key=lambda r:(r['compressedBytes'],r['oid']))
scope={'at':now(),'priorScope':ref(oldscope),'referenceSource':ref(textout),'referenceTips':tips,'commits':newCommits,'scope':'Exact new case-insensitive gzip introductions after previous captured references, excluding immutable blobs already in original or supplements1-3 inventories.','metadataSha256':sha(b''.join(metadata)),'changes':changes,'deletions':deletions,'inventory':items,'mappingChecks':checks,'uniqueNewBlobs':len(items),'compressedBytes':sum(r['compressedBytes'] for r in items),'fullHistoryPass':False}
scopeout.write_bytes(gzip.compress(json.dumps(scope,separators=(',',':')).encode(),mtime=0))
sys.path.insert(0,str(root/'tools/v4ship-lab/security'));from stdin_worker import communicate
command=['gitleaks','stdin',*flags];helper=root/'tools/v4ship-lab/security/stdin_worker.py';report={'at':now(),'scope':ref(scopeout),'scanner':textreport['scanner'],'command':command,'transportHelper':ref(helper),'rows':[],'complete':False,'fullHistoryPass':False,'limits':['Expanded stdin content does not cover path-sensitive rules, encoded/binary payloads or embedded archives.','Original text and gzip scans and refs after this frozen capture remain separate.']}
def save():
 rows=report['rows'];report.update(at=now(),scannedBlobs=len(rows),totalBlobs=len(items),compressedBytes=sum(r['compressedBytes'] for r in rows),expandedBytes=sum(r['expandedBytes'] for r in rows),findings=sum(len(r['findings']) for r in rows),nonUtf8Blobs=sum(not r['utf8'] for r in rows),unresolved=sum(len(r['findings']) for r in rows))
 report['supplementPass']=report['complete'] and not report['unresolved'] and not report['nonUtf8Blobs'];gzout.write_bytes(gzip.compress(json.dumps(report,separators=(',',':')).encode(),mtime=0))
try:
 for index,item in enumerate(items):
  assert not (root/'STOP-V4SHIP').exists();packed=git('cat-file','blob',item['oid']);assert len(packed)==item['compressedBytes'];data=gzip.decompress(packed);utf8=True
  try:data.decode('utf-8')
  except UnicodeDecodeError:utf8=False
  begin=time.monotonic();child=subprocess.Popen(command,cwd=root,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env={**os.environ,'GOMAXPROCS':'1'});output,_=communicate(child,data,lambda:(root/'STOP-V4SHIP').exists());assert child.returncode in [0,1],'Gzip scanner error; raw output suppressed'
  safe=[{'line':r.get('StartLine'),'endLine':r.get('EndLine'),'type':r.get('RuleID'),'classification':'unresolved'} for r in json.loads(output or b'[]')]
  report['rows'].append({'index':index,'oid':item['oid'],'complete':True,'compressedBytes':len(packed),'compressedSha256':sha(packed),'expandedBytes':len(data),'expandedSha256':sha(data),'gzipIntegrity':True,'utf8':utf8,'scannerExitCode':child.returncode,'findings':safe,'seconds':round(time.monotonic()-begin,3)});save()
 report['complete']=len(report['rows'])==len(items)
finally:save()
print(json.dumps({k:report[k] for k in ['complete','scannedBlobs','expandedBytes','findings','supplementPass','fullHistoryPass']}),flush=True)
