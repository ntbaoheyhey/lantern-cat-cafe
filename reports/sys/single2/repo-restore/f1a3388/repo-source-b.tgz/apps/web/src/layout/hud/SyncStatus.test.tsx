import { act, cleanup, render, screen } from '@testing-library/react';
import { afterEach, expect, it, vi } from 'vitest';
import { GameLoopV2 } from '../../game/v2/loopV2';
import { MockGameApiV2 } from '../../api/MockGameApiV2';
import { SyncStatus } from './SyncStatus';

afterEach(() => { cleanup(); vi.restoreAllMocks(); });
it('announces visibility, connectivity, claim progress and failure; cleans up on unmount', async () => {
  const online = vi.spyOn(navigator, 'onLine', 'get').mockReturnValue(true);
  const visibility = vi.spyOn(document, 'visibilityState', 'get').mockReturnValue('visible');
  const api = new MockGameApiV2({ storage: null });
  await api.chooseClass('warrior');
  const loop = new GameLoopV2({ api });
  await loop.start(document);
  const view = render(<SyncStatus loop={loop} />);
  const status = screen.getByRole('status');
  expect(status.textContent).toContain('Live');
  expect(status.getAttribute('aria-live')).toBe('polite');
  act(() => { visibility.mockReturnValue('hidden'); document.dispatchEvent(new Event('visibilitychange')); });
  expect(status.textContent).toContain('Hidden');
  act(() => { online.mockReturnValue(false); window.dispatchEvent(new Event('offline')); });
  expect(status.textContent).toContain('Hidden');
  act(() => { visibility.mockReturnValue('visible'); document.dispatchEvent(new Event('visibilitychange')); });
  expect(status.textContent).toContain('Offline');
  act(() => { online.mockReturnValue(true); window.dispatchEvent(new Event('online')); });
  await act(async () => { await loop.claimNow(); });
  let reject!: (error: Error) => void;
  vi.spyOn(api, 'claim').mockImplementationOnce(() => new Promise((_, no) => { reject = no; }));
  let claiming!: Promise<void>;
  act(() => { claiming = loop.claimNow(); });
  expect(status.textContent).toContain('Syncing');
  await act(async () => { await Promise.resolve(); reject(new Error('Network failed')); await claiming; });
  expect(status.textContent).toContain('Sync error');
  const remove = vi.spyOn(document, 'removeEventListener');
  const removeWindow = vi.spyOn(window, 'removeEventListener');
  view.unmount();
  expect(remove).toHaveBeenCalledWith('visibilitychange', expect.any(Function));
  expect(removeWindow).toHaveBeenCalledWith('online', expect.any(Function));
  expect(removeWindow).toHaveBeenCalledWith('offline', expect.any(Function));
  loop.stop();
});

it('renders the display status supplied by the layout without an independent live subscription', () => {
  const view = render(<SyncStatus status="live" />);
  expect(screen.getByRole('status').textContent).toContain('Live');
  view.rerender(<SyncStatus status="syncing" />);
  expect(screen.getByRole('status').textContent).toContain('Syncing');
});
