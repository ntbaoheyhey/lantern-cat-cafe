// \0rolldown/runtime.js
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
// packages/game-rules/src/cardrpg/depth/economy-c2.ts
/** B4b candidate tables. Consumers opt in through formationC2; old rules retain
* their published guarantees. The first candidate is measured before acceptance.
*/
var ECONOMY_C2 = {
	equipment: {
		commonPower: .008,
		maximumPower: .02,
		minimumMain: 1,
		affixScale: .25,
		defenseWeight: 3,
		hpWeight: .6
	},
	sets: {
		hearthloomShareBp: 500,
		bellsteelSheltersPerBattle: 0,
		bellsteelRipostesPerBattle: 1
	},
	uniques: {
		rainbellCleanseStacks: 1,
		softcollarShield: 8
	},
	dropsPerDay: 6,
	drops: {
		battle: {
			common: 6500,
			rare: 3e3,
			epic: 500,
			legendary: 0
		},
		elite: {
			common: 0,
			rare: 7200,
			epic: 2795,
			legendary: 5
		},
		boss: {
			common: 0,
			rare: 2985,
			epic: 7e3,
			legendary: 15
		}
	},
	equipmentInvitation: { stamps: 300 },
	tailoring: {
		common: {
			fish: 180,
			threads: 30
		},
		rare: {
			fish: 180,
			threads: 30
		},
		epic: {
			fish: 20,
			threads: 240,
			essence: 9
		},
		legendary: {
			fish: 100,
			threads: 300,
			essence: 60
		}
	},
	legendary: {
		seals: 10,
		materials: 200,
		selectorMarks: 72
	}
};
// packages/game-rules/src/cardrpg/depth/events-v4.ts
var LEGACY_EVENT_KINDS = [
	"crew-active",
	"formation-cover",
	"plan-target",
	"gear-trigger",
	"boss-phase",
	"boss-finish",
	"earned-reveal"
];
function emitGameplayEvent(battle, event) {
	if (!battle.v4) return;
	const identity = {
		sequence: battle.v4.events.length,
		round: battle.round
	};
	if (battle.initial.skillsV5) {
		const actionId = battle.procRounds.v5ActionSequence ?? 0;
		battle.v4.events.push({
			...event,
			...identity,
			version: 2,
			actionId,
			stage: battle.procRounds.v5RoundEnd ? "round-end" : actionId ? "action" : "setup",
			logIndex: battle.log.length
		});
	} else {
		if (!LEGACY_EVENT_KINDS.includes(event.kind)) throw Error("Skills V5 event requires skillsV5");
		battle.v4.events.push({
			...event,
			version: 1,
			...identity
		});
	}
}
function battleReasons(battle) {
	if (!battle.v4) return [];
	const reasons = [];
	const cover = battle.v4.events.reduce((n, e) => n + (e.kind === "formation-cover" ? e.amount : 0), 0);
	if (cover) reasons.push(`Front-row cover prevented ${cover} direct damage to the back row.`);
	const shields = battle.log.filter((e) => e.kind === "absorbed" && battle.actors.some((a) => a.id === e.targetId && a.side === "party")).reduce((n, e) => n + e.amount, 0);
	if (shields) reasons.push(`Your shields absorbed ${shields} damage before it reached HP.`);
	const suppressed = battle.log.filter((e) => e.kind === "suppressed");
	if (suppressed.length) reasons.push(`Your control softened or stopped ${suppressed.length} enemy actions.`);
	const gear = battle.v4.events.find((e) => e.kind === "gear-trigger" && e.amount > 0);
	if (gear) reasons.push(gear.text);
	const healing = battle.log.filter((e) => e.kind === "heal" && battle.actors.some((a) => a.id === e.targetId && a.side === "party")).reduce((n, e) => n + e.amount, 0);
	if (healing) reasons.push(`The crew restored ${healing} missing HP.`);
	if (!reasons.length) reasons.push("Direct attacks and current health decided this encounter; no protection contribution was recorded.");
	return reasons.slice(0, 3);
}
// packages/game-rules/src/cardrpg/depth/bonds-a6.ts
var COLLECTION_BONDS_A6 = [
	{
		id: "first-lantern",
		name: "First Lantern",
		cats: [
			"mochi",
			"soot",
			"clover"
		]
	},
	{
		id: "warm-kitchen",
		name: "Warm Kitchen",
		cats: [
			"panko",
			"mallow",
			"biscuit"
		]
	},
	{
		id: "garden-tea",
		name: "Garden Tea",
		cats: [
			"clover",
			"sorrel",
			"marigold"
		]
	},
	{
		id: "night-watch",
		name: "Night Watch",
		cats: [
			"soot",
			"inkcap",
			"velvet"
		]
	},
	{
		id: "shared-aprons",
		name: "Shared Aprons",
		cats: ["mochi", "brioche"]
	},
	{
		id: "second-serving",
		name: "Second Serving",
		cats: ["cinnamon", "sorrel"]
	},
	{
		id: "moon-crumbs",
		name: "Moon Crumbs",
		cats: ["biscuit", "velvet"]
	},
	{
		id: "sunlit-cups",
		name: "Sunlit Cups",
		cats: ["mallow", "marigold"]
	},
	{
		id: "quiet-corner",
		name: "Quiet Corner",
		cats: ["inkcap", "cinnamon"]
	}
];
function collectionBondsA6(state) {
	const owned = new Set(state.account.cards.map((c) => c.cardId));
	return COLLECTION_BONDS_A6.map((bond) => ({
		...bond,
		owned: bond.cats.filter((id) => owned.has(id)),
		missing: bond.cats.filter((id) => !owned.has(id)),
		active: bond.cats.every((id) => owned.has(id))
	}));
}
/** Each completed collection adds half a percent HP/attack, even from the bench. */
function collectionBonusA6(state) {
	if (!(state.run && !state.run.complete ? state.run.gameplayA6 : state.gameplayA6)) return 0;
	return collectionBondsA6(state).filter((b) => b.active).length * 50;
}
var PAIR_COMBOS_A6 = [
	{
		id: "lantern-pledge",
		name: "Lantern Pledge",
		cats: ["mochi", "clover"],
		power: 65,
		support: "shield",
		description: "Strike the weakest foe and shield the team."
	},
	{
		id: "oven-sparks",
		name: "Oven Sparks",
		cats: ["panko", "mallow"],
		power: 90,
		status: "scald",
		description: "Strike and Burn the weakest foe."
	},
	{
		id: "mooncrumb-waltz",
		name: "Mooncrumb Waltz",
		cats: ["biscuit", "velvet"],
		power: 100,
		status: "scent",
		description: "Strike and Mark the weakest foe."
	},
	{
		id: "ink-and-ember",
		name: "Ink and Ember",
		cats: ["soot", "inkcap"],
		power: 80,
		status: "brittle",
		description: "Shred the weakest foe, then strike."
	},
	{
		id: "shared-sunrise",
		name: "Shared Sunrise",
		cats: ["sorrel", "cinnamon"],
		power: 65,
		support: "heal",
		description: "Strike the weakest foe and heal the team."
	},
	{
		id: "golden-canopy",
		name: "Golden Canopy",
		cats: ["brioche", "marigold"],
		power: 75,
		support: "shield",
		description: "Strike the weakest foe and shield the team."
	},
	{
		id: "garden-afterglow",
		name: "Garden Afterglow",
		cats: ["clover", "inkcap"],
		power: 80,
		status: "snag",
		description: "Strike and Bleed the weakest foe."
	},
	{
		id: "crumb-teapot",
		name: "Crumb Teapot",
		cats: ["biscuit", "sorrel"],
		power: 80,
		status: "crumb",
		description: "Strike and leave Crumbs on the weakest foe."
	}
];
var activePairCombosA6 = (team) => PAIR_COMBOS_A6.filter((pair) => pair.cats.every((id) => team.includes(id)));
/** Follow the first partner's action from round three, once per pair, with both alive. */
function triggerPairCombosA6(b, actor, io) {
	if (!b.initial.gameplayA6 || b.initial.tutorial || b.round < 3 || actor.side !== "party" || actor.hp <= 0) return;
	const allies = b.actors.filter((a) => a.side === "party" && a.hp > 0);
	for (const pair of activePairCombosA6(allies.map((a) => a.catalogId))) {
		if (actor.hp <= 0) return;
		if (!pair.cats.every((id) => allies.some((ally) => ally.catalogId === id && ally.hp > 0))) continue;
		if (!pair.cats.includes(actor.catalogId) || b.procRounds[`a6Pair:${pair.id}`]) continue;
		const target = b.actors.filter((a) => a.side === "enemy" && a.hp > 0).sort((a, c) => a.hp - c.hp || a.id.localeCompare(c.id))[0];
		if (!target) return;
		b.procRounds[`a6Pair:${pair.id}`] = 1;
		if (pair.status) io.apply(b, actor, target, pair.status, 1);
		io.damage(b, actor, target, pair.power, 0);
		if (pair.support) for (const ally of allies) io[pair.support](b, actor, ally, 20);
		b.log.push({
			round: b.round,
			actorId: actor.id,
			targetId: target.id,
			skillId: pair.id,
			kind: "bond.combo",
			amount: 1,
			text: pair.name
		});
		emitGameplayEvent(b, {
			kind: "bond.combo",
			actorId: actor.id,
			targetId: target.id,
			comboId: pair.id,
			displayName: pair.name,
			contributors: [...pair.cats],
			targets: [target.id],
			text: `${pair.name} · ${pair.description}`
		});
	}
}
// packages/game-rules/src/squad/config.ts
/** All squad-only tunables. No member of this object is an economic/server rule. */
var SQUAD_CONFIG = {
	version: 1,
	tickMs: 50,
	defaultSeed: 11,
	maxDurationMs: 18e4,
	wavePauseMs: 1600,
	clockTolerance: 1e4,
	stormSpacingMs: 400,
	threadSlot: 7,
	addSlots: [2, 3],
	opening: {
		guardian: [
			2100,
			50,
			0
		],
		witch: [
			1200,
			2600,
			0
		],
		alchemist: [
			3600,
			5300,
			0
		]
	},
	trainingRoles: [
		"guard",
		"healer",
		"flanker",
		"ranger",
		"charger",
		"elite",
		"ranger",
		"flanker"
	],
	maxEnemies: 8,
	maxHeavyWindups: 1,
	enemyOffsetMs: 280,
	initialEnemyMs: 900,
	defenseScale: 80,
	minDamage: 1,
	critMultiplier: 1.5,
	variance: .08,
	caps: {
		speed: .65,
		cdr: .35,
		crit: .4,
		attackBuff: .3,
		guard: .5,
		shieldFraction: .6,
		burn: 3
	},
	control: {
		diminishing: .55,
		minDurationMs: 150,
		continuousMs: 2200,
		immuneMs: 1400,
		bossMultiplier: .45
	},
	burn: {
		tickMs: 1e3,
		damage: 7,
		durationMs: 3600
	},
	ultimate: {
		max: 100,
		perSecond: 2,
		perHit: 2,
		initial: 12
	},
	passive: {
		cooldownMs: 4500,
		guardianShield: 20,
		witchCharge: 9,
		alchemistShield: 24,
		injuredFraction: .65
	},
	healThreshold: .82,
	guardFraction: .3,
	waveFish: 9,
	bossFish: 15,
	boss: {
		phaseFraction: .5,
		enrageMs: 9e4,
		enrageMultiplier: 1.8,
		breakMax: 100,
		bashBreak: 32,
		ordinaryBreak: 4,
		guardedBreak: 8,
		breakMs: 1800,
		exposedMs: 4e3,
		exposedMultiplier: 1.65,
		threadEveryMs: 11500,
		firstThreadMs: 4500,
		addEveryMs: 19e3,
		firstAddMs: 8e3,
		addsPerPhase: 2,
		laneHalfWidth: 32,
		threadDurationMs: 16e3
	},
	gear: {
		pierceMultiplier: .55,
		pierceRadius: 130,
		afterhealShield: 18,
		guardedBreak: 8
	},
	presets: {
		hearthkeepers: {
			name: "Hearthkeepers",
			hp: 1.12,
			attack: 1,
			healing: 1.12,
			shield: 1.15,
			speed: 0,
			cdr: 0,
			gear: "last-light",
			tactic: "protect"
		},
		lanternbreakers: {
			name: "Lanternbreakers",
			hp: .95,
			attack: 1.17,
			healing: 1,
			shield: 1,
			speed: .15,
			cdr: .08,
			gear: "needle-lantern",
			tactic: "opening"
		}
	},
	stats: {
		guardian: {
			hp: 610,
			attack: 28,
			defense: 42,
			intervalMs: 1550,
			crit: .08
		},
		witch: {
			hp: 340,
			attack: 36,
			defense: 14,
			intervalMs: 1850,
			crit: .12
		},
		alchemist: {
			hp: 380,
			attack: 21,
			defense: 22,
			intervalMs: 1950,
			crit: .05
		},
		guard: {
			hp: 270,
			attack: 58,
			defense: 32,
			intervalMs: 2400,
			crit: .04
		},
		flanker: {
			hp: 120,
			attack: 35,
			defense: 5,
			intervalMs: 2200,
			crit: .08
		},
		ranger: {
			hp: 165,
			attack: 53,
			defense: 8,
			intervalMs: 2800,
			crit: .05
		},
		healer: {
			hp: 245,
			attack: 12,
			defense: 12,
			intervalMs: 2800,
			crit: 0
		},
		charger: {
			hp: 245,
			attack: 93,
			defense: 20,
			intervalMs: 4500,
			crit: .05
		},
		elite: {
			hp: 430,
			attack: 95,
			defense: 58,
			intervalMs: 3100,
			crit: .08
		},
		yarn: {
			hp: 4300,
			attack: 170,
			defense: 28,
			intervalMs: 4800,
			crit: 0
		},
		thread: {
			hp: 78,
			attack: 7,
			defense: 0,
			intervalMs: 3500,
			crit: 0
		},
		dummy: {
			hp: 1800,
			attack: 0,
			defense: 16,
			intervalMs: 3e3,
			crit: 0
		}
	},
	formation: {
		party: [
			{
				x: 225,
				y: 206
			},
			{
				x: 114,
				y: 152
			},
			{
				x: 110,
				y: 252
			}
		],
		enemy: [
			{
				x: 394,
				y: 201
			},
			{
				x: 468,
				y: 145
			},
			{
				x: 443,
				y: 259
			},
			{
				x: 526,
				y: 223
			},
			{
				x: 530,
				y: 111
			},
			{
				x: 585,
				y: 288
			},
			{
				x: 606,
				y: 172
			},
			{
				x: 361,
				y: 302
			}
		],
		boss: {
			x: 487,
			y: 214
		},
		bossAdds: [
			{
				x: 487,
				y: 214
			},
			{
				x: 358,
				y: 142
			},
			{
				x: 357,
				y: 287
			},
			{
				x: 581,
				y: 294
			},
			{
				x: 610,
				y: 144
			},
			{
				x: 461,
				y: 310
			},
			{
				x: 587,
				y: 220
			},
			{
				x: 332,
				y: 222
			}
		],
		healer: {
			x: 584,
			y: 123
		}
	},
	waves: [
		{
			name: "Doorstep tangle",
			roles: [
				"guard",
				"flanker",
				"flanker",
				"charger"
			],
			threat: 7,
			goal: "Intercept the charger. Hold the pack for Ember Orb."
		},
		{
			name: "Teatime trouble",
			roles: [
				"guard",
				"healer",
				"ranger",
				"ranger",
				"flanker"
			],
			threat: 9,
			goal: "Mark the Teacup Healer to stop its mending."
		},
		{
			name: "Closing patrol",
			roles: [
				"elite",
				"healer",
				"charger",
				"ranger",
				"flanker",
				"flanker"
			],
			threat: 12,
			goal: "Protect the front. Save a barrier for the heavy windup."
		}
	],
	presentation: {
		width: 680,
		height: 330,
		frameMs: 120,
		idleFrameMs: 280,
		uiMs: 100,
		contactDistance: 44,
		contactLane: 62,
		contactClearance: 55,
		contactReach: 108,
		contactSlots: [
			[44, 0],
			[44, -62],
			[44, 62],
			[92, -30],
			[92, 30]
		],
		defeatFadeMs: 900,
		patchHeight: 52,
		approachMs: 180,
		returnMs: 260,
		residueMs: 520,
		labelMs: 800,
		hitMs: 180,
		maxEffects: 32,
		maxBright: 4,
		quietEffectAlpha: .35,
		maxLabels: 12,
		labelLine: 14,
		hitStopMs: 50,
		shakePx: 2,
		maxDeltaMs: 250,
		fps: 60,
		calmFps: 20,
		idleFps: 8,
		barWidth: 52,
		barHeight: 4,
		heroFrame: 80,
		enemyFrame: 72,
		bossFrame: 144,
		heroFoot: 72,
		enemyFoot: 64,
		bossFoot: 132,
		flaskArc: 72,
		numberRise: 26,
		sceneInset: 12,
		minDesktop: 1280,
		maxSpeed: 4,
		effect: {
			sourceX: 22,
			enemySourceX: -18,
			sourceY: 38,
			targetY: 28,
			markWidth: 46,
			markHeight: 18,
			markLine: 2,
			impactStart: 10,
			impactGrowth: 27,
			calmRadius: 18,
			impactY: 20,
			shardSize: 4,
			shardCount: 6,
			slashLength: 25,
			laneLeft: 50,
			laneRight: 600,
			laneHeight: 48,
			laneOffset: 28,
			stripeSpacing: 22
		},
		budgets: {
			addedGzipBytes: 153600,
			newImageBytes: 2097152,
			frameP95Ms: 25,
			heapBytes: 134217728,
			idleTaskPercent: 2,
			hiddenAdvanceMs: 0
		},
		speeds: [
			1,
			2,
			4
		],
		heroScale: 1,
		enemyScale: 1,
		bossScale: 1,
		logEntries: 18,
		background: "#1d2335",
		partyColor: "#8fd8df",
		dangerColor: "#ff9696",
		healColor: "#a5d5ad",
		goldColor: "#f5cb7b"
	}
};
var routine = {
	cooldownMs: 0,
	windupMs: 250,
	travelMs: 300,
	power: 1,
	target: "front"
};
var ABILITIES = {
	guardianBasic: {
		...routine,
		name: "Hearthblade",
		shape: "slash",
		melee: true,
		travelMs: 200,
		description: "Approach and cut the front foe."
	},
	witchBasic: {
		...routine,
		name: "Wick Spark",
		shape: "orb",
		description: "A small pointed ember seeks the marked foe."
	},
	alchemistBasic: {
		...routine,
		name: "Sour Drop",
		shape: "flask",
		description: "A green flask arcs to the front foe."
	},
	shieldBash: {
		...routine,
		name: "Shield Bash",
		shape: "bash",
		cooldownMs: 5500,
		power: 1.45,
		melee: true,
		travelMs: 200,
		status: "stun",
		durationMs: 900,
		description: "Stagger one foe. Interrupting triggers Steadfast."
	},
	rally: {
		...routine,
		name: "Rally",
		shape: "rally",
		cooldownMs: 9500,
		target: "self",
		power: 0,
		shield: 28,
		status: "guard",
		durationMs: 4200,
		description: "Taunt the enemy line and guard incoming hits."
	},
	hearthwall: {
		...routine,
		name: "Hearthwall",
		shape: "wall",
		cooldownMs: 14e3,
		ultimate: true,
		target: "team",
		power: 0,
		shield: 70,
		status: "guard",
		durationMs: 4500,
		description: "A broad barrier shields every living ally."
	},
	threadSnare: {
		...routine,
		name: "Thread Snare",
		shape: "thread",
		cooldownMs: 6400,
		radius: 100,
		power: .35,
		status: "snare",
		durationMs: 1700,
		description: "Hold a nearby group together for the next burst."
	},
	emberOrb: {
		...routine,
		name: "Ember Orb",
		shape: "orb",
		cooldownMs: 7200,
		travelMs: 500,
		radius: 100,
		power: 2.2,
		status: "burn",
		durationMs: 3600,
		description: "Burst on a group. Burn stacks are capped at three."
	},
	lanternstorm: {
		...routine,
		name: "Lanternstorm",
		shape: "storm",
		cooldownMs: 14e3,
		windupMs: 1e3,
		travelMs: 400,
		ultimate: true,
		radius: 135,
		power: 1.4,
		hits: 3,
		description: "Mark a wide zone, then land three lantern strikes."
	},
	milkFlask: {
		...routine,
		name: "Milk Flask",
		shape: "flask",
		cooldownMs: 5e3,
		target: "injured",
		power: 0,
		heal: 100,
		retarget: true,
		travelMs: 650,
		description: "Arc to the most injured ally; retarget if they fall."
	},
	mossFlask: {
		...routine,
		name: "Moss Flask",
		shape: "patch",
		cooldownMs: 9800,
		target: "injured",
		power: 0,
		heal: 32,
		radius: 150,
		status: "guard",
		durationMs: 4500,
		retarget: true,
		travelMs: 650,
		description: "A marked moss patch protects allies inside its landing zone."
	},
	nineLives: {
		...routine,
		name: "Nine-Lives Shelter",
		shape: "shelter",
		cooldownMs: 14e3,
		target: "team",
		ultimate: true,
		power: 0,
		heal: 55,
		shield: 65,
		cleanse: true,
		description: "Cleanse harmful effects, heal, then shield the whole team."
	},
	guardAttack: {
		...routine,
		name: "Button Cut",
		shape: "slash",
		melee: true,
		description: "A deliberate front-line cut."
	},
	flankerAttack: {
		...routine,
		name: "Sock Skip",
		shape: "slash",
		target: "rear",
		melee: true,
		description: "Leap toward the rear; taunt can redirect it."
	},
	rangerAttack: {
		...routine,
		name: "Needle Shot",
		shape: "arrow",
		target: "rear",
		travelMs: 550,
		description: "A narrow needle trail aimed at a rear cat."
	},
	healerAttack: {
		...routine,
		name: "Teacup Mend",
		shape: "mend",
		target: "injured",
		power: 0,
		heal: 85,
		retarget: true,
		description: "Mend the most injured living enemy."
	},
	chargerAttack: {
		...routine,
		name: "Spool Charge",
		shape: "charge",
		windupMs: 1200,
		travelMs: 250,
		power: 1.5,
		heavy: true,
		melee: true,
		description: "A striped danger lane precedes a heavy charge."
	},
	eliteAttack: {
		...routine,
		name: "Kettle Crush",
		shape: "bash",
		windupMs: 1e3,
		travelMs: 250,
		power: 1.4,
		heavy: true,
		melee: true,
		description: "A heavy lid slam; interrupt before release."
	},
	yarnAttack: {
		...routine,
		name: "Spindle Sweep",
		shape: "sweep",
		windupMs: 1400,
		travelMs: 200,
		power: 1.35,
		heavy: true,
		description: "Sweep the striped lane. Guard its occupants."
	},
	crossSweep: {
		...routine,
		name: "Cross Stitch",
		shape: "cross",
		windupMs: 1500,
		travelMs: 200,
		power: 1.1,
		heavy: true,
		target: "rear",
		description: "Phase two: two crossing lanes strike both rows."
	},
	bindThread: {
		...routine,
		name: "Loose End",
		shape: "thread",
		windupMs: 1e3,
		travelMs: 350,
		power: .3,
		target: "rear",
		heavy: true,
		description: "Bind one ally; destroy the thread to free them and expose the knot."
	},
	threadAttack: {
		...routine,
		name: "Tighten",
		shape: "thread",
		power: .5,
		description: "A thread tightens around its captive."
	},
	dummyAttack: {
		...routine,
		name: "Cushion Nudge",
		shape: "bash",
		power: 0,
		description: "A harmless practice tell."
	}
};
// packages/game-rules/src/squad/turn/config.ts
/** Independent local turn tuning. No real-time numbers or production rewards are changed. */
var TURN_CONFIG = {
	version: 3,
	defaultSeed: 11,
	maxTurns: 650,
	preview: 24,
	initiative: {
		maxMove: 8,
		minRank: 1,
		maxRank: 12
	},
	defenseScale: 80,
	minDamage: 1,
	variance: .08,
	critMultiplier: 1.5,
	caps: {
		crit: .4,
		guard: .5,
		shieldFraction: .6,
		burn: 3
	},
	guardFraction: .3,
	shieldRounds: 2,
	burnDamage: 12,
	charge: {
		max: 100,
		initial: 15,
		action: 16,
		received: 7
	},
	passive: {
		cooldown: 2,
		guardianShield: 30,
		witchCharge: 12,
		alchemistShield: 30,
		injuredFraction: .65
	},
	control: {
		normalRounds: 1,
		bossRounds: 1,
		recoveryRounds: 1,
		bossRecoveryRounds: 2,
		delay: 2,
		bossDelay: 1
	},
	policy: {
		healThreshold: .78,
		urgentHeal: .45,
		guardThreshold: .7,
		shelterThreshold: .72,
		priority: {
			thread: 100,
			healer: 75,
			charger: 55,
			elite: 45,
			ranger: 40,
			flanker: 30,
			guard: 20,
			yarn: 10,
			dummy: 0
		},
		activePriority: {
			thread: 140,
			healer: 90,
			charger: 65,
			elite: 55,
			ranger: 45,
			flanker: 35,
			guard: 20,
			yarn: 15,
			dummy: 0
		},
		woundedBonus: 20,
		killBonus: 100,
		exposedBonus: 85,
		threatBonus: 50,
		lootTwo: 20,
		lootThree: 45,
		lootRole: {
			guardian: .65,
			witch: 2.2,
			alchemist: 1.2
		},
		active: {
			roleWeight: 0,
			interruption: .7,
			bossInterruption: 0,
			rescue: 0,
			shield: 0,
			taunt: 0,
			consumedReserve: 65
		}
	},
	boss: {
		standalone: {
			hp: 3400,
			attack: 220
		},
		phaseFraction: .5,
		enrageRounds: 15,
		enrageMultiplier: 1.7,
		enrageGrowth: .12,
		breakMax: 100,
		bashBreak: 30,
		ordinaryBreak: 7,
		guardedBreak: 12,
		exposedRounds: 2,
		exposedMultiplier: 1.6,
		bindRounds: 3,
		addsEvery: 4,
		addsPerWave: 2,
		maxEnemies: 8,
		threadSlot: 7,
		addSlots: [
			2,
			3,
			1,
			4,
			5,
			6
		],
		cycleOne: ["yarnAttack", "bindThread"],
		cycleTwo: [
			"yarnAttack",
			"bindThread",
			"crossSweep"
		]
	},
	equipment: {
		statScale: 1,
		maxCooldownReduction: 1,
		minUltimateCost: 70,
		costReduction: 15,
		chainPower: .5,
		neighborShield: 24,
		afterheal: 20,
		extraBurnRounds: 1,
		renew: 18,
		extraBreak: 15,
		vampiric: 12,
		actionCharge: 6,
		thorns: 10,
		maxStatusChance: .35,
		sets: {
			hearthDefense: 5,
			hearthShield: .12,
			moonAttack: 6,
			moonCrit: .03,
			mossHealing: .15,
			mossHp: 25
		}
	},
	consumables: {
		counts: {
			healTonic: 2,
			shieldBiscuit: 2,
			quickenYarn: 2,
			cleanseTea: 2,
			ultimateTreat: 1
		},
		tonic: 150,
		biscuit: 80,
		quickenSteps: 2,
		tea: 40,
		treat: 40
	},
	localFish: {
		wave: 9,
		boss: 15
	},
	presets: {
		hearthkeepers: {
			name: "Hearthkeepers",
			hp: 1.12,
			attack: 1.04,
			healing: 1.12,
			shield: 1.15,
			initiative: 0
		},
		lanternbreakers: {
			name: "Lanternbreakers",
			hp: .95,
			attack: 1.04,
			healing: 1,
			shield: 1,
			initiative: 1
		}
	},
	stats: {
		guardian: {
			hp: 610,
			attack: 52,
			defense: 42,
			initiative: 8,
			crit: .08
		},
		witch: {
			hp: 340,
			attack: 65,
			defense: 14,
			initiative: 6,
			crit: .12
		},
		alchemist: {
			hp: 380,
			attack: 38,
			defense: 22,
			initiative: 4,
			crit: .05
		},
		guard: {
			hp: 245,
			attack: 64,
			defense: 32,
			initiative: 5,
			crit: .04
		},
		flanker: {
			hp: 145,
			attack: 40,
			defense: 5,
			initiative: 7,
			crit: .08
		},
		ranger: {
			hp: 175,
			attack: 60,
			defense: 8,
			initiative: 5,
			crit: .05
		},
		healer: {
			hp: 230,
			attack: 12,
			defense: 12,
			initiative: 3,
			crit: 0
		},
		charger: {
			hp: 245,
			attack: 100,
			defense: 20,
			initiative: 2,
			crit: .05
		},
		elite: {
			hp: 380,
			attack: 98,
			defense: 50,
			initiative: 3,
			crit: .08
		},
		yarn: {
			hp: 4e3,
			attack: 245,
			defense: 28,
			initiative: 6,
			crit: 0
		},
		thread: {
			hp: 85,
			attack: 18,
			defense: 0,
			initiative: 5,
			crit: 0
		},
		dummy: {
			hp: 1200,
			attack: 0,
			defense: 16,
			initiative: 1,
			crit: 0
		}
	},
	waves: SQUAD_CONFIG.waves,
	trainingRoles: [
		"guard",
		"flanker",
		"charger",
		"ranger",
		"healer",
		"elite"
	]
};
var skill = (id, target, values = {}) => ({
	id,
	name: ABILITIES[id].name,
	description: ABILITIES[id].description,
	target,
	power: 1,
	cooldown: 0,
	chargeCost: 0,
	icon: ABILITIES[id].shape,
	...values
});
/** Three basics and nine activated hero skills; enemy identities match the comparison engine. */
var TURN_SKILLS = {
	healTonic: {
		id: "healTonic",
		name: "Warm Milk Tonic",
		description: `Restore ${TURN_CONFIG.consumables.tonic} HP. Uses this cat's action.`,
		target: "ally",
		power: 0,
		cooldown: 0,
		chargeCost: 0,
		heal: TURN_CONFIG.consumables.tonic,
		icon: "flask",
		consumable: true
	},
	shieldBiscuit: {
		id: "shieldBiscuit",
		name: "Shield Biscuit",
		description: `Grant ${TURN_CONFIG.consumables.biscuit} shield for 2 rounds. Uses an action.`,
		target: "ally",
		power: 0,
		cooldown: 0,
		chargeCost: 0,
		shield: TURN_CONFIG.consumables.biscuit,
		icon: "wall",
		consumable: true
	},
	quickenYarn: {
		id: "quickenYarn",
		name: "Quicken Yarn",
		description: `Move a pending ally ${TURN_CONFIG.consumables.quickenSteps} places earlier this round; once per recipient per round.`,
		target: "ally",
		power: 0,
		cooldown: 0,
		chargeCost: 0,
		orderSteps: TURN_CONFIG.consumables.quickenSteps,
		icon: "snare",
		consumable: true
	},
	cleanseTea: {
		id: "cleanseTea",
		name: "Clearleaf Tea",
		description: `Cleanse harmful effects and restore ${TURN_CONFIG.consumables.tea} HP. Uses an action.`,
		target: "ally",
		power: 0,
		cooldown: 0,
		chargeCost: 0,
		heal: TURN_CONFIG.consumables.tea,
		cleanse: true,
		icon: "moss",
		consumable: true
	},
	ultimateTreat: {
		id: "ultimateTreat",
		name: "Starlight Treat",
		description: `Grant ${TURN_CONFIG.consumables.treat} ultimate charge. Uses an action.`,
		target: "ally",
		power: 0,
		cooldown: 0,
		chargeCost: 0,
		chargeGrant: TURN_CONFIG.consumables.treat,
		icon: "spark",
		consumable: true
	},
	guardianBasic: skill("guardianBasic", "enemy", { melee: true }),
	witchBasic: skill("witchBasic", "enemy"),
	alchemistBasic: skill("alchemistBasic", "enemy"),
	shieldBash: skill("shieldBash", "enemy", {
		power: 1.35,
		cooldown: 2,
		status: "stun",
		duration: 1,
		delay: 2,
		melee: true,
		description: "Interrupt one committed intent and push it back by two positions. Control resistance prevents repeated locks."
	}),
	rally: skill("rally", "self", {
		power: 0,
		cooldown: 3,
		shield: 45,
		status: "guard",
		duration: 2,
		description: "Guard and shield Mochi for two rounds; taunt all hostile single-target intents."
	}),
	hearthwall: skill("hearthwall", "allAllies", {
		power: 0,
		cooldown: 3,
		chargeCost: 100,
		shield: 95,
		status: "guard",
		duration: 2
	}),
	threadSnare: skill("threadSnare", "row", {
		power: .55,
		cooldown: 3,
		status: "snare",
		duration: 1,
		delay: 2,
		description: "Damage and delay every living foe in the chosen row. Does not cancel their actions."
	}),
	emberOrb: skill("emberOrb", "row", {
		power: 1.75,
		cooldown: 2,
		status: "burn",
		duration: 2,
		description: "Burst across the chosen row and burn it for two rounds."
	}),
	lanternstorm: skill("lanternstorm", "allEnemies", {
		power: .9,
		cooldown: 3,
		chargeCost: 100,
		hits: 3
	}),
	milkFlask: skill("milkFlask", "ally", {
		power: 0,
		cooldown: 1,
		heal: 140
	}),
	mossFlask: skill("mossFlask", "allAllies", {
		power: 0,
		cooldown: 3,
		heal: 45,
		status: "guard",
		duration: 2
	}),
	nineLives: skill("nineLives", "allAllies", {
		power: 0,
		cooldown: 3,
		chargeCost: 100,
		heal: 95,
		shield: 90,
		cleanse: true
	}),
	guardAttack: skill("guardAttack", "enemy", { melee: true }),
	flankerAttack: skill("flankerAttack", "enemy", { melee: true }),
	rangerAttack: skill("rangerAttack", "enemy"),
	healerAttack: skill("healerAttack", "ally", {
		power: 0,
		heal: 80
	}),
	chargerAttack: skill("chargerAttack", "enemy", {
		power: 1.5,
		heavy: true,
		melee: true
	}),
	eliteAttack: skill("eliteAttack", "enemy", {
		power: 1.4,
		heavy: true,
		melee: true
	}),
	yarnAttack: skill("yarnAttack", "row", {
		power: 1.35,
		heavy: true
	}),
	crossSweep: skill("crossSweep", "allEnemies", {
		power: 1.1,
		heavy: true
	}),
	bindThread: skill("bindThread", "enemy", {
		power: .3,
		heavy: true
	}),
	threadAttack: skill("threadAttack", "enemy", { power: .5 }),
	dummyAttack: skill("dummyAttack", "enemy", { power: 0 })
};
var TURN_KITS = {
	guardian: [
		"guardianBasic",
		"shieldBash",
		"rally",
		"hearthwall"
	],
	witch: [
		"witchBasic",
		"threadSnare",
		"emberOrb",
		"lanternstorm"
	],
	alchemist: [
		"alchemistBasic",
		"milkFlask",
		"mossFlask",
		"nineLives"
	]
};
// packages/game-rules/src/cardrpg/config.ts
/** Independent sandbox tuning. Never imported by production CONFIG. */
var CARD_RPG_CONFIG = {
	rarity: {
		common: {
			name: "Common",
			color: "#A7B3BF",
			cap: 20,
			affixes: 0,
			salvage: 2,
			shards: 2
		},
		rare: {
			name: "Rare",
			color: "#63B6F1",
			cap: 30,
			affixes: 1,
			salvage: 5,
			shards: 5
		},
		epic: {
			name: "Epic",
			color: "#C493F5",
			cap: 40,
			affixes: 2,
			salvage: 12,
			shards: 12
		},
		legendary: {
			name: "Legendary",
			color: "#F4C66A",
			cap: 50,
			affixes: 3,
			salvage: 25,
			shards: 25
		}
	},
	odds: {
		common: 6e3,
		rare: 3e3,
		epic: 900,
		legendary: 100
	},
	gearOdds: {
		common: 5500,
		rare: 3400,
		epic: 1e3,
		legendary: 100
	},
	pity: {
		soft: 41,
		hard: 60,
		stepBp: 300,
		featuredBp: 5e3
	},
	cardTraits: {
		hearth: {
			shieldBp: 500,
			effectResistBp: 500
		},
		moon: {
			critBp: 200,
			effectHitBp: 500
		},
		garden: {
			healingBp: 500,
			hp: 15
		}
	},
	roleStats: {
		guardian: {
			hp: 540,
			defense: 34
		},
		witch: {
			hp: 415,
			defense: 22
		},
		alchemist: {
			hp: 350,
			defense: 20
		}
	},
	enemyAttackBp: 11800,
	formationHpBp: 10400,
	baseCritDamageBp: 5e3,
	gear: {
		mainBase: [
			12,
			45,
			6,
			25
		],
		mainPerTier: [
			4,
			12,
			2,
			8
		],
		defenseAffix: 2,
		critAffix: 100,
		critPerTier: 50,
		resistAffix: 300
	},
	sets: {
		hearthTwo: {
			defense: 5,
			shieldBp: 600
		},
		hearthFour: {
			hp: 30,
			shieldBp: 600
		},
		moonTwo: {
			attack: 6,
			critBp: 200
		},
		moonFour: {
			effectHitBp: 800,
			critDamageBp: 1e3
		},
		mossTwo: {
			healingBp: 600,
			hp: 15
		},
		mossFour: {
			healingBp: 600,
			effectResistBp: 1e3
		}
	},
	recipes: {
		gear: {
			fish: 180,
			threads: 30
		},
		epicGear: {
			fish: 120,
			threads: 180,
			essence: 5
		},
		pantryKey: { threads: 40 },
		pantry: { threads: 10 },
		ribbon: {
			essence: 10,
			threads: 20
		},
		epicDesign: {
			fish: 900,
			threads: 120,
			essence: 15
		},
		legendaryDesign: {
			fish: 2400,
			threads: 300,
			essence: 30
		},
		epicProof: 3,
		legendaryProof: 10
	},
	quests: {
		dailyBattles: {
			target: 2,
			reward: {
				currencies: {
					stamps: 100,
					fish: 100
				},
				xp: 40
			}
		},
		dailyService: {
			target: 1,
			reward: {
				currencies: {
					stamps: 100,
					threads: 10
				},
				xp: 40
			}
		},
		weeklyWins: {
			target: 3,
			reward: {
				currencies: {
					stamps: 300,
					essence: 5
				},
				xp: 100,
				stacks: { "pantry-key": 1 }
			}
		},
		boss: {
			target: 1,
			reward: {
				currencies: { essence: 15 },
				xp: 150
			}
		},
		mender: {
			target: 6,
			reward: {
				currencies: { stamps: 100 },
				xp: 100
			}
		}
	},
	supplies: {
		"milk-tonic": {
			skill: "healTonic",
			max: 2
		},
		"shield-biscuit": {
			skill: "shieldBiscuit",
			max: 2
		},
		"quicken-yarn": {
			skill: "quickenYarn",
			max: 2
		},
		"cleanse-tea": {
			skill: "cleanseTea",
			max: 2
		},
		"ultimate-treat": {
			skill: "ultimateTreat",
			max: 1
		}
	},
	drawCost: 150,
	maxBatch: 10,
	maxDrawsPerDay: 30,
	historyLimit: 200,
	starterBalances: {
		fish: 600,
		threads: 40,
		stamps: 600,
		essence: 0
	},
	dailyCaps: {
		fish: 420,
		threads: 90,
		stamps: 480,
		essence: 12
	},
	battle: {
		rewardedPerDay: 6,
		reward: {
			fish: 90,
			threads: 12,
			stamps: 40
		},
		xp: 60,
		lossXp: 20,
		firstClear: {
			fish: 200,
			stamps: 200
		},
		bossProof: 1
	},
	service: {
		minutesPerClaim: 10,
		maxClaims: 2,
		reward: {
			fish: 140,
			threads: 20,
			stamps: 70
		}
	},
	enhance: {
		max: 12,
		fishBase: 30,
		threadsBase: 3,
		growth: .06
	},
	reforge: {
		fish: 90,
		threads: 15
	},
	reforgeValues: {
		hp: 8,
		attack: 2,
		defense: 2,
		critBp: 100,
		effectHitBp: 100,
		effectResistBp: 100,
		healingBp: 100,
		shieldBp: 100
	},
	level: {
		fishBase: 25,
		threads: 2,
		statGrowth: .012,
		maxStars: 5,
		starGrowth: .025,
		shardsBase: 10,
		ascendFish: 150
	},
	shardExchange: {
		shards: 10,
		essence: 1
	},
	dailyXpCap: 180,
	accountXpStep: 200,
	accountLevelCap: 50,
	statCaps: {
		hp: 9999,
		attack: 999,
		defense: 300,
		critBp: 4e3,
		critDamageBp: 1e4,
		effectHitBp: 7500,
		effectResistBp: 6e3,
		healingBp: 6e3,
		shieldBp: 6e3,
		initiative: 12
	},
	combat: {
		defenseScale: 80,
		varianceBp: 800,
		baseEffectBp: 9500,
		enemyResistBp: 1e3,
		minEffectBp: 1500,
		maxEffectBp: 9500
	},
	scarcity: {
		epic: {
			global: 2400,
			season: 400
		},
		legendary: {
			global: 360,
			season: 60
		}
	}
};
// packages/game-rules/src/cardrpg/contract.ts
/** Renderer-independent, local-only contract. All amounts are integer points or basis points. */
var CONTRACT_VERSION$1 = "0.4.0";
var RARITY_ORDER = [
	"common",
	"rare",
	"epic",
	"legendary"
];
var EQUIPMENT_SLOTS = [
	"weapon",
	"outfit",
	"charm",
	"relic"
];
var CURRENCY_IDS = [
	"fish",
	"threads",
	"stamps",
	"essence"
];
var CHAIN_NOTICE = "Design only, not minted";
var CARDS = [
	[
		"mochi",
		"Mochi",
		"common",
		"guardian",
		"hearth",
		"The cafe door never closes on a cold traveler."
	],
	[
		"soot",
		"Soot",
		"common",
		"witch",
		"moon",
		"A lantern keeper who reads tomorrow in spilled cocoa."
	],
	[
		"clover",
		"Clover",
		"common",
		"alchemist",
		"garden",
		"Every chipped cup deserves a second steep."
	],
	[
		"panko",
		"Panko",
		"rare",
		"guardian",
		"garden",
		"A patient baker who shelters seedlings beneath a bread pan."
	],
	[
		"mallow",
		"Mallow",
		"rare",
		"witch",
		"hearth",
		"Small sparks rise from a whisk full of impossible wishes."
	],
	[
		"sorrel",
		"Sorrel",
		"rare",
		"alchemist",
		"moon",
		"A midnight brewer measuring moonlight by the teaspoon."
	],
	[
		"biscuit",
		"Biscuit",
		"epic",
		"guardian",
		"hearth",
		"The oldest recipe in the cafe is standing together."
	],
	[
		"inkcap",
		"Inkcap",
		"epic",
		"witch",
		"garden",
		"Mushroom ink sketches a safe path through the thicket."
	],
	[
		"cinnamon",
		"Cinnamon",
		"epic",
		"alchemist",
		"hearth",
		"A warm kitchen is medicine before the first sip."
	],
	[
		"brioche",
		"Brioche",
		"legendary",
		"guardian",
		"moon",
		"Keeps the night shift beneath an apron embroidered with stars."
	],
	[
		"velvet",
		"Velvet",
		"legendary",
		"witch",
		"moon",
		"Collects lost lantern flames and returns them to the sky."
	],
	[
		"marigold",
		"Marigold",
		"legendary",
		"alchemist",
		"garden",
		"Tends the first tea plant, one careful leaf at a time."
	]
].map(([id, name, rarity, role, flavour, lore]) => {
	const s = TURN_CONFIG.stats[role];
	const baseStats = {
		hp: CARD_RPG_CONFIG.roleStats[role].hp,
		attack: s.attack,
		defense: CARD_RPG_CONFIG.roleStats[role].defense,
		critBp: Math.round(s.crit * 1e4),
		critDamageBp: CARD_RPG_CONFIG.baseCritDamageBp,
		effectHitBp: 0,
		effectResistBp: 0,
		healingBp: 0,
		shieldBp: 0,
		initiative: s.initiative
	};
	if (id !== "mochi" && id !== "soot" && id !== "clover") for (const [stat, value] of Object.entries(CARD_RPG_CONFIG.cardTraits[flavour])) baseStats[stat] += value;
	return {
		id,
		name,
		rarity,
		role,
		flavour,
		lore,
		baseStats,
		levelCap: CARD_RPG_CONFIG.rarity[rarity].cap,
		skills: TURN_KITS[role].map((skillId) => {
			const s = TURN_SKILLS[skillId];
			return {
				id: s.id,
				name: s.name,
				description: s.description.replaceAll("Mochi", name),
				cooldownRounds: s.cooldown,
				chargeCost: s.chargeCost,
				powerBp: Math.round(s.power * 1e4),
				target: s.target
			};
		}),
		passive: {
			id: `${id}-hospitality`,
			name: `${name}'s Hospitality`,
			description: role === "guardian" ? "A trained guard shelters allies; flavour traits are included in base stats." : role === "witch" ? "A trained caster gathers charge; flavour traits are included in base stats." : "A trained brewer shields an injured patient; flavour traits are included in base stats."
		}
	};
});
var CARD_BY_ID = Object.fromEntries(CARDS.map((c) => [c.id, c]));
var SET_BONUSES = [
	{
		id: "hearthloom",
		name: "Hearthloom",
		pieces: 2,
		stats: { ...CARD_RPG_CONFIG.sets.hearthTwo },
		description: "+5 DEF, +6% shielding."
	},
	{
		id: "hearthloom",
		name: "Hearthloom",
		pieces: 4,
		stats: { ...CARD_RPG_CONFIG.sets.hearthFour },
		description: "+30 HP, another +6% shielding."
	},
	{
		id: "moonwick",
		name: "Moonwick",
		pieces: 2,
		stats: { ...CARD_RPG_CONFIG.sets.moonTwo },
		description: "+6 ATK, +2% critical chance."
	},
	{
		id: "moonwick",
		name: "Moonwick",
		pieces: 4,
		stats: { ...CARD_RPG_CONFIG.sets.moonFour },
		description: "+8% effect hit, +10% critical bonus damage."
	},
	{
		id: "mossbrew",
		name: "Mossbrew",
		pieces: 2,
		stats: { ...CARD_RPG_CONFIG.sets.mossTwo },
		description: "+6% healing, +15 HP."
	},
	{
		id: "mossbrew",
		name: "Mossbrew",
		pieces: 4,
		stats: { ...CARD_RPG_CONFIG.sets.mossFour },
		description: "Another +6% healing, +10% effect resistance."
	}
];
var ITEMS = [
	"hearthloom",
	"moonwick",
	"mossbrew"
].flatMap((setId, si) => RARITY_ORDER.flatMap((rarity, ri) => EQUIPMENT_SLOTS.map((slot, sl) => {
	const role = [
		"guardian",
		"witch",
		"alchemist"
	][si];
	const name = {
		weapon: [
			"Pan",
			"Needle",
			"Kettle"
		],
		outfit: [
			"Apron",
			"Shawl",
			"Vest"
		],
		charm: [
			"Bell",
			"Button",
			"Leaf"
		],
		relic: [
			"Cup",
			"Wick",
			"Snowdrop"
		]
	}[slot][si];
	const mainStat = [
		"attack",
		"hp",
		"defense",
		"hp"
	][sl];
	const mainValue = CARD_RPG_CONFIG.gear.mainBase[sl] + ri * CARD_RPG_CONFIG.gear.mainPerTier[sl];
	const pools = [
		{
			stat: "defense",
			value: CARD_RPG_CONFIG.gear.defenseAffix + ri,
			tier: 1
		},
		{
			stat: "critBp",
			value: CARD_RPG_CONFIG.gear.critAffix + ri * CARD_RPG_CONFIG.gear.critPerTier,
			tier: 2
		},
		{
			stat: "effectResistBp",
			value: CARD_RPG_CONFIG.gear.resistAffix,
			tier: 3
		}
	];
	return {
		id: `${setId}-${slot}-${rarity}`,
		name: `${CARD_RPG_CONFIG.rarity[rarity].name} ${SET_BONUSES[si * 2].name} ${name}`,
		kind: "equipment",
		rarity,
		slot,
		fit: slot === "weapon" ? [role] : [
			"guardian",
			"witch",
			"alchemist"
		],
		main: {
			stat: mainStat,
			value: mainValue,
			tier: 1
		},
		affixes: pools.slice(0, CARD_RPG_CONFIG.rarity[rarity].affixes),
		setId,
		...rarity === "legendary" ? { uniqueEffect: [
			"neighborShield",
			"efficient",
			"renew"
		][si] } : {},
		description: rarity === "legendary" ? [
			"Shelter the next ally when guarding.",
			"Ultimate skills cost 15 less charge (minimum 70).",
			"Healing skills restore 18 extra HP."
		][si] : "A cafe-made piece with a predictable enhancement path."
	};
})));
var ITEM_BY_ID$1 = Object.fromEntries(ITEMS.map((i) => [i.id, i]));
var BANNERS = [
	{
		id: "standard",
		name: "Cafe Guestbook",
		kind: "cat",
		cost: { stamps: CARD_RPG_CONFIG.drawCost },
		oddsBp: CARD_RPG_CONFIG.odds,
		softPity: CARD_RPG_CONFIG.pity.soft,
		hardPity: CARD_RPG_CONFIG.pity.hard,
		softStepBp: CARD_RPG_CONFIG.pity.stepBp,
		featuredRateBp: 0,
		pityGroup: "cats-standard",
		description: "Earned stamps only. Unowned cats preferred within the rolled rarity."
	},
	{
		id: "featured",
		name: "Marigold at Closing Time",
		kind: "cat",
		cost: { stamps: CARD_RPG_CONFIG.drawCost },
		oddsBp: CARD_RPG_CONFIG.odds,
		softPity: CARD_RPG_CONFIG.pity.soft,
		hardPity: CARD_RPG_CONFIG.pity.hard,
		softStepBp: CARD_RPG_CONFIG.pity.stepBp,
		featuredCardId: "marigold",
		featuredRateBp: CARD_RPG_CONFIG.pity.featuredBp,
		pityGroup: "cats-featured",
		description: "Legendary: 50% Marigold; after a miss the next legendary is Marigold. Pity carries within this group."
	},
	{
		id: "equipment",
		name: "Mending Basket",
		kind: "equipment",
		cost: { stamps: CARD_RPG_CONFIG.drawCost },
		oddsBp: CARD_RPG_CONFIG.gearOdds,
		softPity: CARD_RPG_CONFIG.pity.soft,
		hardPity: CARD_RPG_CONFIG.pity.hard,
		softStepBp: CARD_RPG_CONFIG.pity.stepBp,
		featuredRateBp: 0,
		pityGroup: "gear",
		description: "Soulbound gear only. Missing templates preferred within rolled rarity."
	}
];
var STACK_ITEMS = [
	{
		id: "boss-proof",
		name: "Yarnkeeper Seal",
		kind: "material",
		rarity: "epic",
		source: "First rewarded boss clear of a local day",
		sink: "Deterministic Relic design recipes",
		description: "Earned effort evidence; never sold or drawn."
	},
	{
		id: "milk-tonic",
		name: "Warm Milk Tonic",
		kind: "consumable",
		rarity: "common",
		source: "Pantry recipe",
		sink: "One battle action",
		description: "Restore 150 HP; finite battle supplies."
	},
	...[
		[
			"shield-biscuit",
			"Shield Biscuit",
			"shieldBiscuit"
		],
		[
			"quicken-yarn",
			"Quicken Yarn",
			"quickenYarn"
		],
		[
			"cleanse-tea",
			"Clearleaf Tea",
			"cleanseTea"
		],
		[
			"ultimate-treat",
			"Starlight Treat",
			"ultimateTreat"
		]
	].map(([id, name, skill]) => ({
		id,
		name,
		kind: "consumable",
		rarity: "rare",
		source: "Pantry recipe",
		sink: "One battle action",
		description: TURN_SKILLS[skill].description
	})),
	{
		id: "pantry-key",
		name: "Pantry Key",
		kind: "key",
		rarity: "rare",
		source: "Weekly quest or deterministic thread mending",
		sink: "Pantry refill recipe",
		description: "One key becomes one tonic; never an NFT."
	},
	{
		id: "cafe-ribbon",
		name: "Cafe Ribbon",
		kind: "cosmetic",
		rarity: "epic",
		source: "Deterministic essence recipe",
		sink: "Permanent local collection unlock",
		description: "A collection badge with no battle stats."
	}
];
var QUESTS = [
	{
		id: "daily-patrol",
		name: "A Table for Three",
		description: "Complete two battles.",
		cadence: "daily",
		metric: "battles",
		...CARD_RPG_CONFIG.quests.dailyBattles
	},
	{
		id: "daily-service",
		name: "Warm the Kettle",
		description: "Complete one ten-minute local cafe service.",
		cadence: "daily",
		metric: "service",
		...CARD_RPG_CONFIG.quests.dailyService
	},
	{
		id: "weekly-wins",
		name: "Seven Good Evenings",
		description: "Win three battles in this local week.",
		cadence: "weekly",
		metric: "wins",
		...CARD_RPG_CONFIG.quests.weeklyWins
	},
	{
		id: "first-boss",
		name: "Untangle the Giant",
		description: "Win a campaign.",
		cadence: "achievement",
		metric: "bossWins",
		...CARD_RPG_CONFIG.quests.boss
	},
	{
		id: "mender",
		name: "A Stitch Remembered",
		description: "Enhance equipment six times.",
		cadence: "achievement",
		metric: "enhances",
		...CARD_RPG_CONFIG.quests.mender
	}
];
var RECIPES = [
	...[
		"hearthloom",
		"moonwick",
		"mossbrew"
	].flatMap((set) => EQUIPMENT_SLOTS.map((slot) => ({
		id: `sew-${set}-${slot}`,
		name: `Sew ${set} ${slot}`,
		outputItemId: `${set}-${slot}-rare`,
		cost: CARD_RPG_CONFIG.recipes.gear,
		materials: {},
		requiredChapter: 1,
		description: "Choose a guaranteed rare piece. Completing a set never needs a lucky draw."
	}))),
	...[
		"hearthloom",
		"moonwick",
		"mossbrew"
	].flatMap((set) => EQUIPMENT_SLOTS.map((slot) => ({
		id: `tailor-${set}-${slot}`,
		name: `Tailor ${set} ${slot}`,
		outputItemId: `${set}-${slot}-epic`,
		cost: CARD_RPG_CONFIG.recipes.epicGear,
		materials: {},
		requiredChapter: 2,
		description: "Choose an epic piece using earned essence and spare threads. No random affix roll."
	}))),
	{
		id: "mend-pantry-key",
		name: "Mend Pantry Key",
		outputStackId: "pantry-key",
		cost: CARD_RPG_CONFIG.recipes.pantryKey,
		materials: {},
		requiredChapter: 1,
		description: "Forty spare threads become one pantry key for a chosen finite supply."
	},
	{
		id: "pantry-tonic",
		name: "Brew Warm Milk",
		outputStackId: "milk-tonic",
		cost: CARD_RPG_CONFIG.recipes.pantry,
		materials: { "pantry-key": 1 },
		requiredChapter: 1,
		description: "One key, one finite battle tonic."
	},
	...[
		"shield-biscuit",
		"quicken-yarn",
		"cleanse-tea",
		"ultimate-treat"
	].map((id) => ({
		id: `pantry-${id}`,
		name: `Prepare ${id}`,
		outputStackId: id,
		cost: CARD_RPG_CONFIG.recipes.pantry,
		materials: { "pantry-key": 1 },
		requiredChapter: 1,
		description: "One pantry key becomes one finite battle supply."
	})),
	{
		id: "cafe-ribbon",
		name: "Weave Cafe Ribbon",
		outputStackId: "cafe-ribbon",
		cost: CARD_RPG_CONFIG.recipes.ribbon,
		materials: {},
		requiredChapter: 1,
		description: "One cosmetic collection badge; duplicates rejected."
	},
	{
		id: "design-moon-collar",
		name: "Moon Collar Design",
		cost: CARD_RPG_CONFIG.recipes.epicDesign,
		materials: { "boss-proof": CARD_RPG_CONFIG.recipes.epicProof },
		requiredChapter: 2,
		scarcityId: "moon-collar",
		description: "Three rewarded boss days; local capped eligibility only. Design only, not minted."
	},
	{
		id: "design-golden-maneki",
		name: "Golden Maneki Design",
		cost: CARD_RPG_CONFIG.recipes.legendaryDesign,
		materials: { "boss-proof": CARD_RPG_CONFIG.recipes.legendaryProof },
		requiredChapter: 2,
		scarcityId: "golden-maneki",
		description: "Ten rewarded boss days; local capped eligibility only. Design only, not minted."
	}
];
var SCARCITY = [{
	id: "moon-collar",
	name: "Moon Collar",
	rarity: "epic",
	relicId: 3,
	rarityIndex: 2,
	globalCap: CARD_RPG_CONFIG.scarcity.epic.global,
	seasonCap: CARD_RPG_CONFIG.scarcity.epic.season,
	issuedDesign: 0,
	seasonIssuedDesign: 0,
	mintedSoFar: 0,
	soulbound: true,
	futureTradeable: true,
	chainId: 43113,
	status: CHAIN_NOTICE,
	path: "Three rewarded boss days + deterministic forge; one eligibility per account per season."
}, {
	id: "golden-maneki",
	name: "Golden Maneki",
	rarity: "legendary",
	relicId: 4,
	rarityIndex: 3,
	globalCap: CARD_RPG_CONFIG.scarcity.legendary.global,
	seasonCap: CARD_RPG_CONFIG.scarcity.legendary.season,
	issuedDesign: 0,
	seasonIssuedDesign: 0,
	mintedSoFar: 0,
	soulbound: true,
	futureTradeable: true,
	chainId: 43113,
	status: CHAIN_NOTICE,
	path: "Ten rewarded boss days + deterministic forge; one eligibility per account per season."
}];
[
	[
		"button-guard",
		"Button Guard",
		"guard",
		"Front guard; interrupt the heavy hit."
	],
	[
		"sock-skipper",
		"Sock Skipper",
		"flanker",
		"Rear hunter; guard the wounded cat."
	],
	[
		"spool-ram",
		"Spool Ram",
		"charger",
		"Charged attack; break its intent."
	],
	[
		"needle-moth",
		"Needle Moth",
		"ranger",
		"Rear volley; shield before impact."
	],
	[
		"teacup-healer",
		"Teacup Healer",
		"healer",
		"Heal the weakest foe; focus it first."
	],
	[
		"kettle-knight",
		"Kettle Knight",
		"elite",
		"Heavy armor; coordinate burst."
	],
	[
		"yarn-giant",
		"Yarn Giant",
		"yarn",
		"Row sweep and binds; rescue and interrupt."
	],
	[
		"binding-thread",
		"Binding Thread",
		"thread",
		"Restrains an ally; destroy the thread."
	],
	[
		"practice-cushion",
		"Practice Cushion",
		"dummy",
		"Training target; test a build."
	],
	[
		"pollen-scout",
		"Pollen Scout",
		"ranger",
		"Design: telegraphed garden volley."
	],
	[
		"rain-spool",
		"Rain Spool",
		"charger",
		"Design: cleanse a soaked row."
	],
	[
		"crumb-sentinel",
		"Crumb Sentinel",
		"guard",
		"Design: swap focus when it braces."
	],
	[
		"pantry-crown",
		"Pantry Crown",
		"yarn",
		"Design: alternate row pressure."
	]
].map(([id, name, role, intent], index) => ({
	id,
	name,
	role,
	chapter: index < 9 ? 1 : index < 11 ? 2 : 3,
	stats: { ...TURN_CONFIG.stats[role] },
	intent,
	counter: intent.split(";")[1]?.trim() ?? "Read the committed intent before choosing.",
	implemented: index < 9
}));
// packages/game-rules/src/cardrpg/internal.ts
var clone = (value) => JSON.parse(JSON.stringify(value));
var RuleFailure = class extends Error {
	code;
	constructor(code, message) {
		super(message);
		this.code = code;
	}
};
function requireRule(condition, code, message) {
	if (!condition) throw new RuleFailure(code, message);
}
function integer$1(n, min = 0, max = Number.MAX_SAFE_INTEGER) {
	return Number.isSafeInteger(n) && n >= min && n <= max;
}
function noBattle(s) {
	requireRule(!s.pendingRun, "BATTLE_PENDING", "Finish or abandon the current battle first.");
}
function transact(state, fn) {
	const s = clone(state), events = [];
	try {
		return {
			ok: true,
			state: s,
			events,
			value: fn(s, events)
		};
	} catch (e) {
		if (!(e instanceof RuleFailure)) throw e;
		return {
			ok: false,
			state,
			events: [],
			error: {
				code: e.code,
				message: e.message
			}
		};
	}
}
function preview(fn) {
	try {
		return {
			ok: true,
			value: fn()
		};
	} catch (e) {
		if (!(e instanceof RuleFailure)) throw e;
		return {
			ok: false,
			error: {
				code: e.code,
				message: e.message
			}
		};
	}
}
function afford(s, cost) {
	for (const key of CURRENCY_IDS) {
		const n = cost[key] ?? 0;
		requireRule(integer$1(n), "INVALID_AMOUNT", "Costs must be nonnegative integer points.");
		requireRule(s.currencies[key] >= n, "INSUFFICIENT_FUNDS", `Need ${n} ${key}.`);
	}
}
function spend(s, cost) {
	afford(s, cost);
	for (const key of CURRENCY_IDS) s.currencies[key] -= cost[key] ?? 0;
}
function progress(s, metric, amount = 1) {
	for (const q of QUESTS.filter((q) => q.metric === metric)) {
		const p = s.quests[q.id];
		p.progress = Math.min(q.target, p.progress + amount);
	}
}
function grant(s, reward, capped = true, events = []) {
	const actual = {
		currencies: {},
		xp: reward.xp,
		...reward.stacks ? { stacks: { ...reward.stacks } } : {}
	};
	for (const key of CURRENCY_IDS) {
		const n = reward.currencies[key] ?? 0;
		requireRule(integer$1(n), "INVALID_AMOUNT", "Rewards must be nonnegative integer points.");
		const value = capped ? Math.min(n, Math.max(0, CARD_RPG_CONFIG.dailyCaps[key] - s.daily.earned[key])) : n;
		if (value) {
			s.currencies[key] += value;
			actual.currencies[key] = value;
			if (capped) s.daily.earned[key] += value;
		}
	}
	requireRule(integer$1(reward.xp), "INVALID_AMOUNT", "XP must be a nonnegative integer.");
	const xp = capped ? Math.min(reward.xp, Math.max(0, CARD_RPG_CONFIG.dailyXpCap - (s.daily.xpEarned ?? 0))) : reward.xp;
	actual.xp = xp;
	if (capped) s.daily.xpEarned = (s.daily.xpEarned ?? 0) + xp;
	s.accountXp = Math.min(CARD_RPG_CONFIG.accountXpStep * (CARD_RPG_CONFIG.accountLevelCap - 1), s.accountXp + xp);
	const level = Math.min(CARD_RPG_CONFIG.accountLevelCap, 1 + Math.floor(s.accountXp / CARD_RPG_CONFIG.accountXpStep));
	if (level > s.accountLevel) events.push({
		type: "levelUp",
		level
	});
	s.accountLevel = level;
	for (const [id, amount] of Object.entries(reward.stacks ?? {})) {
		requireRule(integer$1(amount), "INVALID_AMOUNT", "Stack count must be an integer.");
		s.inventory.stacks[id] = (s.inventory.stacks[id] ?? 0) + amount;
	}
	return actual;
}
// packages/game-rules/src/cardrpg/depth/skills-v5/statuses.ts
/** Core vocabulary is mode-specific; historical catalogue entries remain unchanged. */
var CORE_STATUS_RULES_V5 = [
	{
		id: "scald",
		name: "Burn",
		kind: "debuff",
		cap: 5,
		duration: 3,
		dispellable: true,
		tick: "damage",
		strength: 12,
		description: "Lose 12 HP per stack at round end, through shields."
	},
	{
		id: "snag",
		name: "Bleed",
		kind: "debuff",
		cap: 5,
		duration: 3,
		dispellable: true,
		tick: "none",
		strength: 8,
		description: "Lose 8 HP per stack before your action. Shields absorb it."
	},
	{
		id: "bitter",
		name: "Bitter",
		kind: "debuff",
		cap: 1,
		duration: 2,
		dispellable: true,
		tick: "none",
		strength: 50,
		description: "Receive half as much healing and shielding."
	},
	{
		id: "scent",
		name: "Mark",
		kind: "debuff",
		cap: 1,
		duration: 2,
		dispellable: true,
		tick: "none",
		strength: 20,
		description: "Take 20% more direct damage and become reachable through the front row."
	},
	{
		id: "brittle",
		name: "Shred",
		kind: "debuff",
		cap: 3,
		duration: 2,
		dispellable: true,
		tick: "none",
		strength: 8,
		description: "Lose 8% defense and 15 shield per direct hit, per stack."
	},
	{
		id: "drowsy",
		name: "Daze",
		kind: "debuff",
		cap: 1,
		duration: 1,
		dispellable: true,
		tick: "none",
		strength: 50,
		description: "Your next action becomes a half-power basic. Bosses only lose a signature."
	},
	{
		id: "steep",
		name: "Regen",
		kind: "buff",
		cap: 3,
		duration: 3,
		dispellable: true,
		tick: "heal",
		strength: 18,
		description: "Heal 18 HP per stack at round end and remove one Burn stack."
	},
	{
		id: "cozy",
		name: "Warm",
		kind: "buff",
		cap: 3,
		duration: 2,
		dispellable: true,
		tick: "none",
		strength: 10,
		description: "Take 10% less direct damage per stack. Burn ignores Warm."
	}
];
var NEW_STATUS_RULES_V5 = CORE_STATUS_RULES_V5.filter((s) => s.id === "snag" || s.id === "bitter");
var core = Object.fromEntries(CORE_STATUS_RULES_V5.map((s) => [s.id, s]));
var STATUS_SUBTITLES_V5 = {
	scald: "Scald",
	snag: "Snag",
	bitter: "Bitter tea",
	scent: "Scented",
	brittle: "Brittle sugar",
	drowsy: "Drowsy",
	steep: "Steep",
	cozy: "Cozy"
};
function statusIdV5(id) {
	return id === "tangle" ? "brittle" : id === "hush" || id === "rattled" ? "drowsy" : id;
}
function statusRuleV5(id, fallback) {
	return core[statusIdV5(id)] ?? fallback;
}
var count$2 = (a, id) => a.statuses.find((s) => s.id === id)?.stacks ?? 0;
var receivedV5 = (target, amount) => amount * (count$2(target, "bitter") ? .5 : 1);
var defenseV5 = (target) => target.defense * (1 - .08 * count$2(target, "brittle"));
/** Both DoTs share the boss budget; absorbed Bleed does not spend HP budget. */
function statusDamageV5(b, source, target, id, amount, io) {
	if (target.hp <= 0) return 0;
	amount = Math.max(0, Math.round(amount));
	if (id === "snag") {
		const absorbed = Math.min(target.shield, amount);
		target.shield -= absorbed;
		amount -= absorbed;
		if (absorbed) io.record(b, source, target, "absorbed", absorbed, "Shield absorbed Bleed");
	}
	if (io.isBoss(target)) {
		if (target.bonuses.v5DotRound !== b.round) {
			target.bonuses.v5DotRound = b.round;
			target.bonuses.v5DotDamage = 0;
		}
		amount = Math.min(amount, Math.max(0, Math.floor(target.maxHp * .06) - (target.bonuses.v5DotDamage ?? 0)));
	}
	const actual = io.loseHp(b, source, target, amount, "dot");
	if (io.isBoss(target)) target.bonuses.v5DotDamage = (target.bonuses.v5DotDamage ?? 0) + actual;
	io.record(b, source, target, "status-tick", actual, core[id].name, id);
	emitGameplayEvent(b, {
		kind: "status-tick",
		statusId: id,
		amount: actual,
		sourceId: source.id,
		actorId: source.id,
		targetId: target.id,
		text: `${target.name}: ${core[id].name} ${actual}.`
	});
	return actual;
}
function beforeActionV5(b, actor, io) {
	const bleed = actor.statuses.find((s) => s.id === "snag");
	if (bleed) statusDamageV5(b, b.actors.find((a) => a.id === bleed.source) ?? actor, actor, "snag", 8 * bleed.stacks, io);
	return actor.hp > 0;
}
function consumeDazeV5(b, actor, io) {
	if (!count$2(actor, "drowsy")) return false;
	const controller = b.actors.find((a) => a.id === actor.statuses.find((s) => s.id === "drowsy")?.source);
	actor.statuses = actor.statuses.filter((s) => s.id !== "drowsy");
	if (controller?.bonuses.crewSuppress && !controller.bonuses.crewSuppressed) {
		controller.bonuses.crewSuppressed = 1;
		io.heal(b, controller, controller, controller.bonuses.crewSuppress);
	}
	actor.bonuses.controlImmuneUntil = b.round + 1;
	io.record(b, actor, actor, "suppressed", 1, "Daze spent the next action");
	return true;
}
function tickStatusesV5(b, actors, io) {
	b.procRounds.v5RoundEnd = 1;
	try {
		for (const actor of actors.filter((a) => a.hp > 0)) {
			const regen = actor.statuses.find((s) => s.id === "steep");
			if (regen) {
				const source = b.actors.find((a) => a.id === regen.source) ?? actor, before = actor.hp;
				io.heal(b, source, actor, 18 * regen.stacks);
				io.record(b, source, actor, "status-tick", actor.hp - before, "Regen", "steep");
				emitGameplayEvent(b, {
					kind: "status-tick",
					statusId: "steep",
					amount: actor.hp - before,
					sourceId: source.id,
					actorId: source.id,
					targetId: actor.id,
					text: `${actor.name}: Regen ${actor.hp - before}.`
				});
				const burn = actor.statuses.find((s) => s.id === "scald");
				if (burn) burn.stacks--;
				actor.statuses = actor.statuses.filter((s) => s.stacks > 0);
			}
		}
		for (const actor of actors.filter((a) => a.hp > 0)) {
			const burn = actor.statuses.find((s) => s.id === "scald");
			if (burn) statusDamageV5(b, b.actors.find((a) => a.id === burn.source) ?? actor, actor, "scald", 12 * burn.stacks, io);
		}
		for (const actor of actors) {
			for (const s of actor.statuses) {
				if (s.id === "drowsy") continue;
				s.remaining--;
				if (s.remaining <= 0) io.record(b, actor, actor, "expire", 0, statusRuleV5(s.id, io.rule(s.id)).name);
			}
			actor.statuses = actor.statuses.filter((s) => s.remaining > 0 && s.stacks > 0);
		}
	} finally {
		delete b.procRounds.v5RoundEnd;
	}
}
// packages/game-rules/src/cardrpg/depth/catalog.ts
var FLAVOURS = [
	"hearth",
	"garden",
	"tide",
	"ember",
	"moon"
];
var FLAVOUR_RULE = "Hearth → Garden → Tide → Ember → Moon → Hearth. Advantage adds 1 break pressure, with no damage multiplier.";
var hasAdvantage = (a, b) => FLAVOURS[(FLAVOURS.indexOf(a) + 1) % 5] === b;
var STATUSES = [
	{
		id: "cozy",
		name: "Cozy",
		kind: "buff",
		cap: 3,
		duration: 2,
		dispellable: true,
		tick: "none",
		strength: 10,
		description: "Reduce direct damage by 10% per stack. Does not reduce scald."
	},
	{
		id: "scald",
		name: "Scald",
		kind: "debuff",
		cap: 5,
		duration: 3,
		dispellable: true,
		tick: "damage",
		strength: 12,
		description: "Lose 12 HP per stack at round end, bypassing shields. Steep removes one stack when healing."
	},
	{
		id: "tangle",
		name: "Tangle",
		kind: "debuff",
		cap: 2,
		duration: 2,
		dispellable: true,
		tick: "none",
		strength: 1,
		description: "Direct hits add 1 break pressure per stack. Takes effect immediately."
	},
	{
		id: "steep",
		name: "Steep",
		kind: "buff",
		cap: 3,
		duration: 3,
		dispellable: true,
		tick: "heal",
		strength: 18,
		description: "Heal 18 HP per stack at round end and remove one Scald stack."
	},
	{
		id: "crumb",
		name: "Crumb trail",
		kind: "debuff",
		cap: 4,
		duration: 3,
		dispellable: true,
		tick: "none",
		strength: 24,
		description: "Stores 24 damage per stack for a detonation. Detonation consumes all stacks."
	},
	{
		id: "scent",
		name: "Scented",
		kind: "debuff",
		cap: 1,
		duration: 2,
		dispellable: true,
		tick: "none",
		strength: 20,
		description: "Can be targeted through front-row protection and takes 20% more direct damage."
	},
	{
		id: "rattled",
		name: "Rattled",
		kind: "debuff",
		cap: 2,
		duration: 2,
		dispellable: true,
		tick: "none",
		strength: 15,
		description: "Direct damage dealt falls by 15% per stack."
	},
	{
		id: "drowsy",
		name: "Drowsy",
		kind: "debuff",
		cap: 1,
		duration: 1,
		dispellable: true,
		tick: "none",
		strength: 1,
		description: "Committed enemy signature becomes a half-power basic. Every actor still takes its turn."
	},
	{
		id: "glaze",
		name: "Glaze",
		kind: "buff",
		cap: 2,
		duration: 2,
		dispellable: true,
		tick: "none",
		strength: 20,
		description: "Gain 20 shield per stack when starting a turn, capped at 60% maximum HP."
	},
	{
		id: "shelter",
		name: "Shelter",
		kind: "buff",
		cap: 1,
		duration: 2,
		dispellable: true,
		tick: "none",
		strength: 1,
		description: "Hostile single-target intents prefer this actor while alive. Row-wide attacks remain row-wide."
	},
	{
		id: "riposte",
		name: "Saucer riposte",
		kind: "buff",
		cap: 2,
		duration: 2,
		dispellable: true,
		tick: "none",
		strength: 16,
		description: "Each direct hostile hit returns 16 damage per stack. Reflections cannot trigger reflections."
	},
	{
		id: "hush",
		name: "Hush",
		kind: "debuff",
		cap: 1,
		duration: 2,
		dispellable: true,
		tick: "none",
		strength: 1,
		description: "Enemy heal, summon or shield action becomes a basic. Cat energy skills cost 1 more."
	},
	{
		id: "brittle",
		name: "Brittle sugar",
		kind: "debuff",
		cap: 3,
		duration: 2,
		dispellable: true,
		tick: "none",
		strength: 15,
		description: "Each direct hit removes an extra 15 shield per stack before damage."
	},
	{
		id: "link",
		name: "Apron link",
		kind: "buff",
		cap: 1,
		duration: 3,
		dispellable: true,
		tick: "none",
		strength: 30,
		description: "The living source takes 30% of direct HP damage to the linked ally. Shared damage does not chain."
	},
	{
		id: "sprout",
		name: "Second sprout",
		kind: "buff",
		cap: 1,
		duration: 3,
		dispellable: false,
		tick: "none",
		strength: 25,
		description: "Consume to survive a fatal hit at 25% HP, once per battle per actor."
	},
	{
		id: "decoy",
		name: "Yarn decoy",
		kind: "buff",
		cap: 1,
		duration: 2,
		dispellable: true,
		tick: "none",
		strength: 1,
		description: "Absorbs the next direct hit entirely, then disappears. Scald passes through."
	}
];
var STATUS_BY_ID = Object.fromEntries([...STATUSES, ...NEW_STATUS_RULES_V5].map((s) => [s.id, s]));
var specs = {
	mochi: [
		[
			"Door knock",
			"attack",
			"foe",
			0,
			0,
			1,
			[{
				kind: "hit",
				power: 90
			}, {
				kind: "shield",
				power: 18,
				self: true
			}],
			"Strike and shelter yourself."
		],
		[
			"Warm welcome",
			"defend",
			"ally",
			1,
			0,
			0,
			[{
				kind: "shield",
				power: 70
			}, {
				kind: "rally",
				status: "cozy"
			}],
			"Shield an ally and grant Cozy."
		],
		[
			"Apron crossing",
			"defend",
			"ally",
			2,
			2,
			1,
			[
				{ kind: "swap" },
				{
					kind: "rally",
					status: "link"
				},
				{
					kind: "rally",
					status: "shelter",
					self: true
				}
			],
			"Swap rows with an ally and share their damage."
		],
		[
			"Last light shelter",
			"ultimate",
			"allies",
			2,
			3,
			0,
			[{
				kind: "shield",
				power: 130
			}, {
				kind: "rally",
				status: "cozy",
				stacks: 2
			}],
			"Protect the whole table with shields and Cozy."
		]
	],
	soot: [
		[
			"Cocoa spark",
			"attack",
			"pierce",
			0,
			0,
			1,
			[{
				kind: "hit",
				power: 85
			}, {
				kind: "rally",
				status: "crumb"
			}],
			"Seed a Crumb trail through any row."
		],
		[
			"Black cup",
			"control",
			"foe",
			1,
			0,
			2,
			[{
				kind: "hit",
				power: 55
			}, {
				kind: "rally",
				status: "scent"
			}],
			"Mark a target so every cat can reach it."
		],
		[
			"Lantern wick",
			"attack",
			"foe",
			2,
			1,
			2,
			[{
				kind: "hit",
				power: 105
			}, {
				kind: "detonate",
				power: 150
			}],
			"Detonate Crumb trails and Scald for burst damage."
		],
		[
			"Midnight service",
			"ultimate",
			"foes",
			2,
			3,
			2,
			[
				{
					kind: "hit",
					power: 125
				},
				{
					kind: "detonate",
					power: 125
				},
				{
					kind: "rally",
					status: "hush"
				}
			],
			"Detonate every enemy and quiet utility intents."
		]
	],
	clover: [
		[
			"Leaf tap",
			"attack",
			"foe",
			0,
			0,
			1,
			[{
				kind: "hit",
				power: 80
			}, {
				kind: "heal",
				power: 18,
				self: true
			}],
			"Tap a foe and tend your own scratches."
		],
		[
			"Patient steep",
			"support",
			"ally",
			1,
			0,
			0,
			[{
				kind: "heal",
				power: 35
			}, {
				kind: "rally",
				status: "steep"
			}],
			"Give a small heal and three rounds of Steep."
		],
		[
			"Clearleaf rinse",
			"support",
			"allies",
			2,
			2,
			0,
			[{ kind: "cleanse" }, {
				kind: "heal",
				power: 45
			}],
			"Remove every dispellable debuff and heal all allies."
		],
		[
			"Greenhouse morning",
			"ultimate",
			"allies",
			2,
			3,
			0,
			[{
				kind: "heal",
				power: 90
			}, {
				kind: "rally",
				status: "sprout"
			}],
			"Heal the table and protect each ally from one fatal hit."
		]
	],
	panko: [
		[
			"Pan reply",
			"attack",
			"foe",
			0,
			0,
			1,
			[{
				kind: "hit",
				power: 85
			}, {
				kind: "rally",
				status: "riposte",
				self: true
			}],
			"Strike and ready a saucer counter."
		],
		[
			"Bread cover",
			"defend",
			"self",
			1,
			0,
			0,
			[{
				kind: "shield",
				power: 80
			}, {
				kind: "rally",
				status: "shelter"
			}],
			"Draw single-target pressure onto a fresh shield."
		],
		[
			"Crust return",
			"defend",
			"allies",
			2,
			2,
			0,
			[{
				kind: "rally",
				status: "riposte"
			}, {
				kind: "shield",
				power: 35
			}],
			"Let the whole team counter incoming hits."
		],
		[
			"Oven door",
			"ultimate",
			"self",
			2,
			3,
			0,
			[
				{
					kind: "shield",
					power: 180
				},
				{
					kind: "rally",
					status: "riposte",
					stacks: 2
				},
				{
					kind: "rally",
					status: "shelter"
				}
			],
			"Become the defended counterattack target."
		]
	],
	mallow: [
		[
			"Whisk flare",
			"attack",
			"foe",
			0,
			0,
			1,
			[{
				kind: "hit",
				power: 100
			}, {
				kind: "rally",
				status: "scald"
			}],
			"A direct strike leaves a hot aftertaste."
		],
		[
			"Split ember",
			"attack",
			"row",
			1,
			0,
			1,
			[{
				kind: "hit",
				power: 60
			}, {
				kind: "rally",
				status: "brittle"
			}],
			"Chip an entire row and soften its shields."
		],
		[
			"Burnt sugar",
			"attack",
			"foe",
			2,
			2,
			2,
			[{
				kind: "hit",
				power: 120
			}, {
				kind: "consume",
				power: 45
			}],
			"Consume your Cozy for extra damage. Protection becomes fuel."
		],
		[
			"Closing blaze",
			"ultimate",
			"foes",
			2,
			3,
			2,
			[{
				kind: "hit",
				power: 130
			}, {
				kind: "rally",
				status: "scald",
				stacks: 3
			}],
			"Set every enemy simmering for three rounds."
		]
	],
	sorrel: [
		[
			"Moon spoon",
			"attack",
			"foe",
			0,
			0,
			1,
			[{
				kind: "hit",
				power: 70
			}, {
				kind: "energy",
				power: 1
			}],
			"Restore 1 shared energy after a light hit."
		],
		[
			"Cold brew",
			"control",
			"pierce",
			1,
			0,
			1,
			[{
				kind: "hit",
				power: 50
			}, {
				kind: "rally",
				status: "rattled"
			}],
			"Reach a dangerous rear attacker and lower its damage."
		],
		[
			"Decanted moon",
			"support",
			"ally",
			2,
			2,
			0,
			[{ kind: "transfer" }, {
				kind: "rally",
				status: "glaze"
			}],
			"Move your shield to an ally and grant shield regeneration."
		],
		[
			"Shared pot",
			"ultimate",
			"allies",
			1,
			3,
			0,
			[
				{
					kind: "heal",
					power: 50
				},
				{
					kind: "energy",
					power: 3
				},
				{
					kind: "rally",
					status: "glaze"
				}
			],
			"Restore energy once and keep every cup protected."
		]
	],
	biscuit: [
		[
			"Rolling pin",
			"attack",
			"foe",
			0,
			0,
			2,
			[{
				kind: "hit",
				power: 95
			}, {
				kind: "break",
				power: 1
			}],
			"A heavy basic that pressures break."
		],
		[
			"Sideboard step",
			"defend",
			"ally",
			1,
			0,
			0,
			[{ kind: "swap" }, {
				kind: "shield",
				power: 55
			}],
			"Trade rows and shield the ally moving with you."
		],
		[
			"Last crumb",
			"attack",
			"pierce",
			2,
			2,
			2,
			[{
				kind: "execute",
				power: 165
			}],
			"Deal double damage below 30% enemy HP."
		],
		[
			"Bakers procession",
			"ultimate",
			"foe",
			2,
			3,
			3,
			[{
				kind: "chain",
				power: 130
			}, {
				kind: "rally",
				status: "rattled"
			}],
			"Bounce through three living foes and rattle the first."
		]
	],
	inkcap: [
		[
			"Ink thread",
			"attack",
			"pierce",
			0,
			0,
			1,
			[{
				kind: "hit",
				power: 70
			}, {
				kind: "rally",
				status: "tangle"
			}],
			"Tangle any row for follow-up break pressure."
		],
		[
			"Quiet spores",
			"control",
			"foe",
			1,
			0,
			1,
			[{
				kind: "hit",
				power: 45
			}, {
				kind: "rally",
				status: "hush"
			}],
			"Quiet a healer, shielder or summoner."
		],
		[
			"Paper decoy",
			"defend",
			"ally",
			2,
			2,
			0,
			[{
				kind: "rally",
				status: "decoy"
			}, {
				kind: "rally",
				status: "shelter"
			}],
			"Place a one-hit decoy where enemies will look."
		],
		[
			"Dreaming canopy",
			"ultimate",
			"foes",
			2,
			3,
			2,
			[
				{
					kind: "hit",
					power: 65
				},
				{
					kind: "rally",
					status: "drowsy"
				},
				{
					kind: "rally",
					status: "tangle",
					stacks: 2
				}
			],
			"Soften signatures and prepare every foe for a break."
		]
	],
	cinnamon: [
		[
			"Spice pinch",
			"attack",
			"foe",
			0,
			0,
			1,
			[{
				kind: "hit",
				power: 75
			}, {
				kind: "drain",
				power: 40
			}],
			"Turn part of a hit into self-healing."
		],
		[
			"Comfort cup",
			"support",
			"ally",
			1,
			0,
			0,
			[{
				kind: "heal",
				power: 80
			}, {
				kind: "rally",
				status: "cozy"
			}],
			"Immediate care with a protective aftertaste."
		],
		[
			"Clean apron",
			"support",
			"ally",
			2,
			1,
			0,
			[
				{ kind: "cleanse" },
				{
					kind: "shield",
					power: 85
				},
				{
					kind: "rally",
					status: "steep"
				}
			],
			"Cleanse, shield and slowly mend one patient."
		],
		[
			"Second serving",
			"ultimate",
			"fallen",
			2,
			4,
			0,
			[{
				kind: "revive",
				power: 40
			}],
			"Bring one fallen ally back at 40% HP once per battle."
		]
	],
	brioche: [
		[
			"Bell patrol",
			"attack",
			"foe",
			0,
			0,
			1,
			[{
				kind: "hit",
				power: 80
			}, {
				kind: "rally",
				status: "glaze",
				self: true
			}],
			"Ring the night bell and renew your shield each turn."
		],
		[
			"Borrowed blanket",
			"defend",
			"ally",
			1,
			0,
			0,
			[{ kind: "transfer" }, {
				kind: "heal",
				power: 30
			}],
			"Give your accumulated shield to a hurt ally."
		],
		[
			"Starched collar",
			"control",
			"foe",
			2,
			2,
			2,
			[
				{ kind: "dispel" },
				{
					kind: "hit",
					power: 110
				},
				{
					kind: "rally",
					status: "brittle"
				}
			],
			"Strip buffs, then crack the enemy shield."
		],
		[
			"Constellation apron",
			"ultimate",
			"allies",
			2,
			3,
			0,
			[
				{
					kind: "shield",
					power: 95
				},
				{
					kind: "rally",
					status: "link"
				},
				{
					kind: "rally",
					status: "glaze",
					stacks: 2
				}
			],
			"Link the table to your protection and regenerate shields."
		]
	],
	velvet: [
		[
			"Silk nick",
			"attack",
			"pierce",
			0,
			0,
			1,
			[{
				kind: "hit",
				power: 95
			}, {
				kind: "rally",
				status: "scent"
			}],
			"Expose a rear target for the team."
		],
		[
			"Candle bounce",
			"attack",
			"foe",
			1,
			0,
			1,
			[{
				kind: "chain",
				power: 65
			}],
			"Bounce through three living enemies."
		],
		[
			"Stolen flame",
			"control",
			"foe",
			2,
			2,
			2,
			[
				{ kind: "dispel" },
				{
					kind: "hit",
					power: 90
				},
				{
					kind: "energy",
					power: 2
				}
			],
			"Remove buffs and reclaim shared energy."
		],
		[
			"Velvet curtain",
			"ultimate",
			"foe",
			2,
			3,
			3,
			[{
				kind: "execute",
				power: 210
			}, {
				kind: "rally",
				status: "decoy",
				self: true
			}],
			"Execute a weakened target and vanish behind a decoy."
		]
	],
	marigold: [
		[
			"Seed stitch",
			"attack",
			"foe",
			0,
			0,
			1,
			[{
				kind: "hit",
				power: 65
			}, {
				kind: "rally",
				status: "steep",
				self: true
			}],
			"Plant slow healing while helping the offense."
		],
		[
			"Garden bell",
			"support",
			"allies",
			1,
			0,
			0,
			[{
				kind: "heal",
				power: 24
			}, {
				kind: "rally",
				status: "steep"
			}],
			"Start a patient team-wide recovery."
		],
		[
			"Spring pruning",
			"control",
			"foe",
			2,
			2,
			1,
			[
				{ kind: "dispel" },
				{
					kind: "rally",
					status: "scald",
					stacks: 2
				},
				{
					kind: "rally",
					status: "crumb",
					stacks: 2
				}
			],
			"Prune buffs and seed two kinds of delayed damage."
		],
		[
			"First tea blossom",
			"ultimate",
			"allies",
			2,
			3,
			0,
			[
				{ kind: "cleanse" },
				{
					kind: "heal",
					power: 110
				},
				{
					kind: "energy",
					power: 2
				}
			],
			"Clear the team, restore health and refill the pot."
		]
	]
};
var CATS$1 = [
	[
		"mochi",
		"guardian",
		"hearth",
		"front",
		["shelter", "brew"],
		"Door keeper",
		"Shielding another ally also grants you 12 shield."
	],
	[
		"soot",
		"hexer",
		"moon",
		"rear",
		["trail", "night"],
		"Ash reader",
		"Detonation restores 10 ultimate charge."
	],
	[
		"clover",
		"healer",
		"garden",
		"rear",
		["brew", "garden"],
		"Second steep",
		"The first heal each battle also cleanses its patient."
	],
	[
		"panko",
		"guardian",
		"garden",
		"front",
		["shelter", "counter"],
		"Warm crust",
		"Defend grants Saucer riposte."
	],
	[
		"mallow",
		"striker",
		"ember",
		"front",
		["ember", "trail"],
		"Hot whisk",
		"Attacking a Scalded target grants 8 ultimate charge."
	],
	[
		"sorrel",
		"controller",
		"tide",
		"rear",
		["brew", "night"],
		"Measured pour",
		"Gain 1 energy at the start of each odd round."
	],
	[
		"biscuit",
		"striker",
		"hearth",
		"front",
		["counter", "shelter"],
		"Bakers resolve",
		"Your first low-health strike gains 30 shield."
	],
	[
		"inkcap",
		"controller",
		"garden",
		"rear",
		["trail", "garden"],
		"Soft landing",
		"First hostile hit is softened by an initial Yarn decoy."
	],
	[
		"cinnamon",
		"healer",
		"ember",
		"rear",
		["brew", "ember"],
		"Ground spice",
		"Heals below half HP grant 15 shield."
	],
	[
		"brioche",
		"guardian",
		"moon",
		"front",
		["night", "shelter"],
		"Night watch",
		"Begin each round with 12 shield."
	],
	[
		"velvet",
		"witch",
		"tide",
		"rear",
		["night", "trail"],
		"Lost flame",
		"Defeating a foe grants 15 charge."
	],
	[
		"marigold",
		"healer",
		"garden",
		"rear",
		["garden", "brew"],
		"First leaf",
		"Steep on this cat lasts one extra round."
	]
].map(([id, role, flavour, row, tags, passiveName, description]) => ({
	id,
	name: CARDS.find((c) => c.id === id).name,
	role,
	flavour,
	row,
	tags,
	passive: {
		id: `${id}-passive`,
		name: passiveName,
		description
	},
	skills: specs[id].map(([name, type, target, cost, cooldown, breakPower, effects, description], index) => ({
		id: `${id}-${index + 1}`,
		catId: id,
		name,
		type,
		target,
		cost,
		cooldown,
		breakPower,
		effects,
		description,
		charge: index === 3 ? 80 : 0,
		unlockLevel: index === 3 ? 6 : 1,
		unlockStars: index === 3 ? 3 : 1
	}))
}));
var CAT_BY_ID = Object.fromEntries(CATS$1.map((c) => [c.id, c]));
var SKILLS = Object.fromEntries(CATS$1.flatMap((c) => c.skills.map((s) => [s.id, s])));
var TEAM_COMBOS = [
	{
		id: "warm-table",
		name: "Warm table",
		tags: ["shelter", "brew"],
		description: "A guardian and brewer grant every cat 20 opening shield."
	},
	{
		id: "night-garden",
		name: "Night garden",
		tags: ["night", "garden"],
		description: "Night and garden grant 10 starting ultimate charge."
	},
	{
		id: "crumb-circuit",
		name: "Crumb circuit",
		tags: ["trail", "ember"],
		description: "Trail and ember grant 1 extra first-round energy. Detonation consumes Scald, shortening its damage over time."
	}
];
var teamCombos = (ids) => TEAM_COMBOS.filter((c) => c.tags.every((tag) => ids.some((id) => CAT_BY_ID[id]?.tags.includes(tag))));
var ENEMIES = [
	{
		id: "button-guard",
		name: "Button Guard",
		role: "guard",
		flavour: "garden",
		row: "front",
		tier: "regular",
		hp: 480,
		attack: 19,
		defense: 18,
		breakCap: 4,
		mechanic: "shield",
		intent: "Button brace grants shields to its row.",
		counter: "Hush stops the brace. Brittle strips shield faster.",
		phases: [],
		chapter: 1
	},
	{
		id: "sock-skipper",
		name: "Sock Skipper",
		role: "flanker",
		flavour: "ember",
		row: "rear",
		tier: "regular",
		hp: 701,
		attack: 22,
		defense: 8,
		breakCap: 3,
		mechanic: "steal",
		intent: "Pocket skip steals 1 shared energy and hits the rear.",
		counter: "Break it before its turn or lure it with Shelter.",
		phases: [],
		chapter: 1
	},
	{
		id: "spool-ram",
		name: "Spool Ram",
		role: "charger",
		flavour: "moon",
		row: "front",
		tier: "elite",
		hp: 1050,
		attack: 30,
		defense: 16,
		breakCap: 5,
		mechanic: "charge",
		intent: "Every third round charges a double-power front-row sweep.",
		counter: "Fill break to interrupt. Defend reduces the sweep.",
		phases: [],
		chapter: 1
	},
	{
		id: "needle-moth",
		name: "Needle Moth",
		role: "ranger",
		flavour: "tide",
		row: "rear",
		tier: "regular",
		hp: 659,
		attack: 17,
		defense: 6,
		breakCap: 3,
		mechanic: "dot",
		intent: "Needle rain applies Scald to the rear row.",
		counter: "Cleanse Scald or interrupt with Drowsy.",
		status: "scald",
		phases: [],
		chapter: 1
	},
	{
		id: "teacup-healer",
		name: "Teacup Healer",
		role: "healer",
		flavour: "garden",
		row: "rear",
		tier: "regular",
		hp: 765,
		attack: 14,
		defense: 10,
		breakCap: 3,
		mechanic: "heal",
		intent: "Refills the most wounded ally by 65 HP.",
		counter: "Apply Hush or reach the rear with a Scented mark.",
		phases: [],
		chapter: 1
	},
	{
		id: "kettle-knight",
		name: "Kettle Knight",
		role: "elite",
		flavour: "ember",
		row: "front",
		tier: "elite",
		hp: 1190,
		attack: 25,
		defense: 35,
		breakCap: 6,
		mechanic: "reflect",
		intent: "Reflects 12 damage per hit while its shield holds.",
		counter: "Dispel Cozy, apply Brittle, then break its shield.",
		phases: [],
		chapter: 2
	},
	{
		id: "yarn-giant",
		name: "Yarn Giant",
		role: "yarn",
		flavour: "garden",
		row: "front",
		tier: "boss",
		hp: 2870,
		attack: 32,
		defense: 22,
		breakCap: 7,
		mechanic: "bind",
		intent: "Every third round Loomfall sweeps the front and Tangled threads appear.",
		counter: "Hearth hits add break. Break before Loomfall, cleanse Tangle.",
		status: "tangle",
		phases: ["Winding", "At 50% HP, Loomfall also reaches the rear"],
		chapter: 1
	},
	{
		id: "binding-thread",
		name: "Binding Thread",
		role: "thread",
		flavour: "moon",
		row: "rear",
		tier: "regular",
		hp: 383,
		attack: 10,
		defense: 0,
		breakCap: 2,
		mechanic: "snare",
		intent: "Knots apply Tangle to the weakest cat.",
		counter: "Clear the small thread or cleanse the knot.",
		status: "tangle",
		phases: [],
		chapter: 1
	},
	{
		id: "practice-cushion",
		name: "Practice Cushion",
		role: "dummy",
		flavour: "garden",
		row: "front",
		tier: "regular",
		hp: 230,
		attack: 14,
		defense: 0,
		breakCap: 3,
		mechanic: "lesson",
		intent: "A gentle third-round bump teaches a break interrupt.",
		counter: "Two Hearth hits and a break skill stop the bump.",
		phases: [],
		chapter: 1
	},
	{
		id: "pollen-scout",
		name: "Pollen Scout",
		role: "ranger",
		flavour: "tide",
		row: "rear",
		tier: "elite",
		hp: 945,
		attack: 22,
		defense: 10,
		breakCap: 5,
		mechanic: "summon",
		intent: "Every third round plants a Binding Thread, up to two.",
		counter: "Hush prevents planting. Defeat threads before they multiply pressure.",
		phases: [],
		chapter: 2
	},
	{
		id: "rain-spool",
		name: "Rain Spool",
		role: "charger",
		flavour: "ember",
		row: "front",
		tier: "boss",
		hp: 3675,
		attack: 58,
		defense: 24,
		breakCap: 8,
		mechanic: "storm",
		intent: "Every third round Cloudburst washes shields away before a row hit.",
		counter: "Tide adds break. Use Steep and healing instead of stacking shields.",
		status: "rattled",
		phases: ["Collecting rain", "At 50% HP, Cloudburst targets both rows"],
		chapter: 2
	},
	{
		id: "crumb-sentinel",
		name: "Crumb Sentinel",
		role: "guard",
		flavour: "moon",
		row: "front",
		tier: "elite",
		hp: 1260,
		attack: 27,
		defense: 22,
		breakCap: 6,
		mechanic: "bomb",
		intent: "Every third round Sugar burst detonates Crumb trails on cats.",
		counter: "Cleanse Crumb trails before the signature, or break the sentinel.",
		status: "crumb",
		phases: [],
		chapter: 3
	},
	{
		id: "pantry-crown",
		name: "Pantry Crown",
		role: "yarn",
		flavour: "tide",
		row: "rear",
		tier: "boss",
		hp: 4270,
		attack: 60,
		defense: 25,
		breakCap: 9,
		mechanic: "banquet",
		intent: "Every third round Empty banquet drains energy and silences the table.",
		counter: "Garden adds break. Reserve energy and cleanse Hush.",
		status: "hush",
		phases: ["Counting cups", "At 50% HP, signatures summon a Binding Thread"],
		chapter: 3
	}
];
var ENEMY_BY_ID = Object.fromEntries(ENEMIES.map((e) => [e.id, e]));
// packages/game-rules/src/cardrpg/economy-v3.ts
/** Published v3 policy. Currency amounts are integers; all chances are basis points. */
var ECONOMY_V3 = {
	version: 3,
	rewards: {
		weeklySpool: 1.5,
		chapterSpool: 1,
		seasonRankMax: 6,
		weeklyStarThread: 1
	},
	season: {
		days: 28,
		epoch: Date.UTC(2026, 10, 13),
		editionSupply: 600
	},
	deed: {
		firstId: 30001,
		lastId: 33e3,
		supply: 3e3,
		level: 15,
		demoLevel: 5
	},
	spool: {
		feeBp: 2500,
		minAgeDays: 7,
		cooldownDays: 7,
		weeklyNetCap: 12
	},
	cat: {
		odds: {
			common: 5500,
			rare: 3300,
			epic: 1100,
			legendary: 100
		},
		soft: 50,
		hard: 70,
		stepBp: 600,
		featuredBp: 5e3
	},
	gear: {
		odds: {
			common: 5e3,
			rare: 3500,
			epic: 1420,
			legendary: 80
		},
		soft: 40,
		hard: 60,
		stepBp: 600
	},
	shards: {
		common: 5,
		rare: 10,
		epic: 20,
		legendary: 40
	},
	starShards: [
		10,
		20,
		40,
		80
	],
	selector: 120,
	enhancement: {
		max: 10,
		successBp: [
			1e4,
			1e4,
			1e4,
			1e4,
			1e4,
			8e3,
			7e3,
			6e3,
			5e3,
			4e3
		],
		blessingBp: 1e3,
		fishBase: 30,
		growth: 1.35
	},
	fusion: {
		rare: {
			count: 4,
			input: "common",
			starThread: 0,
			yarn: 0
		},
		epic: {
			count: 3,
			input: "rare",
			starThread: 0,
			yarn: 0
		},
		legendary: {
			count: 3,
			input: "epic",
			starThread: 2,
			yarn: 20
		},
		successBp: 1e4
	},
	seal: {
		level: 15,
		demoLevel: 5,
		perDay: 3,
		deedExtra: 1,
		bossSeals: 1,
		feeBp: 1e3,
		relistMinutes: 10,
		reference: {
			epic: 100,
			legendary: 300,
			mythic: 900,
			starThread: 20
		}
	},
	quality: [
		{
			name: "Worn",
			floorBp: 0,
			offset: 0
		},
		{
			name: "Fine",
			floorBp: 4e3,
			offset: 1e3
		},
		{
			name: "Perfect",
			floorBp: 8500,
			offset: 2e3
		}
	],
	drops: {
		full: 6,
		halfUntil: 18,
		halfBp: 5e3,
		battle: {
			chanceBp: 3e3,
			odds: {
				common: 6500,
				rare: 3e3,
				epic: 500,
				legendary: 0
			}
		},
		elite: {
			chanceBp: 6e3,
			odds: {
				common: 0,
				rare: 7200,
				epic: 2790,
				legendary: 10
			}
		},
		boss: {
			chanceBp: 1e4,
			odds: {
				common: 0,
				rare: 3e3,
				epic: 6970,
				legendary: 30
			}
		},
		firstBoss: {
			chanceBp: 1e4,
			odds: {
				common: 0,
				rare: 0,
				epic: 9700,
				legendary: 300
			}
		},
		tower: {
			chanceBp: 1e4,
			odds: {
				common: 0,
				rare: 0,
				epic: 9500,
				legendary: 500
			}
		}
	},
	allocation: {
		players: 35,
		team: 15,
		treasury: 12,
		investors: 12,
		ecosystem: 10,
		earlyTesters: 6,
		liquidity: 5,
		advisors: 3,
		partners: 2
	},
	market: {
		feeBp: 500,
		burnBp: 200,
		treasuryBp: 300
	}
};
function enhancementQuote(level, blessingBp = 0) {
	if (!Number.isInteger(level) || level < 0 || level >= 10 || !Number.isInteger(blessingBp) || blessingBp < 0 || blessingBp > 1e4) throw new Error("Invalid enhancement");
	return {
		fish: Math.ceil(ECONOMY_V3.enhancement.fishBase * ECONOMY_V3.enhancement.growth ** level),
		chanceBp: Math.min(1e4, ECONOMY_V3.enhancement.successBp[level] + blessingBp)
	};
}
function dropMultiplierBp(dropsToday) {
	if (!Number.isSafeInteger(dropsToday) || dropsToday < 0) throw new Error("Invalid drop count");
	return dropsToday < 6 ? 1e4 : dropsToday < 18 ? 5e3 : 0;
}
function qualityBucket(rollBp) {
	if (!Number.isInteger(rollBp) || rollBp < 0 || rollBp > 1e4) throw new Error("Invalid quality");
	return ECONOMY_V3.quality[rollBp >= 8500 ? 2 : rollBp >= 4e3 ? 1 : 0];
}
// packages/game-rules/src/config.ts
/**
* Classic tunables were signed off by the user on 2026-10-23
* (boss.powerGrowth 1.15 and relic.shardCost 30 changed at sign-off; the rest kept).
* Classic time is in seconds. Docs: docs/game-rules.md (keep in sync).
* ORIG1 is a separate default-off draft; timing units are explicit in docs/design/original-economy.md.
*/
var CONFIG = {
	/** ORIG1 gameplay remains OFF. The local catalog uses this default and opts in without changing it. */
	features: {
		originalEconomy: false,
		cafeAdventure: false,
		squadCombat: false
	},
	/** Original draft tables; see docs/design/original-economy.md for units and rationale. */
	originalEconomy: {
		revision: "orig1-2026-11-02",
		stats: {
			hp: {
				name: "Ninefold Stamina",
				description: "How much punishment a cat can carry before resting.",
				base: 116,
				cap: null,
				unit: "points"
			},
			atk: {
				name: "Pawprint Force",
				description: "The starting strength of one landed hit.",
				base: 12,
				cap: null,
				unit: "points"
			},
			def: {
				name: "Quiltguard",
				description: "Padding that softens each incoming hit.",
				base: 7,
				cap: null,
				unit: "rating"
			},
			attackSpeed: {
				name: "Quickstep Rhythm",
				description: "Shortens the pause between ordinary attacks.",
				base: 0,
				cap: .65,
				unit: "fraction"
			},
			critChance: {
				name: "Glint Focus",
				description: "The share of hits that find a bright opening.",
				base: .035,
				cap: .42,
				unit: "probability"
			},
			critDamage: {
				name: "Flare Payoff",
				description: "Extra damage above a normal hit when an opening is found.",
				base: .55,
				cap: 1.1,
				unit: "fraction"
			},
			dodge: {
				name: "Threadstep",
				description: "The chance to slip entirely past an incoming hit.",
				base: .02,
				cap: .28,
				unit: "probability"
			},
			hpRegen: {
				name: "Purr Reserve",
				description: "The fraction of full stamina restored each second.",
				base: 0,
				cap: .012,
				unit: "fraction/second"
			},
			fishBonus: {
				name: "Pantry Yield",
				description: "Adds a share to fish earned from encounters.",
				base: 0,
				cap: .24,
				unit: "fraction"
			},
			xpBonus: {
				name: "Trail Memory",
				description: "Adds a share to experience earned from encounters.",
				base: 0,
				cap: .2,
				unit: "fraction"
			},
			materialFind: {
				name: "Pocket Scouting",
				description: "Raises material roll chances without changing gear quality.",
				base: 0,
				cap: .18,
				unit: "fraction"
			},
			bossDamage: {
				name: "Gate Pressure",
				description: "Adds a share of damage against the chapter guardian.",
				base: 0,
				cap: .22,
				unit: "fraction"
			}
		},
		combat: {
			attackIntervalMs: 1250,
			defenseScale: 90,
			minDamage: 1
		},
		gear: {
			maxLevel: 6,
			levelGrowth: .055,
			/** Fish to buy levels 2..6, before quality cost scaling; round up once. */
			upgradeFish: [
				18,
				29,
				47,
				76,
				123
			],
			/** Quality weights are conditional on receiving gear; basis points total 10000. */
			qualities: {
				common: {
					name: "Hearthmade",
					multiplier: 1,
					costMultiplier: 1,
					weightBp: 6250
				},
				uncommon: {
					name: "Trailstitched",
					multiplier: 1.22,
					costMultiplier: 1.18,
					weightBp: 2520
				},
				rare: {
					name: "Lamplit",
					multiplier: 1.52,
					costMultiplier: 1.45,
					weightBp: 940
				},
				epic: {
					name: "Aurorawoven",
					multiplier: 1.95,
					costMultiplier: 1.85,
					weightBp: 250
				},
				legendary: {
					name: "Daybreakbound",
					multiplier: 2.45,
					costMultiplier: 2.3,
					weightBp: 40
				}
			},
			items: {
				seamblade: {
					name: "Seamlight Saber",
					description: "A curved edge with a stitched grip for steady patrols.",
					slot: "weapon",
					weaponType: "sword",
					stats: { atk: 7 }
				},
				kettlemaul: {
					name: "Kettlebelly Maul",
					description: "A hollow workshop head gives every swing a low note.",
					slot: "weapon",
					weaponType: "hammer",
					stats: { atk: 9 }
				},
				hemknives: {
					name: "Hemskip Twins",
					description: "Two small blades nest neatly in a folded apron.",
					slot: "weapon",
					weaponType: "daggers",
					stats: { atk: 5 }
				},
				windowpike: {
					name: "Windowline Pike",
					description: "A long reach fashioned for narrow rooftop crossings.",
					slot: "weapon",
					weaponType: "spear",
					stats: { atk: 7 }
				},
				rafterbow: {
					name: "Rafterstring Bow",
					description: "Its woven cord hums beneath the attic beams.",
					slot: "weapon",
					weaponType: "bow",
					stats: { atk: 6 }
				},
				lanternrod: {
					name: "Lanternwake Rod",
					description: "A shaded lamp at the tip guides wandering sparks.",
					slot: "weapon",
					weaponType: "staff",
					stats: { atk: 8 }
				},
				mossflasks: {
					name: "Mossfoam Bottles",
					description: "Soft glass sleeves keep the bubbling cargo snug.",
					slot: "weapon",
					weaponType: "flasks",
					stats: { atk: 6 }
				},
				quiltcap: {
					name: "Quiltfold Cap",
					description: "A padded brim catches dust from the rafters.",
					slot: "helmet",
					stats: {
						hp: 10,
						def: 2
					}
				},
				porchcoat: {
					name: "Porchlight Coat",
					description: "Broad patches keep the evening chill outside.",
					slot: "armor",
					stats: {
						hp: 22,
						def: 4
					}
				},
				spoolmitts: {
					name: "Spoolgrip Mitts",
					description: "Reinforced palms hold fast on wet window ledges.",
					slot: "gloves",
					stats: {
						hp: 6,
						def: 1
					}
				},
				eaveboots: {
					name: "Eaveskip Boots",
					description: "Quiet soles leave only a faint trail on the tiles.",
					slot: "boots",
					stats: {
						hp: 8,
						def: 1
					}
				},
				chimecollar: {
					name: "Firstchime Collar",
					description: "A tiny chime marks the start of each watch.",
					slot: "collar",
					stats: { critChance: .014 }
				},
				pantrystud: {
					name: "Pantrygleam Stud",
					description: "A polished clasp recalls the promise of supper.",
					slot: "earring",
					stats: { fishBonus: .025 }
				},
				hemring: {
					name: "Hemturn Band",
					description: "A smooth loop keeps loose threads from catching.",
					slot: "ring",
					stats: { attackSpeed: .018 }
				},
				purrcharm: {
					name: "Purrwell Token",
					description: "A warm keepsake settles against a tired heartbeat.",
					slot: "charm",
					stats: { hpRegen: .0015 }
				}
			}
		},
		skills: {
			/** Rank prices are incremental fish purchases; rank gates use character level. */
			rankFish: [
				24,
				58,
				126
			],
			unlockLevels: [
				2,
				5,
				9
			],
			entries: {
				seamsweep: {
					name: "Seamlight Sweep",
					description: "Draw a bright seam across one nearby foe.",
					weaponType: "sword",
					trigger: "cooldown",
					every: 9e3,
					effect: "damage",
					hits: 1,
					perRank: [
						1.2,
						1.5,
						1.8
					]
				},
				kettlepulse: {
					name: "Kettlefall Pulse",
					description: "Release the stored ring of seven deliberate swings.",
					weaponType: "hammer",
					trigger: "attacks",
					every: 7,
					effect: "damage",
					hits: 1,
					perRank: [
						1.4,
						1.7,
						2
					]
				},
				hempair: {
					name: "Hemskip Pair",
					description: "Slip two quick cuts through the same opening.",
					weaponType: "daggers",
					trigger: "attacks",
					every: 9,
					effect: "damage",
					hits: 2,
					perRank: [
						.55,
						.68,
						.82
					]
				},
				windowthrust: {
					name: "Windowline Thrust",
					description: "Place a measured jab beyond the nearest pawhold.",
					weaponType: "spear",
					trigger: "cooldown",
					every: 11e3,
					effect: "damage",
					hits: 1,
					perRank: [
						1.65,
						1.95,
						2.3
					]
				},
				rafterecho: {
					name: "Rafter Echo",
					description: "Send a second note along the path of the first arrow.",
					weaponType: "bow",
					trigger: "attacks",
					every: 8,
					effect: "damage",
					hits: 2,
					perRank: [
						.6,
						.75,
						.9
					]
				},
				lanternarc: {
					name: "Lanternwake Arc",
					description: "Gather a patient glow and spill it onto one foe.",
					weaponType: "staff",
					trigger: "cooldown",
					every: 12e3,
					effect: "damage",
					hits: 1,
					perRank: [
						1.9,
						2.2,
						2.6
					]
				},
				mossparcel: {
					name: "Mossfoam Parcel",
					description: "Unwrap a cool poultice to mend your own scrapes.",
					weaponType: "flasks",
					trigger: "cooldown",
					every: 15e3,
					effect: "heal",
					hits: 1,
					perRank: [
						.06,
						.085,
						.11
					]
				}
			}
		},
		rewards: {
			/** Fixed early-loop benchmark, not a replacement for stage/monster rewards. */
			fishPerSecond: .42,
			killIntervalSeconds: 6,
			gearDropChance: .028,
			offlineEfficiency: .55,
			offlineCapSeconds: 21600
		}
	},
	/** Client presentation only. No grants, drops or server combat rules depend on these. */
	gameplay: {
		firstClaimMs: 1e4,
		claimIntervalMs: 18e3,
		closeCallHpFraction: .2,
		greatRollThreshold: .8,
		keyStats: 3,
		coachSteps: 3,
		juice: {
			maxParticles: 16,
			maxTweens: 32,
			maxLabels: 12,
			maxProjectiles: 8,
			critStopMs: 60,
			maxShakePx: 2,
			flashMs: 70,
			chipTrailMs: 650,
			anticipationMs: 180,
			settleMs: 480,
			labelMs: 650,
			calmLabelMs: 220,
			shakeMs: 80,
			resourceGainMs: 900,
			burstNormal: 3,
			burstCrit: 6,
			burstDefeat: 8
		},
		actor: {
			idleFrameMs: [
				700,
				180,
				120,
				180,
				600,
				100,
				120,
				200
			],
			napFrameMs: 1400,
			equipFrameMs: [
				100,
				140,
				140,
				180
			],
			napAfterMs: 12e3
		}
	},
	/** Default-off, local-only Sample adventure. Never used by server grants or replay. */
	cafe: {
		version: 1,
		seed: 1105,
		tickMs: 1e3,
		maxStepSeconds: 3600,
		saveEverySeconds: 5,
		firstFindSeconds: 8,
		encounterSeconds: 16,
		decisionSeconds: 8,
		bossGate: 8,
		maxLog: 80,
		maxItems: 48,
		maxPatches: 999,
		startingPatches: 4,
		gatherPatches: 2,
		riskPatches: 5,
		riskChance: .6,
		riskConsolation: 1,
		encounters: {
			swiftChance: .5,
			swiftPatches: 7,
			thiefChance: .75,
			thiefPatches: 4,
			hazardChance: .4,
			hazardPatches: 7,
			hazardInsight: 2,
			armorBonus: 1
		},
		luckyCapPerTour: 6,
		luckyExtra: 2,
		itemEvery: 2,
		maxInsight: 3,
		insightDamage: .08,
		encounterXp: 2,
		bossXp: 12,
		questXp: 6,
		questPatches: 2,
		hero: {
			hp: 160,
			damage: 13,
			guard: .35,
			guardCap: .7,
			regenCap: 5,
			pounceMultiplier: 2.4,
			pounceCooldown: 8
		},
		gear: {
			baseDamage: 2,
			baseHp: 6,
			chapterDamage: 1,
			chapterHp: 3,
			levelDamage: 1,
			levelHp: 4,
			maxLevel: 3,
			keenDamage: 3,
			cushionedHp: 18,
			steadyGuard: .04,
			luckyPatches: 1,
			fineChance: .28,
			brightChance: .08,
			fineMultiplier: 1.2,
			brightMultiplier: 1.4
		},
		sets: {
			two: 2,
			three: 3,
			four: 4,
			emberDamage: .18,
			emberCooldown: 2,
			emberExposure: .5,
			mossHp: .2,
			mossRegen: 2,
			mossGuard: .12,
			starPatches: 1,
			starLuck: .1
		},
		forge: {
			craftCost: 8,
			steadyCost: 6,
			sparkCost: 3,
			sparkChance: .55,
			sparkLevels: 2,
			pityMisses: 3
		},
		boss: {
			hp: [
				480,
				2200,
				3400,
				4800,
				6600
			],
			damage: [
				25,
				38,
				49,
				63,
				78
			],
			variance: .08,
			shieldReduction: .55,
			phaseThresholds: [.67, .34],
			phaseDamage: [
				1,
				1.12,
				1.25
			],
			windupSeconds: 3,
			finalWindupSeconds: 2,
			recoverySeconds: 2,
			enrageSeconds: 55,
			enrageDamage: 1.7,
			maxSeconds: 90,
			correctExposureSeconds: 2,
			exposureDamage: .4,
			retrySeconds: 3,
			closeCallFraction: .2,
			firstRewardPatches: 8,
			repeatRewardPatches: 2
		},
		tiers: [
			{
				id: "cozy",
				name: "Cozy",
				hp: 1,
				damage: 1,
				quality: 0
			},
			{
				id: "spirited",
				name: "Spirited",
				hp: 1.25,
				damage: 1.15,
				quality: .1
			},
			{
				id: "daring",
				name: "Daring",
				hp: 1.55,
				damage: 1.35,
				quality: .2
			}
		],
		assist: {
			afterLosses: 2,
			damageReduction: .15,
			hpReduction: .1
		},
		mastery: {
			xpPerLevel: 40,
			maxLevel: 5,
			damagePerLevel: .02,
			hpPerLevel: .03,
			scoutPatches: 1
		},
		tour: {
			unlockClears: 3,
			maxBonusTours: 3,
			damagePerTour: .05
		},
		away: {
			minSeconds: 60,
			capSeconds: 7200,
			secondsPerPatch: 120,
			maxPatches: 30
		},
		quests: {
			patrol: 6,
			variety: 4,
			counters: 3,
			crafts: 2,
			boss: 1,
			perfect: 1,
			tour: 1
		},
		debug: {
			seconds: 60,
			patches: 80
		}
	},
	/** Gear slots, in display order (content.ts). */
	slots: [
		{ id: "weapon" },
		{ id: "helm" },
		{ id: "armor" },
		{ id: "ring" }
	].map((s) => s.id),
	/** Rarity tiers, lowest to highest (content.ts). */
	rarities: [
		{
			id: "common",
			relicId: 1
		},
		{
			id: "rare",
			relicId: 2
		},
		{
			id: "epic",
			relicId: 3
		},
		{
			id: "legendary",
			relicId: 4
		}
	].map((r) => r.id),
	hero: {
		/** Power of a naked hero. */
		basePower: 10,
		/** Hero hit points per point of power (boss fight). */
		hpPerPower: 12,
		/** Damage per second per point of power (boss fight). */
		damagePerPower: 1,
		/** Chance of a critical hit per boss-fight round. */
		critChance: .15,
		/** Damage multiplier on a critical hit. */
		critMultiplier: 2
	},
	gear: {
		/** Base stat (power) of a level 1 Common item, per slot. */
		baseStat: {
			weapon: 8,
			helm: 4,
			armor: 5,
			ring: 3
		},
		/** Stat multiplier per rarity. */
		rarityMultiplier: {
			common: 1,
			rare: 1.6,
			epic: 2.6,
			legendary: 4.2
		},
		/** Extra stat per item level above 1, as a fraction of the base stat. */
		levelGrowth: .12,
		/** Highest item level (drops and upgrades). */
		maxLevel: 30,
		/** Gold to upgrade an item from level 1 to 2. */
		upgradeBaseCost: 25,
		/** Cost growth per level. */
		upgradeCostGrowth: 1.3,
		/** Gold cost multiplier per rarity (better items cost more to upgrade). */
		upgradeRarityCostMultiplier: {
			common: 1,
			rare: 1.5,
			epic: 2.5,
			legendary: 4
		}
	},
	idle: {
		/** Gold per second with zero power. */
		baseGoldPerSecond: 1,
		/** Extra gold per second per point of power. */
		goldPerSecondPerPower: .1,
		/** Seconds per enemy kill. Drops and shards roll once per kill. */
		secondsPerKill: 4,
		/** Maximum seconds of progress counted in one claim. */
		offlineCapSeconds: 28800,
		/** Share of gold/shards/drops earned while offline (0..1). */
		offlineEfficiency: .5,
		/** Seconds at the start of each claim paid at the full rate; the rest is offline. */
		onlineWindowSeconds: 300,
		/** Chance a kill drops a gear item. */
		gearDropChance: .05,
		/** Chance a kill drops shards. */
		shardDropChance: .1,
		/** Shards dropped when a shard drop happens. */
		shardsPerDrop: 1,
		/** Max gear items returned from a single claim (best kept). */
		maxDropsPerClaim: 40,
		/** Gear drop rarity weights (relative, need not sum to 1). */
		dropRarityWeights: {
			common: 70,
			rare: 22,
			epic: 7,
			legendary: 1
		}
	},
	boss: {
		/** Boss power at level 1. */
		basePower: 62,
		/** Boss power growth per level (multiplicative). */
		powerGrowth: 1.15,
		/** Boss hit points per point of boss power. */
		hpPerPower: 14,
		/** Boss damage per second per point of boss power. */
		damagePerPower: 1,
		/** Damage roll spread, each round multiplied by 1 +/- this. */
		damageSpread: .2,
		/** Fight is lost if the boss survives this many rounds (1 round = 1 s). */
		maxRounds: 60,
		/** Highest boss level. */
		maxLevel: 50,
		/** Boss fights allowed per day (UTC+7). */
		maxAttemptsPerDay: 5
	},
	relic: {
		/** Shards needed to forge one Relic. */
		shardCost: 30,
		/** Boss Keys needed to forge one Relic. */
		bossKeyCost: 1,
		/** Rarity odds in basis points (1/100 of a percent); must sum to 10000. */
		rarityOddsBp: {
			common: 6e3,
			rare: 2800,
			epic: 1e3,
			legendary: 200
		}
	},
	time: {
		/** Seconds per forge/boss-key day. */
		secondsPerDay: 86400,
		/** The day resets at midnight Vietnam time (UTC+7). */
		dayOffsetSeconds: 25200
	},
	/** Tuning-target check used by tests: active play window in seconds. */
	tuning: {
		targetMinSeconds: 600,
		targetMaxSeconds: 900,
		minWinProbability: .5
	}
};
// packages/game-rules/src/cardrpg/state.ts
/** Internal draft builder; deliberately excluded from the public pure API. */
function makeItem(state, itemId, source) {
	const template = ITEMS.find((i) => i.id === itemId);
	if (!template) throw new Error(`Unknown item ${itemId}`);
	return {
		id: `item-${state.nextId++}`,
		itemId,
		level: 1,
		enhancement: 0,
		affixes: template.affixes.map((a) => ({ ...a })),
		locked: false,
		favourite: false,
		soulbound: true,
		source,
		reforgeCount: 0
	};
}
function createStarterAccount(seed = 11) {
	const s = {
		version: CONTRACT_VERSION$1,
		seed: seed >>> 0,
		nextId: 1,
		day: 1,
		accountXp: 0,
		accountLevel: 1,
		chapter: 1,
		currencies: { ...CARD_RPG_CONFIG.starterBalances },
		cards: [
			"mochi",
			"soot",
			"clover"
		].map((cardId) => ({
			id: cardId,
			cardId,
			level: 1,
			stars: 1,
			shards: 0,
			soulbound: true
		})),
		inventory: {
			items: [],
			stacks: { "pantry-key": 1 }
		},
		loadouts: {},
		teams: [{
			id: "team-1",
			name: "Cafe Opening Shift",
			cardIds: [
				"mochi",
				"soot",
				"clover"
			]
		}],
		activeTeamId: "team-1",
		pity: {},
		history: [],
		quests: Object.fromEntries(QUESTS.map((q) => [q.id, {
			progress: 0,
			claimed: false
		}])),
		claimedBattleIds: [],
		clearedChapters: [],
		daily: {
			battles: 0,
			service: 0,
			draws: 0,
			earned: {
				fish: 0,
				threads: 0,
				stamps: 0,
				essence: 0
			}
		},
		scarcity: Object.fromEntries(SCARCITY.map((x) => [x.id, { ...x }])),
		designClaims: [],
		nextRunId: 1,
		pendingRun: null
	};
	for (const card of s.cards) {
		const set = {
			guardian: "hearthloom",
			witch: "moonwick",
			alchemist: "mossbrew"
		}[CARD_BY_ID[card.cardId].role];
		const weapon = makeItem(s, `${set}-weapon-common`, "starter"), outfit = makeItem(s, `${set}-outfit-common`, "starter");
		s.inventory.items.push(weapon, outfit);
		s.loadouts[card.id] = {
			weapon: weapon.id,
			outfit: outfit.id
		};
	}
	return s;
}
// packages/game-rules/src/cardrpg/progression.ts
function previewForge(s, recipeId) {
	return preview(() => {
		noBattle(s);
		const r = RECIPES.find((r) => r.id === recipeId);
		requireRule(r, "UNKNOWN_ID", "Recipe not found.");
		requireRule(s.chapter >= r.requiredChapter, "NOT_READY", "Clear the first chapter to unlock this recipe.");
		afford(s, r.cost);
		for (const [id, amount] of Object.entries(r.materials)) requireRule((s.inventory.stacks[id] ?? 0) >= amount, "INSUFFICIENT_FUNDS", `Need ${amount} ${id}.`);
		if (r.outputStackId === "cafe-ribbon") requireRule(!s.inventory.stacks[r.outputStackId], "ALREADY_CLAIMED", "The ribbon is already in your collection.");
		if (r.scarcityId) {
			const x = s.scarcity[r.scarcityId];
			requireRule(x, "UNKNOWN_ID", "Design series not found.");
			requireRule(!s.designClaims.includes(x.id), "ALREADY_CLAIMED", "One design eligibility per account and series this season.");
			requireRule(integer$1(x.issuedDesign, 0, x.globalCap) && integer$1(x.seasonIssuedDesign, 0, x.seasonCap), "SUPPLY_CAP", "Invalid design supply counters.");
			requireRule(x.issuedDesign < x.globalCap && x.seasonIssuedDesign < x.seasonCap, "SUPPLY_CAP", "This design series has no remaining issuance.");
		}
		return r;
	});
}
function forge(state, recipeId) {
	return transact(state, (s, events) => {
		const p = previewForge(s, recipeId);
		requireRule(p.ok, p.ok ? "NOT_READY" : p.error.code, p.ok ? "" : p.error.message);
		const r = p.value;
		spend(s, r.cost);
		for (const [id, amount] of Object.entries(r.materials)) s.inventory.stacks[id] -= amount;
		if (r.scarcityId) {
			const x = s.scarcity[r.scarcityId];
			x.issuedDesign++;
			x.seasonIssuedDesign++;
			s.designClaims.push(x.id);
			events.push({
				type: "relic.designClaimed",
				scarcityId: x.id,
				notice: CHAIN_NOTICE
			});
			return x.id;
		}
		const id = r.outputItemId ? (() => {
			const i = makeItem(s, r.outputItemId, "forge");
			s.inventory.items.push(i);
			return i.id;
		})() : r.outputStackId;
		if (r.outputStackId) s.inventory.stacks[r.outputStackId] = (s.inventory.stacks[r.outputStackId] ?? 0) + 1;
		events.push({
			type: "item.forged",
			id
		});
		return id;
	});
}
function claimQuest(state, questId) {
	return transact(state, (s, events) => {
		const q = QUESTS.find((q) => q.id === questId), p = s.quests[questId];
		requireRule(q && p, "UNKNOWN_ID", "Quest not found.");
		requireRule(!p.claimed, "ALREADY_CLAIMED", "Quest reward already claimed.");
		requireRule(p.progress >= q.target, "NOT_READY", "Quest objectives are incomplete.");
		p.claimed = true;
		const reward = grant(s, q.reward, q.cadence !== "achievement", events);
		events.push({
			type: "reward.claimed",
			id: q.id,
			reward
		});
		return reward;
	});
}
function advanceLocalDay(state) {
	return transact(state, (s, events) => {
		noBattle(s);
		s.day++;
		s.daily = {
			battles: 0,
			service: 0,
			draws: 0,
			earned: {
				fish: 0,
				threads: 0,
				stamps: 0,
				essence: 0
			}
		};
		for (const q of QUESTS) if (q.cadence === "daily" || q.cadence === "weekly" && (s.day - 1) % 7 === 0) s.quests[q.id] = {
			progress: 0,
			claimed: false
		};
		events.push({
			type: "day.advanced",
			day: s.day
		});
	});
}
function claimCafeService(state, minutes) {
	return transact(state, (s, events) => {
		noBattle(s);
		requireRule(integer$1(minutes, CARD_RPG_CONFIG.service.minutesPerClaim), "INVALID_AMOUNT", "Cafe service needs at least ten whole minutes.");
		const claims = Math.min(Math.floor(minutes / CARD_RPG_CONFIG.service.minutesPerClaim), CARD_RPG_CONFIG.service.maxClaims - s.daily.service);
		requireRule(claims > 0, "DAILY_CAP", "Both local cafe services are complete.");
		s.daily.service += claims;
		progress(s, "service", claims);
		const reward = grant(s, {
			currencies: Object.fromEntries(Object.entries(CARD_RPG_CONFIG.service.reward).map(([k, v]) => [k, v * claims])),
			xp: 0
		}, true, events);
		events.push({
			type: "reward.claimed",
			id: `service-day-${s.day}-${s.daily.service}`,
			reward
		});
		return reward;
	});
}
function selectTeam(state, cardIds) {
	return transact(state, (s) => {
		noBattle(s);
		requireRule(cardIds.length === 3 && new Set(cardIds).size === 3, "INVALID_TEAM", "Choose three different cats.");
		const cards = cardIds.map((id) => s.cards.find((c) => c.id === id));
		requireRule(cards.every(Boolean), "INVALID_TEAM", "Every team member must be owned.");
		requireRule(new Set(cards.map((c) => CARD_BY_ID[c.cardId].role)).size === 3, "INVALID_TEAM", "Choose one guardian, one witch and one alchemist.");
		const t = s.teams.find((t) => t.id === s.activeTeamId);
		t.cardIds = [...cardIds];
	});
}
function exchangeShards(state, cardId, batches) {
	return transact(state, (s, events) => {
		noBattle(s);
		requireRule(integer$1(batches, 1, 12), "INVALID_AMOUNT", "Exchange one to twelve batches.");
		const card = s.cards.find((c) => c.id === cardId);
		requireRule(card, "UNKNOWN_ID", "Cat not found.");
		requireRule(card.stars === CARD_RPG_CONFIG.level.maxStars, "NOT_READY", "Reach five stars before exchanging spare shards.");
		requireRule(card.shards >= batches * CARD_RPG_CONFIG.shardExchange.shards, "INSUFFICIENT_FUNDS", "Not enough spare shards.");
		requireRule(s.daily.earned.essence + batches * CARD_RPG_CONFIG.shardExchange.essence <= CARD_RPG_CONFIG.dailyCaps.essence, "DAILY_CAP", "Daily essence cap reached.");
		card.shards -= batches * CARD_RPG_CONFIG.shardExchange.shards;
		const reward = grant(s, {
			currencies: { essence: batches * CARD_RPG_CONFIG.shardExchange.essence },
			xp: 0
		}, true, events);
		events.push({
			type: "reward.claimed",
			id: "spare-shards",
			reward
		});
		return reward;
	});
}
/** Pure preview. Older A6 saves acquire this optional record only on a mutation. */
function dailyProgressA6(s) {
	const day = s.account.day, week = Math.floor((day - 1) / 7), old = s.dailyA6;
	return {
		day,
		week,
		completed: old?.day === day ? [...old.completed] : [],
		claimed: old?.day === day ? [...old.claimed] : [],
		weeklyPoints: old?.week === week ? old.weeklyPoints : 0,
		weeklyClaims: old?.week === week ? [...old.weeklyClaims] : [],
		loginDay: old?.loginDay ?? 0,
		loginGifts: old?.loginGifts ?? 0
	};
}
/** Successful public mutations mark activities once; no previews or OFF saves change. */
function observeDailyA6(before, after) {
	if (!after.gameplayA6) return;
	const p = dailyProgressA6(after);
	const mark = (task) => {
		if (!p.completed.includes(task)) p.completed.push(task);
	};
	if (after.run?.complete && after.run.won && (!before.run?.complete || before.run.id !== after.run.id)) mark("patrol");
	if (after.account.daily.service > (before.account.day === after.account.day ? before.account.daily.service : 0)) mark("tips");
	if (after.account.daily.draws > (before.account.day === after.account.day ? before.account.daily.draws : 0) || after.freeInvite && !before.freeInvite) mark("recruit");
	if (after.account.cards.some((c) => c.level > (before.account.cards.find((old) => old.id === c.id)?.level ?? c.level))) mark("train");
	if (after.gear.some((g) => g.enhancement > (before.gear.find((old) => old.id === g.id)?.enhancement ?? g.enhancement))) mark("gear");
	after.dailyA6 = p;
}
// packages/game-rules/src/cardrpg/depth/items-v4.ts
var SUPPLY_IDS_V4 = [
	"milk-tonic",
	"shield-biscuit",
	"quicken-yarn",
	"cleanse-tea",
	"ultimate-treat"
];
var SUPPLY_TEXT_V4 = {
	"milk-tonic": "Restore up to 100 missing HP to one living companion between encounters.",
	"shield-biscuit": "Pack 20 opening shield for the next encounter.",
	"quicken-yarn": "Pack one opening Cozy stack for the next encounter.",
	"cleanse-tea": "Clear the first successfully applied debuff in the next encounter.",
	"ultimate-treat": "Restore 12 missing HP after the first automatic ultimate in the next encounter."
};
function stackCapV4(id) {
	return id === "pantry-key" ? 99 : id === "cafe-ribbon" ? 1 : SUPPLY_IDS_V4.includes(id) ? 20 : Number.MAX_SAFE_INTEGER;
}
/** Reserve one supply now; replacing/cancelling returns the unspent reservation. */
function packSupplyV4(state, id, catId) {
	return transactDepth(state, (s) => {
		const run = s.run;
		requireRule(gameplayV4(s) && run && !run.complete && !run.battle, "NOT_READY", "Pack supplies between encounters, before opening Prepare.");
		if (id === null) {
			if (run.packedSupply) {
				const old = run.packedSupply;
				s.account.inventory.stacks[old.id] = (s.account.inventory.stacks[old.id] ?? 0) + 1;
				delete run.packedSupply;
			}
			return;
		}
		requireRule(SUPPLY_IDS_V4.includes(id), "UNKNOWN_ID", "Choose an available pantry supply.");
		const cat = battleCats(s).find((c) => c.id === catId);
		requireRule(cat && (run.hp[catId] ?? 0) > 0, "INVALID_TEAM", "Choose a living member of this crew.");
		if (id === "milk-tonic") {
			requireRule((run.hp[catId] ?? 0) < cat.stats.hp, "NOT_READY", "This companion has no missing HP.");
			requireRule((s.account.inventory.stacks[id] ?? 0) > 0, "INSUFFICIENT_FUNDS", "No milk tonic remains.");
			s.account.inventory.stacks[id]--;
			run.hp[catId] = Math.min(cat.stats.hp, run.hp[catId] + 100);
			return;
		}
		if (run.packedSupply) {
			const old = run.packedSupply;
			s.account.inventory.stacks[old.id] = (s.account.inventory.stacks[old.id] ?? 0) + 1;
		}
		requireRule((s.account.inventory.stacks[id] ?? 0) > 0, "INSUFFICIENT_FUNDS", "No supply remains. The previous preparation is unchanged.");
		s.account.inventory.stacks[id]--;
		run.packedSupply = {
			id,
			catId
		};
	});
}
function itemCatalogueV4() {
	return STACK_ITEMS.map((item) => ({
		...item,
		cap: stackCapV4(item.id),
		description: SUPPLY_TEXT_V4[item.id] ?? item.description,
		source: item.id === "boss-proof" ? "Legacy-only stack; new boss rewards use the seals counter." : item.source,
		sink: SUPPLY_IDS_V4.includes(item.id) ? "Before an encounter" : item.sink
	}));
}
// packages/game-rules/src/cardrpg/depth/idle-a6.ts
var MINUTE = 6e4;
var DAY = 864e5;
/** Progress comes from earned combat stars, including an unfinished chapter. */
function idleStageA6(s) {
	return Math.max(0, ...s.cleared.map((c) => c * 7), ...Object.values(s.v4?.journey?.stars ?? {}).filter((r) => r.conditions[0] && [
		"battle",
		"elite",
		"boss"
	].includes(r.kind)).map((r) => (r.chapter - 1) * 7 + Number(r.nodeId.split("-")[0]) + 1));
}
function idleChestA6(s, now, fast = false) {
	const floor = Math.max(s.idle.lastAt, s.v4?.clockWatermark ?? 0, (s.idle.dayKey ?? 0) * DAY);
	const rollback = !Number.isSafeInteger(now) || now < floor, effective = rollback ? floor : now;
	const previousDay = s.idle.dayKey ?? Math.floor(s.idle.lastAt / DAY);
	const refreshed = Math.floor(effective / DAY) > previousDay ? syncCalendarDay(s, effective) : null;
	const state = refreshed?.ok ? refreshed.state : s;
	const day = Math.floor(effective / DAY), used = state.idle.a6?.fastDay === day ? state.idle.a6.fastClaims : 0;
	const elapsed = Math.min(43200, Math.max(0, Math.floor((effective - s.idle.lastAt) / 1e3)));
	const minutes = fast ? 60 : Math.floor(elapsed / 60), stage = idleStageA6(s);
	const requested = {
		fish: Math.floor(minutes * (1 + stage * .08)),
		threads: Math.floor(minutes * (.15 + stage * .01)),
		stamps: Math.floor(minutes * (.25 + stage * .015))
	};
	const reward = cappedPreviewV4(state, requested);
	const remaining = Math.max(0, 2 - used);
	const reason = !gameplayA6(s) ? "Open A6 first." : rollback ? "Wait for the cafe clock to catch up." : s.run && !s.run.complete ? "Finish your patrol first." : fast && !remaining ? "Two fast rewards collected. More tomorrow." : !fast && minutes < 10 ? "Tips are ready every ten minutes." : !Object.values(reward).some((n) => n > 0) ? "Today’s supplies are full. Your tips can wait." : null;
	return {
		elapsed,
		effectiveMinutes: minutes,
		claims: reason ? 0 : 1,
		capHours: 12,
		remaining,
		requested,
		reward,
		rollback,
		now: effective,
		readyAt: Math.max(effective, s.idle.lastAt + 10 * MINUTE),
		stage,
		reason
	};
}
function claimIdleA6(state, now, fast = false) {
	return transactDepth(state, (s) => {
		requireHome(s);
		const p = idleChestA6(s, now, fast);
		requireRule(!p.reason, "NOT_READY", p.reason ?? "");
		const refreshed = syncCalendarDay(s, now);
		requireRule(refreshed.ok, "NOT_READY", "The cafe calendar is unavailable.");
		Object.assign(s, refreshed.state);
		grantDepth(s, p.reward);
		if (fast) s.idle.a6 = {
			fastDay: Math.floor(now / DAY),
			fastClaims: 2 - p.remaining + 1
		};
		else {
			s.idle.lastAt = now;
			s.account.daily.service = Math.min(2, s.account.daily.service + 1);
			progress(s.account, "service");
		}
		s.v4.clockWatermark = now;
	});
}
// packages/game-rules/src/cardrpg/depth/meta-v4.ts
function journalV4(s) {
	const journal = s.v4?.journal ?? {
		cats: [],
		gear: [],
		sets: [],
		rewardedRoutes: 0,
		claims: []
	};
	const cats = [.../* @__PURE__ */ new Set([...journal.cats, ...s.account.cards.map((c) => c.cardId)])];
	const gear = [.../* @__PURE__ */ new Set([...journal.gear, ...s.gear.map((i) => i.templateId)])];
	const sets = [...journal.sets];
	for (const slots of Object.values(s.equipment)) {
		const worn = Object.values(slots).map((id) => s.gear.find((i) => i.id === id)).filter(Boolean);
		if (worn.length === 4 && new Set(worn.map((i) => GEAR_BY_ID[i.templateId].setId)).size === 1) {
			const set = GEAR_BY_ID[worn[0].templateId].setId;
			if (!sets.includes(set)) sets.push(set);
		}
	}
	return {
		cats,
		gear,
		sets,
		rewardedRoutes: journal.rewardedRoutes,
		claims: [...journal.claims]
	};
}
/** Called before and after successful public mutations so salvaging never erases discovery. */
function observeCollectionV4(s) {
	if (gameplayV4(s) && s.v4) s.v4.journal = journalV4(s);
}
var MILESTONES_V4 = [
	{
		id: "six-cats",
		name: "Six seats at the table",
		target: 6,
		kind: "cats",
		reward: { stamps: 60 }
	},
	{
		id: "twelve-templates",
		name: "A shelf of possibilities",
		target: 12,
		kind: "gear",
		reward: { threads: 40 }
	},
	{
		id: "first-set",
		name: "A matching shift",
		target: 1,
		kind: "sets",
		reward: { fish: 80 }
	},
	{
		id: "three-chapters",
		name: "Every evening explored",
		target: 3,
		kind: "chapters",
		reward: {}
	},
	{
		id: "ten-routes",
		name: "Ten evenings of effort",
		target: 10,
		kind: "routes",
		reward: { stamps: 60 }
	}
];
function cappedPreviewV4(s, requested) {
	return Object.fromEntries(Object.entries(requested).map(([id, n]) => [id, Math.max(0, Math.min(n, depthCaps(s)[id] - s.account.daily.earned[id]))]));
}
function milestonePreviewV4(s, id) {
	const milestone = MILESTONES_V4.find((m) => m.id === id);
	requireRule(milestone, "UNKNOWN_ID", "Choose a journal milestone.");
	const journal = journalV4(s), progress = milestone.kind === "chapters" ? s.cleared.length : milestone.kind === "routes" ? journal.rewardedRoutes : journal[milestone.kind].length;
	const ribbon = id === "three-chapters" && !s.account.inventory.stacks["cafe-ribbon"];
	const requested = id === "three-chapters" ? ribbon ? {} : { threads: 20 } : milestone.reward;
	const reward = cappedPreviewV4(s, requested), hasReward = ribbon || Object.values(reward).some((n) => n > 0), claimed = journal.claims.includes(id);
	const reason = !gameplayV4(s) ? "Enable Gameplay v4 first." : s.run && !s.run.complete ? "Finish your route first." : claimed ? "Already collected." : progress < milestone.target ? "Keep collecting and exploring." : !hasReward ? "Daily reward space is full. Keep this claim for a later day." : null;
	return {
		...milestone,
		progress,
		claimed,
		requested,
		reward,
		ribbon,
		reason
	};
}
function claimMilestoneV4(state, id) {
	return transactDepth(state, (s) => {
		requireHome(s);
		const preview = milestonePreviewV4(s, id);
		requireRule(!preview.reason, "NOT_READY", preview.reason ?? "");
		grantDepth(s, preview.reward);
		if (preview.ribbon) s.account.inventory.stacks["cafe-ribbon"] = 1;
		s.v4.journal = journalV4(s);
		s.v4.journal.claims.push(id);
	});
}
function boardPreviewV4(s, id) {
	const quest = QUESTS.find((q) => q.id === id);
	requireRule(quest, "UNKNOWN_ID", "Choose a board task.");
	const progress = s.account.quests[id], reward = cappedPreviewV4(s, quest.reward.currencies), stacks = quest.reward.stacks ?? {};
	const fullStack = Object.entries(stacks).some(([id, n]) => (s.account.inventory.stacks[id] ?? 0) + n > stackCapV4(id));
	const useful = Object.values(reward).some((n) => n > 0) || Object.values(stacks).some((n) => n > 0);
	return {
		quest,
		progress,
		reward,
		stacks,
		reason: progress.claimed ? "Already collected." : progress.progress < quest.target ? "Complete this task first." : fullStack ? "Use an item before claiming this full stack." : !useful ? "Daily reward space is full. The reward remains available." : null
	};
}
/** Within the existing meta-command draft; board is the existing quest reward source. */
function settleBoardV4(s, id) {
	const preview = boardPreviewV4(s, id);
	requireRule(!preview.reason, "NOT_READY", preview.reason ?? "");
	grantDepth(s, preview.reward, preview.quest.reward.xp);
	for (const [key, n] of Object.entries(preview.stacks)) s.account.inventory.stacks[key] = (s.account.inventory.stacks[key] ?? 0) + n;
	s.account.quests[id].claimed = true;
}
function cafeShiftV4(s, now) {
	if (gameplayA6(s)) return idleChestA6(s, now);
	const floor = Math.max(s.idle.lastAt, s.v4?.clockWatermark ?? 0, (s.idle.dayKey ?? 0) * 864e5), rollback = !Number.isSafeInteger(now) || now < floor;
	const effective = rollback ? floor : now;
	const state = Math.floor(effective / 864e5) > (s.idle.dayKey ?? Math.floor(s.idle.lastAt / 864e5)) ? syncCalendarDay(s, effective).state : s, preview = idlePreview(state, effective);
	const claims = rollback ? 0 : preview.claims, reward = cappedPreviewV4(state, Object.fromEntries(Object.entries(CARD_RPG_CONFIG.service.reward).map(([id, n]) => [id, n * claims])));
	let readyAt = effective;
	if (!claims) {
		const remaining = 2 - state.account.daily.service;
		const nextState = remaining > 0 ? state : {
			...state,
			account: {
				...state.account,
				daily: {
					...state.account.daily,
					service: 0
				}
			}
		};
		let low = remaining > 0 ? effective : (Math.floor(effective / 864e5) + 1) * 864e5, high = low + 864e5;
		if (idlePreview(nextState, low).claims > 0) readyAt = low;
		else {
			while (high - low > 1e3) {
				const mid = Math.floor((low + high) / 2);
				if (idlePreview(nextState, mid).claims > 0) high = mid;
				else low = mid;
			}
			readyAt = high;
		}
	}
	return {
		...preview,
		claims,
		reward,
		rollback,
		remaining: Math.max(0, 2 - state.account.daily.service),
		now: effective,
		readyAt
	};
}
function claimCafeShiftV4(state, now) {
	if (gameplayA6(state)) return claimIdleA6(state, now);
	return transactDepth(state, (s) => {
		requireHome(s);
		requireRule(gameplayV4(s), "NOT_READY", "Enable Gameplay v4 first.");
		const preview = cafeShiftV4(s, now);
		requireRule(!preview.rollback && preview.claims > 0, "NOT_READY", "Wait for the next useful cafe service.");
		requireRule(Object.values(preview.reward).some((n) => n > 0), "DAILY_CAP", "Daily reward space is full. Your service is not consumed.");
		const refreshed = syncCalendarDay(s, now);
		requireRule(refreshed.ok, "NOT_READY", refreshed.error ?? "Calendar refresh unavailable.");
		const result = claimIdleService(refreshed.state, now);
		requireRule(result.ok, "NOT_READY", result.error ?? "Service unavailable.");
		Object.assign(s, result.state);
		s.v4.clockWatermark = now;
	});
}
function validateJournalV4(s) {
	const j = s.v4?.journal;
	if (j === void 0) return;
	requireRule(!!j && typeof j === "object", "INVALID_AMOUNT", "Invalid collection journal.");
	for (const [entries, allowed] of [
		[j.cats, CARDS.map((c) => c.id)],
		[j.gear, GEAR.map((g) => g.id)],
		[j.sets, SETS.map((s) => s.id)],
		[j.claims, MILESTONES_V4.map((m) => m.id)]
	]) requireRule(Array.isArray(entries) && new Set(entries).size === entries.length && entries.every((x) => allowed.includes(x)), "INVALID_AMOUNT", "Invalid collection journal.");
	requireRule(Number.isSafeInteger(j.rewardedRoutes) && j.rewardedRoutes >= 0, "INVALID_AMOUNT", "Invalid rewarded-route history.");
}
var LESSONS_V4 = [
	{
		id: "front",
		title: "One sturdy front row",
		text: "Keep a guardian in front. Rear companions gain cover while the front holds.",
		action: "Arrange your crew",
		screen: "team"
	},
	{
		id: "intent",
		title: "Read one opponent",
		text: "Look for the next enemy signature before Fight. Hush can stop a healer; cleanse answers Tangle.",
		action: "Read the field guide",
		screen: "codex"
	},
	{
		id: "gear",
		title: "One piece, one purpose",
		text: "Compare an item’s stats and utility before equipping it. A matching set adds a bounded team effect.",
		action: "Compare equipment",
		screen: "inventory"
	},
	{
		id: "invite",
		title: "Invitations you earn",
		text: "Each earned invitation adds one selector mark. Save 24 marks to choose a companion. Welcome invitations add none.",
		action: "Review invitation odds",
		screen: "gacha"
	}
];
function currentLessonV4(s) {
	return s.account.day >= 7 ? null : LESSONS_V4.find((l) => !s.v4?.lessons?.includes(l.id)) ?? null;
}
function finishLessonV4(state, id) {
	return transactDepth(state, (s) => {
		requireHome(s);
		requireRule(gameplayV4(s) && !!s.v4 && LESSONS_V4.some((l) => l.id === id), "NOT_READY", "Choose a current cafe lesson.");
		requireRule(currentLessonV4(s)?.id === id, "NOT_READY", "That lesson is already complete or not next.");
		s.v4.lessons ??= [];
		s.v4.lessons.push(id);
	});
}
/** First-week suggestions, not calendar unlocks or guaranteed drops. No saved state. */
function firstWeekV4(s) {
	if (!gameplayV4(s)) return null;
	const goals = [
		"Place a sturdy companion in front. Try the practice table.",
		"Compare a spare piece. Equip the one that helps your crew.",
		"Spend earned stamps on an invitation. Save marks for your choice.",
		"Try a different crew job. Choose its standing plan before fighting.",
		"Save your favourite shift. Try another piece without losing your setup.",
		"Read the next boss’s guide. Prepare an upgrade you can afford.",
		"Challenge your next uncleared chapter with your prepared crew."
	];
	const day = Math.max(1, s.account.day);
	return {
		day,
		goal: goals[Math.min(day, 7) - 1],
		tomorrow: `${day < 7 ? goals[day] : "Try another crew on a familiar route."} Two cafe services return; earn up to ${depthCaps(s).stamps} stamps across tomorrow’s activities.`
	};
}
// packages/game-rules/src/rng.ts
/** Mix a seed with a salt (splitmix32 style) to derive an independent stream. */
function deriveSeed(seed, salt) {
	let z = seed + Math.imul(salt | 0, 2654435769) + 2654435769 | 0;
	z = Math.imul(z ^ z >>> 16, 2246822507);
	z = Math.imul(z ^ z >>> 13, 3266489909);
	return (z ^ z >>> 16) >>> 0;
}
var Rng = class {
	s;
	constructor(seed) {
		this.s = seed >>> 0;
	}
	/** Float in [0, 1). */
	next() {
		this.s = this.s + 1831565813 | 0;
		let t = this.s;
		t = Math.imul(t ^ t >>> 15, t | 1);
		t ^= t + Math.imul(t ^ t >>> 7, t | 61);
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	}
	chance(p) {
		return this.next() < p;
	}
	/** Integer in [min, max] inclusive. */
	int(min, max) {
		return min + Math.floor(this.next() * (max - min + 1));
	}
	/** Pick a key by relative weights. */
	weighted(weights, order) {
		let total = 0;
		for (const k of order) total += weights[k];
		let r = this.next() * total;
		for (const k of order) {
			r -= weights[k];
			if (r < 0) return k;
		}
		return order[order.length - 1];
	}
};
// packages/game-rules/src/cardrpg/gacha.ts
var emptyPity = () => ({
	sinceLegendary: 0,
	featuredGuaranteed: false,
	totalPulls: 0
});
function bannerById(id) {
	const b = BANNERS.find((b) => b.id === id);
	requireRule(b, "UNKNOWN_ID", "Banner not found.");
	return b;
}
/** Next-pull CONDITIONAL odds. Soft pity starts ON pull 41; hard pity ON pull 60. */
function getBannerOdds(banner, pity = emptyPity()) {
	const b = typeof banner === "string" ? bannerById(banner) : banner;
	requireRule(integer$1(pity.sinceLegendary, 0, b.hardPity - 1), "INVALID_AMOUNT", "Pity is outside this banner range.");
	const next = pity.sinceLegendary + 1;
	if (next >= b.hardPity) return {
		common: 0,
		rare: 0,
		epic: 0,
		legendary: 1e4
	};
	const legendary = Math.min(1e4, b.oddsBp.legendary + Math.max(0, next - b.softPity + 1) * b.softStepBp);
	const remaining = 1e4 - legendary, denominator = 1e4 - b.oddsBp.legendary;
	const rare = Math.floor(b.oddsBp.rare * remaining / denominator), epic = Math.floor(b.oddsBp.epic * remaining / denominator);
	return {
		common: remaining - rare - epic,
		rare,
		epic,
		legendary
	};
}
function pull(bannerId, state, seed, count = 1) {
	return transact(state, (s, events) => {
		noBattle(s);
		const b = bannerById(bannerId);
		requireRule(integer$1(count, 1, CARD_RPG_CONFIG.maxBatch) && integer$1(seed, 0, 4294967295), "INVALID_AMOUNT", "Choose 1–10 draws and an unsigned integer seed.");
		requireRule(s.daily.draws + count <= CARD_RPG_CONFIG.maxDrawsPerDay, "DAILY_CAP", "Local daily draw cap reached.");
		spend(s, Object.fromEntries(Object.entries(b.cost).map(([k, v]) => [k, v * count])));
		const pity = s.pity[b.pityGroup] ??= emptyPity(), results = [];
		const rng = new Rng(deriveSeed(seed, pity.totalPulls));
		for (let n = 0; n < count; n++) {
			const oddsBp = getBannerOdds(b, pity), rarity = rng.weighted(oddsBp, RARITY_ORDER);
			const result = {
				index: pity.totalPulls + 1,
				bannerId,
				rarity,
				duplicate: false,
				shards: 0,
				pityBefore: pity.sinceLegendary,
				oddsBp,
				soulbound: true,
				tradeable: false
			};
			if (b.kind === "cat") {
				let pool = CARDS.filter((c) => c.rarity === rarity);
				if (rarity === "legendary" && b.featuredCardId) {
					const featured = pity.featuredGuaranteed || rng.int(0, 9999) < b.featuredRateBp;
					pool = pool.filter((c) => featured ? c.id === b.featuredCardId : c.id !== b.featuredCardId);
					pity.featuredGuaranteed = !featured;
				}
				const unowned = pool.filter((c) => !s.cards.some((o) => o.cardId === c.id));
				if (unowned.length) pool = unowned;
				requireRule(pool.length > 0, "NOT_READY", "This banner has an empty rarity pool.");
				const card = pool[rng.int(0, pool.length - 1)], owned = s.cards.find((c) => c.cardId === card.id);
				result.cardId = card.id;
				if (owned) {
					result.duplicate = true;
					result.shards = CARD_RPG_CONFIG.rarity[rarity].shards;
					owned.shards += result.shards;
				} else {
					s.cards.push({
						id: card.id,
						cardId: card.id,
						level: 1,
						stars: 1,
						shards: 0,
						soulbound: true
					});
					s.loadouts[card.id] = {};
				}
			} else {
				let pool = ITEMS.filter((i) => i.rarity === rarity);
				const unowned = pool.filter((i) => !s.inventory.items.some((o) => o.itemId === i.id));
				if (unowned.length) pool = unowned;
				const item = pool[rng.int(0, pool.length - 1)];
				result.duplicate = s.inventory.items.some((i) => i.itemId === item.id);
				const instance = makeItem(s, item.id, "draw");
				s.inventory.items.push(instance);
				result.itemId = item.id;
				result.instanceId = instance.id;
			}
			pity.sinceLegendary = rarity === "legendary" ? 0 : pity.sinceLegendary + 1;
			pity.totalPulls++;
			s.daily.draws++;
			s.history.push(result);
			s.history = s.history.slice(-CARD_RPG_CONFIG.historyLimit);
			results.push(result);
			events.push({
				type: "pull.revealed",
				result
			});
			progress(s, "draws");
		}
		return results;
	});
}
// packages/game-rules/src/cardrpg/depth/power-a6.ts
/** The same full-health scale for roster stats and battle actors; not a win probability. */
function powerScoreA6(stats) {
	const core = (stats.maxHp ?? stats.hp) / 5 + stats.attack * 2 + stats.defense * 1.5;
	const crit = stats.critBp ?? stats.bonuses?.critBp ?? 0;
	const secondary = crit * .004 + (stats.critDamageBp ?? stats.bonuses?.critDamageBp ?? 0) * crit / 1e4 * .001 + ((stats.effectHitBp ?? stats.effectHit ?? 0) + (stats.effectResistBp ?? stats.effectResist ?? 0)) * .003 + ((stats.healingBp ?? stats.bonuses?.healingBp ?? 0) + (stats.shieldBp ?? stats.bonuses?.shieldBp ?? 0)) * .002;
	return Math.round((core + secondary) * 10);
}
// packages/game-rules/src/cardrpg/equipment.ts
function findItem(s, id) {
	const i = s.inventory.items.find((x) => x.id === id);
	requireRule(i && ITEM_BY_ID$1[i.itemId], "UNKNOWN_ID", "Equipment not found.");
	return i;
}
function equippedBy(s, id) {
	return Object.keys(s.loadouts).find((card) => Object.values(s.loadouts[card]).includes(id));
}
function activeSets(s, cardId) {
	const counts = {};
	for (const id of Object.values(s.loadouts[cardId] ?? {})) {
		const i = s.inventory.items.find((i) => i.id === id), t = i && ITEM_BY_ID$1[i.itemId];
		if (t) counts[t.setId] = (counts[t.setId] ?? 0) + 1;
	}
	return SET_BONUSES.filter((set) => (counts[set.id] ?? 0) >= set.pieces);
}
function computeCardStats(s, cardId) {
	const instance = s.cards.find((c) => c.id === cardId), card = instance && CARD_BY_ID[instance.cardId];
	requireRule(instance && card, "UNKNOWN_ID", "Cat not found.");
	const stats = { ...card.baseStats };
	for (const key of [
		"hp",
		"attack",
		"defense"
	]) stats[key] = Math.round(stats[key] * (1 + (instance.level - 1) * CARD_RPG_CONFIG.level.statGrowth + (instance.stars - 1) * CARD_RPG_CONFIG.level.starGrowth));
	for (const slot of EQUIPMENT_SLOTS) {
		const id = s.loadouts[cardId]?.[slot];
		if (!id) continue;
		const i = findItem(s, id), t = ITEM_BY_ID$1[i.itemId];
		stats[t.main.stat] += Math.round(t.main.value * (1 + i.enhancement * CARD_RPG_CONFIG.enhance.growth));
		for (const a of i.affixes) stats[a.stat] += a.value;
	}
	for (const set of activeSets(s, cardId)) for (const [stat, value] of Object.entries(set.stats)) stats[stat] += value;
	for (const key of Object.keys(stats)) stats[key] = Math.max(key === "initiative" ? 1 : 0, Math.min(CARD_RPG_CONFIG.statCaps[key], Math.round(stats[key])));
	return stats;
}
function equipDraft(s, cardId, instanceId) {
	noBattle(s);
	const c = s.cards.find((c) => c.id === cardId);
	requireRule(c, "UNKNOWN_ID", "Cat not found.");
	const item = ITEM_BY_ID$1[findItem(s, instanceId).itemId];
	requireRule(item.fit.includes(CARD_BY_ID[c.cardId].role), "WRONG_ROLE", "This weapon belongs to another role.");
	const owner = equippedBy(s, instanceId);
	requireRule(!owner || owner === cardId, "EQUIPPED", "Unequip this piece from its current cat first.");
	(s.loadouts[cardId] ??= {})[item.slot] = instanceId;
	return item.slot;
}
function equip(state, cardId, instanceId) {
	return transact(state, (s, events) => {
		const before = activeSets(s, cardId), slot = equipDraft(s, cardId, instanceId);
		events.push({
			type: "item.equipped",
			cardId,
			instanceId,
			slot
		});
		for (const set of activeSets(s, cardId)) if (!before.some((b) => b.id === set.id && b.pieces === set.pieces)) events.push({
			type: "set.activated",
			cardId,
			setId: set.id,
			pieces: set.pieces
		});
	});
}
function unequip(state, cardId, slot) {
	return transact(state, (s, events) => {
		noBattle(s);
		requireRule(s.cards.some((c) => c.id === cardId), "UNKNOWN_ID", "Cat not found.");
		requireRule(EQUIPMENT_SLOTS.includes(slot), "WRONG_SLOT", "Unknown equipment slot.");
		delete s.loadouts[cardId]?.[slot];
		events.push({
			type: "item.equipped",
			cardId,
			instanceId: null,
			slot
		});
	});
}
function enhanceCost(level) {
	return {
		fish: CARD_RPG_CONFIG.enhance.fishBase * (level + 1) ** 2,
		threads: CARD_RPG_CONFIG.enhance.threadsBase * (level + 1)
	};
}
function previewEnhance(s, instanceId) {
	return preview(() => {
		noBattle(s);
		const i = findItem(s, instanceId);
		requireRule(i.enhancement < CARD_RPG_CONFIG.enhance.max, "MAX_LEVEL", "Enhancement is already +12.");
		const cost = enhanceCost(i.enhancement);
		afford(s, cost);
		return {
			instanceId,
			before: i.enhancement,
			after: i.enhancement + 1,
			cost
		};
	});
}
function enhance(state, instanceId) {
	return transact(state, (s, events) => {
		const p = previewEnhance(s, instanceId);
		requireRule(p.ok, p.ok ? "NOT_READY" : p.error.code, p.ok ? "" : p.error.message);
		spend(s, p.value.cost);
		findItem(s, instanceId).enhancement++;
		progress(s, "enhances");
		events.push({
			type: "item.enhanced",
			instanceId,
			level: p.value.after
		});
		return p.value;
	});
}
function previewSalvage(s, instanceId) {
	return preview(() => {
		noBattle(s);
		const i = findItem(s, instanceId);
		requireRule(!i.locked && !i.favourite, "LOCKED", "Unlock and unfavourite before salvaging.");
		requireRule(!equippedBy(s, instanceId), "EQUIPPED", "Unequip before salvaging.");
		return {
			instanceId,
			reward: {
				currencies: { threads: CARD_RPG_CONFIG.rarity[ITEM_BY_ID$1[i.itemId].rarity].salvage },
				xp: 0
			}
		};
	});
}
function salvage(state, instanceId) {
	return transact(state, (s, events) => {
		const p = previewSalvage(s, instanceId);
		requireRule(p.ok, p.ok ? "NOT_READY" : p.error.code, p.ok ? "" : p.error.message);
		s.inventory.items = s.inventory.items.filter((i) => i.id !== instanceId);
		grant(s, p.value.reward, false);
		events.push({
			type: "item.salvaged",
			id: instanceId
		});
		return p.value;
	});
}
function lockItem(state, instanceId, locked, favourite) {
	return transact(state, (s) => {
		const i = findItem(s, instanceId);
		i.locked = locked;
		if (favourite !== void 0) i.favourite = favourite;
	});
}
var REFORGE_POOL = [
	"hp",
	"attack",
	"defense",
	"critBp",
	"effectHitBp",
	"effectResistBp",
	"healingBp",
	"shieldBp"
];
function reforge(state, instanceId, affixIndex, stat) {
	return transact(state, (s) => {
		noBattle(s);
		const i = findItem(s, instanceId);
		requireRule(Number.isInteger(affixIndex) && !!i.affixes[affixIndex], "INVALID_AMOUNT", "Choose an existing affix.");
		requireRule(REFORGE_POOL.includes(stat), "UNKNOWN_ID", "This stat cannot be reforged.");
		requireRule(!i.locked && !i.favourite, "LOCKED", "Unlock and unfavourite before reforging.");
		requireRule(!i.affixes.some((a, n) => n !== affixIndex && a.stat === stat), "NOT_READY", "Affixes must remain distinct.");
		spend(s, CARD_RPG_CONFIG.reforge);
		const tier = i.affixes[affixIndex].tier;
		i.affixes[affixIndex] = {
			stat,
			tier,
			value: CARD_RPG_CONFIG.reforgeValues[stat] * tier
		};
		i.reforgeCount++;
	});
}
function previewLevel(s, cardId) {
	return preview(() => {
		noBattle(s);
		const c = s.cards.find((c) => c.id === cardId);
		requireRule(c, "UNKNOWN_ID", "Cat not found.");
		requireRule(c.level < CARD_BY_ID[c.cardId].levelCap, "MAX_LEVEL", "Cat reached its rarity level cap.");
		const cost = {
			fish: CARD_RPG_CONFIG.level.fishBase * c.level,
			threads: CARD_RPG_CONFIG.level.threads
		};
		afford(s, cost);
		return {
			cost,
			level: c.level + 1
		};
	});
}
function levelCard(state, cardId) {
	return transact(state, (s, events) => {
		const p = previewLevel(s, cardId);
		requireRule(p.ok, p.ok ? "NOT_READY" : p.error.code, p.ok ? "" : p.error.message);
		spend(s, p.value.cost);
		s.cards.find((c) => c.id === cardId).level = p.value.level;
		events.push({
			type: "levelUp",
			cardId,
			level: p.value.level
		});
	});
}
function previewAscend(s, cardId) {
	return preview(() => {
		noBattle(s);
		const c = s.cards.find((c) => c.id === cardId);
		requireRule(c, "UNKNOWN_ID", "Cat not found.");
		requireRule(c.stars < CARD_RPG_CONFIG.level.maxStars, "MAX_LEVEL", "Cat reached five stars.");
		const shards = CARD_RPG_CONFIG.level.shardsBase * c.stars;
		requireRule(c.shards >= shards, "INSUFFICIENT_FUNDS", `Need ${shards} matching shards.`);
		const cost = { fish: CARD_RPG_CONFIG.level.ascendFish * c.stars };
		afford(s, cost);
		return {
			cost,
			shards,
			stars: c.stars + 1
		};
	});
}
function ascendCard(state, cardId) {
	return transact(state, (s) => {
		const p = previewAscend(s, cardId);
		requireRule(p.ok, p.ok ? "NOT_READY" : p.error.code, p.ok ? "" : p.error.message);
		spend(s, p.value.cost);
		const c = s.cards.find((c) => c.id === cardId);
		c.shards -= p.value.shards;
		c.stars = p.value.stars;
	});
}
var RARITY_MULTIPLIERS_V4 = {
	common: 1,
	rare: 1.25,
	epic: 1.5,
	legendary: 1.75
};
var SET_TEXT_V4 = {
	hearthloom: {
		two: "Defend adds 12 shield.",
		four: "Defend links a weak ally; 15% of HP damage is shared."
	},
	moonwick: {
		two: "Direct hits on marked foes add 3 raw damage.",
		four: "Your first marked hit each round restores 6 missing HP."
	},
	mossbrew: {
		two: "Healing cleanses one debuff once per own turn.",
		four: "Your first Steep application each encounter adds one Cozy."
	},
	rainlace: {
		two: "Row swaps grant both cats 12 shield.",
		four: "Rear cats restore 6 missing HP per round."
	},
	crumbweave: {
		two: "Every third attack plants one Crumb.",
		four: "Detonation grants 8 shield once per own turn."
	},
	bellsteel: {
		two: "Riposte deals 3 extra damage.",
		four: "Defend grants one Riposte and Shelter."
	},
	emberfelt: {
		two: "Scald lasts one extra round, capped at four.",
		four: "Your first Scald application each round restores 6 HP."
	},
	velvetrim: {
		two: "Single-foe skills can reach the rear.",
		four: "Start with 12 shield; Support focus prioritizes enemy utility."
	}
};
var UNIQUE_TEXT_V4 = {
	doorstop: "Defend restores 8 missing HP.",
	nightglass: "First marked hit each round grants 6 shield.",
	seedcup: "First healing recipient gains 12 shield.",
	rainbell: "Swapping clears one of your debuffs.",
	crumbbook: "Detonation grants 10 shield once per turn.",
	panlid: "Defend grants one Riposte stack.",
	warmwick: "First Scald application each round restores 4 HP.",
	silkspool: "First ultimate grants 12 shield.",
	starladle: "First ultimate restores 12 missing HP.",
	softcollar: "Start with 15 shield.",
	tidetray: "Shield-bearing skills prefer a weak ally.",
	gardenkey: "First successful cleanse each turn restores 8 HP."
};
var AFFIX_TEXT_V4 = {
	openingCharge: "Opening shield",
	ultimateCharge: "Missing HP restored after an ultimate",
	brokenDamage: "Extra raw damage to marked foes",
	breakShield: "Shield after the first marked hit each round"
};
function setTextV4(set, enabled, c2 = false) {
	const text = enabled ? {
		...set,
		...SET_TEXT_V4[set.id]
	} : set;
	if (c2 && enabled && set.id === "hearthloom") return {
		...text,
		four: `Defend links a weak ally; ${ECONOMY_C2.sets.hearthloomShareBp / 100}% of HP damage is shared.`
	};
	if (c2 && enabled && set.id === "bellsteel") {
		const triggers = [["Riposte", ECONOMY_C2.sets.bellsteelRipostesPerBattle], ["Shelter", ECONOMY_C2.sets.bellsteelSheltersPerBattle]].filter(([, count]) => count > 0).map(([name, count]) => `${name} ${count}×`).join(", ");
		return {
			...text,
			four: `Defend: ${triggers} per battle.`
		};
	}
	return text;
}
function uniqueTextV4(id, c2 = false) {
	if (c2 && id === "softcollar") return `Start with ${ECONOMY_C2.uniques.softcollarShield} shield.`;
	if (c2 && id === "rainbell") return `Swapping clears ${ECONOMY_C2.uniques.rainbellCleanseStacks} debuff stack.`;
	return UNIQUE_TEXT_V4[id] ?? id;
}
function gearStoryV4(id, c2 = false) {
	const t = GEAR_BY_ID[id];
	return t.unique ? uniqueTextV4(t.unique, c2) : SET_TEXT_V4[t.setId].two;
}
var rawPowerV4 = (s) => s.hp / 5 + 2 * s.attack + 1.5 * s.defense;
function nakedStatsV4(state, cardId) {
	const card = state.account.cards.find((c) => c.cardId === cardId);
	const stats = computeCardStats({
		...state.account,
		loadouts: {}
	}, card.id), awakening = state.awakened[cardId] ?? 0;
	if (gameplayA6(state)) for (const key of [
		"hp",
		"attack",
		"defense"
	]) stats[key] = Math.round(stats[key] * (1 + Math.min(9, card.level - 1) * .04));
	stats.hp = Math.round(stats.hp * (1 + awakening * .03));
	stats.attack = Math.round(stats.attack * (1 + awakening * .03));
	return stats;
}
/** One shared common base across sets; full +12 main remains under 8% naked core. */
function gearMainV4(state, cardId, item) {
	const t = GEAR_BY_ID[item.templateId], core = rawPowerV4(nakedStatsV4(state, cardId));
	const weight = t.main === "attack" ? 2 : t.main === "defense" ? state.formationC2 ? ECONOMY_C2.equipment.defenseWeight : 1.5 : state.formationC2 ? ECONOMY_C2.equipment.hpWeight : .2;
	const budget = state.formationC2 ? ECONOMY_C2.equipment : {
		commonPower: .026,
		maximumPower: .08,
		minimumMain: 4
	};
	const common = Math.max(budget.minimumMain, Math.ceil(core * budget.commonPower / weight));
	return Math.floor(Math.min(core * budget.maximumPower / weight, common * RARITY_MULTIPLIERS_V4[t.rarity] * (1 + .06 * item.enhancement)));
}
/** Explicit three-round reference estimates. Not a win probability or calibrated promise. */
var POWER_REFERENCE_V4 = {
	rounds: 3,
	shieldValue: .2,
	healValue: .2,
	conditionalDamage: .36,
	counterDamage: .3,
	statusDuration: 2,
	reach: 5,
	criticalPerBp: .004,
	effectPerBp: .003
};
var EFFECT_VALUE = {
	"defend-shield": 12 / 5,
	"defend-link": 6,
	"marked-break": 9 / 5,
	"ultimate-refund": 18 / 5,
	"healing-cleanse": 5,
	"steep-cozy": 4,
	"swap-shield": 24 / 5,
	"rear-heal": 18 / 5,
	"third-crumb": 4,
	"detonate-energy": 8 / 5,
	"counter-plus": 9 / 5,
	"defend-riposte": 6,
	"long-scald": 4,
	"scald-charge": 18 / 5,
	"pierce-row": 5,
	"opening-decoy": 12 / 5,
	"unique:doorstop": 8 / 5,
	"unique:nightglass": 18 / 5,
	"unique:seedcup": 12 / 5,
	"unique:rainbell": 3,
	"unique:crumbbook": 2,
	"unique:panlid": 3,
	"unique:warmwick": 12 / 5,
	"unique:silkspool": 12 / 5,
	"unique:starladle": 12 / 5,
	"unique:softcollar": 3,
	"unique:tidetray": 2,
	"unique:gardenkey": 8 / 5
};
function powerV4(state, cardId) {
	const stats = crewStats(depthStats(state, cardId), state.team), { bonuses, effects } = equipmentEffects(state, cardId);
	if (gameplayA6(state)) {
		const total = powerScoreA6(stats);
		return {
			core: Math.round(rawPowerV4(stats) * 10),
			utility: total - Math.round(rawPowerV4(stats) * 10),
			total,
			reference: POWER_REFERENCE_V4
		};
	}
	let utility = effects.reduce((n, id) => n + (EFFECT_VALUE[id] ?? 0), 0);
	for (const [key, value] of Object.entries(bonuses)) if ([
		"openingShield",
		"openingCharge",
		"cleanseShield",
		"breakShield",
		"shieldFlat",
		"healFlat",
		"ultimateCharge"
	].includes(key)) utility += value / 5;
	else if (key === "roundHeal") utility += value * 3 / 5;
	else if (key.endsWith("Damage") || key === "dotPower") utility += value * .36;
	else if (key === "counterPower") utility += value * .3;
	else if (key === "statusDuration") utility += value * 2;
	utility += stats.critBp * .004 + stats.critDamageBp * stats.critBp / 1e4 * .001 + (stats.effectHitBp + stats.effectResistBp) * .003 + (stats.healingBp + stats.shieldBp) * .002;
	return {
		core: rawPowerV4(stats),
		utility,
		total: rawPowerV4(stats) + utility,
		reference: POWER_REFERENCE_V4
	};
}
function teamPowerV4(state) {
	return state.team.reduce((sum, id) => sum + powerV4(state, id).total, 0);
}
function comparisonV4(state, cardId, instanceId) {
	const item = state.gear.find((g) => g.id === instanceId);
	if (!item) return null;
	const transfer = Object.entries(state.equipment).find(([id, slots]) => id !== cardId && Object.values(slots).includes(instanceId))?.[0] ?? null;
	const t = GEAR_BY_ID[item.templateId], next = clone(state);
	for (const loadout of Object.values(next.equipment)) for (const slot of EQUIPMENT_SLOTS) if (loadout[slot] === instanceId) delete loadout[slot];
	next.equipment[cardId] ??= {};
	next.equipment[cardId][t.slot] = instanceId;
	const before = equipmentEffects(state, cardId), after = equipmentEffects(next, cardId);
	const donorAfter = transfer ? equipmentEffects(next, transfer).effects : [];
	const without = clone(next);
	delete without.equipment[cardId][t.slot];
	return {
		before: powerV4(state, cardId),
		after: powerV4(next, cardId),
		teamBefore: teamPowerV4(state),
		teamAfter: teamPowerV4(next),
		share: Math.max(0, teamPowerV4(next) - teamPowerV4(without)) / teamPowerV4(next),
		gained: after.effects.filter((e) => !before.effects.includes(e)),
		lost: before.effects.filter((e) => !after.effects.includes(e)),
		transfer,
		transferLost: transfer ? equipmentEffects(state, transfer).effects.filter((e) => !donorAfter.includes(e)) : []
	};
}
function gearCostV4(id, state) {
	const g = GEAR_BY_ID[id];
	return state?.formationC2 ? ECONOMY_C2.tailoring[g.rarity] : g.rarity === "legendary" ? {
		fish: 500,
		threads: 100,
		essence: 20
	} : g.rarity === "epic" ? {
		fish: 120,
		threads: 180,
		essence: 5
	} : {
		fish: 180,
		threads: 30
	};
}
function legendaryTailoringRequirements(state) {
	return state.formationC2 ? {
		materials: ECONOMY_C2.legendary.materials,
		seals: ECONOMY_C2.legendary.seals
	} : {
		materials: 20,
		seals: 1
	};
}
function rarityMeaningV4(rarity) {
	return [
		"One main stat; readily replaceable.",
		"One affix refines a role.",
		"Two affixes; plan a targeted source.",
		"Three affixes and one bounded unique behavior."
	][RARITY_ORDER.indexOf(rarity)] ?? "Cosmetic edition; no combat power.";
}
function itemUtilityV4(state, cardId, item) {
	const copy = gameplayA6(state) ? {
		...state,
		equipment: {
			...state.equipment,
			[cardId]: {}
		}
	} : clone(state);
	copy.equipment[cardId] = {};
	const bare = powerV4(copy, cardId).total;
	copy.equipment[cardId] = { [GEAR_BY_ID[item.templateId].slot]: item.id };
	return powerV4(copy, cardId).total - bare;
}
function effectTextV4(effect, c2 = false) {
	if (effect.startsWith("unique:")) return uniqueTextV4(effect.slice(7), c2);
	const set = SETS.find((s) => s.twoEffect === effect || s.fourEffect === effect);
	return set ? `${set.name}: ${setTextV4(set, true, c2)[set.twoEffect === effect ? "two" : "four"]}` : effect;
}
var invitationBannerV4 = (id, state) => {
	const b = bannerById(id), v = ECONOMY_V3[b.kind === "equipment" ? "gear" : "cat"];
	return {
		...b,
		...state?.gameplayA6 ? { cost: { stamps: state.formationC2 && id === "equipment" ? ECONOMY_C2.equipmentInvitation.stamps : 60 } } : {},
		...state?.economyV3 ? {
			oddsBp: { ...v.odds },
			softPity: v.soft,
			hardPity: v.hard,
			softStepBp: v.stepBp,
			featuredRateBp: b.featuredCardId ? ECONOMY_V3.cat.featuredBp : 0
		} : {
			softPity: 13,
			hardPity: 24,
			softStepBp: 700
		}
	};
};
var selectorCostV4 = (s, kind, id) => s.economyV3 ? ECONOMY_V3.selector : s.formationC2 && kind === "gear" && GEAR_BY_ID[id]?.rarity === "legendary" ? ECONOMY_C2.legendary.selectorMarks : 24;
function invitationOddsV4(id, pity = emptyPity(), state) {
	const banner = invitationBannerV4(id, state);
	return getBannerOdds(banner, {
		...pity,
		sinceLegendary: Math.min(pity.sinceLegendary, banner.hardPity - 1)
	});
}
function selectorMarksV4(s) {
	return s.v4?.selectorMarks ?? 0;
}
function safeAdd(a, b) {
	requireRule(Number.isSafeInteger(a + b) && a + b >= 0, "MAX_LEVEL", "This saved balance is full.");
	return a + b;
}
function recordReveals(s, results) {
	const v = s.v4;
	v.selectorMarks = safeAdd(selectorMarksV4(s), results.length);
	v.revealSequence ??= 0;
	v.reveals ??= [];
	for (const r of results) {
		const sequence = v.revealSequence;
		v.revealSequence = safeAdd(sequence, 1);
		const event = {
			version: 1,
			sequence,
			round: 0,
			kind: "earned-reveal",
			bannerId: r.bannerId,
			draw: r.index,
			itemId: r.cardId ?? r.itemId,
			rarity: r.rarity,
			duplicate: r.shards,
			pityBefore: r.pityBefore,
			pityAfter: r.rarity === "legendary" ? 0 : r.pityBefore + 1,
			text: `Earned invitation ${r.index}: ${r.cardId ?? r.itemId}${r.shards ? ` → ${r.shards} shards` : ""}.`
		};
		v.reveals.push(event);
	}
	v.reveals = v.reveals.slice(-60);
}
/** Mutates only the enclosing atomic draft; no animation controls acquisition. */
function drawInvitationsV4(s, bannerId, seed, count = 1) {
	requireHome(s);
	requireRule(gameplayV4(s) && !!s.v4, "NOT_READY", "Enable Gameplay v4 first.");
	const b = invitationBannerV4(bannerId, s);
	const results = [];
	requireRule(integer$1(count, 1, CARD_RPG_CONFIG.maxBatch) && integer$1(seed, 0, 4294967295), "INVALID_AMOUNT", "Choose 1–10 invitations and an unsigned seed.");
	requireRule(s.account.daily.draws + count <= CARD_RPG_CONFIG.maxDrawsPerDay, "DAILY_CAP", "Daily invitation limit reached.");
	safeAdd(selectorMarksV4(s), count);
	{
		requireRule(b.kind === "cat" || s.gear.length + count <= 240, "MAX_LEVEL", "Make room for the entire basket before spending.");
		spend(s.account, Object.fromEntries(Object.entries(b.cost).map(([k, v]) => [k, v * count])));
		const pity = s.account.pity[b.pityGroup] ??= emptyPity(), rng = new Rng(deriveSeed(seed, pity.totalPulls));
		for (let n = 0; n < count; n++) {
			const oddsBp = invitationOddsV4(bannerId, pity, s), rarity = rng.weighted(oddsBp, RARITY_ORDER);
			if (b.kind === "cat") {
				let pool = CARDS.filter((c) => c.rarity === rarity);
				if (rarity === "legendary" && b.featuredCardId) {
					const featured = pity.featuredGuaranteed || rng.int(0, 9999) < b.featuredRateBp;
					pool = pool.filter((c) => featured ? c.id === b.featuredCardId : c.id !== b.featuredCardId);
					pity.featuredGuaranteed = !featured;
				}
				const fresh = pool.filter((c) => !s.account.cards.some((o) => o.cardId === c.id));
				if (fresh.length) pool = fresh;
				requireRule(pool.length > 0, "NOT_READY", "This banner has an empty rarity pool.");
				const cat = pool[rng.int(0, pool.length - 1)], owned = s.account.cards.find((o) => o.cardId === cat.id), shards = owned ? s.economyV3 ? ECONOMY_V3.shards[rarity] : CARD_RPG_CONFIG.rarity[rarity].shards : 0;
				if (owned) owned.shards = safeAdd(owned.shards, shards);
				else {
					s.account.cards.push({
						id: cat.id,
						cardId: cat.id,
						level: 1,
						stars: 1,
						shards: 0,
						soulbound: true
					});
					s.account.loadouts[cat.id] = {};
				}
				const result = {
					index: safeAdd(pity.totalPulls, 1),
					bannerId,
					rarity,
					cardId: cat.id,
					duplicate: !!owned,
					shards,
					pityBefore: pity.sinceLegendary,
					oddsBp,
					soulbound: true,
					tradeable: false
				};
				pity.totalPulls = result.index;
				pity.sinceLegendary = rarity === "legendary" ? 0 : pity.sinceLegendary + 1;
				s.account.daily.draws++;
				results.push(result);
				s.account.history.push(result);
				progress(s.account, "draws");
				continue;
			}
			let pool = GEAR.filter((g) => g.rarity === rarity);
			const fresh = pool.filter((g) => !s.gear.some((i) => i.templateId === g.id));
			if (fresh.length) pool = fresh;
			const template = pool[rng.int(0, pool.length - 1)], duplicate = s.gear.some((g) => g.templateId === template.id);
			const gear = makeGear(s, template.id, deriveSeed(seed, s.account.nextId));
			s.gear.push(gear);
			const result = {
				index: safeAdd(pity.totalPulls, 1),
				bannerId,
				rarity,
				itemId: template.id,
				instanceId: gear.id,
				duplicate,
				shards: 0,
				pityBefore: pity.sinceLegendary,
				oddsBp,
				soulbound: true,
				tradeable: false
			};
			pity.totalPulls = result.index;
			pity.sinceLegendary = rarity === "legendary" ? 0 : pity.sinceLegendary + 1;
			s.account.daily.draws++;
			results.push(result);
			s.account.history.push(result);
			progress(s.account, "draws");
		}
		s.account.history = s.account.history.slice(-CARD_RPG_CONFIG.historyLimit);
	}
	for (const c of s.account.cards) {
		requireRule(Number.isSafeInteger(c.shards), "MAX_LEVEL", "Shard balance is full.");
		if (!s.skills[c.cardId]) {
			s.skills[c.cardId] = CAT_BY_ID[c.cardId].skills.slice(0, 3).map((k) => k.id);
			s.rows[c.cardId] = CAT_BY_ID[c.cardId].row;
		}
	}
	recordReveals(s, results);
	return results;
}
function getDrawPoolV4(s, bannerId) {
	const b = invitationBannerV4(bannerId, s), pity = s.account.pity[b.pityGroup] ?? emptyPity(), odds = invitationOddsV4(bannerId, pity, s);
	if (b.kind === "cat") return RARITY_ORDER.flatMap((rarity) => {
		const rows = CARDS.filter((c) => c.rarity === rarity);
		const group = (pool, chance) => {
			const fresh = pool.filter((c) => !s.account.cards.some((o) => o.cardId === c.id)), actual = fresh.length ? fresh : pool;
			return actual.map((c) => ({
				id: c.id,
				rarity,
				probability: odds[rarity] / 1e4 * chance / actual.length
			}));
		};
		if (rarity === "legendary" && b.featuredCardId) {
			const chance = pity.featuredGuaranteed ? 1 : b.featuredRateBp / 1e4;
			return [...group(rows.filter((c) => c.id === b.featuredCardId), chance), ...group(rows.filter((c) => c.id !== b.featuredCardId), 1 - chance)];
		}
		return group(rows, 1);
	});
	return RARITY_ORDER.flatMap((rarity) => {
		const pool = GEAR.filter((g) => g.rarity === rarity), fresh = pool.filter((g) => !s.gear.some((i) => i.templateId === g.id)), actual = fresh.length ? fresh : pool;
		return actual.map((g) => ({
			id: g.id,
			rarity,
			probability: odds[rarity] / 1e4 / actual.length
		}));
	});
}
function selectorEligibilityV4(s, kind, id) {
	if (!gameplayV4(s) || !s.v4) return "Enable Gameplay v4 first.";
	if (s.run && !s.run.complete) return "Finish the current route.";
	const cost = selectorCostV4(s, kind, id);
	if (selectorMarksV4(s) < cost) return `Earn ${cost - selectorMarksV4(s)} more selector marks.`;
	if (kind === "cat") {
		if (!CARDS.some((c) => c.id === id)) return "Choose a companion.";
		if (s.economyV3 && id === invitationBannerV4("featured", s).featuredCardId) return "Featured cats return in future banners.";
		if (s.account.cards.some((c) => c.cardId === id) && !CARDS.every((c) => s.account.cards.some((o) => o.cardId === c.id))) return "Choose an uncollected companion first.";
	} else {
		const g = GEAR_BY_ID[id];
		if (!g) return "Choose an equipment template.";
		if (s.gear.length >= 240) return "The equipment shelf is full (240).";
		if (s.account.chapter < g.chapter) return `Reach chapter ${g.chapter}.`;
		if (g.rarity === "legendary" && !s.masteries.includes(g.chapter)) return `Complete chapter ${g.chapter} mastery for this legendary template.`;
	}
	return null;
}
function chooseSelectorV4(state, kind, id) {
	return transactDepth(state, (s) => {
		requireRule(kind === "cat" || kind === "gear", "INVALID_AMOUNT", "Choose companion or equipment.");
		const reason = selectorEligibilityV4(s, kind, id);
		requireRule(!reason, "NOT_READY", reason ?? "");
		if (kind === "cat") {
			const cat = CARDS.find((c) => c.id === id), owned = s.account.cards.find((c) => c.cardId === id);
			if (owned) owned.shards = safeAdd(owned.shards, s.economyV3 ? ECONOMY_V3.shards[cat.rarity] : CARD_RPG_CONFIG.rarity[cat.rarity].shards);
			else {
				s.account.cards.push({
					id,
					cardId: id,
					level: 1,
					stars: 1,
					shards: 0,
					soulbound: true
				});
				s.account.loadouts[id] = {};
				s.rows[id] = CAT_BY_ID[id].row;
				s.skills[id] = CAT_BY_ID[id].skills.slice(0, 3).map((k) => k.id);
			}
		} else s.gear.push(makeGear(s, id, deriveSeed(s.account.seed, s.account.nextId)));
		s.v4.selectorMarks = selectorMarksV4(s) - selectorCostV4(s, kind, id);
	});
}
// packages/game-rules/src/cardrpg/commands.ts
function applyCommand(state, command) {
	switch (command.type) {
		case "pull": return pull(command.bannerId, state, command.seed, command.count);
		case "equip": return equip(state, command.cardId, command.instanceId);
		case "unequip": return unequip(state, command.cardId, command.slot);
		case "enhance": return enhance(state, command.instanceId);
		case "salvage": return salvage(state, command.instanceId);
		case "forge": return forge(state, command.recipeId);
		case "claimQuest": return claimQuest(state, command.questId);
		case "lock": return lockItem(state, command.instanceId, command.locked, command.favourite);
		case "level": return levelCard(state, command.cardId);
		case "ascend": return ascendCard(state, command.cardId);
		case "reforge": return reforge(state, command.instanceId, command.affixIndex, command.stat);
		case "selectTeam": return selectTeam(state, command.cardIds);
		case "advanceLocalDay": return advanceLocalDay(state);
		case "exchangeShards": return exchangeShards(state, command.cardId, command.batches);
		case "service": return claimCafeService(state, command.minutes);
	}
}
// packages/game-rules/src/cardrpg/depth/contract.ts
/** Battle snapshots retain enemy stats across later balance changes. */
var CONTRACT_VERSION = "0.7.0";
// packages/game-rules/src/cardrpg/depth/state.ts
var DEPTH_CAPS = {
	fish: 420,
	threads: 90,
	stamps: 180,
	essence: 6
};
var DEPTH_CAPS_V4 = {
	...DEPTH_CAPS,
	stamps: 360
};
var depthCaps = (state) => gameplayV4(state) ? DEPTH_CAPS_V4 : DEPTH_CAPS;
function createDepthAccount(seed = 11, now = 0) {
	const account = createStarterAccount(seed);
	const team = account.cards.map((c) => c.cardId);
	const state = {
		version: CONTRACT_VERSION,
		account,
		team,
		rows: Object.fromEntries(team.map((id) => [id, CAT_BY_ID[id].row])),
		skills: Object.fromEntries(team.map((id) => [id, CAT_BY_ID[id].skills.slice(0, 3).map((s) => s.id)])),
		run: null,
		nextRunId: 1,
		cleared: [],
		towerBest: 0,
		lastBattle: null,
		lastChoices: [],
		gear: [],
		equipment: {},
		awakened: {},
		materials: 0,
		seals: 0,
		masteries: [],
		challengeClaims: [],
		claimedRuns: [],
		idle: {
			lastAt: now,
			receiptIds: []
		},
		tutorial: 0,
		freeInvite: false,
		settings: {
			sound: false,
			speed: 1,
			reducedMotion: false,
			quality: "medium"
		},
		relics: [],
		selectedRelic: null,
		designClaims: []
	};
	initializeEquipment(state);
	return state;
}
function transactDepth(state, fn) {
	const next = clone(state);
	try {
		observeCollectionV4(next);
		observeDiscoveriesV4(next);
		fn(next);
		observeDailyA6(state, next);
		observeCollectionV4(next);
		observeDiscoveriesV4(next);
		return {
			ok: true,
			state: next
		};
	} catch (error) {
		if (!(error instanceof RuleFailure)) throw error;
		return {
			ok: false,
			state,
			error: error.message
		};
	}
}
function requireHome(state) {
	requireRule(!state.run || state.run.complete, "BATTLE_PENDING", "Finish or abandon this run before changing its loadout.");
}
function availableSkills(state, id) {
	const owned = state.account.cards.find((c) => c.cardId === id);
	return CAT_BY_ID[id]?.skills.filter((s) => owned && (gameplayA6(state) || owned.level >= s.unlockLevel || owned.stars >= s.unlockStars)) ?? [];
}
/** New encounters derive their complete kit from progression, including old accounts. */
function defaultSkills(state, id) {
	return availableSkills(state, id).map((skill) => skill.id);
}
function configureTeam(state, team, rows, skills) {
	return transactDepth(state, (s) => {
		requireHome(s);
		requireRule(team.length === partySize(s) && new Set(team).size === partySize(s) && team.every((id) => s.account.cards.some((c) => c.cardId === id)), "INVALID_TEAM", `Choose ${partySize(s)} different collected cats.`);
		requireRule(team.some((id) => rows[id] === "front") && team.every((id) => ["front", "rear"].includes(rows[id])), "INVALID_TEAM", "Keep at least one cat in the front row.");
		requireRule(!s.formationC2 || validRowsC2(team, rows), "INVALID_TEAM", "Place two cats in each row.");
		if (!gameplayV4(s)) for (const id of team) {
			const chosen = skills[id] ?? [], unlocked = availableSkills(s, id);
			requireRule(chosen.length === 3 && new Set(chosen).size === 3 && chosen.every((skill) => unlocked.some((u) => u.id === skill) && SKILLS[skill].catId === id), "INVALID_TEAM", "Equip three different unlocked skills per cat.");
		}
		s.team = [...team];
		s.rows = {
			...s.rows,
			...rows
		};
		s.skills = {
			...s.skills,
			...clone(skills)
		};
	});
}
function grantDepth(state, currencies, xp = 0) {
	const capped = Object.fromEntries(Object.entries(currencies).map(([id, amount]) => [id, Math.max(0, Math.min(amount, depthCaps(state)[id] - state.account.daily.earned[id]))]));
	return grant(state.account, {
		currencies: capped,
		xp
	});
}
function metaCommand(state, command) {
	return transactDepth(state, (s) => {
		requireHome(s);
		if (s.economyV3 && command.type === "ascend") {
			const card = s.account.cards.find((c) => c.id === command.cardId);
			requireRule(card && card.stars < 5, "MAX_LEVEL", "Choose a cat below five stars.");
			const cost = ECONOMY_V3.starShards[card.stars - 1];
			requireRule(card.shards >= cost, "INSUFFICIENT_FUNDS", `Need ${cost} matching shards.`);
			spend(s.account, { fish: 150 * card.stars });
			card.shards -= cost;
			card.stars++;
			return;
		}
		if (gameplayV4(s)) {
			if (command.type === "claimQuest") {
				settleBoardV4(s, command.questId);
				return;
			}
			if (command.type === "pull") {
				drawInvitationsV4(s, command.bannerId, command.seed, command.count);
				return;
			}
			requireRule(![
				"equip",
				"unequip",
				"enhance",
				"reforge",
				"salvage",
				"lock",
				"selectTeam"
			].includes(command.type), "NOT_READY", "Use the equipment workbench or crew screen for Gameplay v4.");
			const recipe = command.type === "forge" ? RECIPES.find((r) => r.id === command.recipeId) : void 0;
			requireRule(!recipe?.scarcityId, "NOT_READY", "Use the local edition ledger to reserve a design.");
			if (s.formationC2 && recipe?.outputItemId) {
				requireRule(s.account.chapter >= recipe.requiredChapter, "LOCKED", "Reach the recipe source chapter first.");
				const crafted = craftGear(s, recipe.outputItemId);
				requireRule(crafted.ok, "NOT_READY", crafted.error ?? "The recipe cannot be crafted.");
				Object.assign(s, crafted.state);
				return;
			}
			const slots = recipe?.outputItemId ? 1 : 0;
			requireRule(s.gear.length + slots <= 240 || slots === 0, "MAX_LEVEL", "Equipment shelf is full (240). Make room for the entire reward before spending.");
			for (const [id, count] of Object.entries(recipe?.outputStackId ? { [recipe.outputStackId]: 1 } : {})) requireRule((s.account.inventory.stacks[id] ?? 0) + count <= stackCapV4(id), "MAX_LEVEL", `The ${id} stack is full. Spend one before claiming or crafting.`);
		}
		const before = clone(s.account), result = applyCommand(s.account, command);
		requireRule(result.ok, "INVALID_AMOUNT", result.ok ? "" : result.error.message);
		s.account = result.state;
		for (const item of s.account.inventory.items.filter((item) => !before.inventory.items.some((old) => old.id === item.id))) {
			const gear = makeGear(s, item.itemId, s.account.nextId);
			s.gear.push(gear);
		}
		for (const id of Object.keys(DEPTH_CAPS)) {
			const floor = s.v4 ? Math.max(depthCaps(s)[id], before.daily.earned[id]) : depthCaps(s)[id];
			const excess = Math.max(0, s.account.daily.earned[id] - floor);
			s.account.currencies[id] -= excess;
			s.account.daily.earned[id] -= excess;
		}
		for (const c of s.account.cards) if (!s.skills[c.cardId]) {
			s.skills[c.cardId] = CAT_BY_ID[c.cardId].skills.slice(0, 3).map((sk) => sk.id);
			s.rows[c.cardId] = CAT_BY_ID[c.cardId].row;
		}
		requireRule(s.account.currencies.stamps >= 0 && s.account.day >= before.day, "INVALID_AMOUNT", "Invalid account transition.");
	});
}
function battleCats(state) {
	return state.team.map((id) => {
		const { effects, bonuses } = equipmentEffects(state, id);
		const relic = !gameplayA6(state) && id === state.team[0] && state.relics.includes(state.selectedRelic ?? 0) ? RELIC_EFFECTS.find((r) => r.id === state.selectedRelic) : void 0;
		if (relic) bonuses[relic.bonus] = (bonuses[relic.bonus] ?? 0) + relic.value;
		const stats = depthStats(state, id);
		return {
			id,
			stats: gameplayV4(state) ? crewStats(stats, state.team) : stats,
			skills: defaultSkills(state, id),
			row: state.rows[id],
			equipment: equippedItems(state, id).map((i) => i.templateId),
			effects,
			bonuses
		};
	});
}
// packages/game-rules/src/cardrpg/depth/bridge.ts
var FUJI_RELIC_ADDRESS = "0xB1a1edb7A75Db6e7067E747ddee32B39c2296f2D";
var RELIC_EFFECTS = [
	{
		id: 1,
		rarity: 0,
		name: "Common service cup",
		bonus: "openingShield",
		value: 12,
		description: "Begin each battle with 12 shield."
	},
	{
		id: 2,
		rarity: 1,
		name: "Rare mending cup",
		bonus: "roundHeal",
		value: 3,
		description: "Restore 3 HP at the start of each round."
	},
	{
		id: 3,
		rarity: 2,
		name: "Epic ringing cup",
		bonus: "counterPower",
		value: 4,
		description: "Saucer riposte returns 4 extra damage."
	},
	{
		id: 4,
		rarity: 3,
		name: "Legendary lantern cup",
		bonus: "openingCharge",
		value: 8,
		description: "Begin each battle with 8 ultimate charge."
	}
];
var RELIC_FIXTURE = RELIC_EFFECTS.map((r) => ({
	id: r.id,
	rarity: r.rarity,
	balance: "1"
}));
/** ERC-1155 rarityOf is the existing attribute. Quantities never multiply power. */
function acceptRelicSnapshot(state, chainId, holdings) {
	return transactDepth(state, (draft) => {
		requireRule(chainId === 43113, "INVALID_AMOUNT", "Use Avalanche Fuji 43113.");
		requireRule(holdings.every((h) => RELIC_EFFECTS.some((r) => r.id === h.id && r.rarity === h.rarity) && /^\d{1,78}$/.test(h.balance)), "INVALID_AMOUNT", "Relic attributes differ from the supported Fuji catalogue.");
		draft.relics = [...new Set(holdings.filter((h) => BigInt(h.balance) > 0n).map((h) => h.id))];
		if (draft.selectedRelic && !draft.relics.includes(draft.selectedRelic)) draft.selectedRelic = null;
	});
}
function selectRelic(state, id) {
	return transactDepth(state, (draft) => {
		requireHome(draft);
		requireRule(id === null || draft.relics.includes(id), "LOCKED", "Read an owned Relic or choose fixture mode first.");
		draft.selectedRelic = id;
	});
}
function idlePreview(state, now) {
	const elapsed = Math.min(CONFIG.idle.offlineCapSeconds, Math.max(0, Math.floor((now - state.idle.lastAt) / 1e3)));
	const online = Math.min(elapsed, CONFIG.idle.onlineWindowSeconds);
	const effectiveMinutes = Math.floor((online + (elapsed - online) * CONFIG.idle.offlineEfficiency) / 60);
	return {
		elapsed,
		effectiveMinutes,
		claims: Math.min(Math.floor(effectiveMinutes / CARD_RPG_CONFIG.service.minutesPerClaim), CARD_RPG_CONFIG.service.maxClaims - state.account.daily.service),
		capHours: CONFIG.idle.offlineCapSeconds / 3600
	};
}
function claimIdleService(state, now) {
	return transactDepth(state, (draft) => {
		requireHome(draft);
		requireRule(Number.isSafeInteger(now) && now >= draft.idle.lastAt, "INVALID_AMOUNT", "The service clock must move forward.");
		const preview = idlePreview(draft, now);
		requireRule(preview.claims > 0, "NOT_READY", "The kettle needs more time, or today’s two services are complete.");
		const result = metaCommand(draft, {
			type: "service",
			minutes: preview.effectiveMinutes
		});
		requireRule(result.ok, "NOT_READY", "Service claim unavailable.");
		draft.account = result.state.account;
		draft.idle.lastAt = now;
	});
}
var IDLE_RECEIPT_FIXTURE = {
	source: "taskbar-idle-v2",
	id: "fixture-idle-2026-11-06-1",
	day: 1,
	chapter: 1,
	bossWins: 1,
	lootCount: 2
};
function acceptIdleResult(state, receipt) {
	return transactDepth(state, (draft) => {
		requireRule(receipt.source === "taskbar-idle-v2" && /^[\w-]{1,100}$/.test(receipt.id) && receipt.day === draft.account.day && integer$1(receipt.chapter, 1, 5) && integer$1(receipt.bossWins, 0, 100) && integer$1(receipt.lootCount, 0, 1e3), "INVALID_AMOUNT", "Invalid idle result receipt.");
		requireRule(!draft.idle.receiptIds.includes(receipt.id), "ALREADY_CLAIMED", "This idle result was already read.");
		const key = `depth-material-${draft.account.day}`;
		const earned = draft.account.inventory.stacks[key] ?? 0;
		const material = Math.max(0, Math.min(6, receipt.bossWins * 3 + receipt.lootCount, 30 - earned));
		draft.materials += material;
		draft.account.inventory.stacks[key] = earned + material;
		draft.idle.receiptIds.push(receipt.id);
	});
}
function designEligibility(state, id) {
	const spec = SCARCITY.find((s) => s.id === id);
	const counters = state.account.scarcity[id];
	if (!spec || !counters) throw new Error("Unknown design");
	const seals = id === "moon-collar" ? 3 : 10;
	const effort = state.seals >= seals && (id === "moon-collar" ? state.cleared.length >= 1 : state.masteries.length === 3 || state.towerBest >= 5);
	const supply = counters.issuedDesign < spec.globalCap && counters.seasonIssuedDesign < spec.seasonCap;
	return {
		...spec,
		seals,
		effort,
		supply,
		eligible: effort && supply && !state.designClaims.includes(id),
		globalRemaining: spec.globalCap - counters.issuedDesign,
		seasonRemaining: spec.seasonCap - counters.seasonIssuedDesign
	};
}
function reserveDesignPreview(state, id) {
	return transactDepth(state, (draft) => {
		const eligibility = designEligibility(draft, id);
		requireRule(eligibility.eligible, "NOT_READY", "Meet the effort requirements and remaining design supply.");
		draft.seals -= eligibility.seals;
		draft.account.scarcity[id].issuedDesign++;
		draft.account.scarcity[id].seasonIssuedDesign++;
		draft.designClaims.push(id);
	});
}
/** Daily allowances follow UTC dates in the app, without granting skipped-day rewards. */
function syncCalendarDay(state, now) {
	return transactDepth(state, (draft) => {
		requireRule(Number.isSafeInteger(now) && now >= draft.idle.lastAt, "INVALID_AMOUNT", "The calendar clock must move forward.");
		const key = Math.floor(now / 864e5);
		const previous = draft.idle.dayKey ?? Math.floor(draft.idle.lastAt / 864e5);
		if (key > previous) {
			const oldDay = draft.account.day;
			const advanced = advanceLocalDay(draft.account);
			requireRule(advanced.ok, "NOT_READY", "Calendar refresh is unavailable.");
			draft.account = advanced.state;
			draft.account.day = oldDay + key - previous;
			if (Math.floor((draft.account.day - 1) / 7) > Math.floor((oldDay - 1) / 7)) for (const quest of QUESTS.filter((q) => q.cadence === "weekly")) draft.account.quests[quest.id] = {
				progress: 0,
				claimed: false
			};
		}
		draft.idle.dayKey = Math.max(previous, key);
	});
}
/** One team treasure; quantity and other owned Relics never stack its percentage. */
function relicBonusA6(state) {
	if (!gameplayA6(state) || !state.relics.includes(state.selectedRelic ?? 0)) return 0;
	const relic = RELIC_EFFECTS.find((item) => item.id === state.selectedRelic);
	return relic ? Math.min(800, (relic.rarity + 1) * 200) : 0;
}
// packages/game-rules/src/cardrpg/depth/scarcity.ts
/** Local authority transition. A copied save is not an authenticated global ledger. */
var EDITIONS = {
	"moon-collar": {
		name: "Moon Collar",
		lifetime: 2400,
		season: 400,
		seals: 3
	},
	"golden-maneki": {
		name: "Golden Maneki",
		lifetime: 360,
		season: 60,
		seals: 10
	}
};
var copy = (v) => JSON.parse(JSON.stringify(v));
function check(v, message) {
	if (!v) throw Error(message);
}
var safe = (n) => Number.isSafeInteger(n) && Number(n) >= 0;
var id = (v) => typeof v === "string" && /^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,119}$/.test(v) && ![
	"constructor",
	"prototype",
	"__proto__"
].includes(v);
var month = (v) => typeof v === "string" && /^\d{4}-(0[1-9]|1[0-2])$/.test(v);
function canonical(v) {
	if (v === null || typeof v !== "object") return JSON.stringify(v);
	if (Array.isArray(v)) return `[${v.map(canonical).join(",")}]`;
	const obj = v;
	return `{${Object.keys(obj).sort().map((k) => `${JSON.stringify(k)}:${canonical(obj[k])}`).join(",")}}`;
}
var zero = () => ({
	"moon-collar": 0,
	"golden-maneki": 0
});
var claimKey = (account, edition, season) => `${account}|${edition}|${season}`;
function createIssuanceLedger(authorityId, now, legacy) {
	check(id(authorityId) && Number.isSafeInteger(now) && now >= 0 && now < 0xe677d21fdc00, "Invalid authority/time.");
	return fromGenesis({
		authorityId,
		season: new Date(now).toISOString().slice(0, 7),
		lifetime: legacy?.lifetime ?? zero(),
		seasonal: legacy?.seasonal ?? zero(),
		reservations: legacy?.reservations ?? []
	});
}
function fromGenesis(genesis) {
	check(genesis && id(genesis.authorityId) && month(genesis.season), "Invalid ledger genesis.");
	check(Array.isArray(genesis.reservations) && genesis.reservations.length <= 2760, "Invalid legacy records.");
	for (const edition of Object.keys(EDITIONS)) {
		const total = genesis.lifetime?.[edition], seasonal = genesis.seasonal?.[edition], spec = EDITIONS[edition];
		check(safe(total) && safe(seasonal) && total <= spec.lifetime && seasonal <= spec.season && seasonal <= total, "Legacy supply is inconsistent or over cap; new issuance is disabled.");
		check(genesis.reservations.filter((r) => r.edition === edition).length <= total, "Legacy reservations exceed issued supply.");
		check(genesis.reservations.filter((r) => r.edition === edition && r.season === genesis.season).length <= seasonal, "Legacy season counters are inconsistent.");
	}
	const seen = /* @__PURE__ */ new Set(), claims = /* @__PURE__ */ new Set();
	for (const r of genesis.reservations) {
		check(r && id(r.id) && id(r.accountId) && Object.hasOwn(EDITIONS, r.edition) && month(r.season) && r.season <= genesis.season && r.legacy === true && r.status === "live" && r.sequence === 0, "Invalid legacy reservation.");
		const key = claimKey(r.accountId, r.edition, r.season);
		check(!seen.has(r.id) && !claims.has(key), "Duplicate legacy reservation.");
		seen.add(r.id);
		claims.add(key);
	}
	return {
		version: 1,
		genesis: copy(genesis),
		revision: 0,
		currentSeason: genesis.season,
		lifetimeIssued: copy(genesis.lifetime),
		seasonIssued: { [genesis.season]: copy(genesis.seasonal) },
		accountClaims: [...claims],
		lastReservationDay: {},
		consumedProofIds: [],
		reservations: copy(genesis.reservations),
		badges: [],
		events: []
	};
}
function transition(ledger, command, context) {
	check(command && id(command.commandId) && id(command.accountId) && safe(command.expectedRevision), "Invalid command.");
	check(command.expectedRevision === ledger.revision, "Stale revision; reread local supply.");
	check(!ledger.events.some((e) => e.command.commandId === command.commandId), "Command ID was already used.");
	check(context && context.accountId === command.accountId && Number.isSafeInteger(context.now) && context.now >= 0 && context.now < 0xe677d21fdc00, "Invalid authority context.");
	check(typeof context.chapterOne === "boolean" && typeof context.allMasteries === "boolean" && safe(context.towerBest), "Invalid qualification.");
	const date = new Date(context.now).toISOString().slice(0, 10), season = date.slice(0, 7);
	check(season >= ledger.currentSeason, "Authority season cannot move backward.");
	check(!ledger.events.length || context.now >= ledger.events.at(-1).context.now, "Authority clock cannot move backward.");
	check(Array.isArray(context.effort) && context.effort.length <= 1e4, "Invalid effort receipts.");
	const proofs = /* @__PURE__ */ new Set(), days = /* @__PURE__ */ new Set();
	for (const p of context.effort) {
		check(p && id(p.id) && safe(p.day) && ["boss-day", "legacy-local"].includes(p.source) && !proofs.has(p.id) && !days.has(p.day), "Duplicate or invalid effort receipt.");
		proofs.add(p.id);
		days.add(p.day);
	}
	const event = {
		version: 1,
		sequence: ledger.revision + 1,
		command: copy(command),
		context: {
			...copy(context),
			effort: []
		},
		proofIds: []
	};
	if (command.kind === "advance-season") {
		check(season > ledger.currentSeason, "A later UTC month is required.");
		ledger.currentSeason = season;
		ledger.seasonIssued[season] ??= zero();
	} else {
		check(season === ledger.currentSeason, "Advance the local season before issuance.");
		if (command.kind === "reserve") {
			check(Object.hasOwn(EDITIONS, command.edition), "Unknown edition.");
			const spec = EDITIONS[command.edition];
			const key = claimKey(command.accountId, command.edition, season);
			check(ledger.lifetimeIssued[command.edition] < spec.lifetime && ledger.seasonIssued[season][command.edition] < spec.season, "Edition supply cap reached.");
			check(!ledger.accountClaims.includes(key), "One reservation per account, edition and season.");
			check(ledger.lastReservationDay[command.accountId] !== date, "Only one reservation per account per UTC day.");
			check(command.edition === "moon-collar" ? context.chapterOne : context.allMasteries || context.towerBest >= 5, "Complete the required chapter/mastery milestone.");
			const eligible = context.effort.filter((p) => !ledger.consumedProofIds.includes(p.id));
			check(eligible.length >= spec.seals, "More unspent boss-day seals are required.");
			event.context.effort = copy(eligible.slice(0, spec.seals));
			event.proofIds = event.context.effort.map((p) => p.id);
			ledger.consumedProofIds.push(...event.proofIds);
			ledger.lifetimeIssued[command.edition]++;
			ledger.seasonIssued[season][command.edition]++;
			event.reservationId = `${command.edition}:${ledger.lifetimeIssued[command.edition]}`;
			check(!ledger.reservations.some((r) => r.id === event.reservationId), "Reservation serial collision.");
			ledger.reservations.push({
				id: event.reservationId,
				edition: command.edition,
				accountId: command.accountId,
				season,
				sequence: event.sequence,
				status: "live"
			});
			ledger.accountClaims.push(key);
			ledger.lastReservationDay[command.accountId] = date;
		} else if (command.kind === "burn") {
			check(id(command.reservationId), "Invalid reservation.");
			const r = ledger.reservations.find((r) => r.id === command.reservationId);
			check(r && r.accountId === command.accountId && r.status === "live", "Choose your live reservation.");
			r.status = "burned";
			event.reservationId = r.id;
		} else if (command.kind === "fuse") {
			check(Array.isArray(command.reservationIds) && command.reservationIds.length === 2 && command.reservationIds[0] !== command.reservationIds[1], "Choose two different reservations.");
			const records = command.reservationIds.map((id) => ledger.reservations.find((r) => r.id === id));
			check(records.every((r) => r && r.accountId === command.accountId && r.status === "live" && r.edition === "moon-collar"), "Fusion needs two owned live Moon Collars.");
			check(records[0].season !== records[1].season && !ledger.badges.includes(command.accountId), "Use different seasons; only one fusion badge per account.");
			records.forEach((r) => {
				r.status = "fused";
			});
			ledger.badges.push(command.accountId);
		} else throw Error("Unknown issuance command.");
	}
	ledger.revision++;
	ledger.events.push(event);
	check(ledger.events.length <= 1e4, "Local ledger event limit reached.");
	return event;
}
function replayIssuance(genesis, events) {
	check(Array.isArray(events) && events.length <= 1e4, "Invalid event history.");
	const ledger = fromGenesis(genesis);
	for (const e of events) {
		check(e && e.version === 1 && e.sequence === ledger.revision + 1, "Invalid event order.");
		check(canonical(transition(ledger, e.command, e.context)) === canonical(e), "Event payload or proof use is inconsistent.");
	}
	return ledger;
}
function validateIssuance(ledger) {
	check(ledger?.version === 1, "Unsupported ledger version.");
	check(canonical(replayIssuance(ledger.genesis, ledger.events)) === canonical(ledger), "Ledger snapshot does not match its event history.");
}
function applyIssuance(ledger, command, context) {
	try {
		check(context?.accountId === command?.accountId, "Authority account differs from command.");
		validateIssuance(ledger);
		const old = ledger.events.find((e) => e.command.commandId === command.commandId);
		if (old) {
			check(canonical(old.command) === canonical(command), "Command ID reused with a changed payload.");
			return {
				ok: true,
				ledger,
				receipt: copy(old),
				replayed: true
			};
		}
		const next = copy(ledger);
		return {
			ok: true,
			ledger: next,
			receipt: transition(next, command, context),
			replayed: false
		};
	} catch (error) {
		return {
			ok: false,
			ledger,
			error: error instanceof Error ? error.message : "Invalid local issuance."
		};
	}
}
// packages/game-rules/src/cardrpg/depth/editions-v4.ts
var localEditionAccount = (s) => `local-${s.account.seed}`;
function legacyLedger(s, now) {
	const accountId = localEditionAccount(s), season = new Date(now).toISOString().slice(0, 7), reservations = [];
	const lifetime = {
		"moon-collar": 0,
		"golden-maneki": 0
	}, seasonal = { ...lifetime };
	for (const edition of Object.keys(EDITIONS)) {
		const old = s.account.scarcity[edition];
		lifetime[edition] = old?.issuedDesign ?? 0;
		seasonal[edition] = old?.seasonIssuedDesign ?? 0;
		if (s.designClaims.includes(edition) || s.account.designClaims.includes(edition)) reservations.push({
			id: `legacy:${edition}`,
			edition,
			accountId,
			season,
			sequence: 0,
			status: "live",
			legacy: true
		});
	}
	return createIssuanceLedger(`save-${s.account.seed}`, now, {
		lifetime,
		seasonal,
		reservations
	});
}
function editionLedgerV4(s, now = Date.now()) {
	return s.v4?.issuance ?? legacyLedger(s, now);
}
function editionContextV4(s, ledger, now) {
	const accountId = localEditionAccount(s);
	const earned = Object.entries(s.account.inventory.stacks).filter(([k, v]) => /^depth-seal-\d+$/.test(k) && v > 0).map(([key]) => ({
		id: `${accountId}:${key}`,
		day: Number(key.slice(11)),
		source: "boss-day"
	}));
	const legacyCount = s.v4?.legacySealCount ?? Math.max(0, s.seals - earned.length);
	const legacy = Array.from({ length: Math.min(legacyCount, 1e4) }, (_, i) => ({
		id: `${accountId}:legacy:${i}`,
		day: 1e6 + i,
		source: "legacy-local"
	}));
	return {
		accountId,
		now,
		effort: [...earned, ...legacy].filter((p) => !ledger.consumedProofIds.includes(p.id) && !s.v4?.spentEffortIds?.includes(p.id)).slice(0, s.seals),
		chapterOne: s.cleared.includes(1),
		allMasteries: [
			1,
			2,
			3
		].every((c) => s.masteries.includes(c)),
		towerBest: s.towerBest
	};
}
function issueEditionV4(state, command, now = Date.now()) {
	return transactDepth(state, (s) => {
		requireHome(s);
		requireRule(gameplayV4(s) && !!s.v4, "NOT_READY", "Enable Gameplay v4 first.");
		let ledger;
		try {
			ledger = editionLedgerV4(s, now);
		} catch (e) {
			requireRule(false, "NOT_READY", e instanceof Error ? e.message : "Legacy local supply is inconsistent.");
		}
		requireRule(command.accountId === localEditionAccount(s), "NOT_READY", "Wrong local account.");
		const earned = Object.keys(s.account.inventory.stacks).filter((k) => /^depth-seal-\d+$/.test(k) && s.account.inventory.stacks[k] > 0).length;
		s.v4.legacySealCount ??= Math.max(0, s.seals - earned);
		const result = applyIssuance(ledger, command, editionContextV4(s, ledger, now));
		requireRule(result.ok, "NOT_READY", result.ok ? "" : result.error);
		if (result.replayed) return;
		if (command.kind === "reserve") {
			const cost = EDITIONS[command.edition].seals;
			requireRule(Number.isSafeInteger(s.seals) && s.seals >= cost, "INSUFFICIENT_FUNDS", "More boss seals are required.");
			s.seals -= cost;
		}
		s.v4.issuance = result.ledger;
	});
}
/** Tailoring consumes proof identity with the seal balance, in its existing transaction. */
function spendSealProofsV4(s, count) {
	if (!s.gameplayV4 && !s.run?.gameplayV4) return;
	const ledger = s.v4?.issuance ?? createIssuanceLedger("effort", 0), earned = Object.keys(s.account.inventory.stacks).filter((k) => /^depth-seal-\d+$/.test(k) && s.account.inventory.stacks[k] > 0).length;
	s.v4.legacySealCount ??= Math.max(0, s.seals - earned);
	const eligible = editionContextV4(s, ledger, 0).effort;
	requireRule(eligible.length >= count, "INSUFFICIENT_FUNDS", "More unspent seal receipts are required.");
	s.v4.spentEffortIds ??= [];
	s.v4.spentEffortIds.push(...eligible.slice(0, count).map((p) => p.id));
}
/** Keep the legacy API from bypassing v4 receipt accounting; OFF remains exact. */
function reserveDesignPreviewV4Guard(state, id) {
	if (!gameplayV4(state)) return reserveDesignPreview(state, id);
	return transactDepth(state, () => requireRule(false, "NOT_READY", "Use the local edition ledger to reserve a design."));
}
// packages/game-rules/src/cardrpg/depth/equipment.ts
var SETS = [
	{
		id: "hearthloom",
		name: "Hearthloom",
		two: "Defend adds 25 shield.",
		four: "Defend links your weakest ally to you.",
		twoEffect: "defend-shield",
		fourEffect: "defend-link"
	},
	{
		id: "moonwick",
		name: "Moonwick",
		two: "Hits on Scented foes add 1 break.",
		four: "Ultimates refund 20 charge.",
		twoEffect: "marked-break",
		fourEffect: "ultimate-refund"
	},
	{
		id: "mossbrew",
		name: "Mossbrew",
		two: "Healing skills cleanse one debuff.",
		four: "Applying Steep also grants Cozy.",
		twoEffect: "healing-cleanse",
		fourEffect: "steep-cozy"
	},
	{
		id: "rainlace",
		name: "Rainlace",
		two: "Row swaps grant 25 shield to both cats.",
		four: "Rear-row cats heal 16 HP each round.",
		twoEffect: "swap-shield",
		fourEffect: "rear-heal"
	},
	{
		id: "crumbweave",
		name: "Crumbweave",
		two: "Every third attack plants a Crumb trail.",
		four: "A successful detonation restores 1 energy.",
		twoEffect: "third-crumb",
		fourEffect: "detonate-energy"
	},
	{
		id: "bellsteel",
		name: "Bellsteel",
		two: "Saucer riposte deals 8 extra damage.",
		four: "Defend grants Shelter and one Riposte stack.",
		twoEffect: "counter-plus",
		fourEffect: "defend-riposte"
	},
	{
		id: "emberfelt",
		name: "Emberfelt",
		two: "Scald lasts one extra round.",
		four: "Your Scald ticks grant you 3 charge.",
		twoEffect: "long-scald",
		fourEffect: "scald-charge"
	},
	{
		id: "velvetrim",
		name: "Velvetrim",
		two: "Your single-foe skills can target the rear.",
		four: "Begin each encounter with a Yarn decoy.",
		twoEffect: "pierce-row",
		fourEffect: "opening-decoy"
	}
];
var UNIQUES = [
	{
		id: "doorstop",
		name: "The patient doorstop",
		description: "Defend also heals you for 25 HP."
	},
	{
		id: "nightglass",
		name: "The nightglass needle",
		description: "First hit each round on a marked foe restores 1 energy."
	},
	{
		id: "seedcup",
		name: "The first seedcup",
		description: "Your first healing skill each battle grants Second sprout."
	},
	{
		id: "rainbell",
		name: "The rain bell",
		description: "Row swapping clears your debuffs."
	},
	{
		id: "crumbbook",
		name: "The crumb ledger",
		description: "Detonation grants you 35 shield."
	},
	{
		id: "panlid",
		name: "The returning pan lid",
		description: "Defend grants two Riposte stacks."
	},
	{
		id: "warmwick",
		name: "The unfading wick",
		description: "Applying Scald restores 6 HP to you."
	},
	{
		id: "silkspool",
		name: "The hidden silk spool",
		description: "Your first ultimate grants a Yarn decoy."
	},
	{
		id: "starladle",
		name: "The star ladle",
		description: "Your first ultimate refunds 25 charge."
	},
	{
		id: "softcollar",
		name: "The soft collar",
		description: "Start each battle with Second sprout."
	},
	{
		id: "tidetray",
		name: "The tide tray",
		description: "Pour energy also gives the weakest ally 30 shield."
	},
	{
		id: "gardenkey",
		name: "The garden key",
		description: "Cleansing a debuff heals its patient for 25 HP."
	}
];
var AFFIXES = [
	[
		"hp",
		"Sturdy seams",
		[...EQUIPMENT_SLOTS],
		8,
		18,
		"Maximum HP"
	],
	[
		"attack",
		"Keen edge",
		["weapon", "relic"],
		2,
		5,
		"Attack"
	],
	[
		"defense",
		"Quilted lining",
		["outfit", "charm"],
		2,
		4,
		"Defense"
	],
	[
		"critBp",
		"Precise stitch",
		["weapon", "charm"],
		80,
		160,
		"Critical chance in basis points"
	],
	[
		"critDamageBp",
		"Sharp finish",
		["weapon", "relic"],
		150,
		300,
		"Critical bonus in basis points"
	],
	[
		"effectHitBp",
		"Clear aroma",
		["weapon", "charm"],
		100,
		240,
		"Effect Hit in basis points"
	],
	[
		"effectResistBp",
		"Firm handle",
		["outfit", "relic"],
		100,
		240,
		"Effect Resist in basis points"
	],
	[
		"healingBp",
		"Gentle steep",
		["charm", "relic"],
		100,
		220,
		"Healing bonus in basis points"
	],
	[
		"shieldBp",
		"Warm lining",
		["outfit", "charm"],
		100,
		220,
		"Shield bonus in basis points"
	],
	[
		"frontDamage",
		"Doorway edge",
		["weapon", "outfit"],
		2,
		5,
		"Extra raw damage from the front row"
	],
	[
		"rearDamage",
		"Back shelf",
		["weapon", "charm"],
		2,
		5,
		"Extra raw damage from the rear row"
	],
	[
		"bossDamage",
		"Giant stitch",
		["weapon", "relic"],
		3,
		6,
		"Extra raw damage against bosses"
	],
	[
		"eliteDamage",
		"Brass point",
		["weapon", "charm"],
		3,
		6,
		"Extra raw damage against elites"
	],
	[
		"scaldDamage",
		"Hot finish",
		["weapon", "relic"],
		2,
		5,
		"Extra raw damage against Scalded foes"
	],
	[
		"markedDamage",
		"Scent thread",
		["weapon", "charm"],
		2,
		5,
		"Extra raw damage against Scented foes"
	],
	[
		"brokenDamage",
		"Split glaze",
		["weapon", "relic"],
		3,
		6,
		"Extra raw damage against broken foes"
	],
	[
		"shieldedDamage",
		"Covered paw",
		["weapon", "outfit"],
		2,
		5,
		"Extra raw damage while shielded"
	],
	[
		"lowHpDamage",
		"Last crumb",
		["weapon", "relic"],
		3,
		6,
		"Extra raw damage below half HP"
	],
	[
		"healFlat",
		"Full cup",
		["charm", "relic"],
		3,
		6,
		"Extra skill healing"
	],
	[
		"shieldFlat",
		"Thick fold",
		["outfit", "charm"],
		3,
		6,
		"Extra skill shielding"
	],
	[
		"openingShield",
		"Door cushion",
		["outfit", "relic"],
		5,
		10,
		"Opening shield"
	],
	[
		"openingCharge",
		"Late glow",
		["charm", "relic"],
		2,
		5,
		"Opening ultimate charge"
	],
	[
		"dotPower",
		"Slow ember",
		["weapon", "charm"],
		1,
		3,
		"Extra Scald damage per stack"
	],
	[
		"roundHeal",
		"Mending thread",
		["outfit", "relic"],
		2,
		4,
		"Heal each round"
	],
	[
		"cleanseShield",
		"Clear cloth",
		["charm", "relic"],
		4,
		8,
		"Shield after cleansing a debuff"
	],
	[
		"ultimateCharge",
		"Cup reserve",
		["weapon", "relic"],
		2,
		4,
		"Charge refunded after an ultimate"
	],
	[
		"counterPower",
		"Ringing rim",
		["weapon", "outfit"],
		2,
		5,
		"Extra Riposte damage"
	],
	[
		"executeThreshold",
		"Fine recipe",
		["weapon", "charm"],
		1,
		2,
		"Raise execute HP threshold by percentage points"
	],
	[
		"statusDuration",
		"Slow steep",
		["charm", "relic"],
		1,
		1,
		"Extend your Steep by rounds, capped at 2"
	],
	[
		"breakShield",
		"Soft landing",
		["outfit", "relic"],
		4,
		9,
		"Gain shield after breaking a foe"
	]
].map(([stat, name, slots, min, max, description]) => ({
	id: `affix-${stat}`,
	name,
	slots,
	stat,
	description,
	tiers: [
		1,
		2,
		3
	].map((tier) => [Math.max(1, Math.round(min * tier * .25)), Math.max(1, Math.round(max * tier * .25))])
}));
var AFFIX_BY_ID = Object.fromEntries(AFFIXES.map((a) => [a.id, a]));
var pieceNames = {
	weapon: "Utensil",
	outfit: "Apron",
	charm: "Clasp",
	relic: "Keepsake"
};
var GEAR = SETS.flatMap((set, si) => RARITY_ORDER.flatMap((rarity, ri) => EQUIPMENT_SLOTS.map((slot, sl) => {
	const id = `${set.id}-${slot}-${rarity}`, old = ITEMS.find((i) => i.id === id), legendary = rarity === "legendary";
	const unique = legendary ? UNIQUES[(si * 4 + sl) % UNIQUES.length] : void 0;
	return {
		id,
		name: unique ? `${unique.name} · ${set.name} ${pieceNames[slot]}` : old?.name ?? `${rarity[0].toUpperCase() + rarity.slice(1)} ${set.name} ${pieceNames[slot]}`,
		slot,
		rarity,
		setId: set.id,
		level: 1 + ri * 8 + Math.floor(si / 3) * 4,
		chapter: si < 3 ? 1 : si < 6 ? 2 : 3,
		source: legendary ? "Chapter bosses, elites and mastery tailoring" : si < 3 ? "Tangled Cafe and chosen tailoring" : si < 6 ? "Rooftop Orchard and chosen tailoring" : "Midnight Pantry and chosen tailoring",
		main: old?.main.stat ?? [
			"attack",
			"hp",
			"defense",
			"hp"
		][sl],
		value: Math.round((old?.main.value ?? [
			12 + ri * 4,
			45 + ri * 12,
			6 + ri * 2,
			25 + ri * 8
		][sl]) * .75),
		affixes: AFFIXES.filter((a) => a.slots.includes(slot)).slice(si % 5, si % 5 + ri).map((a) => a.id),
		unique: unique?.id,
		story: unique ? unique.description : `${set.name} changes your ${set.two.toLowerCase()} Collect two or four matching pieces.`
	};
})));
var GEAR_BY_ID = Object.fromEntries(GEAR.map((g) => [g.id, g]));
function makeGear(state, id, seed) {
	const template = GEAR_BY_ID[id];
	requireRule(template, "UNKNOWN_ID", "Unknown equipment template.");
	const rng = new Rng(seed), tier = Math.min(3, Math.max(1, Math.floor(template.level / 10) + 1));
	const rolls = Object.fromEntries(template.affixes.map((id) => {
		const range = AFFIX_BY_ID[id].tiers[tier - 1];
		return [id, rng.int(range[0], range[1])];
	}));
	return {
		id: `depth-gear-${state.account.nextId++}`,
		templateId: id,
		enhancement: 0,
		tier,
		affixes: [...template.affixes],
		rolls
	};
}
function initializeEquipment(state) {
	if (state.gear.length) return;
	for (const item of state.account.inventory.items) {
		const g = makeGear(state, item.itemId, deriveSeed(state.account.seed, state.gear.length));
		g.enhancement = item.enhancement;
		state.gear.push(g);
		for (const card of state.account.cards) for (const [slot, id] of Object.entries(state.account.loadouts[card.id] ?? {})) if (id === item.id) {
			state.equipment[card.cardId] ??= {};
			state.equipment[card.cardId][slot] = g.id;
		}
	}
}
function equippedItems(state, cardId) {
	return Object.entries(state.equipment[cardId] ?? {}).filter(([slot]) => !(!gameplayA6(state) && slot === "relic" && cardId === state.team[0] && state.relics.includes(state.selectedRelic ?? 0))).map(([, id]) => state.gear.find((g) => g.id === id)).filter((g) => !!g);
}
/** Apply current balance bounds when reading both new and older saved rolls. */
function gearAffixRoll(item, id, state) {
	const [minimum, maximum] = AFFIX_BY_ID[id].tiers[item.tier - 1];
	const roll = Math.min(maximum, Math.max(minimum, item.rolls[id] ?? minimum));
	return state?.formationC2 ? Math.max(1, Math.round(roll * ECONOMY_C2.equipment.affixScale)) : roll;
}
function equipmentEffects(state, cardId) {
	const items = equippedItems(state, cardId), counts = {}, effects = [], bonuses = {};
	for (const item of items) {
		const template = GEAR_BY_ID[item.templateId];
		counts[template.setId] = (counts[template.setId] ?? 0) + 1;
		if (template.unique) effects.push("unique:" + template.unique);
		for (const id of item.affixes) {
			const a = AFFIX_BY_ID[id];
			bonuses[a.stat] = (bonuses[a.stat] ?? 0) + gearAffixRoll(item, id, state);
		}
	}
	for (const set of SETS) {
		if ((counts[set.id] ?? 0) >= 2) effects.push(set.twoEffect);
		if ((counts[set.id] ?? 0) >= 4) effects.push(set.fourEffect);
	}
	return {
		effects: [...new Set(effects)],
		bonuses,
		counts
	};
}
function depthStats(state, cardId) {
	const card = state.account.cards.find((c) => c.cardId === cardId);
	requireRule(card, "UNKNOWN_ID", "Cat is not collected.");
	const v4 = gameplayV4(state);
	const stats = v4 ? nakedStatsV4(state, cardId) : computeCardStats({
		...state.account,
		loadouts: {}
	}, card.id), items = equippedItems(state, cardId), bonus = equipmentEffects(state, cardId).bonuses;
	for (const item of items) {
		const template = GEAR_BY_ID[item.templateId];
		stats[template.main] += v4 ? gearMainV4(state, cardId, item) : Math.round(template.value * (1 + item.enhancement * .06));
	}
	for (const key of Object.keys(stats)) stats[key] = Math.min(CARD_RPG_CONFIG.statCaps[key], stats[key] + (bonus[key] ?? 0));
	const awakening = v4 ? 0 : state.awakened[cardId] ?? 0;
	stats.hp = Math.round(stats.hp * (1 + awakening * .03));
	stats.attack = Math.round(stats.attack * (1 + awakening * .03));
	const collection = collectionBonusA6(state);
	if (collection) {
		stats.hp = Math.min(CARD_RPG_CONFIG.statCaps.hp, Math.round(stats.hp * (1 + collection / 1e4)));
		stats.attack = Math.min(CARD_RPG_CONFIG.statCaps.attack, Math.round(stats.attack * (1 + collection / 1e4)));
	}
	const treasure = relicBonusA6(state);
	if (treasure && state.team.includes(cardId)) for (const stat of [
		"hp",
		"attack",
		"defense"
	]) stats[stat] = Math.min(CARD_RPG_CONFIG.statCaps[stat], Math.floor(stats[stat] * (1 + treasure / 1e4)));
	return stats;
}
function equipGear(state, cardId, instanceId, slot) {
	return transactDepth(state, (s) => {
		requireHome(s);
		requireRule(s.account.cards.some((c) => c.cardId === cardId), "UNKNOWN_ID", "Collect this cat first.");
		s.equipment[cardId] ??= {};
		if (instanceId === null) {
			requireRule(slot && EQUIPMENT_SLOTS.includes(slot), "WRONG_SLOT", "Choose a valid slot.");
			delete s.equipment[cardId][slot];
			return;
		}
		const item = s.gear.find((g) => g.id === instanceId);
		requireRule(item, "UNKNOWN_ID", "Equipment is missing.");
		const template = GEAR_BY_ID[item.templateId];
		for (const loadout of Object.values(s.equipment)) for (const [slot, id] of Object.entries(loadout)) if (id === instanceId) delete loadout[slot];
		s.equipment[cardId][template.slot] = instanceId;
	});
}
function enhancementPreview(item, state, cardId) {
	if (state?.economyV3) {
		const quote = enhancementQuote(Math.min(9, item.enhancement), item.blessingBp ?? 0), before = cardId ? gearMainV4(state, cardId, item) : GEAR_BY_ID[item.templateId].value;
		return {
			before,
			after: cardId ? gearMainV4(state, cardId, {
				...item,
				enhancement: Math.min(10, item.enhancement + 1)
			}) : before,
			cost: {
				fish: quote.fish,
				threads: 0
			},
			chanceBp: item.enhancement >= 10 ? 0 : quote.chanceBp,
			blessingBp: item.blessingBp ?? 0
		};
	}
	if (state && cardId && gameplayV4(state)) return {
		before: gearMainV4(state, cardId, item),
		after: gearMainV4(state, cardId, {
			...item,
			enhancement: Math.min(12, item.enhancement + 1)
		}),
		cost: {
			fish: 30 * (item.enhancement + 1) ** 2,
			threads: 3 * (item.enhancement + 1)
		}
	};
	const g = GEAR_BY_ID[item.templateId];
	return {
		before: Math.round(g.value * (1 + .06 * item.enhancement)),
		after: Math.round(g.value * (1 + .06 * (item.enhancement + 1))),
		cost: {
			fish: 30 * (item.enhancement + 1) ** 2,
			threads: 3 * (item.enhancement + 1)
		}
	};
}
function enhanceGear(state, id) {
	return transactDepth(state, (s) => {
		requireHome(s);
		const item = s.gear.find((g) => g.id === id);
		requireRule(item, "UNKNOWN_ID", "Equipment is missing.");
		requireRule(item.enhancement < (s.economyV3 ? ECONOMY_V3.enhancement.max : 12), "MAX_LEVEL", `Enhancement is capped at +${s.economyV3 ? 10 : 12}.`);
		spend(s.account, enhancementPreview(item, s).cost);
		if (s.economyV3) {
			const quote = enhancementQuote(item.enhancement, item.blessingBp ?? 0), attempt = item.enhanceAttempts ?? 0;
			requireRule(Number.isSafeInteger(attempt) && attempt < 1e6, "MAX_LEVEL", "Enhancement limit reached.");
			let hash = 0;
			for (const ch of id) hash = Math.imul(hash, 31) + ch.charCodeAt(0) >>> 0;
			const roll = new Rng(deriveSeed(s.account.seed, deriveSeed(hash, attempt))).int(0, 9999);
			item.enhanceAttempts = attempt + 1;
			if (roll < quote.chanceBp) {
				item.enhancement++;
				item.blessingBp = 0;
			} else item.blessingBp = Math.min(1e4, (item.blessingBp ?? 0) + ECONOMY_V3.enhancement.blessingBp);
		} else item.enhancement++;
		progressEnhance(s);
	});
}
function progressEnhance(s) {
	const p = s.account.quests.mender;
	if (p) p.progress = Math.min(6, p.progress + 1);
}
function reforgeGear(state, id, index, affixId) {
	return transactDepth(state, (s) => {
		requireHome(s);
		const item = s.gear.find((g) => g.id === id), affix = AFFIX_BY_ID[affixId];
		requireRule(item && Number.isInteger(index) && index >= 0 && index < item.affixes.length && affix, "INVALID_AMOUNT", "Choose an existing affix to replace.");
		requireRule(affix.slots.includes(GEAR_BY_ID[item.templateId].slot) && !item.affixes.includes(affixId), "WRONG_SLOT", "Choose a compatible different affix.");
		spend(s.account, {
			fish: 90,
			threads: 15
		});
		delete item.rolls[item.affixes[index]];
		item.affixes[index] = affixId;
		item.rolls[affixId] = affix.tiers[item.tier - 1][0];
	});
}
function salvageGear(state, id) {
	return transactDepth(state, (s) => {
		requireHome(s);
		const item = s.gear.find((g) => g.id === id);
		requireRule(item, "UNKNOWN_ID", "Equipment is missing.");
		requireRule(!Object.values(s.equipment).some((l) => Object.values(l).includes(id)), "EQUIPPED", "Unequip before salvaging.");
		s.gear = s.gear.filter((g) => g.id !== id);
		s.account.currencies.threads += CARD_RPG_CONFIG.rarity[GEAR_BY_ID[item.templateId].rarity].salvage;
	});
}
function craftGear(state, id) {
	return transactDepth(state, (s) => {
		requireHome(s);
		const g = GEAR_BY_ID[id];
		requireRule(g, "UNKNOWN_ID", "Choose a template.");
		requireRule(!gameplayV4(s) || s.gear.length < 240, "MAX_LEVEL", "Equipment shelf is full (240). Salvage a piece before tailoring.");
		requireRule(s.account.chapter >= g.chapter, "LOCKED", "Reach the item source chapter first.");
		if (g.rarity === "legendary") {
			const { materials, seals } = legendaryTailoringRequirements(s);
			requireRule(s.cleared.includes(3) && s.materials >= materials && s.seals >= seals, "LOCKED", `Legendary tailoring needs a Pantry clear, ${materials} materials and ${seals} boss seal${seals === 1 ? "" : "s"}.`);
			spendSealProofsV4(s, seals);
			s.materials -= materials;
			s.seals -= seals;
		}
		spend(s.account, gearCostV4(id, s));
		s.gear.push(makeGear(s, id, deriveSeed(s.account.seed, s.account.nextId)));
	});
}
/** The next rank's cost is visible even before its requirements are met. */
function awakeningCost(rank) {
	return {
		materials: 30 * (rank + 1),
		currencies: {
			fish: 300 * (rank + 1),
			threads: 40 * (rank + 1),
			essence: 5 * (rank + 1)
		}
	};
}
function awakenCat(state, id) {
	return transactDepth(state, (s) => {
		requireHome(s);
		const c = s.account.cards.find((c) => c.cardId === id), rank = s.awakened[id] ?? 0;
		requireRule(c && c.level >= 10 && c.stars >= 2, "LOCKED", "Awakening needs level 10 and two stars.");
		requireRule(rank < 3, "MAX_LEVEL", "Awakening is capped at three.");
		const { materials, currencies } = awakeningCost(rank);
		requireRule(s.materials >= materials, "INSUFFICIENT_FUNDS", `Need ${materials} mastery materials.`);
		spend(s.account, currencies);
		s.materials -= materials;
		s.awakened[id] = rank + 1;
	});
}
var LEGACY_DROP_ODDS = {
	battle: {
		common: 6500,
		rare: 3e3,
		epic: 500,
		legendary: 0
	},
	elite: {
		common: 0,
		rare: 7e3,
		epic: 2700,
		legendary: 300
	},
	boss: {
		common: 0,
		rare: 2e3,
		epic: 7e3,
		legendary: 1e3
	}
};
function gearDropPreview(state, kind, chapter) {
	const cap = state.economyV3 ? ECONOMY_V3.drops.halfUntil : state.formationC2 ? ECONOMY_C2.dropsPerDay : 6;
	const remaining = Math.max(0, cap - (state.account.inventory.stacks[`depth-drops-${state.account.day}`] ?? 0));
	const base = state.economyV3 ? ECONOMY_V3.drops[kind].odds : state.formationC2 ? ECONOMY_C2.drops[kind === "firstBoss" || kind === "tower" ? "boss" : kind] : LEGACY_DROP_ODDS[kind === "firstBoss" || kind === "tower" ? "boss" : kind];
	const chanceBp = state.economyV3 ? ECONOMY_V3.drops[kind].chanceBp * dropMultiplierBp(state.account.inventory.stacks[`depth-drops-${state.account.day}`] ?? 0) / 1e4 : 1e4;
	const odds = Object.fromEntries(RARITY_ORDER.map((r) => [r, remaining ? base[r] * chanceBp / 1e4 : 0]));
	const pool = GEAR.filter((g) => g.chapter <= chapter);
	return {
		cap,
		remaining,
		base,
		odds,
		chanceBp,
		pool: pool.map((g) => ({
			id: g.id,
			rarity: g.rarity,
			probability: odds[g.rarity] / 1e4 / pool.filter((p) => p.rarity === g.rarity).length
		}))
	};
}
function dropGear(state, kind, seed, chapter) {
	const dayKey = `depth-drops-${state.account.day}`, count = state.account.inventory.stacks[dayKey] ?? 0;
	const { remaining, base, chanceBp } = gearDropPreview(state, kind, chapter);
	if (!remaining) return null;
	if (state.economyV3) {
		state.account.inventory.stacks[dayKey] = count + 1;
		if (new Rng(deriveSeed(seed, 701)).int(0, 9999) >= chanceBp) return null;
	}
	const rng = new Rng(seed), roll = rng.int(0, 9999), rarity = roll < base.legendary ? "legendary" : roll < base.legendary + base.epic ? "epic" : roll < base.legendary + base.epic + base.rare ? "rare" : "common";
	const pool = GEAR.filter((g) => g.chapter <= chapter && g.rarity === rarity), template = pool[rng.int(0, pool.length - 1)];
	state.account.inventory.stacks[dayKey] = count + 1;
	if (gameplayV4(state) && state.gear.length >= 240) {
		const amount = CARD_RPG_CONFIG.rarity[rarity].salvage;
		if (state.formationC2) {
			requireRule(Number.isSafeInteger(state.account.currencies.threads + amount), "MAX_LEVEL", "Thread balance is full.");
			state.account.currencies.threads += amount;
			state.run?.earnedItems.push(`Full shelf: ${template.name} → ${amount} threads.`);
		} else {
			const threads = grantDepth(state, { threads: amount }).currencies.threads ?? 0;
			state.run?.earnedItems.push(`Full shelf: ${template.name} converted to ${threads} threads (daily reward cap applies).`);
		}
		return null;
	}
	state.gear.push(makeGear(state, template.id, deriveSeed(seed, 7)));
	return template.id;
}
// packages/game-rules/src/cardrpg/depth/stars-v4.ts
var combatNode = (node) => [
	"battle",
	"elite",
	"boss"
].includes(node.kind);
var starRoundBudgetV4 = (node) => node.kind === "boss" ? 10 : node.kind === "elite" ? 8 : 6;
function nodeStarGoalsV4(node) {
	return combatNode(node) ? [
		{
			id: "finish",
			text: "Win this encounter."
		},
		{
			id: "healthy",
			text: "Win without a cat falling."
		},
		{
			id: "challenge",
			text: `Win within ${starRoundBudgetV4(node)} rounds.`
		}
	] : [
		{
			id: "finish",
			text: "Complete this stop."
		},
		{
			id: "healthy",
			text: "Leave every cat with at least half HP."
		},
		{
			id: "challenge",
			text: "Visit with a four-mark crew job active."
		}
	];
}
/** A chapter/band/map position has three badges; replaying never creates a new reward identity. */
function nodeStarKeyV4(run, node) {
	return `${run.chapter}/${run.challengeLevel ?? 0}/${node.id}/${node.kind}`;
}
/** Read only. Called with the committed encounter, before finishEncounter removes it. */
function combatStarsV4(run, node, battle) {
	if (!run.gameplayV4 || !battle.v4 || !combatNode(node) || !battle.result) return null;
	const won = battle.result === "party";
	const ids = new Set(battle.initial.cats.map((cat) => cat.id));
	const fell = battle.log.some((event) => event.kind === "defeat" && ids.has(event.targetId));
	const intact = battle.actors.filter((actor) => actor.side === "party").every((actor) => actor.hp > 0);
	return {
		key: nodeStarKeyV4(run, node),
		chapter: run.chapter,
		band: run.challengeLevel ?? 0,
		nodeId: node.id,
		kind: node.kind,
		conditions: [
			won,
			won && intact && !fell,
			won && battle.round <= starRoundBudgetV4(node)
		]
	};
}
/** Read only. Invoke only after a successful noncombat resolution, never on a preview. */
function stopStarsV4(state, run, node, maxHp) {
	if (!run.gameplayV4 || combatNode(node) || !run.visited.includes(node.id)) return null;
	const healthy = state.team.every((id) => Number.isFinite(maxHp[id]) && maxHp[id] > 0 && (run.hp[id] ?? 0) >= maxHp[id] / 2);
	return {
		key: nodeStarKeyV4(run, node),
		chapter: run.chapter,
		band: run.challengeLevel ?? 0,
		nodeId: node.id,
		kind: node.kind,
		conditions: [
			true,
			healthy,
			crewThresholds(state.team).some((crew) => crew.threshold === 4)
		]
	};
}
/** Badges are independent achievements. Merging is monotone and cannot award any badge twice. */
function mergeNodeStarsV4(before, receipt) {
	if (before && before.key !== receipt.key) throw Error("Different route positions cannot share stars.");
	const conditions = receipt.conditions.map((earned, index) => earned || !!before?.conditions[index]);
	const added = conditions.filter((earned, index) => earned && !before?.conditions[index]).length;
	return {
		value: {
			...receipt,
			conditions
		},
		added
	};
}
// packages/game-rules/src/cardrpg/depth/journey-v4.ts
var STAR_TIERS_V4 = [
	3,
	9,
	18,
	30,
	60
];
var STAR_REWARDS_V4 = [
	{
		id: "stars-3",
		target: 3,
		name: "First constellation",
		reward: { stamps: 30 }
	},
	{
		id: "stars-9",
		target: 9,
		name: "A brighter route",
		reward: { threads: 20 }
	},
	{
		id: "stars-18",
		target: 18,
		name: "A sky of possibilities",
		reward: { stamps: 40 }
	}
];
var discoveryIdsV4 = () => [
	...[
		"door",
		"kettle",
		"table",
		"lantern"
	].flatMap((id) => [2, 4].map((n) => `crew:${id}:${n}`)),
	...SETS.map((s) => `set:${s.id}`),
	...CARDS.flatMap((c) => [
		2,
		3,
		4,
		5
	].map((rank) => `rank:${c.id}:${rank}`)),
	"legendary:first",
	...STAR_TIERS_V4.map((n) => `stars:${n}`)
];
var emptyJourneyV4 = () => ({
	version: 1,
	stars: {},
	found: [],
	pending: [],
	sequence: 0,
	claims: []
});
var starCountV4 = (s) => Object.values(s.v4?.journey?.stars ?? {}).reduce((n, r) => n + r.conditions.filter(Boolean).length, 0);
function presentDiscoveries(s) {
	const discoveries = [];
	for (const crew of crewThresholds(s.team)) for (const threshold of [2, 4]) if (crew.threshold >= threshold) discoveries.push({
		id: `crew:${crew.id}:${threshold}`,
		kind: "crew",
		itemId: crew.id,
		text: `${crew.name} reached its ${threshold}-mark bonus.`
	});
	const sets = new Set(s.v4?.journal?.sets ?? []);
	for (const slots of Object.values(s.equipment)) {
		const worn = Object.values(slots).map((id) => s.gear.find((g) => g.id === id)).filter(Boolean);
		if (worn.length === 4 && new Set(worn.map((g) => GEAR_BY_ID[g.templateId].setId)).size === 1) sets.add(GEAR_BY_ID[worn[0].templateId].setId);
	}
	for (const id of sets) discoveries.push({
		id: `set:${id}`,
		kind: "set",
		itemId: id,
		text: `${SETS.find((set) => set.id === id).name}: all four pieces together.`
	});
	for (const cat of s.account.cards) for (let rank = 2; rank <= cat.stars; rank++) discoveries.push({
		id: `rank:${cat.cardId}:${rank}`,
		kind: "rank",
		itemId: cat.cardId,
		text: `${CARDS.find((c) => c.id === cat.cardId).name} reached rank ${rank}.`
	});
	const legendaryCat = s.account.cards.find((c) => CARDS.find((x) => x.id === c.cardId)?.rarity === "legendary");
	const legendaryGear = s.gear.find((g) => GEAR_BY_ID[g.templateId]?.rarity === "legendary");
	if (legendaryCat || legendaryGear) discoveries.push({
		id: "legendary:first",
		kind: "legendary",
		itemId: legendaryCat?.cardId ?? legendaryGear.templateId,
		text: `${legendaryCat ? CARDS.find((c) => c.id === legendaryCat.cardId).name : GEAR_BY_ID[legendaryGear.templateId].name}: your first Legendary.`
	});
	for (const n of STAR_TIERS_V4) if (starCountV4(s) >= n) discoveries.push({
		id: `stars:${n}`,
		kind: "stars",
		itemId: `stars-${n}`,
		text: `${n} route stars. A little brighter every evening.`
	});
	return discoveries;
}
/** Legacy saves keep existing discoveries quietly; importing is never a new earned celebration. */
function initializeJourneyV4(s, quiet = true) {
	if (!s.v4 || s.v4.journey) return;
	s.v4.journey = emptyJourneyV4();
	if (quiet) observeDiscoveriesV4(s, true);
}
/** Called inside the same transaction as the earned change. No combat or currency mutation. */
function observeDiscoveriesV4(s, quiet = false) {
	if (!s.v4 || !quiet && !gameplayV4(s)) return;
	if (!s.v4.journey) {
		initializeJourneyV4(s);
		return;
	}
	const journal = s.v4.journey;
	for (const discovery of presentDiscoveries(s)) {
		if (journal.found.some((d) => d.id === discovery.id)) continue;
		journal.found.push({
			id: discovery.id,
			day: s.account.day,
			text: discovery.text
		});
		if (!quiet) journal.pending.push({
			version: 2,
			kind: "earned-reveal",
			sequence: journal.sequence++,
			round: 0,
			discovery: {
				kind: discovery.kind,
				id: discovery.id
			},
			itemId: discovery.itemId,
			text: discovery.text
		});
	}
	journal.pending = journal.pending.slice(-8);
}
function recordNodeStarsV4(s, receipt) {
	if (!receipt || !gameplayV4(s) || !s.v4 || !receipt.conditions.some(Boolean)) return;
	initializeJourneyV4(s);
	const journal = s.v4.journey;
	journal.stars[receipt.key] = mergeNodeStarsV4(journal.stars[receipt.key], receipt).value;
}
function acknowledgeDiscoveryV4(state, sequence) {
	return transactDepth(state, (s) => {
		requireRule(gameplayV4(s) && s.v4?.journey?.pending[0]?.sequence === sequence, "NOT_READY", "That discovery is already in your journal.");
		s.v4.journey.pending.shift();
	});
}
function starRewardPreviewV4(s, id) {
	const target = STAR_REWARDS_V4.find((t) => t.id === id);
	requireRule(target, "UNKNOWN_ID", "Choose a star milestone.");
	const progress = starCountV4(s), claimed = !!s.v4?.journey?.claims.includes(id), reward = cappedPreviewV4(s, target.reward);
	const reason = !gameplayV4(s) ? "Open Gameplay v4 first." : s.run && !s.run.complete ? "Finish your route first." : claimed ? "Already collected." : progress < target.target ? "Earn another route star." : !Object.values(reward).some((n) => n > 0) ? "Your daily allowance is full. This reward can wait." : null;
	return {
		...target,
		progress,
		claimed,
		requested: target.reward,
		reward,
		reason
	};
}
function claimStarRewardV4(state, id) {
	return transactDepth(state, (s) => {
		requireHome(s);
		const p = starRewardPreviewV4(s, id);
		requireRule(!p.reason, "NOT_READY", p.reason ?? "");
		initializeJourneyV4(s);
		grantDepth(s, p.reward);
		s.v4.journey.claims.push(id);
	});
}
function validateJourneyV4(s) {
	const j = s.v4?.journey;
	if (j === void 0) return;
	const discoveryIds = discoveryIdsV4();
	const valid = (condition) => requireRule(condition, "INVALID_AMOUNT", "Invalid discovery journal.");
	valid(j && j.version === 1 && j.stars && typeof j.stars === "object" && !Array.isArray(j.stars));
	valid(Number.isSafeInteger(j.sequence) && j.sequence >= 0);
	valid(Array.isArray(j.found) && j.found.length <= discoveryIds.length);
	valid(new Set(j.found.map((d) => d.id)).size === j.found.length);
	for (const d of j.found) valid(discoveryIds.includes(d.id) && Number.isSafeInteger(d.day) && d.day >= 1 && typeof d.text === "string" && d.text.length <= 180);
	valid(Array.isArray(j.pending) && j.pending.length <= 8);
	let previous = -1;
	for (const e of j.pending) {
		valid(e && e.version === 2 && e.kind === "earned-reveal" && e.round === 0 && e.discovery);
		const found = j.found.find((d) => d.id === e.discovery.id);
		valid(found && found.text === e.text && [
			"crew",
			"set",
			"rank",
			"legendary",
			"stars"
		].includes(e.discovery.kind));
		valid(e.discovery.id.startsWith(e.discovery.kind + ":") && typeof e.itemId === "string" && e.itemId.length <= 100);
		valid(Number.isSafeInteger(e.sequence) && e.sequence > previous && e.sequence < j.sequence);
		previous = e.sequence;
	}
	valid(Array.isArray(j.claims) && new Set(j.claims).size === j.claims.length && j.claims.every((id) => STAR_REWARDS_V4.some((r) => r.id === id)));
	valid(Object.keys(j.stars).length <= 14994);
	for (const [key, r] of Object.entries(j.stars)) {
		valid(r && r.key === key && Number.isInteger(r.chapter) && r.chapter >= 1 && r.chapter <= 3 && Number.isInteger(r.band) && r.band >= 0 && r.band <= 50 && /^[0-6]-[01]$/.test(r.nodeId));
		valid([
			"battle",
			"elite",
			"boss",
			"event",
			"treasure",
			"shop",
			"campfire"
		].includes(r.kind));
		valid(key === `${r.chapter}/${r.band}/${r.nodeId}/${r.kind}` && Array.isArray(r.conditions) && r.conditions.length === 3 && r.conditions.every((c) => typeof c === "boolean"));
	}
}
// packages/game-rules/src/cardrpg/depth/gameplay-v4.ts
var DEFAULT_PLAN = {
	focus: "finish",
	care: "steady"
};
var CREW_JOBS = [
	{
		id: "door",
		name: "Door team",
		small: "+3% maximum HP",
		full: "+6% maximum HP; front cats start with 8 shield"
	},
	{
		id: "kettle",
		name: "Kettle team",
		small: "+4% healing",
		full: "+8% healing; first cleanse grants 8 shield"
	},
	{
		id: "table",
		name: "Table team",
		small: "+3% direct attack",
		full: "+6% direct attack; +3 raw damage to marked foes"
	},
	{
		id: "lantern",
		name: "Lantern team",
		small: "+4% effect accuracy",
		full: "+8% effect accuracy; first softened or stopped enemy action heals its controller 8"
	}
];
var CAT_CREWS = {
	mochi: ["door", "kettle"],
	panko: ["door", "table"],
	brioche: ["door", "lantern"],
	clover: ["kettle", "door"],
	cinnamon: ["kettle", "table"],
	marigold: ["kettle", "lantern"],
	soot: ["table", "lantern"],
	mallow: ["table", "door"],
	biscuit: ["table", "kettle"],
	sorrel: ["lantern", "kettle"],
	inkcap: ["lantern", "door"],
	velvet: ["lantern", "table"]
};
function crewThresholds(ids) {
	return CREW_JOBS.map((job) => {
		const contributors = [...new Set(ids)].filter((id) => CAT_CREWS[id]?.includes(job.id));
		const marks = contributors.reduce((n, id) => n + (CAT_CREWS[id][0] === job.id ? 2 : 1), 0);
		const threshold = contributors.length < 2 ? 0 : marks >= 4 ? 4 : marks >= 2 ? 2 : 0;
		return {
			...job,
			contributors,
			marks,
			threshold,
			description: threshold === 4 ? job.full : threshold === 2 ? job.small : "Needs two contributing cats and at least two marks"
		};
	});
}
/** Active routes retain their committed mode even after next-run preferences change. */
function gameplayV4(state) {
	return state.run && !state.run.complete ? state.run.gameplayV4 === true : state.gameplayV4 === true;
}
function validPlan(value) {
	if (!value || typeof value !== "object") return false;
	const plan = value;
	return [
		"finish",
		"support",
		"leader"
	].includes(plan.focus) && ["steady", "protect"].includes(plan.care);
}
function setGameplayV4(state, enabled) {
	const next = clone(state);
	if (!enabled && !next.v4 && next.gameplayV4 === void 0) return next;
	next.gameplayV4 = enabled;
	if (enabled) next.v4 ??= {
		version: 1,
		plan: { ...DEFAULT_PLAN },
		journey: emptyJourneyV4()
	};
	return next;
}
function crewStats(stats, ids) {
	const next = { ...stats }, crew = crewThresholds(ids);
	const tier = (id) => crew.find((c) => c.id === id).threshold;
	next.hp = Math.round(next.hp * (1 + tier("door") * .015));
	next.attack = Math.round(next.attack * (1 + tier("table") * .015));
	next.healingBp += tier("kettle") * 200;
	next.effectHitBp += tier("lantern") * 200;
	return next;
}
function openingCrewBonus(ids, actor) {
	for (const crew of crewThresholds(ids).filter((c) => c.threshold === 4)) {
		if (crew.id === "door" && actor.row === "front") actor.shield += 8;
		if (crew.id === "table") actor.bonuses.markedDamage = (actor.bonuses.markedDamage ?? 0) + 3;
		if (crew.id === "kettle") actor.bonuses.crewCleanse = 8;
		if (crew.id === "lantern") actor.bonuses.crewSuppress = 8;
	}
}
function planPreference(battle, choice) {
	const plan = battle.v4?.plan;
	if (!plan) return 0;
	const target = battle.actors.find((a) => a.id === choice.targetId);
	if (!target) return 0;
	if (target.side === "enemy") {
		if (plan.focus === "finish") return 28 * (1 - target.hp / target.maxHp);
		if (plan.focus === "support") return [
			"heal",
			"shield",
			"summon"
		].includes(ENEMY_BY_ID[target.catalogId]?.mechanic ?? "") ? 40 + (battle.actors.find((a) => a.id === battle.queue[0])?.setEffects.includes("opening-decoy") ? 3 : 0) : 0;
		return ENEMY_BY_ID[target.catalogId]?.tier === "boss" ? 40 : 0;
	}
	const skill = SKILLS[choice.skillId];
	if (battle.actors.find((a) => a.id === battle.queue[0])?.setEffects.includes("unique:tidetray") && skill?.effects.some((e) => e.kind === "shield")) return 8 * (1 - target.hp / target.maxHp);
	const care = plan.care === "protect" ? .65 : .45;
	return target.hp / target.maxHp < care && (skill?.effects.some((e) => [
		"heal",
		"shield",
		"cleanse",
		"transfer"
	].includes(e.kind)) || choice.skillId === "defend") ? (care - target.hp / target.maxHp) * 100 : 0;
}
function skillDescriptionV4(skill) {
	return ({
		"sorrel-1": "A light hit grants the most injured ally 6 shield.",
		"sorrel-4": "Heal and protect the table; grant the most injured ally 18 extra shield.",
		"biscuit-1": "A heavy basic can Rattle its target, lowering its direct damage.",
		"inkcap-1": "Tangle any row to lower its direct attack by 4% per stack.",
		"inkcap-4": "Soften enemy signatures and lower direct attack with Tangle.",
		"velvet-3": "Remove buffs and grant the most injured ally 12 shield.",
		"marigold-4": "Clear debuffs, restore health and grant the most injured ally 12 shield."
	}[skill.id] ?? skill.description) + (skill.type === "ultimate" ? ` Ready after two own turns; ${skill.cooldown + 1}-turn cooldown.` : "");
}
function passiveDescriptionV4(id) {
	return {
		soot: "A successful detonation grants 6 shield, once per turn.",
		mallow: "The first hit each round on a Scalded foe heals 4 HP.",
		sorrel: "On odd rounds, grant the weakest ally 6 shield.",
		velvet: "Defeating a foe restores 6 missing HP."
	}[id] ?? CAT_BY_ID[id].passive.description;
}
function statusDescriptionV4(id) {
	return {
		tangle: "Direct attack falls by 4% per stack.",
		hush: "Enemy heal, shield or summon actions are suppressed; cat support skills stay on cooldown normally."
	}[id] ?? STATUS_BY_ID[id]?.description ?? id;
}
function enemyGuideV4(id) {
	const enemy = ENEMY_BY_ID[id];
	return {
		heal: {
			intent: "Every third round restores 65 HP to the most injured foe.",
			counter: "Hush prevents the refill; focus support before its next signature.",
			exception: "Basic pressure between refills"
		},
		shield: {
			intent: "Every third round grants 45 shield to its row.",
			counter: "Hush prevents the brace; Brittle strips its shield.",
			exception: "Basic pressure between braces"
		},
		steal: {
			intent: "Reaches a rear cat and removes 6 shield.",
			counter: "Cover the vulnerable rear cat with healing or a decoy.",
			exception: "Rear reach bypasses cover"
		},
		snare: {
			intent: "Knots weaken the most injured reachable cat.",
			counter: "Cleanse Tangle or focus the small thread.",
			exception: "Front row while it lives"
		},
		dot: {
			intent: "Needle rain applies Scald to the rear row.",
			counter: "Bring cleanse and patient healing.",
			exception: "Row attacks ignore cover"
		},
		charge: {
			intent: "Every third round sweeps the front row.",
			counter: "Spread your rows, shield the front, or apply Drowsy.",
			exception: "Row attacks ignore cover"
		},
		bind: {
			intent: "Loomfall sweeps the front and summons threads; below half HP it reaches both rows.",
			counter: "Keep a sturdy front, cleanse Tangle, and focus the leader.",
			exception: "Row attacks ignore cover"
		},
		storm: {
			intent: "Cloudburst removes shields before hitting a row; below half HP it reaches both.",
			counter: "Prefer healing and Steep; Drowsy softens the signature.",
			exception: "Row attacks ignore cover"
		},
		banquet: {
			intent: "Empty banquet removes shield and applies Hush; the closing phase also summons.",
			counter: "Cleanse Hush and focus the leader; linked threads leave with it.",
			exception: "Row attacks ignore cover"
		},
		bomb: {
			intent: "Every third round detonates Crumb trails.",
			counter: "Cleanse trails before the signature or soften it with Drowsy.",
			exception: "Front row while it lives"
		},
		lesson: {
			intent: "A gentle third-round bump tests your preparation.",
			counter: "Put a guardian in front and watch its protection.",
			exception: "Front row while it lives"
		}
	}[enemy.mechanic] ?? {
		intent: enemy.intent,
		counter: enemy.counter,
		exception: "Front row while it lives"
	};
}
/** A short description of each kit's job, not a promised win or a power ranking. */
var CAT_SPECIALTIES_V4 = {
	"mochi": "Shielding the crew against front-row pressure.",
	"soot": "Detonating stacked Crumb trails.",
	"clover": "Cleansing Scald and healing over time.",
	"panko": "Returning damage when enemies hit the front row.",
	"mallow": "Burning several foes through their shields.",
	"sorrel": "Weakening rear attackers and sharing spare shields.",
	"biscuit": "Finishing wounded foes through row cover.",
	"inkcap": "Quieting healers and tangling dangerous targets.",
	"cinnamon": "Rescuing a hurt ally with healing and Cozy.",
	"brioche": "Building shields and lending them to an ally.",
	"velvet": "Marking rear targets so the whole crew can reach them.",
	"marigold": "Keeping several allies healthy over long fights."
};
// packages/game-rules/src/cardrpg/depth/skills-v5/shapes.ts
var alive = (b, side) => b.actors.filter((a) => a.side === side && a.hp > 0);
var weakestV5 = (actors) => [...actors].sort((a, c) => a.hp / a.maxHp - c.hp / c.maxHp || a.id.localeCompare(c.id))[0];
/** Actor order is the stable formation order, including the front/rear boundary. */
function adjacentV5(b, target) {
	const formation = b.actors.filter((a) => a.side === target.side && (a.hp > 0 || a.id === target.id));
	const i = formation.findIndex((a) => a.id === target.id);
	if (i < 0) return [];
	return [formation[i - 1], formation[i + 1]].filter((a) => !!a && a.hp > 0);
}
function shapeV5(skill) {
	if (skill.shape) return skill.shape;
	return {
		foe: "single",
		pierce: "pierce",
		row: "row",
		foes: "all",
		ally: "one",
		allies: "team",
		self: "self",
		fallen: "fallen"
	}[skill.target];
}
function landingsV5(b, actor, main, shape, roll) {
	const foes = alive(b, actor.side === "party" ? "enemy" : "party"), allies = alive(b, actor.side);
	const one = (target, multiplier = 1) => target ? [{
		target,
		multiplier
	}] : [];
	switch (shape) {
		case "self": return one(actor);
		case "weakest": return one(weakestV5(allies));
		case "ally-splash": {
			const patient = weakestV5(allies);
			return patient ? [...one(patient), ...adjacentV5(b, patient).map((target) => ({
				target,
				multiplier: .4
			}))] : [];
		}
		case "team": return allies.map((target) => ({
			target,
			multiplier: 1
		}));
		case "ally-row": return allies.filter((t) => t.row === main.row).map((target) => ({
			target,
			multiplier: 1
		}));
		case "row": return foes.filter((t) => t.row === main.row).map((target) => ({
			target,
			multiplier: b.initial.formationC2 ? FORMATION_C2.rowMultiplier : .6
		}));
		case "all": return foes.map((target) => ({
			target,
			multiplier: b.initial.formationC2 ? FORMATION_C2.areaMultiplier : .6
		}));
		case "splash": return [...one(main), ...adjacentV5(b, main).map((target) => ({
			target,
			multiplier: b.initial.formationC2 ? FORMATION_C2.splashMultiplier : .4
		}))];
		case "bounce": return [main, ...foes.filter((t) => t.id !== main.id)].slice(0, 3).map((target, i) => ({
			target,
			multiplier: [
				1,
				.7,
				.5
			][i]
		}));
		case "multi-hit": return foes.length ? Array.from({ length: 3 }, () => ({
			target: foes[roll(foes.length)],
			multiplier: .4
		})) : [];
		default: return one(main);
	}
}
/** Resolve each landing before the next; a later random hit cannot select a defeated foe. */
function executeShapeV5(b, actor, main, skill, io) {
	const shape = shapeV5(skill), rolled = (n) => io.roll(b, n);
	const ordinary = shape === "multi-hit" ? [] : landingsV5(b, actor, main, shape, rolled);
	const once = skill.effects.filter((e) => e.self || e.recipient || e.kind === "energy" || e.kind === "chain");
	const perTarget = skill.effects.filter((e) => !once.includes(e));
	const targets = [];
	const length = shape === "multi-hit" ? 3 : ordinary.length;
	for (let i = 0; i < length; i++) {
		if (actor.hp <= 0) break;
		const foes = shape === "multi-hit" ? alive(b, actor.side === "party" ? "enemy" : "party") : [];
		const landing = shape === "multi-hit" ? foes.length ? {
			target: foes[rolled(foes.length)],
			multiplier: .4
		} : void 0 : ordinary[i];
		if (!landing) break;
		if (landing.target.hp <= 0 && shape !== "fallen") continue;
		targets.push(landing.target.id);
		io.record(b, actor, landing.target, "multi-hit", i, shape, skill.id);
		for (const effect of perTarget) {
			const weighted = skill.shape && (["hit", "execute"].includes(effect.kind) || shape === "ally-splash" && effect.kind === "heal") ? {
				...effect,
				power: (effect.power ?? 0) * landing.multiplier
			} : effect;
			io.effect(b, actor, landing.target, weighted, skill);
		}
	}
	if (targets.length && [
		"splash",
		"multi-hit",
		"bounce",
		"row",
		"all",
		"team",
		"ally-row",
		"ally-splash"
	].includes(shape)) emitGameplayEvent(b, {
		kind: "multi-hit",
		actorId: actor.id,
		skillId: skill.id,
		shape,
		targets,
		text: `${actor.name}: ${skill.name} reaches ${targets.length} landings.`
	});
	if (actor.hp <= 0) return;
	for (const effect of once) {
		const recipients = effect.self ? [actor] : effect.recipient === "weakest" ? [weakestV5(alive(b, actor.side))] : effect.recipient === "team" ? alive(b, actor.side) : [main];
		for (const target of recipients) if (target) io.effect(b, actor, target, effect, skill);
	}
}
// packages/game-rules/src/cardrpg/depth/skills-v5/reactions.ts
var REACTION_NAMES_V5 = {
	"crumb-burst": "Crumb Burst",
	wildfire: "Wildfire",
	rupture: "Rupture",
	spread: "Spread"
};
var count$1 = (a, id) => a.statuses.find((s) => s.id === id)?.stacks ?? 0;
function canReactV5(b, target) {
	return b.initial.skillsV5 === true && !b.procRounds.v5ReactionDepth && target.bonuses.v5ReactionRound !== b.round;
}
function react(b, source, target, id, io, primerIds, targets, apply) {
	if (!canReactV5(b, target)) return false;
	target.bonuses.v5ReactionRound = b.round;
	b.procRounds.v5ReactionDepth = 1;
	try {
		apply();
	} finally {
		delete b.procRounds.v5ReactionDepth;
	}
	io.record(b, source, target, "reaction", 1, REACTION_NAMES_V5[id], id);
	emitGameplayEvent(b, {
		kind: "reaction",
		reactionId: id,
		primerIds,
		targets: targets.map((a) => a.id),
		actorId: source.id,
		sourceId: source.id,
		targetId: target.id,
		text: `${source.name} → ${REACTION_NAMES_V5[id]}.`
	});
	return true;
}
function crumbBurstV5(b, source, target, io, detonate) {
	return target.hp > 0 && count$1(target, "crumb") > 0 && react(b, source, target, "crumb-burst", io, count$1(target, "scald") ? ["crumb", "scald"] : ["crumb"], [target], detonate);
}
/** A lethal hit offers Spread first; a living direct-hit target offers Rupture before Wildfire. */
function directReactionV5(b, source, target, shape, io) {
	if (!canReactV5(b, target)) return false;
	const bleed = count$1(target, "snag");
	if (target.hp > 0 && bleed && count$1(target, "brittle")) return react(b, source, target, "rupture", io, ["snag", "brittle"], [target], () => {
		target.statuses = target.statuses.filter((s) => s.id !== "snag");
		io.loseHp(b, source, target, 12 * bleed, "reaction-damage");
	});
	const neighbours = adjacentV5(b, target);
	if (count$1(target, "scald") >= 3 && [
		"splash",
		"row",
		"all"
	].includes(shape) && neighbours.length) return react(b, source, target, "wildfire", io, ["scald"], neighbours, () => {
		for (const other of neighbours) io.apply(b, source, other, "scald", 1);
	});
	return false;
}
function spreadV5(b, source, target, io) {
	if (target.hp > 0 || !count$1(target, "scent") || !canReactV5(b, target)) return false;
	const nearest = adjacentV5(b, target)[0];
	if (!nearest) return false;
	const debuffs = target.statuses.filter((s) => io.rule(s.id).kind === "debuff");
	return react(b, source, target, "spread", io, debuffs.map((s) => s.id), [nearest], () => {
		for (const status of debuffs) io.apply(b, source, nearest, status.id, Math.ceil(status.stacks / 2));
	});
}
// packages/game-rules/src/cardrpg/depth/skills-v5/kits.ts
var COMBO_ROLES_V5 = {
	mochi: "Protects primers",
	soot: "Primes and triggers Crumb Burst",
	clover: "Answers enemy Burn and Bleed",
	panko: "Primes Shred for Rupture",
	mallow: "Primes Burn; triggers Wildfire",
	sorrel: "Bitter answers healers",
	biscuit: "Primes Bleed; triggers Rupture",
	inkcap: "Daze stops boss signatures",
	cinnamon: "Sustains Burn crews",
	brioche: "Shred triggers Rupture from the front row",
	velvet: "Mark and Bleed prime Spread",
	marigold: "Primes Burn and Crumb Burst"
};
var CREWS_V5 = [
	{
		id: "oven",
		name: "Oven",
		cats: [
			"mallow",
			"cinnamon",
			"mochi"
		],
		reaction: "wildfire"
	},
	{
		id: "thread",
		name: "Thread",
		cats: [
			"velvet",
			"biscuit",
			"brioche"
		],
		reaction: "rupture"
	},
	{
		id: "night-lamp",
		name: "Night lamp",
		cats: [
			"soot",
			"marigold",
			"inkcap"
		],
		reaction: "crumb-burst"
	},
	{
		id: "afternoon-tea",
		name: "Afternoon tea",
		cats: [
			"clover",
			"sorrel",
			"panko"
		],
		reaction: null
	}
];
var patches = {
	"mochi-1": { shape: "splash" },
	"mochi-2": { shape: "weakest" },
	"mochi-3": {
		shape: "ally-row",
		effects: [
			{
				kind: "swap",
				recipient: "main"
			},
			{
				kind: "shield",
				power: 55
			},
			{
				kind: "rally",
				status: "link"
			},
			{
				kind: "rally",
				status: "shelter",
				self: true
			}
		]
	},
	"mochi-4": {
		shape: "team",
		effects: [
			{
				kind: "cleanse",
				cleanseCount: 1
			},
			{
				kind: "shield",
				power: 130
			},
			{
				kind: "rally",
				status: "cozy",
				stacks: 2
			}
		]
	},
	"soot-2": { cooldown: 2 },
	"soot-1": { shape: "pierce" },
	"soot-4": {
		shape: "all",
		effects: [
			{
				kind: "hit",
				power: 125
			},
			{
				kind: "detonate",
				power: 125
			},
			{
				kind: "rally",
				status: "drowsy"
			}
		]
	},
	"clover-1": { effects: [{
		kind: "hit",
		power: 80
	}, {
		kind: "heal",
		power: 18,
		recipient: "weakest"
	}] },
	"clover-2": { shape: "ally-row" },
	"panko-1": { effects: [
		{
			kind: "hit",
			power: 85
		},
		{
			kind: "rally",
			status: "riposte",
			self: true
		},
		{
			kind: "rally",
			status: "brittle"
		}
	] },
	"panko-2": {
		shape: "ally-row",
		effects: [{
			kind: "shield",
			power: 65
		}, {
			kind: "rally",
			status: "shelter",
			self: true
		}]
	},
	"mallow-1": {
		shape: "splash",
		effects: [{
			kind: "hit",
			power: 100
		}, {
			kind: "rally",
			status: "scald",
			recipient: "main"
		}]
	},
	"mallow-2": {
		shape: "row",
		effects: [{
			kind: "hit",
			power: 115
		}, {
			kind: "rally",
			status: "scald"
		}]
	},
	"mallow-3": { effects: [{
		kind: "hit",
		power: 120,
		burnScaling: .3
	}] },
	"mallow-4": {
		shape: "all",
		effects: [{
			kind: "hit",
			power: 130
		}, {
			kind: "rally",
			status: "scald",
			stacks: 3
		}]
	},
	"sorrel-1": { effects: [{
		kind: "hit",
		power: 70
	}, {
		kind: "rally",
		status: "bitter"
	}] },
	"sorrel-2": {
		shape: "pierce",
		effects: [{
			kind: "hit",
			power: 50
		}, {
			kind: "rally",
			status: "drowsy"
		}]
	},
	"sorrel-3": {
		shape: "ally-row",
		effects: [
			{
				kind: "transfer",
				recipient: "main"
			},
			{
				kind: "shield",
				power: 45
			},
			{
				kind: "rally",
				status: "glaze"
			}
		]
	},
	"sorrel-4": {
		shape: "team",
		effects: [{
			kind: "heal",
			power: 50
		}, {
			kind: "rally",
			status: "glaze"
		}]
	},
	"biscuit-1": {
		shape: "multi-hit",
		effects: [{
			kind: "hit",
			power: 95
		}, {
			kind: "rally",
			status: "snag"
		}]
	},
	"biscuit-2": { effects: [
		{ kind: "swap" },
		{
			kind: "shield",
			power: 65
		},
		{
			kind: "rally",
			status: "cozy"
		}
	] },
	"biscuit-3": { shape: "pierce" },
	"biscuit-4": {
		shape: "bounce",
		effects: [{
			kind: "hit",
			power: 130
		}, {
			kind: "rally",
			status: "brittle"
		}]
	},
	"inkcap-1": {
		cooldown: 1,
		shape: "pierce",
		effects: [{
			kind: "hit",
			power: 70
		}, {
			kind: "rally",
			status: "brittle"
		}]
	},
	"inkcap-2": {
		shape: "pierce",
		effects: [{
			kind: "hit",
			power: 45
		}, {
			kind: "rally",
			status: "drowsy"
		}]
	},
	"inkcap-4": {
		shape: "all",
		effects: [
			{
				kind: "hit",
				power: 65
			},
			{
				kind: "rally",
				status: "drowsy"
			},
			{
				kind: "rally",
				status: "brittle",
				stacks: 2
			}
		]
	},
	"cinnamon-1": { effects: [
		{
			kind: "hit",
			power: 75
		},
		{
			kind: "drain",
			power: 40
		},
		{
			kind: "rally",
			status: "scald"
		}
	] },
	"cinnamon-2": {
		shape: "ally-splash",
		cooldown: 1,
		effects: [{
			kind: "heal",
			power: 80
		}, {
			kind: "rally",
			status: "cozy",
			recipient: "main"
		}]
	},
	"brioche-3": { effects: [
		{ kind: "dispel" },
		{
			kind: "rally",
			status: "brittle"
		},
		{
			kind: "hit",
			power: 110
		}
	] },
	"velvet-1": {
		cooldown: 1,
		shape: "pierce",
		effects: [
			{
				kind: "hit",
				power: 95
			},
			{
				kind: "rally",
				status: "scent"
			},
			{
				kind: "rally",
				status: "snag",
				stacks: 2
			}
		]
	},
	"velvet-2": {
		shape: "bounce",
		effects: [{
			kind: "hit",
			power: 65
		}]
	},
	"velvet-3": { effects: [{ kind: "dispel" }, {
		kind: "hit",
		power: 90
	}] }
};
var SHAPE_LABELS_V5 = {
	single: "Single",
	pierce: "Pierce",
	row: "Row · 60% each",
	splash: "Splash · 100/40%",
	bounce: "Bounce · 100/70/50%",
	all: "All · 60% each",
	"multi-hit": "Three hits · 40% each",
	one: "One ally",
	weakest: "Weakest ally",
	"ally-row": "Ally row",
	"ally-splash": "Weakest ally + adjacent allies · 100/40% healing",
	team: "Team",
	self: "Self",
	fallen: "Fallen ally"
};
function describeEffect(e) {
	const status = e.status ? CORE_STATUS_RULES_V5.find((s) => s.id === e.status)?.name ?? {
		crumb: "Crumb",
		riposte: "Riposte",
		link: "Link",
		sprout: "Second sprout",
		decoy: "Decoy",
		glaze: "Glaze",
		shelter: "Shelter"
	}[e.status] ?? e.status : "";
	const recipient = e.self ? " on self" : e.recipient === "weakest" ? " on the weakest ally" : e.recipient === "team" ? " on the team" : e.recipient === "main" ? " on the main target" : "";
	const power = e.power ?? 0;
	return [{
		hit: `${power}% attack${e.burnScaling ? "; +30% per Burn stack" : ""}`,
		execute: `${power}% attack; doubles against a weakened foe`,
		shield: `${power} shield`,
		heal: `Heal ${power}`,
		cleanse: e.cleanseCount ? "Remove one debuff" : "Cleanse debuffs",
		dispel: "Dispel buffs",
		detonate: "Trigger Crumb Burst",
		transfer: "Transfer your shield",
		revive: `Revive at ${power}% HP`,
		drain: `Drain ${power}% attack as healing`,
		swap: "Swap rows",
		energy: "Shield the weakest ally",
		rally: "",
		chain: "Bounce through three foes",
		consume: "Consume Warm for damage",
		break: "Apply Daze"
	}[e.kind], status ? `${e.stacks ?? 1} ${status}` : ""].filter(Boolean).join("; ") + recipient;
}
function describeSkillV5(skill) {
	return skill.id === "cinnamon-4" ? "Revive a fallen ally at 40% HP once per battle. Otherwise heal the team 35 and grant 1 Warm each." : `${SHAPE_LABELS_V5[shapeV5(skill)]}. ${skill.effects.map(describeEffect).filter(Boolean).join(". ")}.`;
}
function situationalSkillV5(b, actor, skill) {
	if (skill.id === "cinnamon-4" && (actor.passiveUsed || !b.actors.some((a) => a.side === actor.side && a.hp === 0))) return {
		...skill,
		target: "allies",
		shape: "team",
		effects: [{
			kind: "heal",
			power: 35
		}, {
			kind: "rally",
			status: "cozy"
		}]
	};
	return skill;
}
var cache$1 = /* @__PURE__ */ new Map();
function kitSkillV5(original) {
	const prior = cache$1.get(original);
	if (prior) return prior;
	const patch = patches[original.id] ?? {};
	const skill = {
		...original,
		...patch,
		shape: patch.shape ?? shapeV5(original),
		effects: (patch.effects ?? original.effects).map((e) => ({ ...e }))
	};
	if (skill.shape === "pierce") skill.target = "pierce";
	if (skill.shape === "weakest" || skill.shape === "ally-row" || skill.shape === "ally-splash") skill.target = "ally";
	skill.description = describeSkillV5(skill);
	cache$1.set(original, skill);
	return skill;
}
function crewHintsV5(cats) {
	return CREWS_V5.filter((c) => c.cats.filter((id) => cats.includes(id)).length >= 2).map((c) => `${c.name}: ${c.reaction ? {
		wildfire: "Burn primes Wildfire",
		rupture: "Bleed + Shred primes Rupture",
		"crumb-burst": "Crumb primes Crumb Burst"
	}[c.reaction] : "Bitter and sustained care answer healers"}.`);
}
// packages/game-rules/src/cardrpg/depth/skills-v5/enemies.ts
/** Existing helpers make isolated boss/elite encounters readable combo opportunities. */
function encounterEnemiesV5(ids) {
	const tier = ids.length === 1 ? ENEMY_BY_ID[ids[0]].tier : "";
	return tier === "boss" ? [
		...ids,
		"binding-thread",
		"binding-thread"
	] : tier === "elite" ? [...ids, "binding-thread"] : ids;
}
function phaseHelpersV5(b, boss, spawn) {
	if (boss.hp <= 0 || boss.phase !== 2 || ENEMY_BY_ID[boss.catalogId]?.tier !== "boss" || boss.bonuses.v5Helpers) return;
	boss.bonuses.v5Helpers = 1;
	spawn(b, boss, 4);
	spawn(b, boss, 4);
}
/** A defeated thread releases only its own knot; another source's Shred stays. */
function releaseThreadV5(b, thread) {
	if (thread.catalogId !== "binding-thread") return;
	for (const ally of b.actors.filter((a) => a.side === "party")) {
		const removed = ally.statuses.filter((s) => s.source === thread.id && ["brittle", "drowsy"].includes(s.id));
		if (!removed.length) continue;
		ally.statuses = ally.statuses.filter((s) => !removed.includes(s));
		b.log.push({
			round: b.round,
			actorId: thread.id,
			targetId: ally.id,
			skillId: "",
			kind: "dispel",
			amount: removed.length,
			text: "Binding Thread defeated; knot released."
		});
	}
}
var ENEMY_MECHANICS_V5 = {
	"button-guard": {
		mechanic: "Shields and Warms its whole row.",
		counter: "Shred strips shields; Burn passes through."
	},
	"sock-skipper": {
		mechanic: "Targets rear cats and applies Bleed.",
		counter: "Shield the rear before their next actions."
	},
	"spool-ram": {
		mechanic: "Charges for one turn, then hits a row.",
		counter: "Daze interrupts the charged action."
	},
	"needle-moth": {
		mechanic: "Three seeded hits on random cats.",
		counter: "Warm and team shields soften repeated hits."
	},
	"teacup-healer": {
		mechanic: "Heals its weakest ally every two rounds.",
		counter: "Bitter halves healing; Mark opens rear access."
	},
	"kettle-knight": {
		mechanic: "Below half HP, basics Burn the front row.",
		counter: "Cleanse or Regen removes Burn."
	},
	"binding-thread": {
		mechanic: "Knots apply Shred; every third turn Dazes the weakest cat.",
		counter: "Defeat the thread to release its knot or Cleanse."
	},
	"yarn-giant": {
		mechanic: "Row + Shred signatures; closing phase All + Bitter.",
		counter: "Cleanse the crew; Daze stops its signature."
	}
};
function enemyIntentV5(b, actor, intent) {
	const spec = ENEMY_MECHANICS_V5[actor.catalogId];
	if (!spec) return intent;
	const signature = actor.catalogId === "spool-ram" ? !!actor.bonuses.v5Charge : actor.catalogId === "teacup-healer" ? b.round % 2 === 0 : intent.signature;
	const label = actor.catalogId === "spool-ram" ? signature ? "Charged row strike" : "Charging for next turn" : actor.catalogId === "teacup-healer" && signature ? "Refill the weakest cup" : signature ? spec.mechanic : intent.label;
	return {
		...intent,
		signature,
		label,
		counter: spec.counter
	};
}
/** Only chapter-one opponents change; other chapters keep their existing mechanics. */
function enemyActionV5(b, actor, intent, target, io) {
	if (!ENEMY_MECHANICS_V5[actor.catalogId]) return false;
	const party = () => b.actors.filter((a) => a.side === "party" && a.hp > 0), foes = () => b.actors.filter((a) => a.side === "enemy" && a.hp > 0);
	const targets = [];
	let resolvedShape = "single";
	const hit = (t, power = 100, shape = "single") => {
		targets.push(t.id);
		resolvedShape = shape;
		io.record(b, actor, t, "multi-hit", 0, shape, actor.catalogId);
		io.damage(b, actor, t, power, 0, shape === "single", shape);
	};
	switch (actor.catalogId) {
		case "button-guard":
			if (actor.turns === 0) io.apply(b, actor, actor, "cozy");
			if (intent.signature) for (const ally of foes().filter((a) => a.row === actor.row)) io.shield(b, actor, ally, 45);
			else hit(target);
			break;
		case "sock-skipper": {
			if (b.initial.formationC2 && !intent.signature) {
				hit(target);
				break;
			}
			const rear = party().filter((a) => a.row === "rear"), victim = party().find((a) => a.statuses.some((s) => s.id === "shelter")) ?? weakestV5(rear.length ? rear : party());
			if (victim) {
				hit(victim);
				io.apply(b, actor, victim, "snag");
			}
			break;
		}
		case "spool-ram":
			if (!actor.bonuses.v5Charge) {
				actor.bonuses.v5Charge = 1;
				io.record(b, actor, actor, "charge", 1, "Charging a row strike");
			} else {
				actor.bonuses.v5Charge = 0;
				for (const landing of landingsV5(b, actor, target, "row", (n) => io.roll(b, n))) hit(landing.target, 175 * landing.multiplier, "row");
			}
			break;
		case "needle-moth":
			if (b.initial.formationC2 && !intent.signature) {
				hit(target);
				break;
			}
			for (let i = 0; i < 3 && actor.hp > 0; i++) {
				const living = party();
				if (!living.length) break;
				const victim = living[io.roll(b, living.length)];
				targets.push(victim.id);
				resolvedShape = "multi-hit";
				io.record(b, actor, victim, "multi-hit", i, "multi-hit", actor.catalogId);
				io.damage(b, actor, victim, 40, 0, false, "multi-hit");
			}
			break;
		case "teacup-healer":
			if (actor.turns === 0) io.apply(b, actor, actor, "steep");
			if (intent.signature) {
				const patient = weakestV5(foes());
				if (patient) io.heal(b, actor, patient, 65);
			} else {
				hit(target);
				io.apply(b, actor, target, "scent");
			}
			break;
		case "kettle-knight":
			hit(target, intent.signature ? intent.power : 100);
			if (!intent.signature && actor.hp < actor.maxHp / 2) for (const front of party().filter((a) => a.row === "front")) io.apply(b, actor, front, "scald");
			if (actor.turns === 0) {
				io.shield(b, actor, actor, 70);
				io.apply(b, actor, actor, "cozy");
			}
			break;
		case "binding-thread":
			hit(target, 50);
			io.apply(b, actor, target, "brittle");
			if (intent.signature) io.apply(b, actor, target, "drowsy");
			break;
		case "yarn-giant": if (!intent.signature) hit(target);
		else {
			const shape = actor.phase === 2 ? "all" : "row", status = actor.phase === 2 ? "bitter" : "brittle";
			for (const landing of landingsV5(b, actor, target, shape, (n) => io.roll(b, n))) {
				if (actor.hp <= 0) break;
				hit(landing.target, intent.power * landing.multiplier, shape);
				io.apply(b, actor, landing.target, status);
			}
		}
	}
	if (targets.length && resolvedShape !== "single") emitGameplayEvent(b, {
		kind: "multi-hit",
		skillId: actor.catalogId,
		shape: resolvedShape,
		targets,
		actorId: actor.id,
		text: `${actor.name}: ${targets.length} landings.`
	});
	return true;
}
// packages/game-rules/src/cardrpg/depth/skills-v5/events.ts
var strings = (x) => Array.isArray(x) && x.length <= 1024 && x.every((s) => typeof s === "string" && s.length > 0);
var integer = (x) => typeof x === "number" && Number.isSafeInteger(x) && x >= 0;
/** Old v1 battle events remain valid inside THC14/15; new payloads require the V5 flag. */
function validBattleEventV5(value, index, enabled) {
	if (!value || typeof value !== "object" || Array.isArray(value)) return false;
	const e = value;
	if (e.sequence !== index || !integer(e.round) || typeof e.text !== "string" || typeof e.kind !== "string") return false;
	if (e.version === 1) return LEGACY_EVENT_KINDS.includes(e.kind);
	if (!enabled || e.version !== 2 || !integer(e.actionId) || !integer(e.logIndex) || ![
		"setup",
		"action",
		"round-end"
	].includes(String(e.stage))) return false;
	if (LEGACY_EVENT_KINDS.includes(e.kind)) return true;
	if (e.kind === "rage.full") return typeof e.actorId === "string" && e.actorId.length > 0 && e.amount === 100;
	if (e.kind === "ultimate.cast") return typeof e.actorId === "string" && typeof e.skillId === "string" && typeof e.displayName === "string" && e.displayName.length > 0;
	if (e.kind === "bond.combo") return typeof e.actorId === "string" && typeof e.comboId === "string" && e.comboId.length > 0 && typeof e.displayName === "string" && e.displayName.length > 0 && strings(e.contributors) && e.contributors.length === 2 && new Set(e.contributors).size === 2 && strings(e.targets) && e.targets.length > 0;
	const status = typeof e.statusId === "string" && Object.prototype.hasOwnProperty.call(STATUS_BY_ID, e.statusId);
	const actor = typeof e.sourceId === "string" && e.sourceId.length > 0 && typeof e.targetId === "string" && e.targetId.length > 0;
	if (e.kind === "status-applied") return !!(actor && status && integer(e.stacks) && Number(e.stacks) > 0 && Number(e.stacks) <= 5);
	if (e.kind === "status-tick") return !!(actor && status && integer(e.amount));
	if (e.kind === "reaction") return actor && [
		"crumb-burst",
		"wildfire",
		"rupture",
		"spread"
	].includes(String(e.reactionId)) && strings(e.primerIds) && e.primerIds.every((id) => Object.prototype.hasOwnProperty.call(STATUS_BY_ID, id)) && strings(e.targets) && e.targets.length > 0;
	if (e.kind === "multi-hit") return typeof e.skillId === "string" && e.skillId.length > 0 && [
		"single",
		"pierce",
		"row",
		"splash",
		"bounce",
		"all",
		"multi-hit",
		"one",
		"weakest",
		"ally-row",
		"ally-splash",
		"team",
		"self",
		"fallen"
	].includes(String(e.shape)) && strings(e.targets) && e.targets.length > 0;
	return false;
}
// packages/game-rules/src/cardrpg/depth/skills-v5/index.ts
/** Like V4, a run retains its committed rules while preferences apply to the next run. */
function skillsV5(state) {
	return !!(state.run && !state.run.complete ? state.run.skillsV5 : state.gameplayV4 && state.skillsV5);
}
function setSkillsV5(state, enabled) {
	const next = enabled ? setGameplayV4(state, true) : clone(state);
	if (enabled) next.skillsV5 = true;
	else delete next.skillsV5;
	return next;
}
// packages/game-rules/src/cardrpg/depth/gameplay-a6.ts
/** Preferences affect the next route; a committed route keeps its rules. */
function gameplayA6(state) {
	return !!(state.run && !state.run.complete ? state.run.gameplayA6 : state.gameplayA6);
}
function setGameplayA6(state, enabled) {
	const next = enabled ? setSkillsV5(state, true) : clone(state);
	if (enabled) {
		next.gameplayA6 = true;
		if (next.settings.speed === 4) next.settings.speed = 3;
	} else {
		delete next.gameplayA6;
		if (!next.run?.gameplayA6 && next.settings.speed === 3) next.settings.speed = 2;
	}
	return next;
}
var RAGE_GAIN_A6 = {
	mochi: 1.1,
	panko: 1.1,
	brioche: 1.1,
	mallow: 1.1,
	soot: 1.1,
	cinnamon: 1.1,
	clover: 1.2,
	sorrel: 1.2,
	marigold: 1.2,
	velvet: 1.1,
	biscuit: 1.1,
	inkcap: 1.1
};
function gainRageA6(b, actor, amount) {
	if (!b.initial.gameplayA6 || actor.hp <= 0) return;
	const before = actor.charge;
	actor.charge = Math.min(100, before + Math.round(amount * (RAGE_GAIN_A6[actor.catalogId] ?? 1)));
	if (before < 100 && actor.charge === 100) emitGameplayEvent(b, {
		kind: "rage.full",
		actorId: actor.id,
		amount: 100,
		text: `${actor.name}: rage full!`
	});
}
/** One hit reward per action prevents multi-hit kits from dominating rage gain. */
function hitRageA6(b, source, target, amount) {
	if (!b.initial.gameplayA6 || amount <= 0) return;
	const action = b.procRounds.v5ActionSequence ?? 0;
	if (source.bonuses.a6HitAction !== action) {
		source.bonuses.a6HitAction = action;
		gainRageA6(b, source, 5);
	}
	gainRageA6(b, target, Math.min(12, Math.max(2, Math.round(amount / target.maxHp * 40))));
}
/** A short shield beat at 66%, then the existing V5 Binding Thread phase at 33%. */
function phaseBossA6(b, boss) {
	if (!b.initial.gameplayA6 || boss.side !== "enemy" || ENEMY_BY_ID[boss.catalogId]?.tier !== "boss" || boss.hp <= 0) return;
	if (boss.hp <= boss.maxHp * .66 && !boss.bonuses.a6FirstPhase) {
		boss.bonuses.a6FirstPhase = 1;
		const amount = Math.round(boss.maxHp * .06);
		boss.shield += amount;
		b.log.push({
			round: b.round,
			actorId: boss.id,
			targetId: boss.id,
			kind: "shield",
			skillId: "",
			amount,
			text: `${boss.name} gathers a woolguard shield.`
		});
		emitGameplayEvent(b, {
			kind: "boss-phase",
			actorId: boss.id,
			bossId: boss.catalogId,
			from: 1,
			to: 2,
			threshold: .66,
			text: `${boss.name}: woolguard shield!`
		});
	}
	if (boss.hp <= boss.maxHp * .33 && boss.phase === 1) {
		boss.phase = 2;
		emitGameplayEvent(b, {
			kind: "boss-phase",
			actorId: boss.id,
			bossId: boss.catalogId,
			from: 2,
			to: 3,
			threshold: .33,
			text: `${boss.name}: Binding Threads! Clear the knots.`
		});
	}
}
/** An opted-in encounter scales once on actor creation, never the replay setup. */
function prepareBattleA6(b) {
	if (!b.initial.gameplayA6 || b.initial.tutorial) return;
	for (const actor of b.actors) {
		actor.charge = actor.side === "party" ? 35 : 15;
		if (actor.side !== "enemy") continue;
		const hpScale = ENEMY_BY_ID[actor.catalogId]?.tier === "boss" ? .82 : 1.95;
		actor.maxHp = Math.round(actor.maxHp * hpScale);
		actor.hp = actor.maxHp;
		actor.attack = Math.max(1, Math.round(actor.attack * (b.chapter === 1 ? .65 : .85)));
	}
}
var BOONS = [
	["shelter", [
		[
			"Door mat",
			"openingShield",
			"Start every encounter with 25 shield per cat.",
			25
		],
		[
			"Spare saucer",
			"defendCharge",
			"Defend grants 8 extra ultimate charge.",
			8
		],
		[
			"Soft lining",
			"shieldHeal",
			"Shield skills also heal their recipient for 8 HP.",
			8
		],
		[
			"Crust edge",
			"shieldStrike",
			"Direct hits deal 10 extra raw damage while you have a shield.",
			10
		],
		[
			"Shared apron",
			"roundShield",
			"Front-row cats gain 10 shield each round.",
			10
		]
	]],
	["garden", [
		[
			"Patient kettle",
			"healing",
			"Healing skills restore 12 extra HP.",
			12
		],
		[
			"Second leaves",
			"steepPower",
			"Each Steep stack heals 6 extra HP at round end.",
			6
		],
		[
			"Cup overflow",
			"overhealShield",
			"20% of unused healing becomes shield.",
			20
		],
		[
			"Clean strainer",
			"healCleanse",
			"Healing skills remove one dispellable debuff.",
			1
		],
		[
			"Fresh shoots",
			"openingSteep",
			"Begin each encounter with one Steep stack.",
			1
		]
	]],
	["ember", [
		[
			"Hot coaster",
			"scaldPower",
			"Each Scald stack deals 5 extra HP damage per round.",
			5
		],
		[
			"Red kettle",
			"scaldCharge",
			"Hitting a Scalded foe grants 4 extra ultimate charge.",
			4
		],
		[
			"Sugar crack",
			"scaldBrittle",
			"Applying Scald also applies one Brittle stack.",
			1
		],
		[
			"Long steep",
			"scaldDuration",
			"Scald lasts one extra round.",
			1
		],
		[
			"Cinder crumb",
			"scaldCrumb",
			"Applying Scald also plants one Crumb trail.",
			1
		]
	]],
	["trail", [
		[
			"Crumb tin",
			"detonatePower",
			"Detonation deals 8 extra damage per consumed stack.",
			8
		],
		[
			"Loose stitch",
			"breakPressure",
			"The first direct hit by each cat each round adds 1 break.",
			1
		],
		[
			"Rung bell",
			"breakEnergy",
			"The first enemy broken each round restores 1 energy.",
			1
		],
		[
			"Paper tag",
			"markCrumb",
			"Applying Scented also plants one Crumb trail.",
			1
		],
		[
			"Sweep brush",
			"detonateSplash",
			"Detonation deals 12 damage to each other living foe.",
			12
		]
	]],
	["night", [
		[
			"Late candle",
			"openingCharge",
			"Begin each encounter with 12 extra ultimate charge.",
			12
		],
		[
			"Returned wick",
			"ultimateEnergy",
			"Using an ultimate restores 1 energy after its cost.",
			1
		],
		[
			"Quiet velvet",
			"killHeal",
			"Defeating a foe heals the acting cat for 20 HP.",
			20
		],
		[
			"Back shelf",
			"rearDamage",
			"Rear-row cats deal 8 extra raw damage.",
			8
		],
		[
			"Soft moon",
			"tangleRattle",
			"Applying Tangle also applies one Rattled stack.",
			1
		]
	]],
	["flow", [
		[
			"Full pot",
			"roundEnergy",
			"Gain 1 extra shared energy each round.",
			1
		],
		[
			"Small sip",
			"waitHeal",
			"Pour energy also heals its user for 22 HP.",
			22
		],
		[
			"Measured cup",
			"healCharge",
			"A healing skill grants its user 5 charge.",
			5
		],
		[
			"Passing tray",
			"swapShield",
			"Row swapping grants both cats 22 shield.",
			22
		],
		[
			"Clear pour",
			"cleanseEnergy",
			"A cleanse that removes a debuff restores 1 energy once per action.",
			1
		]
	]]
].flatMap(([archetype, entries]) => entries.map(([name, trigger, description, value], i) => ({
	id: `${archetype}-${i + 1}`,
	name,
	trigger,
	description,
	value,
	archetype,
	cap: 2
})));
var BOON_BY_ID = Object.fromEntries(BOONS.map((b) => [b.id, b]));
var replacements = {
	"shelter-2": {
		trigger: "defendHeal",
		value: 8,
		description: "Defend restores up to 8 missing HP."
	},
	"ember-2": {
		trigger: "scaldHeal",
		value: 4,
		description: "The first hit each round on a Scalded foe restores 4 HP."
	},
	"trail-2": {
		trigger: "markedDirect",
		value: 1,
		description: "Direct hits against marked foes gain 1 raw damage."
	},
	"trail-3": {
		trigger: "markedShield",
		value: 6,
		description: "The first marked hit each round grants its user 6 shield."
	},
	"night-1": {
		trigger: "openingShield",
		value: 12,
		description: "Start every encounter with 12 extra shield."
	},
	"night-2": {
		trigger: "ultimateShield",
		value: 6,
		description: "An automatic ultimate grants its user 6 shield."
	},
	"flow-1": {
		trigger: "roundShield",
		value: 6,
		description: "Front-row cats gain 6 shield each round."
	},
	"flow-2": {
		trigger: "defendHeal",
		value: 11,
		description: "Defend restores up to 11 missing HP."
	},
	"flow-3": {
		trigger: "healShield",
		value: 5,
		description: "The first healed ally per action also gains 5 shield."
	},
	"flow-5": {
		trigger: "cleanseExtraShield",
		value: 6,
		description: "The first successful cleanse per action grants 6 shield."
	}
};
function boonForMode(id, enabled) {
	const base = BOON_BY_ID[id];
	return enabled && replacements[id] ? {
		...base,
		...replacements[id]
	} : base;
}
function boonValue(battle, trigger) {
	return Object.entries(battle.boons).reduce((total, [id, count]) => {
		const b = boonForMode(id, battle.initial?.gameplayV4 === true);
		return total + (b?.trigger === trigger ? b.value * Math.min(b.cap, count) : 0);
	}, 0);
}
// packages/game-rules/src/cardrpg/depth/route-upgrades.ts
/** Shared with route choices; preserve the existing battle multiplier. */
var ROUTE_SKILL_POWER_PER_RANK = .2;
var routeSkillPowerBonusPercent = (rank) => Math.round(rank * ROUTE_SKILL_POWER_PER_RANK * 100);
// packages/game-rules/src/cardrpg/depth/pacing-v4.ts
/** Frozen content level: never depends on equipped items or selected editions. */
function challengeStatsV4(level) {
	if (!Number.isSafeInteger(level) || level < 1 || level > 50) throw Error("Choose a challenge band from 1 to 50.");
	const training = level <= 5 ? 0 : Math.min(1, .6 + (level - 6) * .1);
	const growth = (1 + (level - 1) * .012) * (1 + .12 * training);
	return Object.fromEntries(Object.values(ENEMY_BY_ID).map((e) => {
		const pressure = e.tier === "boss" ? [
			3.1,
			1.9,
			2.3
		][e.chapter - 1] * (1 + .15 * training) : 1;
		const hp = e.tier === "boss" ? e.chapter === 3 ? .25 : .3 : e.tier === "elite" ? .3 : .25;
		return [e.id, {
			hp: Math.max(1, Math.round(e.hp * hp * growth)),
			attack: Math.max(1, Math.round(e.attack * growth * pressure)),
			defense: e.defense
		}];
	}));
}
function phaseBossV4(battle, boss) {
	if (!battle.v4 || boss.side !== "enemy" || ENEMY_BY_ID[boss.catalogId]?.tier !== "boss" || boss.phase !== 1 || boss.hp > boss.maxHp / 2 || boss.hp <= 0) return;
	boss.phase = 2;
	const text = `${boss.name}: closing phase. The next signature reaches both rows.`;
	battle.log.push({
		round: battle.round,
		actorId: boss.id,
		targetId: boss.id,
		skillId: "",
		kind: "phase",
		amount: 2,
		text
	});
	emitGameplayEvent(battle, {
		kind: "boss-phase",
		actorId: boss.id,
		bossId: boss.catalogId,
		from: 1,
		to: 2,
		threshold: .5,
		text
	});
}
/** Called after all damage in a single action, before any next actor or round tick. */
function finishBossV4(battle) {
	if (!battle.v4) return false;
	const primary = battle.actors.find((a) => a.side === "enemy" && ENEMY_BY_ID[a.catalogId]?.tier === "boss");
	if (!primary || primary.hp > 0) return false;
	if (battle.v4.events.some((e) => e.kind === "boss-finish")) return !!battle.result;
	const retired = battle.actors.filter((a) => a.side === "enemy" && a.linkedBossId === primary.id && a.hp > 0);
	for (const actor of retired) {
		actor.hp = 0;
		actor.shield = 0;
		actor.statuses = [];
		battle.log.push({
			round: battle.round,
			actorId: primary.id,
			targetId: actor.id,
			skillId: "",
			kind: "retire",
			amount: 0,
			text: `${actor.name} leaves with ${primary.name}.`
		});
	}
	const outcome = battle.actors.some((a) => a.side === "party" && a.hp > 0) ? "party" : "enemy";
	if (outcome === "enemy" || !battle.actors.some((a) => a.side === "enemy" && a.hp > 0)) {
		battle.result = outcome;
		battle.queue = [];
	} else battle.queue = battle.queue.filter((id) => battle.actors.some((a) => a.id === id && a.hp > 0));
	emitGameplayEvent(battle, {
		kind: "boss-finish",
		actorId: primary.id,
		bossId: primary.catalogId,
		retiredIds: retired.map((a) => a.id),
		outcome,
		text: `${primary.name} is defeated; ${retired.length} linked helpers leave. ${outcome === "enemy" ? "The crew also fell; the route is lost." : battle.result === "party" ? "The crew wins." : "Unlinked foes remain."}`
	});
	return !!battle.result;
}
// packages/game-rules/src/cardrpg/depth/battle.ts
var clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, n));
var hasEffect = (actor, id) => actor.setEffects.includes(id);
var stacks = (actor, id) => actor.statuses.find((s) => s.id === id)?.stacks ?? 0;
var living = (battle, side) => battle.actors.filter((a) => a.side === side && a.hp > 0);
function roll(battle, max = 1e4) {
	const result = new Rng(battle.rng).int(0, max - 1);
	battle.rng = deriveSeed(battle.rng, 1);
	return result;
}
function record$1(b, source, target, kind, amount = 0, text = "", skillId = "") {
	b.log.push({
		round: b.round,
		actorId: source.id,
		targetId: target.id,
		skillId,
		kind,
		amount,
		text
	});
}
function dispel(b, source, target, kind) {
	const before = target.statuses.length;
	target.statuses = target.statuses.filter((s) => STATUS_BY_ID[s.id].kind !== kind || !STATUS_BY_ID[s.id].dispellable);
	record$1(b, source, target, "dispel", before - target.statuses.length, `Removed ${kind}s`);
}
function linkShareBps(b, protector, status) {
	return b.initial.formationC2 && status.linkShareBp !== void 0 ? status.linkShareBp : b.v4 && hasEffect(protector, "defend-link") ? b.initial.formationC2 ? ECONOMY_C2.sets.hearthloomShareBp : 1500 : STATUS_BY_ID.link.strength * 100;
}
function applyStatus(b, source, target, id, count = 1, linkStrengthBp) {
	if (b.initial.skillsV5) id = statusIdV5(id);
	const rule = b.initial.skillsV5 ? statusRuleV5(id, STATUS_BY_ID[id]) : STATUS_BY_ID[id];
	if (target.hp <= 0) return false;
	const control = id === "drowsy" || id === "hush";
	if (control && (target.bonuses.controlImmuneUntil ?? 0) >= b.round) {
		record$1(b, source, target, "immune", 0, `${target.name} recovered control resistance`);
		return false;
	}
	if (rule.kind === "debuff" && roll(b) >= clamp(9e3 + source.effectHit - target.effectResist - (b.initial.skillsV5 && id === "drowsy" && ENEMY_BY_ID[target.catalogId]?.tier === "boss" ? 3e3 : 0), 1e3, 9800)) {
		record$1(b, source, target, "resist", 0, `${target.name} resisted ${rule.name}`);
		return false;
	}
	if (b.v4 && rule.kind === "debuff" && target.bonuses.pantryCleanse) {
		target.bonuses.pantryCleanse = 0;
		record$1(b, target, target, "cleanse", 1, "Clearleaf Tea cleared the first debuff");
		return false;
	}
	let status = target.statuses.find((s) => s.id === id);
	if (b.initial.formationC2 && id === "link" && status) {
		const previousSource = status.source;
		const protector = b.actors.find((a) => a.id === previousSource && a.hp > 0 && a.id !== target.id);
		if (protector && linkShareBps(b, protector, status) > (linkStrengthBp ?? rule.strength * 100)) return false;
	}
	if (!status) {
		status = {
			id,
			stacks: 0,
			remaining: 0,
			source: source.id,
			appliedRound: b.round
		};
		target.statuses.push(status);
	}
	status.stacks = Math.min(rule.cap, status.stacks + count);
	status.remaining = rule.duration + (id === "steep" ? Math.min(2, source.bonuses.statusDuration ?? 0) : 0) + (id === "scald" && hasEffect(source, "long-scald") ? 1 : 0) + (id === "scald" && source.side === "party" ? boonValue(b, "scaldDuration") : 0) + (id === "steep" && target.catalogId === "marigold" ? 1 : 0);
	if (b.v4 && id === "scald") status.remaining = Math.min(4, status.remaining);
	if (b.initial.skillsV5) status.remaining = rule.duration;
	if (control && ENEMY_BY_ID[target.catalogId]?.tier === "boss") status.remaining = 1;
	status.source = source.id;
	status.appliedRound = b.round;
	if (b.initial.formationC2 && id === "link") status.linkShareBp = linkStrengthBp ?? rule.strength * 100;
	if (control && !b.initial.skillsV5) target.bonuses.controlImmuneUntil = b.round + 1;
	record$1(b, source, target, "status", status.stacks, rule.name);
	if (b.initial.skillsV5) emitGameplayEvent(b, {
		kind: "status-applied",
		statusId: id,
		stacks: status.stacks,
		sourceId: source.id,
		actorId: source.id,
		targetId: target.id,
		text: `${target.name}: ${rule.name} ×${status.stacks}.`
	});
	if (source.side === "party") {
		if (id === "steep" && hasEffect(source, "steep-cozy") && (!b.v4 || !source.bonuses.steepCozyUsed)) {
			if (b.v4) source.bonuses.steepCozyUsed = 1;
			applyStatus(b, source, target, "cozy");
		}
		if (id === "scald" && (!b.v4 || source.bonuses.wickRound !== b.round)) {
			if (b.v4) source.bonuses.wickRound = b.round;
			if (hasEffect(source, "unique:warmwick")) gearGrant(b, source, source, "unique:warmwick", "heal", b.v4 ? 4 : 6);
			if (b.v4 && hasEffect(source, "scald-charge")) gearGrant(b, source, source, "scald-charge", "heal", 6);
		}
		if (id === "scald" && boonValue(b, "scaldBrittle")) applyStatus(b, source, target, "brittle");
		if (id === "scald" && boonValue(b, "scaldCrumb")) applyStatus(b, source, target, "crumb");
		if (id === "scent" && boonValue(b, "markCrumb")) applyStatus(b, source, target, "crumb");
		if (id === "tangle" && boonValue(b, "tangleRattle")) applyStatus(b, source, target, "rattled");
	}
	return true;
}
function shield(b, source, target, amount) {
	if (amount <= 0) return;
	amount *= 1 + (source.bonuses.shieldBp ?? 0) / 1e4;
	if (b.initial.skillsV5) amount = receivedV5(target, amount);
	const actual = Math.min(Math.round(amount), Math.max(0, Math.floor(target.maxHp * .6) - target.shield));
	target.shield += actual;
	record$1(b, source, target, "shield", actual);
	if (source.catalogId === "mochi" && source.id !== target.id) source.shield = Math.min(Math.floor(source.maxHp * .6), source.shield + (b.initial.skillsV5 ? receivedV5(source, 12) : 12));
}
function heal(b, source, target, amount) {
	if (target.hp <= 0 || amount <= 0) return;
	amount *= 1 + (source.bonuses.healingBp ?? 0) / 1e4;
	if (b.initial.skillsV5) amount = receivedV5(target, amount);
	if (source.catalogId === "cinnamon" && target.hp < target.maxHp / 2) shield(b, source, target, 15);
	const actual = Math.min(target.maxHp - target.hp, Math.round(amount));
	const overflow = Math.max(0, Math.round(amount) - actual);
	if (source.side === "party" && overflow) shield(b, source, target, overflow * boonValue(b, "overhealShield") / 100);
	target.hp += actual;
	record$1(b, source, target, "heal", actual);
	if (source.catalogId === "clover" && !source.passiveUsed) {
		source.passiveUsed = true;
		dispel(b, source, target, "debuff");
	}
}
function loseHp(b, source, target, amount, kind) {
	const actual = Math.min(target.hp, Math.max(0, Math.round(amount)));
	target.hp -= actual;
	hitRageA6(b, source, target, actual);
	record$1(b, source, target, kind, actual);
	if (target.hp === 0 && stacks(target, "sprout") && !target.bonuses.sproutUsed) {
		target.bonuses.sproutUsed = 1;
		target.statuses = target.statuses.filter((s) => s.id !== "sprout");
		target.hp = Math.round(target.maxHp * .25);
		record$1(b, target, target, "survive", target.hp, "Second sprout");
	}
	if (target.hp === 0) {
		if (target.side === "party" && b.firstDeath === null) b.firstDeath = target.role;
		record$1(b, source, target, "defeat");
		if (b.initial.skillsV5) releaseThreadV5(b, target);
		if (b.initial.skillsV5) spreadV5(b, source, target, reactionRuntimeV5);
		if (source.catalogId === "velvet") {
			if (b.v4) heal(b, source, source, 6);
			else source.charge = Math.min(100, source.charge + 15);
		}
		if (source.side === "party" && source.hp > 0) heal(b, source, source, boonValue(b, "killHeal"));
	}
	if (b.initial.gameplayA6) phaseBossA6(b, target);
	else phaseBossV4(b, target);
	if (b.initial.skillsV5) phaseHelpersV5(b, target, spawnThread);
	return actual;
}
function damage(b, source, target, power, pressure, cover = false, shape = "single") {
	if (target.hp <= 0) return;
	if (stacks(target, "decoy")) {
		target.statuses = target.statuses.filter((s) => s.id !== "decoy");
		record$1(b, source, target, "decoy", 0, "Yarn decoy absorbed the hit");
		return;
	}
	const variance = (9200 + roll(b, 1601)) / 1e4;
	if (!b.v4) {
		const weak = hasAdvantage(source.flavour, target.flavour) ? 1 : 0;
		const extraPressure = source.side === "party" && source.bonuses.pressureRound !== b.round ? boonValue(b, "breakPressure") : 0;
		source.bonuses.pressureRound = b.round;
		const pressureTotal = pressure + weak + stacks(target, "tangle") + extraPressure + (hasEffect(source, "marked-break") && stacks(target, "scent") ? 1 : 0);
		target.break = Math.min(target.breakCap, target.break + pressureTotal);
		if (target.break >= target.breakCap) {
			const intent = b.intents.find((i) => i.actorId === target.id);
			if (intent) intent.interrupted = true;
			record$1(b, source, target, "break", pressureTotal, "Intent interrupted");
			if (source.side === "party" && b.procRounds.breakEnergy !== b.round) {
				b.energy = Math.min(10, b.energy + boonValue(b, "breakEnergy"));
				b.procRounds.breakEnergy = b.round;
			}
		}
	}
	const extraDamage = source.side === "party" ? (source.shield > 0 ? boonValue(b, "shieldStrike") : 0) + (source.row === "rear" ? boonValue(b, "rearDamage") : 0) : 0;
	const bonus = source.bonuses;
	const conditional = (source.row === "front" ? bonus.frontDamage ?? 0 : bonus.rearDamage ?? 0) + (ENEMY_BY_ID[target.catalogId]?.tier === "boss" ? bonus.bossDamage ?? 0 : 0) + (ENEMY_BY_ID[target.catalogId]?.tier === "elite" ? bonus.eliteDamage ?? 0 : 0) + (stacks(target, "scald") ? bonus.scaldDamage ?? 0 : 0) + (stacks(target, "scent") ? bonus.markedDamage ?? 0 : 0) + ((b.v4 ? stacks(target, "scent") > 0 : target.break >= target.breakCap) ? bonus.brokenDamage ?? 0 : 0) + (source.shield > 0 ? bonus.shieldedDamage ?? 0 : 0) + (source.hp < source.maxHp / 2 ? bonus.lowHpDamage ?? 0 : 0);
	const marked = b.v4 && stacks(target, "scent") ? (hasEffect(source, "marked-break") ? 3 : 0) + boonValue(b, "markedDirect") : 0;
	const attack = source.attack * power / 100 + extraDamage + conditional + marked;
	const critical = (bonus.critBp ?? 0) > 0 && roll(b) < bonus.critBp ? 1 + (bonus.critDamageBp ?? 5e3) / 1e4 : 1;
	const mitigation = 80 / (80 + (b.initial.skillsV5 ? defenseV5(target) : target.defense));
	const cozy = 1 - stacks(target, "cozy") * .1;
	const rattled = 1 - stacks(source, "rattled") * .15;
	const scent = stacks(target, "scent") ? 1.2 : 1;
	const broken = !b.v4 && target.break >= target.breakCap ? 1.2 : 1;
	const tangled = b.v4 ? 1 - stacks(source, "tangle") * .04 : 1;
	let amount = Math.max(1, Math.round(attack * mitigation * cozy * rattled * scent * broken * variance * critical * tangled));
	if (b.v4 && cover && target.row === "rear" && living(b, target.side).some((a) => a.row === "front")) {
		const prevented = amount - Math.max(1, Math.round(amount * (b.initial.formationC2 ? FORMATION_C2.rearCoverMultiplier : .9)));
		amount -= prevented;
		if (prevented) emitGameplayEvent(b, {
			kind: "formation-cover",
			actorId: source.id,
			targetId: target.id,
			amount: prevented,
			text: `Front cover prevented ${prevented} damage to ${target.name}.`
		});
	}
	target.shield = Math.max(0, target.shield - stacks(target, "brittle") * 15);
	const absorbed = Math.min(target.shield, amount);
	target.shield -= absorbed;
	if (b.v4 && absorbed) record$1(b, source, target, "absorbed", absorbed, "Shield absorbed direct damage");
	let hpDamage = amount - absorbed;
	const link = target.statuses.find((s) => s.id === "link");
	const protector = link && b.actors.find((a) => a.id === link.source && a.hp > 0 && a.id !== target.id);
	if (protector) {
		const shared = Math.floor(hpDamage * linkShareBps(b, protector, link) / 1e4);
		hpDamage -= shared;
		loseHp(b, source, protector, shared, "shared");
	}
	loseHp(b, source, target, hpDamage, "damage");
	if (b.initial.skillsV5) directReactionV5(b, source, target, shape, reactionRuntimeV5);
	if (b.v4 ? stacks(target, "scent") > 0 && source.bonuses.breakShieldRound !== b.round : target.break >= target.breakCap) {
		if (b.v4) source.bonuses.breakShieldRound = b.round;
		shield(b, source, source, source.bonuses.breakShield ?? 0);
	}
	if (b.v4 && hasEffect(source, "ultimate-refund") && stacks(target, "scent") && source.bonuses.moonHealRound !== b.round) {
		source.bonuses.moonHealRound = b.round;
		gearGrant(b, source, source, "ultimate-refund", "heal", 6);
	}
	if (hasEffect(source, "third-crumb") && (b.v4 ? source.bonuses.thirdCrumbTurn !== source.turns && ((source.bonuses.attackCount ?? 0) + 1) % 3 === 0 : (source.turns + 1) % 3 === 0)) {
		if (b.v4) source.bonuses.thirdCrumbTurn = source.turns;
		applyStatus(b, source, target, "crumb");
	}
	if (hasEffect(source, "unique:nightglass") && stacks(target, "scent") && source.bonuses.nightglassRound !== b.round) {
		if (b.v4) gearGrant(b, source, source, "unique:nightglass", "shield", 6);
		else b.energy = Math.min(10, b.energy + 1);
		source.bonuses.nightglassRound = b.round;
	}
	if (!b.v4) {
		source.charge = Math.min(100, source.charge + 8);
		target.charge = Math.min(100, target.charge + 7);
		if (source.side === "party" && stacks(target, "scald")) source.charge = Math.min(100, source.charge + boonValue(b, "scaldCharge"));
		if (source.catalogId === "mallow" && stacks(target, "scald")) source.charge = Math.min(100, source.charge + 8);
	} else if (source.catalogId === "mallow" && stacks(target, "scald") && source.bonuses.mallowRound !== b.round) {
		source.bonuses.mallowRound = b.round;
		heal(b, source, source, 4);
	}
	if (b.v4 && stacks(target, "scald") && source.bonuses.scaldHealRound !== b.round) {
		source.bonuses.scaldHealRound = b.round;
		heal(b, source, source, boonValue(b, "scaldHeal"));
	}
	if (b.v4 && stacks(target, "scent") && source.bonuses.markShieldRound !== b.round) {
		source.bonuses.markShieldRound = b.round;
		shield(b, source, source, boonValue(b, "markedShield"));
	}
	if (source.catalogId === "biscuit" && source.hp < source.maxHp / 2 && !source.passiveUsed) {
		source.passiveUsed = true;
		shield(b, source, source, 30);
	}
	const reflect = stacks(target, "riposte") * (16 + (target.bonuses.counterPower ?? 0) + (hasEffect(target, "counter-plus") ? b.v4 ? 3 : 8 : 0)) + (target.catalogId === "kettle-knight" && target.shield > 0 ? 12 : 0);
	if (reflect && source.hp > 0) loseHp(b, target, source, reflect, "reflect");
}
var reactionRuntimeV5 = {
	apply: applyStatus,
	loseHp,
	record: record$1,
	rule: (id) => STATUS_BY_ID[id]
};
var statusRuntimeV5 = {
	heal,
	loseHp,
	record: record$1,
	rule: (id) => STATUS_BY_ID[id],
	isBoss: (actor) => ENEMY_BY_ID[actor.catalogId]?.tier === "boss"
};
function tickStatuses(b, actor) {
	if (b.initial.skillsV5) return tickStatusesV5(b, [actor], statusRuntimeV5);
	if (actor.hp <= 0) return;
	for (const s of [...actor.statuses]) {
		const rule = STATUS_BY_ID[s.id], source = b.actors.find((a) => a.id === s.source) ?? actor;
		if (rule.tick === "damage") loseHp(b, source, actor, (rule.strength + (source.side === "party" ? boonValue(b, "scaldPower") + (source.bonuses.dotPower ?? 0) : 0)) * s.stacks, "dot");
		if (!b.v4 && rule.tick === "damage" && hasEffect(source, "scald-charge")) source.charge = Math.min(100, source.charge + 3);
		if (actor.hp <= 0) break;
		if (rule.tick === "heal") {
			heal(b, source, actor, (rule.strength + (actor.side === "party" ? boonValue(b, "steepPower") : 0)) * s.stacks);
			const scald = actor.statuses.find((x) => x.id === "scald");
			if (scald) scald.stacks--;
		}
		s.remaining--;
		if (s.remaining <= 0) record$1(b, actor, actor, "expire", 0, rule.name);
	}
	actor.statuses = actor.statuses.filter((s) => s.remaining > 0 && s.stacks > 0);
}
function actorBase() {
	return {
		shield: 0,
		charge: 20,
		break: 0,
		statuses: [],
		cooldowns: {},
		passiveUsed: false,
		phase: 1,
		equipment: [],
		setEffects: [],
		bonuses: {},
		turns: 0
	};
}
function enemyActor(id, index, chapter, tutorial = false, enemyStats) {
	const e = ENEMY_BY_ID[id];
	if (!e) throw Error("Unknown enemy");
	const stats = enemyStats?.[id] ?? e;
	const scale = tutorial ? .55 : 1 + Math.max(0, chapter - e.chapter) * .16;
	return {
		...actorBase(),
		id: `foe-${index}-${id}`,
		catalogId: id,
		name: e.name,
		side: "enemy",
		role: e.role,
		row: e.row,
		flavour: e.flavour,
		hp: Math.round(stats.hp * scale),
		maxHp: Math.round(stats.hp * scale),
		attack: Math.round(stats.attack * scale * (tutorial ? 1 : [
			2.7,
			1.95,
			1.6
		][chapter - 1])),
		defense: stats.defense,
		initiative: 5 - index % 3,
		effectHit: 0,
		effectResist: e.tier === "boss" ? 1200 : 500,
		breakCap: e.breakCap,
		skills: []
	};
}
function createBattle(setup) {
	if (setup.formationC2 && (!setup.gameplayA6 || !validRowsC2(setup.cats.map((c) => c.id), Object.fromEntries(setup.cats.map((c) => [c.id, c.row]))))) throw Error("C2 requires four cats, two in each row, and Gameplay A6");
	if (setup.gameplayA6 && (!setup.skillsV5 || !setup.gameplayV4)) throw Error("Gameplay A6 requires Skills V5");
	if (setup.skillsV5 && !setup.gameplayV4) throw Error("Skills V5 requires automatic Gameplay V4");
	const initial = clone(setup);
	if (!initial.skillsV5) delete initial.skillsV5;
	if (!initial.gameplayA6) delete initial.gameplayA6;
	if (setup.gameplayV4) {
		if (setup.plan && !validPlan(setup.plan)) throw Error("Invalid standing plan");
		initial.plan = clone(setup.plan ?? DEFAULT_PLAN);
	}
	if (setup.gameplayV4 && setup.challengeLevel !== void 0) initial.enemyStats ??= challengeStatsV4(setup.challengeLevel);
	initial.enemyStats ??= Object.fromEntries(Object.values(ENEMY_BY_ID).map(({ id, hp, attack, defense }) => [id, {
		hp,
		attack,
		defense
	}]));
	const actors = setup.cats.map((c, index) => {
		const cat = CAT_BY_ID[c.id];
		if (!cat || ![3, 4].includes(c.skills.length) || new Set(c.skills).size !== c.skills.length || c.skills.some((id) => SKILLS[id]?.catId !== c.id)) throw Error("Invalid cat skill kit");
		return {
			...actorBase(),
			id: c.id,
			catalogId: c.id,
			name: cat.name,
			side: "party",
			role: cat.role,
			row: c.row,
			flavour: cat.flavour,
			hp: Math.min(c.stats.hp, setup.hp?.[c.id] ?? c.stats.hp),
			maxHp: c.stats.hp,
			attack: c.stats.attack,
			defense: c.stats.defense,
			initiative: 9 - index,
			effectHit: c.stats.effectHitBp,
			effectResist: c.stats.effectResistBp,
			breakCap: 6,
			skills: [...c.skills],
			equipment: c.equipment ?? [],
			setEffects: c.effects ?? [],
			bonuses: {
				...c.bonuses,
				critBp: c.stats.critBp,
				critDamageBp: c.stats.critDamageBp,
				healingBp: c.stats.healingBp,
				shieldBp: c.stats.shieldBp
			}
		};
	});
	actors.push(...(setup.skillsV5 ? encounterEnemiesV5(setup.enemies) : setup.enemies).map((id, i) => enemyActor(id, i, setup.chapter, setup.tutorial, initial.enemyStats)));
	if (setup.formationC2) {
		const count = {
			front: 0,
			rear: 0
		};
		for (const foe of actors.filter((a) => a.side === "enemy")) {
			if (count[foe.row] >= 2) foe.row = foe.row === "front" ? "rear" : "front";
			count[foe.row]++;
		}
	}
	const b = {
		version: CONTRACT_VERSION,
		seed: setup.seed,
		rng: setup.seed,
		chapter: setup.chapter,
		actors,
		round: 0,
		queue: [],
		acted: [],
		energy: 0,
		maxEnergy: 5,
		intents: [],
		log: [],
		choices: [],
		result: null,
		firstDeath: null,
		procRounds: {},
		boons: { ...setup.boons },
		mutator: setup.mutator ?? "",
		initial
	};
	if (setup.gameplayV4) {
		b.v4 = {
			version: 1,
			plan: clone(initial.plan),
			events: [],
			committed: false
		};
		b.maxEnergy = 0;
		const primary = actors.find((a) => a.side === "enemy" && ENEMY_BY_ID[a.catalogId]?.tier === "boss");
		if (primary) {
			for (const a of actors) if (a.side === "enemy" && a.id !== primary.id && ENEMY_BY_ID[a.catalogId]?.tier !== "boss") a.linkedBossId = primary.id;
		}
		for (const actor of actors) actor.charge = 0;
		for (const crew of crewThresholds(setup.cats.map((c) => c.id))) if (crew.threshold) emitGameplayEvent(b, {
			kind: "crew-active",
			crew: crew.id,
			marks: crew.marks,
			contributors: crew.contributors,
			threshold: crew.threshold,
			text: `${crew.name}: ${crew.description}.`
		});
	}
	prepareBattleA6(b);
	const combos = setup.gameplayV4 ? [] : teamCombos(setup.cats.map((c) => c.id));
	for (const actor of living(b, "party")) {
		actor.shield += boonValue(b, "openingShield") + (actor.bonuses.openingShield ?? 0);
		if (b.v4 && setup.packedSupply?.catId === actor.id) {
			const id = setup.packedSupply.id;
			if (id === "shield-biscuit") actor.shield += 20;
			if (id === "quicken-yarn") applyStatus(b, actor, actor, "cozy");
			if (id === "cleanse-tea") actor.bonuses.pantryCleanse = 1;
			if (id === "ultimate-treat") actor.bonuses.pantryTreat = 1;
		}
		if (b.v4) {
			openingCrewBonus(setup.cats.map((c) => c.id), actor);
			actor.shield += actor.bonuses.openingCharge ?? 0;
		} else actor.charge = Math.min(100, actor.charge + boonValue(b, "openingCharge") + (actor.bonuses.openingCharge ?? 0));
		if (hasEffect(actor, "opening-decoy")) {
			if (b.v4) actor.shield += 12;
			else applyStatus(b, actor, actor, "decoy");
		}
		if (hasEffect(actor, "unique:softcollar")) {
			if (b.v4) actor.shield += setup.formationC2 ? ECONOMY_C2.uniques.softcollarShield : 15;
			else applyStatus(b, actor, actor, "sprout");
		}
		if (boonValue(b, "openingSteep")) applyStatus(b, actor, actor, "steep", boonValue(b, "openingSteep"));
		if (combos.some((c) => c.id === "warm-table")) actor.shield += 20;
		if (combos.some((c) => c.id === "night-garden")) actor.charge += 10;
		if (actor.catalogId === "inkcap") applyStatus(b, actor, actor, "decoy");
	}
	if (setup.mutator === "thin-pot" && !b.v4) b.maxEnergy = 4;
	for (const actor of b.actors) {
		if (b.v4 && setup.mutator === "thin-pot" && actor.side === "party") {
			actor.shield += 12;
			actor.bonuses.healingBp = (actor.bonuses.healingBp ?? 0) - 1e3;
		}
		if (setup.mutator === "rainy" && actor.side === "enemy") actor.shield += 20;
		if (setup.mutator === "warm-floor" && actor.row === "front") applyStatus(b, actor, actor, "cozy");
		if (setup.mutator === "late-shift") {
			if (actor.side === "enemy") actor.attack = Math.round(actor.attack * 1.1);
			else if (b.v4) actor.shield += 15;
			else actor.charge += 15;
		}
	}
	beginRound(b);
	if (combos.some((c) => c.id === "crumb-circuit")) b.energy++;
	return b;
}
function weakest(actors) {
	return [...actors].sort((a, c) => a.hp / a.maxHp - c.hp / c.maxHp)[0];
}
function setIntents(b) {
	const party = living(b, "party");
	if (!party.length) return;
	b.intents = living(b, "enemy").map((a) => {
		const spec = ENEMY_BY_ID[a.catalogId];
		const signature = b.initial.gameplayA6 ? a.charge >= 100 : b.round % 3 === 0;
		const rear = party.filter((p) => p.row === "rear");
		const front = party.filter((p) => p.row === "front");
		const reachable = b.v4 && front.length ? front : party;
		const target = spec.mechanic === "steal" && (!b.initial.formationC2 || signature) && rear.length ? weakest(rear) : b.v4 && spec.mechanic === "snare" ? weakest(reachable) : reachable[roll(b, reachable.length)];
		const intent = {
			actorId: a.id,
			targetId: target.id,
			label: signature ? b.v4 ? enemyGuideV4(a.catalogId).intent : spec.intent : `${a.name} · ${!b.v4 && spec.mechanic === "heal" ? "Cup refill" : "basic pressure"}`,
			counter: b.v4 ? enemyGuideV4(a.catalogId).counter : spec.counter,
			power: signature ? 175 : 100,
			status: signature ? spec.status : void 0,
			signature,
			interrupted: false
		};
		return b.initial.skillsV5 ? enemyIntentV5(b, a, intent) : intent;
	});
}
function beginRound(b) {
	b.round++;
	b.acted = [];
	b.energy = b.v4 ? 0 : Math.min(10, b.maxEnergy + boonValue(b, "roundEnergy"));
	b.queue = b.actors.filter((a) => a.hp > 0).sort((a, c) => c.initiative - a.initiative || a.id.localeCompare(c.id)).map((a) => a.id);
	for (const a of b.actors) {
		for (const id of Object.keys(a.cooldowns)) a.cooldowns[id] = Math.max(0, a.cooldowns[id] - 1);
		if (a.hp > 0 && a.side === "party" && a.row === "front") shield(b, a, a, boonValue(b, "roundShield"));
		if (a.hp > 0 && a.side === "party") heal(b, a, a, (a.bonuses.roundHeal ?? 0) + (hasEffect(a, "rear-heal") && a.row === "rear" ? b.v4 ? 6 : 16 : 0));
		if (a.hp > 0 && a.catalogId === "brioche") shield(b, a, a, 12);
		if (a.hp > 0 && a.catalogId === "sorrel" && b.round % 2 === 1) {
			if (b.v4) shield(b, a, weakest(living(b, "party")), 6);
			else b.energy++;
		}
		const enemy = ENEMY_BY_ID[a.catalogId];
		if (!b.v4 && enemy?.tier === "boss" && a.hp <= a.maxHp / 2 && a.phase === 1) {
			a.phase = 2;
			record$1(b, a, a, "phase", 2, enemy.phases[1]);
		}
	}
	setIntents(b);
}
function checkResult(b) {
	if (b.result) return;
	if (finishBossV4(b)) return;
	if (!living(b, "party").length || b.round > 50) b.result = "enemy";
	else if (!living(b, "enemy").length) b.result = "party";
}
function currentActor(b) {
	return b.actors.find((a) => a.id === b.queue[0] && a.hp > 0);
}
function targets(b, actor, skill) {
	const foes = living(b, actor.side === "party" ? "enemy" : "party"), allies = living(b, actor.side);
	if (b.initial.skillsV5) {
		skill = situationalSkillV5(b, actor, skill);
		if (["weakest", "ally-splash"].includes(shapeV5(skill))) {
			const target = weakestV5(allies);
			return target ? [target] : [];
		}
	}
	if (skill.target === "self") return [actor];
	if (skill.target === "fallen") return b.actors.filter((a) => a.side === actor.side && a.hp === 0);
	if (skill.target === "ally" || skill.target === "allies") return allies;
	if (skill.target === "foe" && !hasEffect(actor, "pierce-row")) return foes.filter((a) => a.row === "front").length ? foes.filter((a) => a.row === "front" || stacks(a, "scent")) : foes;
	return foes;
}
var defend = {
	id: "defend",
	catId: "",
	name: "Defend",
	description: "Gain 35 shield and Cozy. Panko also gains Riposte.",
	type: "defend",
	target: "self",
	cost: 0,
	cooldown: 0,
	charge: 0,
	breakPower: 0,
	effects: [{
		kind: "shield",
		power: 35
	}, {
		kind: "rally",
		status: "cozy"
	}],
	unlockLevel: 1,
	unlockStars: 1
};
var COMMON_SKILLS = {
	defend,
	wait: {
		...defend,
		id: "wait",
		name: "Pour energy",
		description: "Gain 1 shared energy. Use one action.",
		type: "support",
		effects: [{
			kind: "energy",
			power: 1
		}]
	}
};
function skillById(id, v5 = false) {
	const skill = SKILLS[id] ?? COMMON_SKILLS[id];
	return v5 && skill ? kitSkillV5(skill) : skill;
}
function energyCost(actor, skill) {
	return skill.cost + (skill.cost > 0 && stacks(actor, "hush") ? 1 : 0);
}
function legalChoices(b) {
	const actor = currentActor(b);
	if (!actor || actor.side !== "party" || b.result) return [];
	return [
		...actor.skills,
		"defend",
		...b.v4 ? [] : ["wait"]
	].flatMap((id) => {
		const base = skillById(id, b.initial.skillsV5), skill = b.initial.skillsV5 ? situationalSkillV5(b, actor, base) : base;
		if (!b.v4 && (energyCost(actor, skill) > b.energy || skill.charge > actor.charge) || b.v4 && skill.type === "ultimate" && (b.initial.gameplayA6 ? actor.charge < 100 : actor.turns < 2) || (actor.cooldowns[id] ?? 0) > 0 || skill.effects.some((e) => e.kind === "revive") && actor.passiveUsed) return [];
		return targets(b, actor, skill).map((t) => ({
			actorId: actor.id,
			skillId: id,
			targetId: t.id
		}));
	});
}
function gearGrant(b, actor, target, effect, kind, amount) {
	const before = kind === "heal" ? target.hp : target.shield;
	if (kind === "heal") heal(b, actor, target, amount);
	else shield(b, actor, target, amount);
	const actual = (kind === "heal" ? target.hp : target.shield) - before;
	if (b.v4 && actual > 0) {
		const set = SETS.find((s) => s.twoEffect === effect || s.fourEffect === effect);
		const templateId = actor.equipment.find((id) => effect.startsWith("unique:") ? GEAR_BY_ID[id]?.unique === effect.slice(7) : GEAR_BY_ID[id]?.setId === set?.id) ?? "";
		emitGameplayEvent(b, {
			kind: "gear-trigger",
			actorId: actor.id,
			targetId: target.id,
			templateId,
			effect,
			amount: actual,
			text: `${GEAR_BY_ID[templateId]?.name ?? effect} ${kind === "heal" ? "restored" : "granted"} ${actual} ${kind === "heal" ? "HP" : "shield"} to ${target.name}.`
		});
	}
}
function cleanseUniqueV4(b, actor, target) {
	if (hasEffect(actor, "unique:gardenkey") && actor.bonuses.gardenTurn !== actor.turns) {
		actor.bonuses.gardenTurn = actor.turns;
		gearGrant(b, actor, target, "unique:gardenkey", "heal", 8);
	}
}
function executeEffect(b, actor, target, effect, skill) {
	const power = Math.round((effect.power ?? 0) * (1 + ROUTE_SKILL_POWER_PER_RANK * (b.initial.upgrades?.[skill.id] ?? 0)) * (b.initial.skillsV5 ? 1 + (effect.burnScaling ?? 0) * stacks(target, "scald") : 1));
	switch (effect.kind) {
		case "hit":
			damage(b, actor, target, power, skill.breakPower, false, shapeV5(skill));
			break;
		case "shield":
			shield(b, actor, target, power + (actor.bonuses.shieldFlat ?? 0));
			if (boonValue(b, "shieldHeal")) heal(b, actor, target, boonValue(b, "shieldHeal"));
			break;
		case "heal":
			heal(b, actor, target, power + boonValue(b, "healing") + (actor.bonuses.healFlat ?? 0));
			if (hasEffect(actor, "unique:seedcup") && !actor.bonuses.seedcupUsed) {
				if (b.v4) gearGrant(b, actor, target, "unique:seedcup", "shield", 12);
				else applyStatus(b, actor, target, "sprout");
				actor.bonuses.seedcupUsed = 1;
			}
			if (boonValue(b, "healCleanse") || hasEffect(actor, "healing-cleanse") && (!b.v4 || actor.bonuses.setCleanseTurn !== actor.turns)) {
				const debuff = target.statuses.find((s) => STATUS_BY_ID[s.id].kind === "debuff" && STATUS_BY_ID[s.id].dispellable);
				if (debuff) {
					target.statuses = target.statuses.filter((s) => s !== debuff);
					if (b.v4) {
						actor.bonuses.setCleanseTurn = actor.turns;
						cleanseUniqueV4(b, actor, target);
					}
				}
			}
			if (!actor.bonuses.healProc) {
				if (b.v4) shield(b, actor, target, boonValue(b, "healShield"));
				else actor.charge = Math.min(100, actor.charge + boonValue(b, "healCharge"));
				actor.bonuses.healProc = 1;
			}
			break;
		case "cleanse": {
			const before = target.statuses.length;
			if (b.initial.skillsV5 && effect.cleanseCount) {
				const removed = target.statuses.filter((s) => STATUS_BY_ID[s.id].kind === "debuff" && STATUS_BY_ID[s.id].dispellable).slice(0, effect.cleanseCount);
				target.statuses = target.statuses.filter((s) => !removed.includes(s));
				record$1(b, actor, target, "dispel", removed.length, "Removed debuffs");
			} else dispel(b, actor, target, "debuff");
			if (before > target.statuses.length) {
				shield(b, actor, target, actor.bonuses.cleanseShield ?? 0);
				if (b.v4) cleanseUniqueV4(b, actor, target);
				else if (hasEffect(actor, "unique:gardenkey")) heal(b, actor, target, 25);
			}
			if (before > target.statuses.length && !actor.bonuses.cleanseProc) {
				if (b.v4) {
					shield(b, actor, target, boonValue(b, "cleanseExtraShield"));
					if (actor.bonuses.crewCleanse && !actor.bonuses.crewCleansed) {
						actor.bonuses.crewCleansed = 1;
						shield(b, actor, target, actor.bonuses.crewCleanse);
					}
				} else b.energy = Math.min(10, b.energy + boonValue(b, "cleanseEnergy"));
				actor.bonuses.cleanseProc = 1;
			}
			break;
		}
		case "dispel":
			dispel(b, actor, target, "buff");
			break;
		case "detonate": {
			const detonate = () => {
				const count = stacks(target, "crumb") + stacks(target, "scald");
				loseHp(b, actor, target, count * (24 + boonValue(b, "detonatePower")) * power / 100, "detonate");
				target.statuses = target.statuses.filter((s) => s.id !== "crumb" && s.id !== "scald");
				if (count && boonValue(b, "detonateSplash")) for (const other of living(b, target.side).filter((a) => a.id !== target.id)) loseHp(b, actor, other, boonValue(b, "detonateSplash"), "detonate");
				if (count && hasEffect(actor, "detonate-energy")) {
					if (b.v4) {
						if (actor.bonuses.setDetonateTurn !== actor.turns) {
							actor.bonuses.setDetonateTurn = actor.turns;
							gearGrant(b, actor, actor, "detonate-energy", "shield", 8);
						}
					} else b.energy = Math.min(10, b.energy + 1);
				}
				if (count && hasEffect(actor, "unique:crumbbook") && (!b.v4 || actor.bonuses.bookTurn !== actor.turns)) {
					if (b.v4) actor.bonuses.bookTurn = actor.turns;
					gearGrant(b, actor, actor, "unique:crumbbook", "shield", b.v4 ? 10 : 35);
				}
				if (count && actor.catalogId === "soot") {
					if (b.v4) shield(b, actor, actor, 6);
					else actor.charge = Math.min(100, actor.charge + 10);
				}
			};
			if (b.initial.skillsV5) crumbBurstV5(b, actor, target, reactionRuntimeV5, detonate);
			else detonate();
			break;
		}
		case "transfer": {
			const amount = actor.shield;
			actor.shield = 0;
			shield(b, actor, target, amount);
			break;
		}
		case "revive":
			target.hp = Math.round(target.maxHp * power / 100);
			target.statuses = [];
			actor.passiveUsed = true;
			record$1(b, actor, target, "revive", target.hp);
			break;
		case "execute":
			damage(b, actor, target, power * (target.hp / target.maxHp < .3 + (actor.bonuses.executeThreshold ?? 0) / 100 ? 2 : 1), skill.breakPower, false, shapeV5(skill));
			break;
		case "chain": {
			const others = living(b, target.side).filter((t) => t.id !== target.id);
			for (const [i, t] of [target, ...others].slice(0, 3).entries()) damage(b, actor, t, power * (1 - i * .15), skill.breakPower);
			break;
		}
		case "energy":
			if (b.v4) {
				const ally = weakest(living(b, actor.side));
				if (ally) shield(b, actor, ally, Math.min(18, power * 6));
			} else {
				b.energy = Math.min(10, b.energy + power);
				record$1(b, actor, actor, "energy", power);
			}
			break;
		case "swap": {
			const row = actor.row;
			actor.row = target.row;
			target.row = row;
			shield(b, actor, actor, boonValue(b, "swapShield") + (hasEffect(actor, "swap-shield") ? b.v4 ? 12 : 25 : 0));
			shield(b, actor, target, boonValue(b, "swapShield") + (hasEffect(actor, "swap-shield") ? b.v4 ? 12 : 25 : 0));
			if (hasEffect(actor, "unique:rainbell")) {
				if (b.v4) {
					const debuff = actor.statuses.find((s) => STATUS_BY_ID[s.id].kind === "debuff" && STATUS_BY_ID[s.id].dispellable);
					if (debuff) {
						if (b.initial.formationC2) debuff.stacks = Math.max(0, debuff.stacks - ECONOMY_C2.uniques.rainbellCleanseStacks);
						if (!b.initial.formationC2 || debuff.stacks === 0) actor.statuses = actor.statuses.filter((s) => s !== debuff);
					}
				} else dispel(b, actor, actor, "debuff");
			}
			break;
		}
		case "drain":
			heal(b, actor, actor, actor.attack * power / 100);
			break;
		case "consume": {
			const count = stacks(actor, "cozy");
			actor.statuses = actor.statuses.filter((s) => s.id !== "cozy");
			if (count) damage(b, actor, target, count * power, 0);
			break;
		}
		case "break":
			if (b.v4) {
				applyStatus(b, actor, target, "rattled", 1);
				break;
			}
			target.break = Math.min(target.breakCap, target.break + power);
			if (target.break >= target.breakCap) {
				const i = b.intents.find((i) => i.actorId === target.id);
				if (i) i.interrupted = true;
			}
	}
	if (effect.status) applyStatus(b, actor, target, effect.status, effect.stacks ?? 1);
}
function finishAction(b, actor) {
	actor.turns++;
	if (b.v4) {
		b.energy = 0;
		for (const a of b.actors) {
			if (!b.initial.gameplayA6) a.charge = 0;
			a.break = 0;
		}
		gainRageA6(b, actor, 24);
	} else actor.charge = Math.min(100, actor.charge + 6);
	b.acted.push(actor.id);
	b.queue = b.queue.filter((id) => id !== actor.id && b.actors.some((a) => a.id === id && a.hp > 0));
	checkResult(b);
	if (!b.result && !b.queue.length) {
		if (b.initial.skillsV5) tickStatusesV5(b, b.actors, statusRuntimeV5);
		else for (const a of b.actors) {
			tickStatuses(b, a);
			if (b.v4) {
				checkResult(b);
				if (b.result) break;
			}
		}
		checkResult(b);
		if (!b.result) beginRound(b);
	}
}
/** Mutates only an accepted legal choice. Rejected actions leave the snapshot identical. */
function actionDescription(b, actor, target, skill) {
	const health = Math.round(target.hp / target.maxHp * 100);
	if (skill.effects.some((effect) => effect.kind === "revive")) return `${actor.name} revives ${target.name} · ${skill.name}`;
	if (skill.target === "allies") {
		const lowest = Math.min(...living(b, "party").map((ally) => Math.round(ally.hp / ally.maxHp * 100)));
		return `${actor.name} supports the team (lowest HP ${lowest}%) · ${skill.name}`;
	}
	if (target.side === "enemy") {
		const weakest = Math.min(...targets(b, actor, skill).map((foe) => foe.hp));
		const reason = target.hp === weakest ? "focuses the weakest reachable foe" : "pressures a foe";
		return `${actor.name} ${reason}, ${target.name} (HP ${health}%) · ${skill.name}`;
	}
	const verb = skill.effects.some((effect) => effect.kind === "heal") ? "heals" : "protects";
	if (skill.id === "wait") return `${actor.name} restores shared energy for the team`;
	return `${actor.name} ${verb} ${target.name} (HP ${health}%) · ${skill.name}`;
}
function act(b, choice) {
	if (!legalChoices(b).some((c) => c.actorId === choice.actorId && c.skillId === choice.skillId && c.targetId === choice.targetId)) return false;
	const actor = currentActor(b);
	if (b.initial.skillsV5) b.procRounds.v5ActionSequence = (b.procRounds.v5ActionSequence ?? 0) + 1;
	if (b.initial.skillsV5 && !beforeActionV5(b, actor, statusRuntimeV5)) {
		b.choices.push({ ...choice });
		record$1(b, actor, actor, "action", 0, "Bleed prevented the action", choice.skillId);
		finishAction(b, actor);
		return true;
	}
	let skill = skillById(choice.skillId, b.initial.skillsV5), target = b.actors.find((a) => a.id === choice.targetId);
	if (b.initial.skillsV5) skill = situationalSkillV5(b, actor, skill);
	if (b.initial.skillsV5 && consumeDazeV5(b, actor, statusRuntimeV5)) {
		const basic = skillById(actor.skills[0], true);
		skill = {
			...basic,
			effects: basic.effects.map((e) => ({
				...e,
				...e.power !== void 0 ? { power: e.power * .5 } : {}
			}))
		};
		target = targets(b, actor, skill)[0] ?? target;
	}
	const description = actionDescription(b, actor, target, skill);
	b.choices.push({ ...choice });
	actor.bonuses.healProc = 0;
	actor.bonuses.cleanseProc = 0;
	if (b.v4) {
		b.v4.committed = true;
		emitGameplayEvent(b, {
			kind: "plan-target",
			actorId: actor.id,
			targetId: target.id,
			plan: { ...b.v4.plan },
			reason: description,
			text: `${b.v4.plan.focus}/${b.v4.plan.care} plan: ${description}`
		});
	} else {
		b.energy -= energyCost(actor, skill);
		actor.charge -= skill.charge;
	}
	if (b.initial.gameplayA6 && skill.type === "ultimate") {
		actor.charge = 0;
		emitGameplayEvent(b, {
			kind: "ultimate.cast",
			actorId: actor.id,
			targetId: target.id,
			skillId: skill.id,
			displayName: skill.name,
			text: `${actor.name} · ${skill.name}`
		});
	}
	actor.cooldowns[skill.id] = skill.cooldown + 1;
	shield(b, actor, actor, stacks(actor, "glaze") * 20);
	if (b.initial.skillsV5) executeShapeV5(b, actor, target, skill, {
		roll,
		effect: executeEffect,
		record: record$1
	});
	else {
		const affected = skill.target === "foes" ? living(b, "enemy") : skill.target === "allies" ? living(b, "party") : skill.target === "row" ? living(b, target.side).filter((a) => a.row === target.row) : [target];
		for (const effect of skill.effects) if (effect.self || effect.kind === "energy" || effect.kind === "chain") executeEffect(b, actor, effect.self ? actor : target, effect, skill);
		else for (const t of affected) executeEffect(b, actor, t, effect, skill);
	}
	if (actor.catalogId === "panko" && skill.id === "defend") applyStatus(b, actor, actor, "riposte");
	if (skill.id === "defend") {
		if (hasEffect(actor, "defend-shield")) gearGrant(b, actor, actor, "defend-shield", "shield", b.v4 ? 12 : 25);
		if (hasEffect(actor, "defend-link")) {
			const ally = weakest(living(b, "party").filter((a) => a.id !== actor.id));
			if (ally) applyStatus(b, actor, ally, "link", 1, ECONOMY_C2.sets.hearthloomShareBp);
		}
		if (hasEffect(actor, "defend-riposte")) {
			if (!b.initial.formationC2 || (actor.bonuses.bellsteelShelters ?? 0) < ECONOMY_C2.sets.bellsteelSheltersPerBattle) {
				applyStatus(b, actor, actor, "shelter");
				if (b.initial.formationC2) actor.bonuses.bellsteelShelters = (actor.bonuses.bellsteelShelters ?? 0) + 1;
			}
			if (!b.initial.formationC2 || (actor.bonuses.bellsteelRipostes ?? 0) < ECONOMY_C2.sets.bellsteelRipostesPerBattle) {
				applyStatus(b, actor, actor, "riposte");
				if (b.initial.formationC2) actor.bonuses.bellsteelRipostes = (actor.bonuses.bellsteelRipostes ?? 0) + 1;
			}
		}
		if (hasEffect(actor, "unique:panlid")) applyStatus(b, actor, actor, "riposte", b.v4 ? 1 : 2);
		if (hasEffect(actor, "unique:doorstop")) gearGrant(b, actor, actor, "unique:doorstop", "heal", b.v4 ? 8 : 25);
	}
	if (skill.id === "wait" && hasEffect(actor, "unique:tidetray")) shield(b, actor, weakest(living(b, "party")), 30);
	if (skill.charge && !b.v4) {
		actor.charge = Math.min(100, actor.charge + (actor.bonuses.ultimateCharge ?? 0) + (hasEffect(actor, "ultimate-refund") ? 20 : 0));
		if (hasEffect(actor, "unique:starladle") && !actor.bonuses.starladleUsed) {
			actor.charge = Math.min(100, actor.charge + 25);
			actor.bonuses.starladleUsed = 1;
		}
		if (hasEffect(actor, "unique:silkspool") && !actor.bonuses.silkspoolUsed) {
			applyStatus(b, actor, actor, "decoy");
			actor.bonuses.silkspoolUsed = 1;
		}
	}
	if (skill.id === "defend" && !b.v4) actor.charge = Math.min(100, actor.charge + boonValue(b, "defendCharge"));
	if (skill.id === "wait") heal(b, actor, actor, boonValue(b, "waitHeal"));
	if (skill.charge && !b.v4) b.energy = Math.min(10, b.energy + boonValue(b, "ultimateEnergy"));
	if (b.v4 && skill.id === "defend") heal(b, actor, actor, boonValue(b, "defendHeal"));
	if (b.v4 && skill.type === "ultimate") shield(b, actor, actor, boonValue(b, "ultimateShield"));
	if (b.v4) {
		if (skill.effects.some((e) => [
			"hit",
			"chain",
			"execute"
		].includes(e.kind))) actor.bonuses.attackCount = (actor.bonuses.attackCount ?? 0) + 1;
		if (skill.type === "ultimate") {
			heal(b, actor, actor, actor.bonuses.ultimateCharge ?? 0);
			if (!actor.bonuses.uniqueUltimateUsed) {
				actor.bonuses.uniqueUltimateUsed = 1;
				if (hasEffect(actor, "unique:silkspool")) gearGrant(b, actor, actor, "unique:silkspool", "shield", 12);
				if (hasEffect(actor, "unique:starladle")) gearGrant(b, actor, actor, "unique:starladle", "heal", 12);
				if (actor.bonuses.pantryTreat) {
					heal(b, actor, actor, 12);
					actor.bonuses.pantryTreat = 0;
				}
			}
		}
	}
	triggerPairCombosA6(b, actor, {
		damage,
		apply: applyStatus,
		shield,
		heal
	});
	record$1(b, actor, target, "action", 0, description, skill.id);
	finishAction(b, actor);
	return true;
}
function spawnThread(b, source, limit = 2) {
	if (living(b, "enemy").filter((a) => a.catalogId === "binding-thread").length >= limit) return;
	const actor = enemyActor("binding-thread", b.actors.length, b.chapter, false, b.initial.enemyStats);
	if (b.v4) actor.linkedBossId = ENEMY_BY_ID[source.catalogId]?.tier === "boss" ? source.id : source.linkedBossId;
	b.actors.push(actor);
	record$1(b, source, actor, "summon", 0, "Binding Thread joins next round");
}
function enemyAct(b) {
	const actor = currentActor(b);
	if (!actor || actor.side !== "enemy" || b.result) return false;
	if (b.initial.skillsV5) b.procRounds.v5ActionSequence = (b.procRounds.v5ActionSequence ?? 0) + 1;
	if (b.initial.skillsV5 && !beforeActionV5(b, actor, statusRuntimeV5)) {
		record$1(b, actor, actor, "enemy-action", 0, "Bleed prevented the action");
		finishAction(b, actor);
		return true;
	}
	const dazed = b.initial.skillsV5 && consumeDazeV5(b, actor, statusRuntimeV5);
	const intent = b.intents.find((i) => i.actorId === actor.id);
	const spec = ENEMY_BY_ID[actor.catalogId];
	const party = living(b, "party");
	const shelter = party.find((a) => stacks(a, "shelter") && (!b.initial.formationC2 || a.row === "front" || !party.some((p) => p.row === "front")));
	const front = party.filter((a) => a.row === "front");
	const reachable = b.v4 && front.length && (spec.mechanic !== "steal" || b.initial.formationC2 && !intent.signature) ? front : party;
	const target = shelter ?? reachable.find((a) => a.id === intent.targetId) ?? weakest(reachable);
	if (!target) {
		checkResult(b);
		return false;
	}
	shield(b, actor, actor, stacks(actor, "glaze") * 20);
	const impaired = intent.interrupted || stacks(actor, "drowsy") > 0 || !!dazed;
	const quiet = stacks(actor, "hush") > 0;
	const rageReady = !!b.initial.gameplayA6 && actor.charge >= 100 && !impaired && !quiet;
	if (rageReady) {
		actor.charge = 0;
		intent.power = 175;
		emitGameplayEvent(b, {
			kind: "ultimate.cast",
			actorId: actor.id,
			skillId: actor.catalogId,
			displayName: spec.intent,
			text: `${actor.name} · ${spec.intent}`
		});
	}
	const signature = (intent.signature || rageReady) && !impaired;
	if (rageReady) intent.signature = true;
	const creditSuppression = () => {
		record$1(b, actor, actor, "suppressed", 1, impaired ? "Control softened enemy action" : "Hush stopped enemy utility");
		const controller = b.actors.find((a) => a.id === actor.statuses.find((s) => s.id === (impaired ? "drowsy" : "hush"))?.source);
		if (controller?.bonuses.crewSuppress && !controller.bonuses.crewSuppressed) {
			controller.bonuses.crewSuppressed = 1;
			heal(b, controller, controller, controller.bonuses.crewSuppress);
		}
	};
	if (b.v4 && impaired && !b.initial.skillsV5) creditSuppression();
	if (impaired) {
		if (b.initial.skillsV5 && actor.catalogId === "spool-ram") actor.bonuses.v5Charge = 0;
		damage(b, actor, target, b.initial.skillsV5 ? spec.tier === "boss" ? 100 : 50 : 40, 0, b.v4 && spec.mechanic !== "steal");
	} else if (b.initial.skillsV5 && enemyActionV5(b, actor, intent, target, {
		damage,
		apply: applyStatus,
		shield,
		heal,
		roll,
		record: record$1
	})) {} else if (b.v4 && signature && quiet && ["heal", "shield"].includes(spec.mechanic)) creditSuppression();
	else if (spec.mechanic === "heal" && !quiet && (!b.v4 || signature)) heal(b, actor, weakest(living(b, "enemy")), 65);
	else if (spec.mechanic === "shield" && !quiet && (!b.v4 || signature)) for (const a of living(b, "enemy").filter((a) => a.row === actor.row)) shield(b, actor, a, 45);
	else {
		let affected = [target];
		if (signature && [
			"charge",
			"bind",
			"storm",
			"banquet",
			"dot"
		].includes(spec.mechanic)) affected = party.filter((a) => actor.phase === 2 || a.row === (spec.mechanic === "dot" ? "rear" : "front"));
		if (!affected.length) affected = [target];
		for (const t of affected) {
			if (signature && spec.mechanic === "storm") t.shield = 0;
			const wide = signature && [
				"charge",
				"bind",
				"storm",
				"banquet",
				"dot"
			].includes(spec.mechanic);
			const landing = b.initial.gameplayA6 && wide ? spec.mechanic === "storm" ? .65 : spec.mechanic === "banquet" ? .9 : 1 : 1;
			damage(b, actor, t, (signature ? intent.power : 100) * landing, 0, !!b.v4 && !wide && spec.mechanic !== "steal");
			if (spec.status && (signature || [
				"dot",
				"snare",
				"bomb"
			].includes(spec.mechanic))) applyStatus(b, actor, t, spec.status);
			if (signature && spec.mechanic === "bomb") {
				loseHp(b, actor, t, stacks(t, "crumb") * 35, "detonate");
				t.statuses = t.statuses.filter((s) => s.id !== "crumb");
			}
		}
		if (spec.mechanic === "steal" || signature && spec.mechanic === "banquet") {
			if (b.v4) {
				const removed = Math.min(6, target.shield);
				target.shield -= removed;
				record$1(b, actor, target, "strip-shield", removed);
			} else b.energy = Math.max(0, b.energy - 1);
		}
		if ((!b.v4 || actor.hp > 0) && signature && (spec.mechanic === "summon" || spec.mechanic === "banquet" && actor.phase === 2 || spec.mechanic === "bind")) {
			if (!quiet) spawnThread(b, actor);
			else if (b.v4 && living(b, "enemy").filter((a) => a.catalogId === "binding-thread").length < 2) creditSuppression();
		}
		if (spec.mechanic === "reflect" && actor.turns === 0) {
			shield(b, actor, actor, 70);
			applyStatus(b, actor, actor, "cozy");
		}
	}
	record$1(b, actor, target, "enemy-action", 0, impaired ? b.v4 ? "Drowsy intent · softened basic" : "Broken intent · softened basic" : intent.label, b.initial.gameplayA6 ? `enemy:${actor.catalogId}${signature ? "" : ":basic"}` : "");
	actor.break = 0;
	finishAction(b, actor);
	return true;
}
function replayBattle(setup, choices) {
	const b = createBattle(setup);
	for (const choice of choices) {
		while (!b.result && currentActor(b)?.side === "enemy") enemyAct(b);
		if (!act(b, choice)) throw Error("Replay contains an illegal action");
	}
	while (!b.result && currentActor(b)?.side === "enemy") enemyAct(b);
	return b;
}
// packages/game-rules/src/cardrpg/depth/formation-c2.ts
/** C2 is recorded on each encounter; an old committed replay retains its rules. */
var FORMATION_C2 = {
	partySize: 4,
	rowCapacity: 2,
	starterFourth: "panko",
	rearCoverMultiplier: .9,
	rowMultiplier: .6,
	areaMultiplier: .6,
	splashMultiplier: .4
};
var partySize = (state) => state.formationC2 ? FORMATION_C2.partySize : 3;
function validRowsC2(team, rows, hp) {
	return team.length === 4 && new Set(team).size === 4 && team.every((id) => rows[id] === "front" || rows[id] === "rear") && team.filter((id) => rows[id] === "front").length === 2 && team.some((id) => rows[id] === "front" && (hp?.[id] ?? 1) > 0);
}
/** Preserve legal choices; fill an overfull/empty row deterministically, without touching health. */
function balancedRowsC2(team, rows, hp) {
	const ordered = [...team].sort((a, b) => Number(rows[b] === "front") - Number(rows[a] === "front") || Number(CAT_BY_ID[b]?.role === "guardian") - Number(CAT_BY_ID[a]?.role === "guardian") || team.indexOf(a) - team.indexOf(b));
	const front = ordered.slice(0, 2);
	if (hp && !front.some((id) => (hp[id] ?? 1) > 0)) {
		const living = ordered.slice(2).find((id) => (hp[id] ?? 1) > 0);
		if (living) front[1] = living;
	}
	return Object.fromEntries(team.map((id) => [id, front.includes(id) ? "front" : "rear"]));
}
function formationSeatsC2(team, rows) {
	return [
		0,
		1,
		2,
		3
	].map((slot) => team.filter((id) => rows[id] === (slot < 2 ? "front" : "rear"))[slot % 2]);
}
/** Moving to an occupied seat swaps both cats, so the two-per-row invariant always holds. */
function placeInSlotC2(team, rows, catId, slot) {
	const seats = formationSeatsC2(team, rows), from = seats.indexOf(catId);
	if (from < 0 || !Number.isInteger(slot) || slot < 0 || slot > 3) return null;
	[seats[from], seats[slot]] = [seats[slot], seats[from]];
	if (seats.some((id) => !id)) return null;
	return {
		team: seats,
		rows: {
			...rows,
			...Object.fromEntries(seats.map((id, i) => [id, i < 2 ? "front" : "rear"]))
		}
	};
}
/** One-time migration. Never removes a collected cat, item, currency, or recorded battle. */
function setFormationC2(state) {
	if (state.formationC2) return state;
	const s = clone(state), before = [...s.team];
	for (const id of [
		"panko",
		"mochi",
		"soot",
		"clover"
	]) {
		if (s.account.cards.length >= 4) break;
		if (!s.account.cards.some((card) => card.cardId === id)) s.account.cards.push({
			id,
			cardId: id,
			level: 1,
			stars: 1,
			shards: 0,
			soulbound: true
		});
	}
	const power = (id) => powerScoreA6(depthStats(s, id));
	const strongest = (ids) => [...new Set(ids)].sort((a, b) => power(b) - power(a) || a.localeCompare(b));
	const normalize = (ids) => {
		const owned = ids.filter((id) => s.account.cards.some((card) => card.cardId === id));
		const kept = owned.length > 4 ? strongest(owned).slice(0, 4) : owned;
		return [...kept, ...strongest(s.account.cards.map((card) => card.cardId).filter((id) => !kept.includes(id)))].slice(0, 4);
	};
	s.team = normalize(s.team);
	s.rows = {
		...s.rows,
		...balancedRowsC2(s.team, s.rows, s.run && !s.run.complete ? s.run.hp : void 0)
	};
	for (const card of s.account.cards) {
		s.rows[card.cardId] ??= CAT_BY_ID[card.cardId].row;
		s.skills[card.cardId] ??= CAT_BY_ID[card.cardId].skills.slice(0, 3).map((skill) => skill.id);
	}
	for (const preset of s.v4?.loadouts ?? []) if (preset) {
		preset.team = normalize(preset.team);
		preset.rows = balancedRowsC2(preset.team, preset.rows);
		preset.equipment = Object.fromEntries(preset.team.map((id) => [id, preset.equipment[id] ?? clone(s.equipment[id] ?? {})]));
	}
	s.formationC2 = true;
	if (s.run && !s.run.complete) {
		s.run.formationC2 = true;
		s.run.gameplayA6 = true;
		s.run.skillsV5 = true;
		s.run.gameplayV4 = true;
		for (const id of s.team) s.run.hp[id] ??= depthStats(s, id).hp;
		const battle = s.run.battle;
		if (battle && !battle.v4?.committed && !battle.choices.length && battle.actors.every((a) => a.turns === 0)) {
			s.run.battle = createBattle({
				...battle.initial,
				formationC2: true,
				gameplayA6: true,
				skillsV5: true,
				gameplayV4: true,
				cats: battleCats(s),
				hp: clone(s.run.hp)
			});
			s.lastBattle = clone(s.run.battle.initial);
		}
	}
	s.formationNoticeC2 = before.length > 4 ? "bench" : "four";
	return s;
}
// packages/game-rules/src/cardrpg/depth/skills-v5/policy.ts
var count = (a, id) => a.statuses.find((s) => s.id === id)?.stacks ?? 0;
/** Expected near-term status value, summed for every target by the existing evaluator. */
function actorValueV5(b, a) {
	if (a.hp <= 0) return a.side === "party" ? -300 : -35;
	const foes = b.actors.filter((x) => x.side !== a.side && x.hp > 0), allies = b.actors.filter((x) => x.side === a.side && x.hp > 0);
	const threat = foes.reduce((n, x) => n + x.attack, 0) * 80 / (80 + a.defense);
	const due = foes.reduce((n, foe) => {
		const intent = b.intents.find((i) => i.actorId === foe.id);
		if (!intent || b.acted.includes(foe.id)) return n;
		return n + (intent.targetId === a.id || count(a, "shelter") > 0 ? foe.attack * (intent.power ?? 100) / 100 * 80 / (80 + a.defense) : 0);
	}, 0);
	const hp = a.hp + (a.hp / a.maxHp < .3 ? -65 : 0), shield = Math.min(a.shield, a.maxHp * .35) * .45;
	const bitter = count(a, "bitter") > 0, regen = 18 * count(a, "steep") * (bitter ? .5 : 1);
	const buffs = Math.min(a.maxHp - a.hp + threat * .4, regen * 2) + count(a, "cozy") * threat * .08 + count(a, "decoy") * Math.max(25, due * .85) + count(a, "sprout") * 30 + count(a, "glaze") * 9 + count(a, "riposte") * (a.row === "front" ? 14 : 5);
	const protector = a.statuses.find((s) => s.id === "link"), guard = protector && allies.find((x) => x.id === protector.source && x.id !== a.id);
	const share = guard && b.initial.formationC2 ? linkShareBps(b, guard, protector) / 1e4 : .3;
	const cover = guard ? Math.min(due * share, Math.max(0, guard.hp - guard.maxHp * .4) + guard.shield) * Math.max(0, 1 - a.hp / a.maxHp) : 0;
	const healer = allies.some((x) => [
		"clover",
		"sorrel",
		"cinnamon",
		"marigold",
		"teacup-healer"
	].includes(x.catalogId));
	const intent = b.intents.find((i) => i.actorId === a.id), boss = ENEMY_BY_ID[a.catalogId]?.tier === "boss";
	const debuffs = count(a, "scald") * 24 + Math.max(0, count(a, "snag") * 16 - a.shield * .3) + count(a, "crumb") * 18 + count(a, "scent") * (threat * .2 * Math.min(2, a.statuses.find((s) => s.id === "scent")?.remaining ?? 0) + (allies.length > 1 ? Math.min(45, count(a, "scald") * 12 + count(a, "snag") * 8 + count(a, "brittle") * 10) * (a.hp < threat * 2 ? 1 : .25) : 0)) + count(a, "brittle") * (threat * .04 + Math.min(15, a.shield)) + (bitter ? healer ? 32 : 8 : 0) + (count(a, "drowsy") ? !boss || intent?.signature ? a.attack * .55 : 0 : 0);
	return hp + shield + buffs + cover - debuffs;
}
function actionBonusV5(before, after, choice) {
	let score = after.log.filter((e) => e.kind === "reaction").length * 12;
	for (const old of before.actors) {
		const next = after.actors.find((a) => a.id === old.id);
		if (!next) continue;
		if (old.side === "party") score += Math.max(0, old.statuses.filter((s) => [
			"scald",
			"snag",
			"bitter",
			"drowsy"
		].includes(s.id)).length - next.statuses.filter((s) => [
			"scald",
			"snag",
			"bitter",
			"drowsy"
		].includes(s.id)).length) * 6;
		else if (before.intents.some((i) => i.actorId === old.id && i.signature) && !count(old, "drowsy") && count(next, "drowsy")) score += 15;
	}
	const actor = before.actors.find((a) => a.id === choice.actorId);
	if (choice.skillId.endsWith("-4") && actor && !before.choices.some((c) => c.actorId === actor.id && c.skillId === choice.skillId)) score += 8;
	return score;
}
// packages/game-rules/src/cardrpg/depth/policies.ts
function previewCopy(b) {
	return {
		...b,
		...b.v4 ? { v4: {
			...b.v4,
			plan: { ...b.v4.plan },
			events: []
		} } : {},
		procRounds: { ...b.procRounds },
		actors: b.v4 ? b.actors.map((a) => ({
			...a,
			statuses: a.statuses.map((s) => ({ ...s })),
			cooldowns: { ...a.cooldowns },
			skills: [...a.skills],
			equipment: [...a.equipment],
			setEffects: [...a.setEffects],
			bonuses: { ...a.bonuses }
		})) : clone(b.actors),
		queue: [...b.queue],
		acted: [...b.acted],
		intents: clone(b.intents),
		log: [],
		choices: []
	};
}
function actorValue(a) {
	if (a.hp <= 0) return a.side === "party" ? -300 : -35;
	const health = a.hp + (a.hp / a.maxHp < .3 ? -65 : 0);
	const beneficial = stacks(a, "steep") * 28 + stacks(a, "cozy") * 8 + stacks(a, "decoy") * 25 + stacks(a, "sprout") * 30;
	const harmful = stacks(a, "scald") * 27 + stacks(a, "crumb") * 13 + stacks(a, "rattled") * 14 + stacks(a, "hush") * 12;
	return health + Math.min(a.shield, a.maxHp * .35) * .45 + beneficial - harmful;
}
/** Bounded one-turn utility: value the prevention already present on an actor. */
function valueV4(b, a) {
	let n = actorValue(a);
	if (a.hp <= 0) return n;
	if (a.side === "party") {
		const exposed = a.row === "front" || !b.actors.some((x) => x.side === "party" && x.hp > 0 && x.row === "front");
		n += stacks(a, "glaze") * 9 + stacks(a, "riposte") * (exposed ? 14 : 5);
	} else {
		const intent = b.intents.find((i) => i.actorId === a.id);
		n -= stacks(a, "tangle") * a.attack * .04;
		if (intent?.signature && stacks(a, "drowsy")) n -= a.attack * .5;
		if (intent?.signature && stacks(a, "hush") && [
			"heal",
			"shield",
			"summon",
			"bind"
		].includes(ENEMY_BY_ID[a.catalogId]?.mechanic ?? "")) n -= 24;
	}
	return n;
}
function value(b) {
	const party = b.actors.filter((a) => a.side === "party").reduce((n, a) => n + (b.initial.skillsV5 ? actorValueV5(b, a) : b.v4 ? valueV4(b, a) : actorValue(a)), 0);
	if (b.result) return b.result === "party" ? 1e5 + party * 2 - b.round * 40 - b.choices.length * 3 : -1e5;
	const foes = b.actors.filter((a) => a.side === "enemy").reduce((n, a) => n + (b.initial.skillsV5 ? actorValueV5(b, a) : b.v4 ? valueV4(b, a) : actorValue(a)) * (a.catalogId === "binding-thread" ? .2 : 1), 0);
	const pressure = b.actors.filter((a) => a.side === "enemy" && a.hp > 0).reduce((n, a) => {
		const intent = b.intents.find((i) => i.actorId === a.id);
		return n + a.break * (intent?.signature ? 12 : 5) + (intent?.interrupted ? 35 : 0);
	}, 0);
	return b.v4 ? party - foes * 1.1 : party - foes * 1.1 + pressure + b.energy * 3;
}
/** One-action lookahead keeps playback cheap and makes every decision reproducible. */
function automatic(b) {
	const choices = legalChoices(b);
	const charged = b.initial.gameplayA6 ? choices.filter((choice) => skillById(choice.skillId, true)?.type === "ultimate") : [];
	const scored = (charged.length ? charged : choices).map((choice) => {
		const preview = previewCopy(b);
		act(preview, choice);
		let score = value(preview) + planPreference(b, choice) + (b.initial.skillsV5 ? actionBonusV5(b, preview, choice) : 0);
		for (const actor of b.actors) {
			const after = preview.actors.find((candidate) => candidate.id === actor.id);
			if (actor.side === "enemy" && actor.hp > 0 && after.hp === 0) score += 200;
			if (actor.side === "party" && actor.hp > 0 && actor.hp < actor.maxHp * .5) score += Math.max(0, after.hp - actor.hp) * (1 - actor.hp / actor.maxHp) * 2;
		}
		return {
			choice,
			score
		};
	});
	scored.sort((a, c) => c.score - a.score || a.choice.skillId.localeCompare(c.choice.skillId) || a.choice.targetId.localeCompare(c.choice.targetId));
	return scored[0].choice;
}
function ordinary(b, policy) {
	if (policy === "auto" || b.initial.skillsV5) return automatic(b);
	const choices = legalChoices(b);
	return [...choices.filter((c) => skillById(c.skillId).effects.some((e) => [
		"hit",
		"execute",
		"chain"
	].includes(e.kind)))].sort((a, c) => {
		const power = (choice) => skillById(choice.skillId).effects.reduce((n, e) => n + ([
			"hit",
			"chain",
			"execute"
		].includes(e.kind) ? e.power ?? 0 : 0), 0);
		return power(c) - power(a);
	})[0] ?? choices[0];
}
function chooseAction(b, policy) {
	const choices = legalChoices(b);
	if (!choices.length) throw Error("No legal party action");
	if (policy === "random") return choices[new Rng(deriveSeed(b.seed, b.choices.length + 700)).int(0, choices.length - 1)];
	if (policy === "auto" || policy === "greedy") return ordinary(b, policy);
	const scored = choices.map((choice) => {
		const preview = previewCopy(b), round = preview.round;
		act(preview, choice);
		let steps = 0;
		while (!preview.result && preview.round < round + 2 && steps++ < 32) if (currentActor(preview)?.side === "enemy") enemyAct(preview);
		else act(preview, ordinary(preview, "greedy"));
		return {
			choice,
			score: value(preview) + (b.initial.skillsV5 ? actionBonusV5(b, preview, choice) : 0)
		};
	});
	scored.sort((a, c) => c.score - a.score || a.choice.skillId.localeCompare(c.choice.skillId) || a.choice.targetId.localeCompare(c.choice.targetId));
	return scored[0].choice;
}
function playBattle(b, policy, maxActions = 900) {
	for (let i = 0; i < maxActions && !b.result; i++) if (currentActor(b)?.side === "enemy") {
		if (!enemyAct(b)) throw Error("Enemy turn stalled");
	} else if (!act(b, chooseAction(b, policy))) throw Error("Policy selected an illegal action");
	if (!b.result) throw Error("Battle exceeded its action bound");
	return b;
}
// packages/game-rules/src/cardrpg/depth/balance-c2.ts
/** B4 round four, pass 5 (user reopened tuning on 12 Nov). Authored chapter budgets, independent of player
* stats, inventory, win history or elapsed time. See reports/cardrpg-c2/BALANCE.md.
* New encounters freeze these numbers in enemyStats; replays never retune. */
var BALANCE_C2 = { campaign: {
	ordinary: {
		hp: [
			3.2,
			3.7,
			1
		],
		attack: [
			1.1,
			.95,
			2.65
		]
	},
	boss: {
		hp: [
			2.2,
			1.7,
			1.35
		],
		attack: [
			.7,
			.7,
			1.8
		]
	}
} };
// packages/game-rules/src/cardrpg/depth/onboarding-a6.ts
function campaignPressureA6(chapter, kind, depth) {
	return kind === "boss" ? chapter === 3 ? 1.51 : chapter === 2 ? 1.18 : 1.08 : kind === "elite" ? 1.52 : depth < 4 ? 1.36 : 1.52;
}
/** Early campaign bands teach the route with a gradual pressure ramp, including replays. */
function patrolPressureA6(state) {
	const run = state.run;
	if (!run?.gameplayA6 || run.mode !== "campaign") return 1;
	const node = run.nodes.find((n) => n.id === run.current);
	return campaignPressureA6(run.chapter, node?.kind ?? "battle", node?.depth ?? 0);
}
/** Shared Night Patrol defaults. Unfinished first clears keep their starting band. */
function patrolDefaultsA6(state) {
	const active = !!state.run && !state.run.complete;
	const ceiling = Math.min(...state.team.map((id) => state.account.cards.find((c) => c.cardId === id).level));
	const unlocked = [
		1,
		2,
		3
	].filter((chapter) => chapter === 1 || state.cleared.includes(chapter - 1));
	const next = unlocked.find((chapter) => !state.cleared.includes(chapter));
	const pending = Object.values(state.v4?.journey?.stars ?? {}).filter((r) => r.conditions.some((c) => !c) && r.band >= 1 && r.band <= ceiling && unlocked.includes(r.chapter));
	const first = next ? (state.run?.chapter === next ? state.run.challengeLevel : void 0) ?? 1 : void 0;
	const band = active ? state.run.challengeLevel ?? ceiling : Math.min(first ?? pending[0]?.band ?? ceiling, ceiling);
	const replay = !next ? pending.find((r) => r.band === band) : void 0;
	return {
		active,
		ceiling,
		band,
		chapter: active ? state.run.chapter : next ?? replay?.chapter ?? 3
	};
}
function introductionA6(state) {
	const trained = state.account.cards.some((card) => card.level > 1);
	const guide = state.tutorial < 3 ? "patrol" : !state.freeInvite ? "recruit" : !trained ? "upgrade" : null;
	const features = [
		{
			id: "team",
			name: "Team formation",
			hint: "Choose who stands in front.",
			open: state.tutorial >= 3
		},
		{
			id: "gear",
			name: "Cat gear",
			hint: "A good keepsake makes a stronger crew.",
			open: state.freeInvite
		},
		{
			id: "bonds",
			name: "Bond Book",
			hint: "Friends bring out each other’s best.",
			open: state.freeInvite && state.account.cards.length >= 4
		},
		{
			id: "daily",
			name: "Cafe gifts",
			hint: "Small goals, a gift every day.",
			open: trained
		},
		{
			id: "tower",
			name: "Yarn Tower",
			hint: "Thirty floors above the lanterns.",
			open: state.cleared.includes(1)
		},
		{
			id: "relic",
			name: "Relic Fuji",
			hint: "One keepsake supports your whole crew.",
			open: state.cleared.includes(2)
		}
	];
	return {
		guide,
		goal: guide === "patrol" ? "Meet your crew on a short first patrol." : guide === "recruit" ? "A free friend is waiting at Recruit." : guide === "upgrade" ? "Give one cat its first level." : !state.cleared.includes(1) ? "Clear Tangled Cafe to open Yarn Tower." : !state.cleared.includes(2) ? "Reach the rooftops and discover Relic Fuji." : "Collect three stars or climb the next tower floor.",
		features
	};
}
var TOWER_CHESTS_A6 = [
	5,
	10,
	15,
	20,
	25,
	30
];
var formations = [
	[
		["button-guard", "needle-moth"],
		["sock-skipper", "teacup-healer"],
		["spool-ram", "needle-moth"],
		["kettle-knight", "sock-skipper"]
	],
	[
		["pollen-scout", "needle-moth"],
		["kettle-knight", "teacup-healer"],
		["spool-ram", "button-guard"],
		["needle-moth", "sock-skipper"]
	],
	[
		["crumb-sentinel", "binding-thread"],
		["sock-skipper", "teacup-healer"],
		["kettle-knight", "pollen-scout"],
		["binding-thread", "needle-moth"]
	]
];
/** The same floor always has the same foes, level and seed, on every account. */
function towerFloorA6(floor) {
	requireRule(integer$1(floor, 1, 30), "INVALID_AMOUNT", "Choose a floor from one to thirty.");
	const chapter = floor <= 10 ? 1 : floor <= 20 ? 2 : 3;
	const boss = floor % 5 === 0;
	const enemies = boss ? [[
		"yarn-giant",
		"rain-spool",
		"pantry-crown"
	][chapter - 1]] : [...formations[chapter - 1][(floor - 1) % 4]];
	const level = 1 + Math.floor((floor - 1) / 3), seed = 670001 + floor * 97;
	const stats = challengeStatsV4(level);
	const scale = 1 + (floor - 1) * .025;
	return {
		floor,
		chapter,
		level,
		seed,
		boss,
		enemies,
		enemyStats: Object.fromEntries(Object.entries(stats).map(([id, s]) => {
			const active = enemies.includes(id);
			const formationBudget = chapter > 1 && (enemies.includes("kettle-knight") || enemies.includes("teacup-healer")) ? .72 : 1;
			const hp = !active ? s.hp : boss ? Math.min(s.hp * scale * .55, 450 + floor * 2) * (chapter === 2 ? 1.12 : 1) : Math.max(225 + floor * 2, Math.min(s.hp * scale, 250 + floor * 2)) * formationBudget;
			return [id, {
				hp: Math.max(1, Math.round(hp)),
				attack: Math.max(1, Math.round(s.attack * (1 + (floor - 1) * .015))),
				defense: active && !boss ? Math.min(s.defense, 25) : s.defense
			}];
		})),
		node: {
			id: "0-0",
			depth: 0,
			lane: 0,
			kind: boss ? "boss" : "battle",
			next: [],
			enemies
		}
	};
}
function startTowerFloorA6(state, floor = Math.min(30, state.towerBest + 1)) {
	return transactDepth(state, (s) => {
		requireHome(s);
		requireRule(gameplayA6(s), "NOT_READY", "Open A6 first.");
		requireRule(s.cleared.includes(1), "LOCKED", "Clear Tangled Cafe to open Yarn Tower.");
		const f = towerFloorA6(floor);
		requireRule(floor <= s.towerBest + 1, "LOCKED", "Clear the preceding floor first.");
		requireRule(!s.formationC2 || validRowsC2(s.team, s.rows), "INVALID_TEAM", "Place two cats in each row.");
		const cats = battleCats(s);
		s.run = {
			...s.formationC2 ? { formationC2: true } : {},
			id: s.nextRunId++,
			seed: f.seed,
			chapter: f.chapter,
			mode: "tower",
			floor,
			gameplayA6: true,
			skillsV5: true,
			gameplayV4: true,
			challengeLevel: f.level,
			towerA6: { enemyStats: clone(f.enemyStats) },
			nodes: [clone(f.node)],
			visited: [],
			current: null,
			points: 0,
			boons: {},
			upgrades: {},
			rewardChoices: [],
			hp: Object.fromEntries(cats.map((c) => [c.id, c.stats.hp])),
			battle: null,
			complete: false,
			won: false,
			mutator: "",
			supplies: 0,
			earnedItems: [],
			date: "2026-11-10"
		};
	});
}
function towerChestA6(s, floor) {
	requireRule(TOWER_CHESTS_A6.includes(floor), "UNKNOWN_ID", "Choose a Tower milestone.");
	const id = `a6-tower-chest-${floor}`, claimed = s.challengeClaims.includes(id);
	const requested = {
		stamps: 50 + floor * 2,
		threads: 10 + floor
	}, reward = cappedPreviewV4(s, requested);
	return {
		id,
		floor,
		claimed,
		requested,
		reward,
		reason: !gameplayA6(s) ? "Open A6 first." : s.run && !s.run.complete ? s.run.towerA6 ? "Finish this floor first." : "Finish your route first." : claimed ? "Already collected." : s.towerBest < floor ? `Clear floor ${floor}.` : !Object.values(reward).some((n) => n > 0) ? "Today’s supplies are full. This chest can wait." : null
	};
}
function claimTowerChestA6(state, floor) {
	return transactDepth(state, (s) => {
		requireHome(s);
		const p = towerChestA6(s, floor);
		requireRule(!p.reason, "NOT_READY", p.reason ?? "");
		grantDepth(s, p.reward);
		s.challengeClaims.push(p.id);
	});
}
// packages/game-rules/src/cardrpg/depth/run.ts
var CHAPTERS = [
	{
		id: 1,
		name: "Tangled Cafe",
		boss: "yarn-giant",
		palette: "#d8a76d",
		ambience: 174,
		pool: [
			"button-guard",
			"sock-skipper",
			"needle-moth",
			"teacup-healer"
		],
		elites: ["spool-ram", "kettle-knight"],
		reward: "A Yarnkeeper Seal and 80 mastery materials"
	},
	{
		id: 2,
		name: "Rooftop Orchard",
		boss: "rain-spool",
		palette: "#83b4a6",
		ambience: 220,
		pool: [
			"needle-moth",
			"teacup-healer",
			"button-guard",
			"sock-skipper"
		],
		elites: ["pollen-scout", "kettle-knight"],
		reward: "An Orchard Seal and 100 mastery materials"
	},
	{
		id: 3,
		name: "Midnight Pantry",
		boss: "pantry-crown",
		palette: "#a292c2",
		ambience: 146,
		pool: [
			"sock-skipper",
			"teacup-healer",
			"binding-thread",
			"needle-moth"
		],
		elites: ["crumb-sentinel", "pollen-scout"],
		reward: "A Pantry Seal, 120 mastery materials and Tower access"
	}
];
var EVENTS = [
	{
		id: "chipped-cup",
		name: "The chipped cup",
		story: "A little cup on the roof still remembers the cafe. Its handle could mend an apron, or hold one more warm drink.",
		choices: [
			{
				id: "mend",
				label: "Mend the handle",
				description: "Spend 25 run points. Gain a Shelter charm.",
				cost: 25,
				heal: 0,
				points: 0,
				boon: "shelter-3"
			},
			{
				id: "share",
				label: "Share a warm drink",
				description: "Heal every cat by 18% HP. Lose 10 run points.",
				cost: 10,
				heal: 18,
				points: 0,
				boon: ""
			},
			{
				id: "recycle",
				label: "Return it to the kiln",
				description: "Gain 35 run points. Every cat loses 8% current HP.",
				cost: 0,
				heal: -8,
				points: 35,
				boon: ""
			}
		]
	},
	{
		id: "lost-seed",
		name: "A seed in the gutter",
		story: "Clover finds a seed caught in a lantern. Keeping it warm will take the last clean cloth.",
		choices: [
			{
				id: "plant",
				label: "Wrap the seed",
				description: "Spend 20 run points. Gain a Garden charm.",
				cost: 20,
				heal: 0,
				points: 0,
				boon: "garden-5"
			},
			{
				id: "brew",
				label: "Brew its leaves",
				description: "Heal every cat by 25% HP. Give up the charm.",
				cost: 0,
				heal: 25,
				points: 0,
				boon: ""
			},
			{
				id: "sell",
				label: "Trade with the baker",
				description: "Gain 30 run points. Lose 10% current HP climbing down.",
				cost: 0,
				heal: -10,
				points: 30,
				boon: ""
			}
		]
	},
	{
		id: "quiet-bell",
		name: "A quiet bell",
		story: "A tiny bell rings only when everyone takes a breath together. The pantry door creaks nearby.",
		choices: [
			{
				id: "listen",
				label: "Listen together",
				description: "Spend 20 run points. Gain a Night charm.",
				cost: 20,
				heal: 0,
				points: 0,
				boon: "night-1"
			},
			{
				id: "polish",
				label: "Polish the bell",
				description: "Lose 12% current HP to sharp edges. Gain 45 run points.",
				cost: 0,
				heal: -12,
				points: 45,
				boon: ""
			},
			{
				id: "leave",
				label: "Leave a cup beside it",
				description: "Heal every cat by 10% HP.",
				cost: 0,
				heal: 10,
				points: 0,
				boon: ""
			}
		]
	}
];
var MUTATORS = [
	{
		id: "rainy",
		name: "Rainy evening",
		description: "Enemies begin with 20 shield."
	},
	{
		id: "thin-pot",
		name: "Small teapot",
		description: "Shared energy per round is 4."
	},
	{
		id: "warm-floor",
		name: "Warm floorboards",
		description: "Every front-row actor begins with one Cozy stack."
	},
	{
		id: "late-shift",
		name: "Late shift",
		description: "Enemies gain 10% attack. Cats gain 15 opening charge."
	}
];
function calendarChallenge(date) {
	requireRule(/^\d{4}-\d{2}-\d{2}$/.test(date), "INVALID_AMOUNT", "Use a calendar date in YYYY-MM-DD form.");
	const ms = Date.parse(date + "T00:00:00Z");
	requireRule(Number.isFinite(ms) && new Date(ms).toISOString().slice(0, 10) === date, "INVALID_AMOUNT", "Invalid calendar date.");
	const day = Math.floor(ms / 864e5), week = Math.floor((day + 3) / 7);
	return {
		seed: deriveSeed(43113, day),
		week,
		mutator: MUTATORS[(week % MUTATORS.length + MUTATORS.length) % MUTATORS.length]
	};
}
function generateMap(seed, chapter) {
	const spec = CHAPTERS[chapter - 1];
	if (!spec) throw Error("Unknown chapter");
	const rng = new Rng(seed);
	const nodes = [
		[
			0,
			0,
			"battle"
		],
		[
			1,
			0,
			"event"
		],
		[
			1,
			1,
			"elite"
		],
		[
			2,
			0,
			"treasure"
		],
		[
			3,
			0,
			"shop"
		],
		[
			4,
			0,
			"campfire"
		],
		[
			5,
			0,
			"battle"
		],
		[
			5,
			1,
			"elite"
		],
		[
			6,
			0,
			"boss"
		]
	].map(([depth, lane, kind]) => {
		const enemies = kind === "boss" ? [spec.boss] : kind === "elite" ? [spec.elites[rng.int(0, spec.elites.length - 1)], spec.pool[rng.int(0, spec.pool.length - 1)]] : kind === "battle" ? [spec.pool[rng.int(0, spec.pool.length - 1)], spec.pool[rng.int(0, spec.pool.length - 1)]] : [];
		return {
			id: `${depth}-${lane}`,
			depth,
			lane,
			kind,
			next: [],
			enemies,
			...kind === "event" ? { eventId: EVENTS[rng.int(0, EVENTS.length - 1)].id } : {}
		};
	});
	for (const node of nodes) node.next = nodes.filter((n) => n.depth === node.depth + 1).map((n) => n.id);
	return nodes;
}
function availableNodes(run) {
	if (run.complete || run.current || run.rewardChoices.length) return [];
	const last = run.nodes.find((n) => n.id === run.visited.at(-1));
	return run.nodes.filter((n) => last ? last.next.includes(n.id) : n.depth === 0);
}
/** Authored campaign pressure. No player stats/equipment or completion count enter this budget.
* Preserve the existing seven-stop route: early streets, late streets, then the guardian.
* Map, preparation and replay all consume this same frozen enemy snapshot. */
function campaignEnemyStatsA6(run, node) {
	const stats = challengeStatsV4(run.challengeLevel ?? 1);
	if (!run.gameplayA6 || run.mode !== "campaign" || !node.enemies.length) return stats;
	if (node.kind === "boss" && run.chapter > 1) {
		for (const id of node.enemies) if (ENEMY_BY_ID[id].tier === "boss") stats[id].hp = Math.round(stats[id].hp * 1.05);
	}
	const enemies = createBattle({
		seed: 1,
		chapter: run.chapter,
		cats: [],
		enemies: node.enemies,
		gameplayV4: true,
		skillsV5: true,
		gameplayA6: true,
		enemyStats: stats
	}).actors;
	const target = [
		7500,
		7900,
		8200
	][run.chapter - 1] * campaignPressureA6(run.chapter, node.kind, node.depth) * (1 + ((run.challengeLevel ?? 1) - 1) * .012);
	const attacks = enemies.reduce((n, actor) => n + actor.attack * 20, 0);
	const other = enemies.reduce((n, actor) => n + powerScoreA6(actor) - actor.attack * 20, 0);
	const multiplier = Math.max(.1, (target - other) / Math.max(1, attacks));
	for (const value of Object.values(stats)) value.attack = Math.max(1, Math.round(value.attack * multiplier));
	if (node.kind === "boss" && run.chapter > 1) {
		for (const id of node.enemies) if (ENEMY_BY_ID[id].tier === "boss") stats[id].attack = Math.max(1, Math.round(stats[id].attack * (run.chapter === 2 ? .78 : .9)));
	}
	if (run.formationC2) for (const [id, value] of Object.entries(stats)) {
		const budget = ENEMY_BY_ID[id]?.tier === "boss" ? BALANCE_C2.campaign.boss : BALANCE_C2.campaign.ordinary;
		value.hp = Math.max(1, Math.round(value.hp * budget.hp[run.chapter - 1]));
		value.attack = Math.max(1, Math.round(value.attack * budget.attack[run.chapter - 1]));
	}
	return stats;
}
function startRun(state, chapter, seed, mode = "campaign", date = "2026-11-06", challengeLevel) {
	if (state.gameplayA6 && mode === "tower") return startTowerFloorA6(state);
	return transactDepth(state, (s) => {
		requireHome(s);
		requireRule(integer$1(chapter, 1, 3) && integer$1(seed, 0, 4294967295), "INVALID_AMOUNT", "Invalid chapter or seed.");
		requireRule(chapter === 1 || s.cleared.includes(chapter - 1), "LOCKED", "Clear the preceding chapter first.");
		requireRule(mode !== "tower" || s.cleared.includes(3), "LOCKED", "Clear Midnight Pantry to open the Tower.");
		const defaultBand = s.gameplayA6 && mode === "campaign" ? patrolDefaultsA6(s).band : void 0;
		const challenge = calendarChallenge(date), actualSeed = mode === "daily" ? challenge.seed : seed;
		requireRule(!s.formationC2 || validRowsC2(s.team, s.rows), "INVALID_TEAM", "Place two cats in each row.");
		const cats = battleCats(s);
		s.run = {
			id: s.nextRunId++,
			seed: actualSeed,
			chapter,
			mode,
			nodes: generateMap(actualSeed, chapter),
			visited: [],
			current: null,
			points: 35,
			boons: {},
			hp: Object.fromEntries(cats.map((c) => [c.id, c.stats.hp])),
			upgrades: {},
			rewardChoices: [],
			battle: null,
			complete: false,
			won: false,
			floor: 1,
			mutator: mode === "campaign" ? "" : challenge.mutator.id,
			supplies: 1,
			earnedItems: [],
			date
		};
		if (s.formationC2) s.run.formationC2 = true;
		if (s.gameplayA6 && mode === "campaign") {
			for (const node of s.run.nodes) if (node.kind === "battle" && node.depth >= 4) node.enemies.push("binding-thread");
		}
		if (s.gameplayV4) {
			const ceiling = Math.min(...s.team.map((id) => s.account.cards.find((c) => c.cardId === id).level));
			const band = challengeLevel ?? defaultBand ?? ceiling;
			requireRule(integer$1(band, 1, ceiling), "LOCKED", "Choose a challenge band no higher than your lowest-level crew member.");
			s.run.gameplayV4 = true;
			s.run.challengeLevel = band;
			if (s.skillsV5) s.run.skillsV5 = true;
			if (s.gameplayA6) s.run.gameplayA6 = true;
		}
	});
}
function enterNode(state, id) {
	return transactDepth(state, (s) => {
		const run = s.run;
		requireRule(run, "NOT_READY", "Start a run first.");
		const node = availableNodes(run).find((n) => n.id === id);
		requireRule(node, "NOT_READY", "Choose a connected node on the map.");
		run.current = id;
		if (node.enemies.length) {
			const setup = {
				...run.formationC2 ? { formationC2: true } : {},
				...run.gameplayA6 ? { gameplayA6: true } : {},
				...run.skillsV5 ? { skillsV5: true } : {},
				seed: deriveSeed(run.seed, run.visited.length + run.floor * 100),
				chapter: run.chapter,
				cats: battleCats(s),
				enemies: node.enemies,
				hp: run.hp,
				boons: run.boons,
				upgrades: run.upgrades,
				mutator: run.mutator,
				...run.gameplayV4 ? {
					gameplayV4: true,
					...run.challengeLevel !== void 0 ? {
						challengeLevel: run.challengeLevel,
						enemyStats: clone(run.towerA6?.enemyStats ?? challengeStatsV4(run.challengeLevel))
					} : {},
					plan: clone(s.v4?.plan ?? DEFAULT_PLAN),
					...run.packedSupply ? { packedSupply: clone(run.packedSupply) } : {}
				} : {}
			};
			if (run.gameplayA6 && run.mode === "campaign") setup.enemyStats = campaignEnemyStatsA6(run, node);
			run.battle = createBattle(setup);
			s.lastBattle = clone(run.battle.initial);
			s.lastChoices = [];
		}
	});
}
/** Only the untouched preparation can be rebuilt; seed and carried HP never reroll. */
function configurePreparation(state, team, rows, plan) {
	return transactDepth(state, (s) => {
		const run = s.run, battle = run?.battle;
		requireRule(run && battle?.v4 && !run.complete && !battle.result && !battle.v4.committed && battle.choices.length === 0 && battle.actors.every((a) => a.turns === 0), "NOT_READY", "Preparation is locked after Fight.");
		requireRule(validPlan(plan), "INVALID_AMOUNT", "Choose a valid standing plan.");
		requireRule(team.length === partySize(s) && new Set(team).size === partySize(s) && team.every((id) => s.account.cards.some((c) => c.cardId === id)), "INVALID_TEAM", `Choose ${partySize(s)} collected companions.`);
		requireRule(team.every((id) => ["front", "rear"].includes(rows[id])) && team.some((id) => rows[id] === "front" && (run.hp[id] ?? 1) > 0), "INVALID_TEAM", "Keep at least one living companion in front.");
		requireRule(!s.formationC2 || validRowsC2(team, rows, run.hp), "INVALID_TEAM", "Two per row; keep a living cat in front.");
		requireRule(!(s.formationC2 ? team.some((id) => !s.team.includes(id)) : team.some((id, i) => id !== s.team[i])) || run.visited.length === 0 && (run.floor === 1 || !!run.towerA6), "NOT_READY", "The roster stays together after the first stop; change rows or plans here.");
		requireRule(!battle.initial.packedSupply || team.includes(battle.initial.packedSupply.catId), "INVALID_TEAM", "Keep the companion with the packed supply for this encounter.");
		s.team = [...team];
		s.rows = {
			...s.rows,
			...rows
		};
		for (const id of team) s.skills[id] ??= CAT_BY_ID[id].skills.slice(0, 3).map((skill) => skill.id);
		s.v4 ??= {
			version: 1,
			plan: { ...DEFAULT_PLAN }
		};
		s.v4.plan = { ...plan };
		const cats = battleCats(s);
		for (const cat of cats) run.hp[cat.id] = Math.min(run.hp[cat.id] ?? cat.stats.hp, cat.stats.hp);
		run.battle = createBattle({
			...battle.initial,
			...s.formationC2 ? { formationC2: true } : {},
			cats,
			hp: clone(run.hp),
			plan: { ...plan }
		});
		s.lastBattle = clone(run.battle.initial);
		s.lastChoices = [];
	});
}
function commitPreparation(state) {
	return transactDepth(state, (s) => {
		const battle = s.run?.battle;
		requireRule(battle?.v4 && !battle.result, "NOT_READY", "Open an automatic preparation first.");
		requireRule(!battle.initial.formationC2 || validRowsC2(battle.actors.filter((a) => a.side === "party").map((a) => a.id), Object.fromEntries(battle.actors.map((a) => [a.id, a.row])), Object.fromEntries(battle.actors.map((a) => [a.id, a.hp]))), "INVALID_TEAM", "Keep a living cat in front.");
		battle.v4.committed = true;
		delete s.run.packedSupply;
	});
}
function addBoon(run, id) {
	const boon = BOON_BY_ID[id];
	requireRule(boon, "UNKNOWN_ID", "Unknown charm.");
	requireRule((run.boons[id] ?? 0) < boon.cap, "MAX_LEVEL", "This charm is at its stacking cap.");
	run.boons[id] = (run.boons[id] ?? 0) + 1;
}
function finishNode(run) {
	requireRule(run.current, "NOT_READY", "Choose a node.");
	run.visited.push(run.current);
	run.current = null;
}
function rewardOptions(run, skillIds) {
	const rng = new Rng(deriveSeed(run.seed, run.visited.length + run.floor * 51));
	const pool = BOONS.filter((b) => (run.boons[b.id] ?? 0) < b.cap).map((b) => b.id), options = [];
	while (options.length < 2 && pool.length) options.push(pool.splice(rng.int(0, pool.length - 1), 1)[0]);
	const upgrade = skillIds.filter((id) => (run.upgrades[id] ?? 0) < 3);
	if (upgrade.length) options.push("skill:" + upgrade[rng.int(0, upgrade.length - 1)]);
	else if (pool.length) options.push(pool[rng.int(0, pool.length - 1)]);
	return options;
}
function settleRun(s, won) {
	const run = s.run;
	requireRule(!s.claimedRuns.includes(run.id), "ALREADY_CLAIMED", "Run already settled.");
	run.complete = true;
	run.won = won;
	s.claimedRuns.push(run.id);
	const challengeId = run.mode === "daily" ? `daily-${run.date}` : run.mode === "tower" ? run.towerA6 ? `a6-tower-floor-${run.floor}` : `tower-${run.date}` : "";
	const rewarded = (!run.towerA6 || won) && s.account.daily.battles < 6 && (!challengeId || !s.challengeClaims.includes(challengeId));
	if (rewarded) {
		if (run.gameplayV4 && s.v4?.journal) s.v4.journal.rewardedRoutes++;
		s.account.daily.battles++;
		progress(s.account, "battles");
		grantDepth(s, {
			fish: won ? 90 : 30,
			threads: won ? 18 : 6,
			stamps: won ? 40 : 10,
			essence: won ? 2 : 0
		}, won ? 60 : 20);
		const key = `depth-material-${s.account.day}`, earned = s.account.inventory.stacks[key] ?? 0, amount = Math.min(30 - earned, run.visited.length * 2 + (won ? 5 : 0));
		s.materials += Math.max(0, amount);
		s.account.inventory.stacks[key] = earned + Math.max(0, amount);
		if (challengeId) s.challengeClaims.push(challengeId);
	}
	if (won) {
		if (rewarded) {
			progress(s.account, "wins");
			if (!run.towerA6 || run.floor % 5 === 0) progress(s.account, "bossWins");
		}
		const sealKey = `depth-seal-${s.account.day}`;
		if (rewarded && !s.account.inventory.stacks[sealKey]) {
			s.seals++;
			s.account.inventory.stacks[sealKey] = 1;
		}
		if (run.mode === "campaign" && !s.cleared.includes(run.chapter)) {
			s.cleared.push(run.chapter);
			s.materials += 60 + run.chapter * 20;
			s.account.chapter = Math.max(s.account.chapter, run.chapter + 1);
			grantDepth(s, {
				fish: 120,
				stamps: 80,
				essence: 4
			});
		}
		if (!run.towerA6 && run.visited.filter((id) => run.nodes.find((n) => n.id === id)?.kind === "elite").length >= 2 && !s.masteries.includes(run.chapter)) s.masteries.push(run.chapter);
		if (run.mode === "tower") s.towerBest = Math.max(s.towerBest, run.floor);
	}
}
function finishEncounter(state) {
	return transactDepth(state, (s) => {
		const run = s.run, b = run?.battle;
		requireRule(run && b?.result, "NOT_READY", "Finish the encounter.");
		const node = run.nodes.find((n) => n.id === run.current);
		requireRule(node, "NOT_READY", "Encounter node missing.");
		if (!run.towerA6) recordNodeStarsV4(s, combatStarsV4(run, node, b));
		if (run.gameplayV4) delete run.packedSupply;
		run.hp = Object.fromEntries(b.actors.filter((a) => a.side === "party").map((a) => [a.catalogId, a.hp]));
		s.lastChoices = clone(b.choices);
		run.battle = null;
		if (b.result === "enemy") {
			settleRun(s, false);
			return;
		}
		if (!run.towerA6) run.points += node.kind === "elite" ? 65 : node.kind === "boss" ? 100 : 35;
		const dropKind = s.economyV3 ? run.towerA6 ? "tower" : node.kind === "boss" && !s.cleared.includes(run.chapter) ? "firstBoss" : node.kind : node.kind;
		const drop = s.economyV3 && run.towerA6 && run.floor % 10 !== 0 ? null : dropGear(s, dropKind, deriveSeed(run.seed, run.visited.length + 999), run.chapter);
		if (drop) run.earnedItems.push(drop);
		if (node.kind === "boss" || run.towerA6) {
			finishNode(run);
			settleRun(s, true);
			return;
		}
		run.rewardChoices = rewardOptions(run, s.team.flatMap((id) => defaultSkills(s, id)));
		if (!run.rewardChoices.length) finishNode(run);
	});
}
function chooseReward(state, id) {
	return transactDepth(state, (s) => {
		const run = s.run;
		requireRule(run && run.rewardChoices.includes(id), "NOT_READY", "Choose an offered reward.");
		if (id.startsWith("skill:")) {
			const skill = id.slice(6);
			requireRule((run.upgrades[skill] ?? 0) < 3, "MAX_LEVEL", "Skill upgrade capped.");
			run.upgrades[skill] = (run.upgrades[skill] ?? 0) + 1;
		} else addBoon(run, id);
		run.rewardChoices = [];
		finishNode(run);
	});
}
function resolveNode(state, choice, targetId) {
	return transactDepth(state, (s) => {
		const run = s.run;
		requireRule(run && !run.battle && !run.rewardChoices.length && !run.complete, "NOT_READY", "Resolve the current encounter first.");
		const node = run.nodes.find((n) => n.id === run.current);
		requireRule(node, "NOT_READY", "Enter a map node.");
		const cats = battleCats(s);
		const healTeam = (percent) => {
			for (const cat of cats) {
				const old = run.hp[cat.id] ?? cat.stats.hp;
				run.hp[cat.id] = percent >= 0 ? Math.min(cat.stats.hp, old + Math.round(cat.stats.hp * percent / 100)) : old === 0 ? 0 : Math.max(1, Math.round(old * (1 + percent / 100)));
			}
		};
		if (node.kind === "campfire") {
			if (choice === "heal") healTeam(35);
			else {
				requireRule(choice === "upgrade" && targetId && s.team.some((id) => defaultSkills(s, id).includes(targetId)) && (run.upgrades[targetId] ?? 0) < 3, "INVALID_AMOUNT", "Choose an unlocked skill below rank three.");
				run.upgrades[targetId] = (run.upgrades[targetId] ?? 0) + 1;
			}
		} else if (node.kind === "event") {
			const option = EVENTS.find((e) => e.id === node.eventId).choices.find((c) => c.id === choice);
			requireRule(option, "UNKNOWN_ID", "Choose a story option.");
			requireRule(run.points >= option.cost, "INSUFFICIENT_FUNDS", "Insufficient earned run points.");
			run.points += option.points - option.cost;
			healTeam(option.heal);
			if (option.boon) addBoon(run, option.boon);
		} else if (node.kind === "shop") {
			if (choice !== "leave") {
				requireRule(run.points >= 45, "INSUFFICIENT_FUNDS", "Need 45 earned run points.");
				if (choice === "tonic") {
					requireRule(!run.gameplayV4 || run.supplies < 5, "MAX_LEVEL", "Carry at most five packed tonics.");
					run.supplies++;
				} else {
					requireRule(shopStock(run).includes(choice), "UNKNOWN_ID", "Choose a charm from this shop.");
					addBoon(run, choice);
				}
				run.points -= 45;
			}
		} else if (node.kind === "treasure") {
			requireRule(["points", "charm"].includes(choice), "INVALID_AMOUNT", "Choose points or the offered charm.");
			if (choice === "points") run.points += 70;
			else addBoon(run, shopStock(run)[0]);
		} else requireRule(false, "NOT_READY", "This node requires a battle.");
		finishNode(run);
		recordNodeStarsV4(s, stopStarsV4(s, run, node, Object.fromEntries(cats.map((c) => [c.id, c.stats.hp]))));
	});
}
function shopStock(run) {
	const rng = new Rng(deriveSeed(run.seed, 500 + run.floor));
	const pool = BOONS.filter((b) => (run.boons[b.id] ?? 0) < b.cap).map((b) => b.id), stock = [];
	while (stock.length < 3 && pool.length) stock.push(pool.splice(rng.int(0, pool.length - 1), 1)[0]);
	return stock;
}
function useTonic(state) {
	return transactDepth(state, (s) => {
		const r = s.run;
		requireRule(r && !r.complete, "NOT_READY", "Start a route before using a route tonic.");
		requireRule(!r.battle, "NOT_READY", "Use route tonics between encounters, before opening Prepare.");
		requireRule(r.supplies > 0, "NOT_READY", "No route tonics remain. Buy one at a route tea cart.");
		const cats = battleCats(s);
		requireRule(cats.some((cat) => (r.hp[cat.id] ?? 0) < cat.stats.hp), "NOT_READY", "Every companion is already at full HP.");
		for (const cat of cats) r.hp[cat.id] = Math.min(cat.stats.hp, (r.hp[cat.id] ?? 0) + 100);
		r.supplies--;
	});
}
function abandonRun(state) {
	return transactDepth(state, (s) => {
		requireRule(s.run && !s.run.complete, "NOT_READY", "No active run.");
		if (s.run.packedSupply && !s.run.battle?.v4?.committed) {
			const old = s.run.packedSupply;
			s.account.inventory.stacks[old.id] = (s.account.inventory.stacks[old.id] ?? 0) + 1;
		}
		delete s.run.packedSupply;
		if (s.run.battle) s.lastChoices = clone(s.run.battle.choices);
		s.run.battle = null;
		s.run.rewardChoices = [];
		settleRun(s, false);
	});
}
function nextTowerFloor(state) {
	if (state.run?.towerA6) {
		const old = state.run;
		if (!old.complete || !old.won || old.floor >= 30) return {
			ok: false,
			state,
			error: old.floor >= 30 ? "All thirty floors are complete." : "Clear this floor first."
		};
		return startTowerFloorA6(state, old.floor + 1);
	}
	return transactDepth(state, (s) => {
		const old = s.run;
		requireRule(old?.mode === "tower" && old.complete && old.won, "NOT_READY", "Clear a Tower floor first.");
		const floor = old.floor + 1, seed = deriveSeed(old.seed, floor), chapter = (floor - 1) % 3 + 1;
		s.run = {
			...old,
			id: s.nextRunId++,
			seed,
			floor,
			chapter,
			nodes: generateMap(seed, chapter),
			visited: [],
			current: null,
			complete: false,
			won: false,
			battle: null,
			rewardChoices: [],
			mutator: MUTATORS[(floor - 1) % 4].id
		};
	});
}
// packages/game-rules/src/cardrpg/depth/save.ts
var legacyEnemyStats = {
	"button-guard": {
		hp: 210,
		attack: 48,
		defense: 25
	},
	"sock-skipper": {
		hp: 165,
		attack: 54,
		defense: 8
	},
	"spool-ram": {
		hp: 300,
		attack: 74,
		defense: 16
	},
	"needle-moth": {
		hp: 155,
		attack: 43,
		defense: 6
	},
	"teacup-healer": {
		hp: 180,
		attack: 35,
		defense: 10
	},
	"kettle-knight": {
		hp: 340,
		attack: 62,
		defense: 35
	},
	"yarn-giant": {
		hp: 820,
		attack: 80,
		defense: 22
	},
	"binding-thread": {
		hp: 90,
		attack: 25,
		defense: 0
	},
	"practice-cushion": {
		hp: 230,
		attack: 14,
		defense: 0
	},
	"pollen-scout": {
		hp: 270,
		attack: 54,
		defense: 10
	},
	"rain-spool": {
		hp: 1050,
		attack: 85,
		defense: 24
	},
	"crumb-sentinel": {
		hp: 360,
		attack: 68,
		defense: 22
	},
	"pantry-crown": {
		hp: 1220,
		attack: 92,
		defense: 25
	}
};
var SAVE_KEY = "taskbar-hero-cardrpg-depth-v1";
/** Detects accidental copy/paste corruption. Local saves are user-editable. */
function saveChecksum(text) {
	let hash = 2166136261;
	for (let index = 0; index < text.length; index++) {
		hash ^= text.charCodeAt(index);
		hash = Math.imul(hash, 16777619);
	}
	return (hash >>> 0).toString(16).padStart(8, "0");
}
function fail() {
	throw new Error("Save code has an unsupported or damaged structure.");
}
function record(value) {
	return value !== null && typeof value === "object" && !Array.isArray(value);
}
function safeTree(value, depth = 0) {
	if (depth > 35) fail();
	if (typeof value === "number" && (!Number.isFinite(value) || Math.abs(value) > Number.MAX_SAFE_INTEGER)) fail();
	if (!value || typeof value !== "object") return;
	if (Object.keys(value).length > 5e4) fail();
	for (const [key, child] of Object.entries(value)) {
		if ([
			"__proto__",
			"prototype",
			"constructor"
		].includes(key)) fail();
		safeTree(child, depth + 1);
	}
}
/** Required schema fields are checked recursively, including legacy account fields. */
function shape(value, example) {
	if (example === null) return;
	if (Array.isArray(example)) {
		if (!Array.isArray(value)) fail();
		if (example.length) for (const entry of value) shape(entry, example[0]);
	} else if (record(example)) {
		if (!record(value)) fail();
		for (const [key, child] of Object.entries(example)) shape(value[key], child);
	} else if (typeof value !== typeof example) fail();
}
function validateAccount(value) {
	shape(value, createStarterAccount());
	const account = value;
	if (account.version !== "0.4.0" || account.cards.length < 3 || account.cards.some((c) => !CAT_BY_ID[c.cardId] || !Number.isInteger(c.level) || c.level < 1 || c.level > 60 || !Number.isInteger(c.stars) || c.stars < 1 || c.stars > 5)) fail();
	if (Object.values(account.currencies).some((n) => !Number.isInteger(n) || n < 0)) fail();
}
function migrateAccount(legacy, now = 0) {
	validateAccount(legacy);
	const state = createDepthAccount(legacy.seed, now);
	state.account = clone(legacy);
	state.account.pendingRun = null;
	state.gear = [];
	state.equipment = {};
	state.team = legacy.teams.find((t) => t.id === legacy.activeTeamId).cardIds.map((id) => legacy.cards.find((c) => c.id === id).cardId);
	for (const card of legacy.cards) {
		state.rows[card.cardId] = CAT_BY_ID[card.cardId].row;
		state.skills[card.cardId] = CAT_BY_ID[card.cardId].skills.slice(0, 3).map((s) => s.id);
	}
	initializeEquipment(state);
	state.tutorial = 3;
	return state;
}
function validateSupply(value) {
	if (value === void 0) return;
	if (!record(value) || !SUPPLY_IDS_V4.includes(value.id) || value.id === "milk-tonic" || typeof value.catId !== "string" || !CAT_BY_ID[value.catId]) fail();
}
function validateEnemySnapshot(value) {
	if (!record(value) || !record(value.enemyStats)) fail();
	for (const id of Object.keys(ENEMY_BY_ID)) {
		const stats = value.enemyStats[id];
		if (!record(stats) || !Number.isInteger(stats.hp) || Number(stats.hp) <= 0 || !Number.isInteger(stats.attack) || Number(stats.attack) <= 0 || !Number.isInteger(stats.defense) || Number(stats.defense) < 0) fail();
	}
	if (value.challengeLevel !== void 0 && (!Number.isSafeInteger(value.challengeLevel) || Number(value.challengeLevel) < 1 || Number(value.challengeLevel) > 50)) fail();
	validateSupply(value.packedSupply);
	if (value.formationC2 !== void 0 && typeof value.formationC2 !== "boolean") fail();
	if (value.formationC2) {
		if (!value.gameplayA6 || !Array.isArray(value.cats) || value.cats.some((c) => !record(c))) fail();
		const cats = value.cats;
		if (!validRowsC2(cats.map((c) => c.id), Object.fromEntries(cats.map((c) => [c.id, c.row])))) fail();
	}
	if (value.gameplayA6 !== void 0 && (typeof value.gameplayA6 !== "boolean" || value.gameplayA6 && (!value.skillsV5 || !value.gameplayV4))) fail();
	if (value.skillsV5 !== void 0 && (typeof value.skillsV5 !== "boolean" || value.skillsV5 && !value.gameplayV4)) fail();
	if (value.gameplayV4 !== void 0 && typeof value.gameplayV4 !== "boolean") fail();
	if (value.gameplayV4 && !validPlan(value.plan)) fail();
}
function validateDepth(value, legacyFormation = false) {
	safeTree(value);
	const example = createDepthAccount();
	example.equipment = {};
	shape(value, example);
	const state = value;
	if (state.formationC2 !== void 0 && (typeof state.formationC2 !== "boolean" || state.formationC2 && !state.gameplayA6)) fail();
	if (state.formationNoticeC2 !== void 0 && !["four", "bench"].includes(state.formationNoticeC2)) fail();
	const validSize = (length) => legacyFormation && !state.formationC2 ? [
		3,
		4,
		5,
		6
	].includes(length) : length === partySize(state);
	const dailyA6 = state.dailyA6;
	if (dailyA6 !== void 0) {
		if (!record(dailyA6) || !Number.isSafeInteger(dailyA6.day) || dailyA6.day < 1 || dailyA6.day > state.account.day || !Number.isSafeInteger(dailyA6.week) || dailyA6.week !== Math.floor((dailyA6.day - 1) / 7) || !Number.isInteger(dailyA6.weeklyPoints) || dailyA6.weeklyPoints < 0 || dailyA6.weeklyPoints > 35 || !Number.isSafeInteger(dailyA6.loginDay) || dailyA6.loginDay < 0 || dailyA6.loginDay > state.account.day || !Number.isInteger(dailyA6.loginGifts) || dailyA6.loginGifts < 0 || dailyA6.loginGifts > 7) fail();
		for (const tasks of [dailyA6.completed, dailyA6.claimed]) if (!Array.isArray(tasks) || new Set(tasks).size !== tasks.length || tasks.some((t) => ![
			"patrol",
			"tips",
			"recruit",
			"train",
			"gear"
		].includes(t))) fail();
		if (dailyA6.claimed.some((t) => !dailyA6.completed.includes(t)) || !Array.isArray(dailyA6.weeklyClaims) || new Set(dailyA6.weeklyClaims).size !== dailyA6.weeklyClaims.length || dailyA6.weeklyClaims.some((n) => ![
			10,
			20,
			30
		].includes(n) || n > dailyA6.weeklyPoints)) fail();
	}
	const idleA6 = state.idle.a6;
	if (idleA6 !== void 0 && (!record(idleA6) || !Number.isSafeInteger(idleA6.fastDay) || idleA6.fastDay < 0 || !Number.isInteger(idleA6.fastClaims) || idleA6.fastClaims < 0 || idleA6.fastClaims > 2)) fail();
	if (state.gameplayA6 !== void 0 && (typeof state.gameplayA6 !== "boolean" || state.gameplayA6 && (!state.skillsV5 || !state.gameplayV4))) fail();
	if (state.skillsV5 !== void 0 && typeof state.skillsV5 !== "boolean") fail();
	if (state.gameplayV4 !== void 0 && typeof state.gameplayV4 !== "boolean") fail();
	if (state.gameplayV4 && !state.v4) fail();
	if (state.v4 && (state.v4.version !== 1 || !validPlan(state.v4.plan))) fail();
	if (state.v4?.loadouts !== void 0) {
		if (!Array.isArray(state.v4.loadouts) || state.v4.loadouts.length !== 3) fail();
		for (const preset of state.v4.loadouts) {
			if (preset === null) continue;
			if (!record(preset) || typeof preset.name !== "string" || !preset.name.trim() || preset.name.length > 40 || !Array.isArray(preset.team) || !validSize(preset.team.length) || new Set(preset.team).size !== preset.team.length || !record(preset.rows) || !record(preset.equipment) || !validPlan(preset.plan)) fail();
			if (preset.team.some((id) => !CAT_BY_ID[id] || !["front", "rear"].includes(preset.rows[id])) || !preset.team.some((id) => preset.rows[id] === "front")) fail();
			if (state.formationC2 && !validRowsC2(preset.team, preset.rows)) fail();
			const refs = /* @__PURE__ */ new Set();
			for (const [id, slots] of Object.entries(preset.equipment)) {
				if (!preset.team.includes(id) || !record(slots)) fail();
				for (const [slot, ref] of Object.entries(slots)) {
					if (!EQUIPMENT_SLOTS.includes(slot) || typeof ref !== "string" || !ref || refs.has(ref)) fail();
					refs.add(ref);
				}
			}
		}
	}
	if (state.v4) {
		const v = state.v4;
		for (const n of [
			v.selectorMarks,
			v.revealSequence,
			v.legacySealCount
		]) if (n !== void 0 && (!Number.isSafeInteger(n) || n < 0)) fail();
		if (v.legacySealCount !== void 0 && v.legacySealCount > 1e4) fail();
		if (v.spentEffortIds !== void 0 && (!Array.isArray(v.spentEffortIds) || v.spentEffortIds.length > 1e4 || new Set(v.spentEffortIds).size !== v.spentEffortIds.length || v.spentEffortIds.some((p) => typeof p !== "string" || p.length > 120))) fail();
		if (v.reveals !== void 0) {
			if (!Array.isArray(v.reveals) || v.reveals.length > 60 || v.revealSequence === void 0) fail();
			for (const [i, e] of v.reveals.entries()) if (e.version !== 1 || e.kind !== "earned-reveal" || e.sequence !== v.revealSequence - v.reveals.length + i || e.round !== 0 || !Number.isSafeInteger(e.draw) || e.draw < 1 || typeof e.itemId !== "string" || typeof e.text !== "string" || !Number.isSafeInteger(e.duplicate) || e.duplicate < 0 || !Number.isSafeInteger(e.pityBefore) || e.pityBefore < 0 || e.pityBefore > 59 || !Number.isSafeInteger(e.pityAfter) || e.pityAfter < 0 || e.pityAfter > 59) fail();
		}
		if (v.issuance) validateIssuance(v.issuance);
		validateJournalV4(state);
		validateJourneyV4(state);
		if (v.clockWatermark !== void 0 && (!Number.isSafeInteger(v.clockWatermark) || v.clockWatermark < 0)) fail();
		if (v.lessons !== void 0 && (!Array.isArray(v.lessons) || new Set(v.lessons).size !== v.lessons.length || v.lessons.some((id) => !LESSONS_V4.some((l) => l.id === id)))) fail();
	}
	validateAccount(state.account);
	if (state.version !== "0.7.0" || !validSize(state.team.length) || new Set(state.team).size !== state.team.length) fail();
	for (const id of state.team) {
		if (!state.account.cards.some((c) => c.cardId === id) || !["front", "rear"].includes(state.rows[id])) fail();
		const skills = state.skills[id];
		if (!Array.isArray(skills) || skills.length !== 3 || new Set(skills).size !== 3 || skills.some((s) => SKILLS[s]?.catId !== id)) fail();
	}
	if (!state.team.some((id) => state.rows[id] === "front")) fail();
	if (state.formationC2 && !validRowsC2(state.team, state.rows)) fail();
	if (new Set(state.gear.map((g) => g.id)).size !== state.gear.length) fail();
	for (const gear of state.gear) if (!GEAR_BY_ID[gear.templateId] || !Number.isInteger(gear.enhancement) || gear.enhancement < 0 || gear.blessingBp !== void 0 && (!Number.isInteger(gear.blessingBp) || gear.blessingBp < 0 || gear.blessingBp > 1e4) || gear.enhanceAttempts !== void 0 && (!Number.isSafeInteger(gear.enhanceAttempts) || gear.enhanceAttempts < 0 || gear.enhanceAttempts > 1e6) || gear.enhancement > 12 || ![
		1,
		2,
		3
	].includes(gear.tier) || !Array.isArray(gear.affixes) || !record(gear.rolls) || new Set(gear.affixes).size !== gear.affixes.length || gear.affixes.some((id) => !AFFIX_BY_ID[id]?.slots.includes(GEAR_BY_ID[gear.templateId].slot)) || Object.values(gear.rolls).some((n) => !Number.isSafeInteger(n) || n < 0)) fail();
	const equipped = /* @__PURE__ */ new Set();
	for (const [cardId, loadout] of Object.entries(state.equipment)) {
		if (!state.account.cards.some((card) => card.cardId === cardId) || !record(loadout)) fail();
		for (const [slot, instanceId] of Object.entries(loadout)) {
			if (!EQUIPMENT_SLOTS.includes(slot) || typeof instanceId !== "string" || equipped.has(instanceId)) fail();
			const item = state.gear.find((gear) => gear.id === instanceId);
			if (!item || GEAR_BY_ID[item.templateId].slot !== slot) fail();
			equipped.add(instanceId);
		}
	}
	if (state.run) {
		const run = state.run;
		if (run.challengeLevel !== void 0 && (!Number.isSafeInteger(run.challengeLevel) || run.challengeLevel < 1 || run.challengeLevel > 50)) fail();
		validateSupply(run.packedSupply);
		if (run.towerA6 !== void 0) {
			if (!record(run.towerA6) || !run.gameplayA6 || run.mode !== "tower" || !Number.isInteger(run.floor) || run.floor < 1 || run.floor > 30) fail();
			validateEnemySnapshot({ enemyStats: run.towerA6.enemyStats });
		}
		if (!record(run) || !Array.isArray(run.nodes) || !Array.isArray(run.visited) || !Array.isArray(run.rewardChoices) || !record(run.hp) || !record(run.boons) || !record(run.upgrades) || ![
			1,
			2,
			3
		].includes(run.chapter) || ![
			"campaign",
			"daily",
			"tower"
		].includes(run.mode) || typeof run.complete !== "boolean") fail();
		for (const node of run.nodes) if (!Array.isArray(node.next) || !Array.isArray(node.enemies) || typeof node.id !== "string") fail();
		if (run.battle && (!Array.isArray(run.battle.actors) || !Array.isArray(run.battle.queue) || !Array.isArray(run.battle.log) || !Array.isArray(run.battle.choices) || !record(run.battle.initial))) fail();
		if (run.gameplayA6 !== void 0 && (typeof run.gameplayA6 !== "boolean" || run.gameplayA6 && (!run.skillsV5 || !run.gameplayV4))) fail();
		if (run.skillsV5 !== void 0 && (typeof run.skillsV5 !== "boolean" || run.skillsV5 && !run.gameplayV4)) fail();
		if (run.gameplayV4 !== void 0 && typeof run.gameplayV4 !== "boolean") fail();
		if (run.battle?.initial.gameplayV4) {
			const v = run.battle.v4;
			if (!v || v.version !== 1 || !validPlan(v.plan) || typeof v.committed !== "boolean" || !Array.isArray(v.events)) fail();
			if (v.events.some((e, i) => !validBattleEventV5(e, i, !!run.battle?.initial.skillsV5))) fail();
		}
	}
	if (state.lastBattle) validateEnemySnapshot(state.lastBattle);
	if (state.run?.battle) validateEnemySnapshot(state.run.battle.initial);
	if (!(state.gameplayA6 || state.run?.gameplayA6 ? [
		1,
		2,
		3,
		4
	] : [
		1,
		2,
		4
	]).includes(state.settings.speed) || ![
		"low",
		"medium",
		"high"
	].includes(state.settings.quality)) fail();
}
function exportSave(state) {
	validateDepth(state);
	const payload = JSON.stringify(state);
	return `THC${state.formationC2 ? "16" : state.skillsV5 || state.run?.skillsV5 || state.lastBattle?.skillsV5 ? "15" : state.v4?.journey ? "13" : state.v4 ? "12" : "7"}.${saveChecksum(payload)}.${payload}`;
}
function migrateDepth(value) {
	if (!record(value) || !["0.5.0", "0.6.0"].includes(String(value.version))) fail();
	const next = clone(value);
	next.version = CONTRACT_VERSION;
	if (record(next.lastBattle)) next.lastBattle.enemyStats = clone(legacyEnemyStats);
	if (record(next.run) && record(next.run.battle)) {
		next.run.battle.version = CONTRACT_VERSION;
		if (record(next.run.battle.initial)) next.run.battle.initial.enemyStats = clone(legacyEnemyStats);
	}
	return next;
}
function importSave(code, now = 0, formationC2 = false) {
	const trimmed = code.trim();
	if (trimmed.length > 8e6) throw new Error("Save code exceeds the supported size.");
	if (trimmed.startsWith("{")) {
		const legacy = JSON.parse(trimmed);
		safeTree(legacy);
		validateAccount(legacy);
		const migrated = migrateAccount(legacy, now);
		return formationC2 ? setFormationC2(setGameplayA6(migrated, true)) : migrated;
	}
	const match = /^THC(5|6|7|8|9|10|11|12|13|14|15|16)\.([a-f0-9]{8})\.([\s\S]+)$/.exec(trimmed);
	if (!match || saveChecksum(match[3]) !== match[2]) throw new Error("Save checksum failed. Copy the complete code again.");
	const parsed = JSON.parse(match[3]);
	safeTree(parsed);
	const state = [
		"7",
		"8",
		"9",
		"10",
		"11",
		"12",
		"13",
		"14",
		"15",
		"16"
	].includes(match[1]) ? parsed : migrateDepth(parsed);
	validateDepth(state, formationC2);
	if (![
		"13",
		"14",
		"15",
		"16"
	].includes(match[1])) initializeJourneyV4(state);
	const migrated = formationC2 ? setFormationC2(setGameplayA6(state, true)) : state;
	validateDepth(migrated);
	return migrated;
}
// packages/game-rules/src/cardrpg/depth/loadouts-v4.ts
function saveLoadoutV4(state, slot, name) {
	return transactDepth(state, (s) => {
		requireHome(s);
		requireRule(gameplayV4(s) && s.v4, "NOT_READY", "Shift loadouts need Gameplay v4.");
		requireRule(integer$1(slot, 0, 2) && typeof name === "string" && name.trim().length > 0 && name.trim().length <= 40, "INVALID_AMOUNT", "Choose one of three shifts and a name of 1–40 characters.");
		const saved = {
			name: name.trim(),
			team: [...s.team],
			rows: Object.fromEntries(s.team.map((id) => [id, s.rows[id]])),
			plan: clone(s.v4.plan),
			equipment: Object.fromEntries(s.team.map((id) => [id, clone(s.equipment[id] ?? {})]))
		};
		s.v4.loadouts ??= [
			null,
			null,
			null
		];
		s.v4.loadouts[slot] = saved;
	});
}
function applyLoadoutV4(state, slot) {
	return transactDepth(state, (s) => {
		requireHome(s);
		requireRule(gameplayV4(s) && s.v4 && integer$1(slot, 0, 2), "NOT_READY", "Choose an available shift.");
		const saved = s.v4.loadouts?.[slot];
		requireRule(saved, "NOT_READY", "Save a shift here first.");
		requireRule(saved.team.length === partySize(s) && new Set(saved.team).size === partySize(s) && (!s.formationC2 || validRowsC2(saved.team, saved.rows)) && saved.team.every((id) => s.account.cards.some((c) => c.cardId === id) && ["front", "rear"].includes(saved.rows[id])) && saved.team.some((id) => saved.rows[id] === "front") && validPlan(saved.plan), "INVALID_TEAM", "This saved formation is not available.");
		const wanted = [];
		for (const id of saved.team) for (const [slot, instanceId] of Object.entries(saved.equipment[id] ?? {})) {
			const gear = s.gear.find((g) => g.id === instanceId);
			requireRule(EQUIPMENT_SLOTS.includes(slot) && gear && GEAR_BY_ID[gear.templateId].slot === slot && !wanted.includes(instanceId), "WRONG_SLOT", "A saved piece is missing, repeated, or in the wrong slot; nothing changed.");
			wanted.push(instanceId);
		}
		for (const slots of Object.values(s.equipment)) for (const slot of EQUIPMENT_SLOTS) if (wanted.includes(slots[slot] ?? "")) delete slots[slot];
		for (const id of saved.team) s.equipment[id] = clone(saved.equipment[id] ?? {});
		s.team = [...saved.team];
		s.rows = {
			...s.rows,
			...saved.rows
		};
		s.v4.plan = clone(saved.plan ?? DEFAULT_PLAN);
	});
}
function previewLoadoutV4(state, slot) {
	const applied = applyLoadoutV4(state, slot);
	if (!applied.ok) return {
		ok: false,
		error: applied.error,
		transfers: [],
		changes: [],
		before: teamPowerV4(state),
		after: null
	};
	const transfers = [], changes = [];
	for (const id of applied.state.team) {
		for (const piece of Object.values(applied.state.equipment[id] ?? {})) {
			const old = Object.entries(state.equipment).find(([, gear]) => Object.values(gear).includes(piece))?.[0];
			if (old && old !== id) transfers.push(`${piece}: ${old} → ${id}`);
		}
		const before = equipmentEffects(state, id).effects, after = equipmentEffects(applied.state, id).effects;
		for (const effect of after.filter((e) => !before.includes(e))) changes.push(`${id}: gains ${effect}`);
		for (const effect of before.filter((e) => !after.includes(e))) changes.push(`${id}: loses ${effect}`);
	}
	return {
		ok: true,
		error: "",
		transfers,
		changes,
		before: teamPowerV4(state),
		after: teamPowerV4(applied.state)
	};
}
// packages/game-rules/src/cardrpg/depth/outcome-v4.ts
var damageKinds$1 = /* @__PURE__ */ new Set([
	"damage",
	"dot",
	"detonate",
	"shared",
	"reflect",
	"reaction-damage"
]);
var planNames = {
	finish: "Weak foes",
	support: "Their support",
	leader: "Their leader"
};
var careNames = {
	steady: "Steady",
	protect: "Protect"
};
/** Observed effects, not a counterfactual claim that a single contribution caused victory. */
function outcomeV4(battle) {
	const party = battle.actors.filter((actor) => actor.side === "party");
	const partyIds = new Set(party.map((actor) => actor.id));
	const enemies = new Set(battle.actors.filter((actor) => actor.side === "enemy").map((actor) => actor.id));
	const name = (id) => battle.actors.find((actor) => actor.id === id)?.name ?? id;
	const causes = [];
	const totalDamage = battle.log.reduce((n, event) => n + (damageKinds$1.has(event.kind) && partyIds.has(event.actorId) && enemies.has(event.targetId) ? event.amount : 0), 0);
	const rows = Object.fromEntries(battle.initial.cats.map((cat) => [cat.id, cat.row]));
	const damageByRow = {
		front: 0,
		rear: 0
	};
	for (const event of battle.log) {
		if (damageKinds$1.has(event.kind) && partyIds.has(event.targetId)) damageByRow[rows[event.targetId]] += event.amount;
		if (event.kind === "action" && SKILLS[event.skillId]?.effects.some((effect) => effect.kind === "swap") && partyIds.has(event.actorId) && partyIds.has(event.targetId)) [rows[event.actorId], rows[event.targetId]] = [rows[event.targetId], rows[event.actorId]];
	}
	for (const actor of party) {
		const damage = battle.log.reduce((n, event) => n + (event.actorId === actor.id && enemies.has(event.targetId) && damageKinds$1.has(event.kind) ? event.amount : 0), 0);
		const healing = battle.log.reduce((n, event) => n + (event.actorId === actor.id && partyIds.has(event.targetId) && event.kind === "heal" ? event.amount : 0), 0);
		const absorbed = battle.log.reduce((n, event) => n + (event.targetId === actor.id && event.kind === "absorbed" ? event.amount : 0), 0);
		if (damage) causes.push({
			id: `damage:${actor.id}`,
			actorId: actor.id,
			kind: "damage",
			amount: damage,
			unit: "damage",
			text: `${actor.name} dealt ${damage} damage · ${Math.round(damage * 100 / totalDamage)}% of your total.`
		});
		if (healing) causes.push({
			id: `heal:${actor.id}`,
			actorId: actor.id,
			kind: "healing",
			amount: healing,
			unit: "HP",
			text: `${actor.name} restored ${healing} missing HP.`
		});
		if (absorbed) causes.push({
			id: `absorb:${actor.id}`,
			actorId: actor.id,
			kind: "absorption",
			amount: absorbed,
			unit: "damage",
			text: `${actor.name}’s shields absorbed ${absorbed} damage.`
		});
	}
	const gearGroups = /* @__PURE__ */ new Map();
	for (const event of battle.v4?.events ?? []) {
		if (event.kind !== "gear-trigger" || !event.actorId || !partyIds.has(event.actorId) || event.amount <= 0) continue;
		const unit = event.text.includes(" restored ") && event.text.includes(" HP to ") ? "HP" : event.text.includes(" granted ") && event.text.includes(" shield to ") ? "shield" : null;
		if (!unit) continue;
		const template = GEAR_BY_ID[event.templateId];
		if (!template) continue;
		const worn = battle.initial.cats.find((cat) => cat.id === event.actorId)?.equipment ?? [];
		const set = SETS.find((set) => set.id === template.setId);
		const count = worn.filter((id) => GEAR_BY_ID[id]?.setId === template.setId).length;
		const unique = event.effect.startsWith("unique:");
		const threshold = set?.twoEffect === event.effect ? 2 : set?.fourEffect === event.effect ? 4 : null;
		if (unique ? event.effect !== `unique:${template.unique}` || !worn.includes(template.id) : !threshold || count < threshold) continue;
		const key = `${event.actorId}:${unique ? template.id : template.setId}:${event.effect}:${unit}`;
		const amount = (gearGroups.get(key)?.amount ?? 0) + event.amount;
		const source = unique ? template.name : `${set.name} ${threshold}-piece`;
		gearGroups.set(key, {
			id: `gear:${key}`,
			kind: "gear",
			actorId: event.actorId,
			amount,
			unit,
			templateId: event.templateId,
			text: `${source} on ${name(event.actorId)} ${unit === "HP" ? "restored" : "granted"} ${amount} ${unit}.`
		});
	}
	const cover = (battle.v4?.events ?? []).filter((event) => event.kind === "formation-cover" && event.targetId && partyIds.has(event.targetId));
	for (const actor of party) {
		const amount = cover.reduce((n, event) => n + (event.kind === "formation-cover" && event.targetId === actor.id ? event.amount : 0), 0);
		if (amount) causes.push({
			id: `cover:${actor.id}`,
			actorId: actor.id,
			kind: "cover",
			amount,
			unit: "damage",
			text: `Front-row cover protected ${actor.name} from ${amount} damage.`
		});
	}
	const gear = [...gearGroups.values()].sort((a, b) => b.amount - a.amount || a.id.localeCompare(b.id));
	const ranked = causes.sort((a, b) => b.amount - a.amount || a.id.localeCompare(b.id));
	const top = (gear.length ? [gear[0], ...ranked] : ranked).slice(0, 3);
	if (top.length < 3 && battle.v4) {
		const plans = /* @__PURE__ */ new Map();
		for (const event of battle.v4.events) {
			if (event.kind !== "plan-target" || !event.actorId || !partyIds.has(event.actorId) || !validPlan(event.plan)) continue;
			const id = `plan:${event.actorId}:${event.plan.focus}:${event.plan.care}`;
			const amount = (plans.get(id)?.amount ?? 0) + 1;
			plans.set(id, {
				id,
				actorId: event.actorId,
				kind: "plan",
				amount,
				unit: "actions",
				text: `${name(event.actorId)} took ${amount} action${amount === 1 ? "" : "s"} with “${planNames[event.plan.focus]} · ${careNames[event.plan.care]}” selected.`
			});
		}
		const most = [...plans.values()].sort((a, b) => b.amount - a.amount || a.id.localeCompare(b.id))[0];
		if (most) top.push(most);
	}
	const totalTaken = damageByRow.front + damageByRow.rear;
	const firstFall = battle.log.find((event) => event.kind === "defeat" && partyIds.has(event.targetId));
	return {
		causes: top,
		allCauses: [...gear, ...ranked],
		totalDamage,
		damageByRow,
		rearShare: totalTaken ? Math.round(damageByRow.rear * 100 / totalTaken) : 0,
		firstFallen: firstFall ? {
			id: firstFall.targetId,
			name: name(firstFall.targetId),
			round: firstFall.round
		} : null,
		reconstructedRows: rows
	};
}
// packages/game-rules/src/cardrpg/depth/recommendation-v4.ts
/** Exact state projection, not a probabilistic hash. Timers/settings do not invalidate a build. */
function adviceBuildKeyV4(s) {
	return JSON.stringify({
		on: gameplayV4(s),
		cards: s.account.cards,
		currencies: s.account.currencies,
		team: s.team,
		rows: s.rows,
		skills: s.skills,
		gear: s.gear,
		equipment: s.equipment,
		awakened: s.awakened,
		plan: s.v4?.plan,
		run: s.run ? [s.run.id, s.run.complete] : null
	});
}
/** Public atomic build change; checks ownership, affordability and the home boundary. */
function changeBuildV4(state, change) {
	if (!gameplayV4(state) || !state.v4) return {
		ok: false,
		state,
		error: "Open a Gameplay v4 crew first."
	};
	if (change.kind === "cat") {
		if (!state.team.includes(change.catId) || state.team.includes(change.replacementId) || !state.account.cards.some((card) => card.cardId === change.replacementId)) return {
			ok: false,
			state,
			error: "Choose a collected cat outside your current crew."
		};
		return configureTeam(state, state.team.map((id) => id === change.catId ? change.replacementId : id), {
			...state.rows,
			[change.replacementId]: state.rows[change.catId]
		}, state.skills);
	}
	if (change.kind === "row") {
		if (!state.team.includes(change.catId) || !["front", "rear"].includes(change.row)) return {
			ok: false,
			state,
			error: "Choose a cat in your crew and an available row."
		};
		return configureTeam(state, state.team, {
			...state.rows,
			[change.catId]: change.row
		}, state.skills);
	}
	if (change.kind === "equip") return equipGear(state, change.catId, change.gearId);
	if (change.kind === "level") return metaCommand(state, {
		type: "level",
		cardId: change.cardId
	});
	return transactDepth(state, (s) => {
		requireHome(s);
		requireRule(validPlan(change.plan), "INVALID_TEAM", "Choose an available standing plan.");
		s.v4.plan = { ...change.plan };
	});
}
function applyAdviceV4(state, advice) {
	if (adviceBuildKeyV4(state) !== advice.expectedBuild) return {
		ok: false,
		state,
		error: "Your crew changed. Check its new suggestion first."
	};
	return changeBuildV4(state, advice.change);
}
/** Preserve the same missing HP, enemy snapshot, boons and challenge in both comparison arms. */
function setupFor(state, encounter) {
	const cats = battleCats(state);
	const hp = Object.fromEntries(cats.map((cat) => {
		const old = encounter.cats.find((c) => c.id === cat.id);
		const missing = old ? Math.max(0, old.stats.hp - (encounter.hp?.[cat.id] ?? old.stats.hp)) : 0;
		return [cat.id, Math.max(0, cat.stats.hp - missing)];
	}));
	return {
		...encounter,
		cats,
		hp,
		plan: { ...state.v4.plan }
	};
}
function sample(setup) {
	let wins = 0, margin = 0;
	for (let seed = 1; seed <= 10; seed++) {
		const b = playBattle(createBattle({
			...setup,
			seed
		}), "auto");
		if (b.result === "party") wins++;
		const party = b.actors.filter((a) => a.side === "party");
		const enemy = b.actors.filter((a) => a.side === "enemy");
		margin += party.reduce((n, a) => n + a.hp / a.maxHp, 0) / party.length - enemy.reduce((n, a) => n + a.hp / a.maxHp, 0) / enemy.length;
	}
	return {
		wins,
		margin: margin / 10
	};
}
/** Run in a worker. Fixed TRAIN seeds; bounded candidates; never grants items or starts a route. */
function recommendBuildV4(state, encounter) {
	if (!gameplayV4(state) || !state.v4 || !encounter.gameplayV4 || state.run && !state.run.complete) return null;
	const changes = [];
	for (const id of state.team) {
		const row = state.rows[id] === "front" ? "rear" : "front";
		changes.push({
			change: {
				kind: "row",
				catId: id,
				row
			},
			label: `Place ${CAT_BY_ID[id].name} in ${row === "front" ? "Front" : "Back"}`
		});
		const card = state.account.cards.find((c) => c.cardId === id);
		changes.push({
			change: {
				kind: "level",
				cardId: card.id
			},
			label: `Raise ${CAT_BY_ID[id].name} to level ${card.level + 1}`
		});
		const elsewhere = new Set(Object.entries(state.equipment).filter(([cat]) => cat !== id).flatMap(([, worn]) => Object.values(worn)));
		for (const slot of EQUIPMENT_SLOTS) {
			const item = state.gear.filter((g) => GEAR_BY_ID[g.templateId].slot === slot && !elsewhere.has(g.id) && g.id !== state.equipment[id]?.[slot]).map((g) => ({
				g,
				utility: itemUtilityV4(state, id, g)
			})).sort((a, b) => b.utility - a.utility || a.g.id.localeCompare(b.g.id))[0]?.g;
			if (item) changes.push({
				change: {
					kind: "equip",
					catId: id,
					gearId: item.id
				},
				label: `Give ${CAT_BY_ID[id].name} ${GEAR_BY_ID[item.templateId].name}`
			});
		}
	}
	const names = {
		finish: "Finish weak foes",
		support: "Stop their support",
		leader: "Focus the boss"
	};
	for (const focus of [
		"finish",
		"support",
		"leader"
	]) for (const care of ["steady", "protect"]) if (focus !== state.v4.plan.focus || care !== state.v4.plan.care) changes.push({
		change: {
			kind: "plan",
			plan: {
				focus,
				care
			}
		},
		label: `${names[focus]} · ${care === "protect" ? "Protect" : "Steady"}`
	});
	const reserves = state.account.cards.filter((card) => card.level >= (encounter.challengeLevel ?? 1)).map((card) => card.cardId).filter((id) => !state.team.includes(id)).sort();
	for (const catId of state.team) for (const replacementId of reserves) {
		const row = state.rows[catId] === "front" ? "Front" : "Back";
		changes.push({
			change: {
				kind: "cat",
				catId,
				replacementId
			},
			label: `Replace ${CAT_BY_ID[catId].name} with ${CAT_BY_ID[replacementId].name} in ${row}`
		});
	}
	const retryEncounter = gameplayA6(state) ? {
		...encounter,
		hp: void 0
	} : encounter;
	const before = sample(setupFor(state, retryEncounter)), expectedBuild = adviceBuildKeyV4(state);
	const options = [];
	const counts = {};
	const limits = {
		row: 3,
		level: 3,
		plan: 2,
		equip: 2,
		cat: 2
	};
	const candidates = gameplayA6(state) ? changes.map((option) => ({
		...option,
		applied: changeBuildV4(state, option.change)
	})).filter((option) => option.applied.ok).sort((a, b) => teamPowerV4(b.applied.state) - teamPowerV4(a.applied.state) || a.label.localeCompare(b.label)).filter((option) => (counts[option.change.kind] = (counts[option.change.kind] ?? 0) + 1) <= limits[option.change.kind]) : changes;
	for (const { change, label } of candidates) {
		const applied = changeBuildV4(state, change);
		if (!applied.ok || adviceBuildKeyV4(applied.state) === expectedBuild) continue;
		const after = sample(setupFor(applied.state, retryEncounter));
		if (after.wins < before.wins || after.wins === before.wins && after.margin - before.margin < .05) continue;
		const cost = Object.fromEntries(Object.entries(state.account.currencies).flatMap(([id, n]) => {
			const spent = n - (applied.state.account.currencies[id] ?? n);
			return spent > 0 ? [[id, spent]] : [];
		}));
		options.push({
			change,
			label,
			cost,
			expectedBuild,
			before,
			after,
			samples: 10
		});
	}
	if (gameplayA6(state)) {
		const reliable = options.filter((option) => option.after.wins >= 8);
		const cost = (option) => Object.entries(option.cost).reduce((sum, [id, n]) => sum + n * (id === "threads" ? 3 : id === "essence" ? 20 : 1), 0);
		if (reliable.length) return reliable.sort((a, b) => cost(a) - cost(b) || b.after.wins - a.after.wins || b.after.margin - a.after.margin || a.label.localeCompare(b.label))[0];
	}
	return options.sort((a, b) => b.after.wins - a.after.wins || b.after.margin - a.after.margin || Object.values(a.cost).reduce((n, v) => n + v, 0) - Object.values(b.cost).reduce((n, v) => n + v, 0) || a.label.localeCompare(b.label))[0] ?? null;
}
/** Settle a finished loss on a copy. The advice preview never spends or grants on the live account. */
function resultAdviceStateV4(state) {
	if (!gameplayV4(state) || state.run?.battle?.result !== "enemy") return {
		ok: false,
		state,
		error: "Finish this route before changing the crew."
	};
	const settled = finishEncounter(state);
	if (!settled.ok) return settled;
	return settled.state.run && !settled.state.run.complete ? abandonRun(settled.state) : settled;
}
/** Recheck the same settled build; a repeated or stale click leaves the original account intact. */
function applyResultAdviceV4(state, advice) {
	const settled = resultAdviceStateV4(state);
	if (!settled.ok) return settled;
	const applied = applyAdviceV4(settled.state, advice);
	if (!applied.ok) return {
		...applied,
		state
	};
	const band = state.run?.challengeLevel;
	if (!state.run?.towerA6 && band !== void 0 && applied.state.team.some((id) => applied.state.account.cards.find((card) => card.cardId === id).level < band)) return {
		ok: false,
		state,
		error: `Choose a companion ready for challenge band ${band}.`
	};
	return applied;
}
// packages/game-rules/src/cardrpg/depth/forecast-key-v4.ts
/** Encounter RNG is excluded: every forecast uses the same registered training seeds. */
function forecastKeyV4(setup) {
	const canonical = (value) => Array.isArray(value) ? value.map(canonical) : value && typeof value === "object" ? Object.fromEntries(Object.entries(value).sort(([left], [right]) => left.localeCompare(right)).map(([key, v]) => [key, canonical(v)])) : value;
	const { seed: ignored, ...build } = setup;
	return JSON.stringify(canonical(build));
}
// packages/game-rules/src/cardrpg/depth/forecast-v4.ts
/** Fixed training seeds only. No state is changed, no acceptance seed is sampled. */
function forecastV4(setup, now = Date.now) {
	if (!setup.gameplayV4) throw Error("Forecast requires Gameplay v4.");
	const started = now();
	let wins = 0;
	const fallen = /* @__PURE__ */ new Map();
	for (let seed = 1; seed <= 20; seed++) {
		const battle = playBattle(createBattle({
			...setup,
			seed
		}), "auto");
		if (battle.result === "party") wins++;
		const first = battle.log.find((event) => event.kind === "defeat" && setup.cats.some((cat) => cat.id === event.targetId));
		if (first) {
			const old = fallen.get(first.targetId);
			fallen.set(first.targetId, {
				name: battle.actors.find((actor) => actor.id === first.targetId).name,
				count: (old?.count ?? 0) + 1
			});
		}
	}
	const likely = [...fallen.entries()].sort((a, b) => b[1].count - a[1].count || a[0].localeCompare(b[0]))[0];
	const enemy = setup.enemies.map((id) => ENEMY_BY_ID[id]).find((e) => e.tier === "boss") ?? ENEMY_BY_ID[setup.enemies[0]];
	const danger = enemyGuideV4(enemy.id);
	const risk = likely ? `${likely[1].name} often falls first. ${danger.counter}` : `${enemy.name}: ${danger.intent}`;
	return {
		band: wins < 8 ? "Risky" : wins < 15 ? "Even" : "Favoured",
		risk,
		samples: 20,
		wins,
		firstFallen: likely?.[0] ?? null,
		computeMs: now() - started
	};
}
// packages/game-rules/src/cardrpg/depth/scouting-v4.ts
/** A route choice reveals a distinct clue only after that stop is completed. */
function nodeClueV4(node) {
	if (node.kind === "boss") return null;
	if (node.depth === 0) return "opening";
	if (node.kind === "elite") return "closing";
	if (node.kind === "event") return "reach";
	return null;
}
function scoutingV4(run) {
	if (!run?.gameplayV4) return {
		found: 0,
		total: 3,
		clues: []
	};
	const chapter = CHAPTERS[run.chapter - 1];
	const guide = enemyGuideV4(chapter.boss);
	const learned = new Set(run.nodes.filter((node) => run.visited.includes(node.id)).map(nodeClueV4));
	const text = {
		opening: run.chapter === 1 ? "Loomfall sweeps the front row and summons threads." : run.chapter === 2 ? "Cloudburst removes shields before hitting one row." : "Empty Banquet removes shields and applies Hush.",
		closing: run.chapter === 1 ? "Below half HP, Loomfall reaches both rows and brings threads." : run.chapter === 2 ? "Below half HP, Cloudburst reaches both rows and removes shields." : "Below half HP, Empty Banquet reaches both rows and summons threads.",
		reach: guide.exception
	};
	const clues = [
		"opening",
		"closing",
		"reach"
	].map((id) => ({
		id,
		known: learned.has(id),
		label: id === "opening" ? "Opening pattern" : id === "closing" ? "Closing pattern" : "Who it can reach",
		text: learned.has(id) ? text[id] : null
	}));
	return {
		found: clues.filter((clue) => clue.known).length,
		total: 3,
		clues
	};
}
// packages/game-rules/src/cardrpg/depth/upgrades-a6.ts
var atHome = (s) => gameplayA6(s) && (!s.run || s.run.complete);
function applyUpgradeA6(state, change, expectedBuild) {
	if (!atHome(state)) return {
		ok: false,
		state,
		error: "Finish your route before upgrading."
	};
	if (expectedBuild && expectedBuild !== adviceBuildKeyV4(state)) return {
		ok: false,
		state,
		error: "Your crew changed. Review the new upgrade first."
	};
	return change.kind === "enhance" ? enhanceGear(state, change.gearId) : metaCommand(state, {
		type: change.kind,
		cardId: change.cardId
	});
}
/** Preview legal purchases on copies. The displayed gain and cost come from the real transaction. */
function upgradeOptionsA6(state) {
	if (!atHome(state)) return [];
	const options = [], before = Math.round(teamPowerV4(state));
	const add = (change, label) => {
		const result = applyUpgradeA6(state, change);
		if (!result.ok) return;
		const after = Math.round(teamPowerV4(result.state));
		if (after <= before) return;
		const cost = Object.fromEntries(Object.entries(state.account.currencies).flatMap(([id, amount]) => {
			const used = amount - result.state.account.currencies[id];
			return used > 0 ? [[id, used]] : [];
		}));
		if (change.kind === "ascend") {
			const old = state.account.cards.find((card) => card.id === change.cardId);
			cost.shards = old.shards - result.state.account.cards.find((card) => card.id === old.id).shards;
		}
		const weights = {
			threads: 3,
			essence: 20,
			shards: 25
		};
		const weight = Object.entries(cost).reduce((sum, [id, n]) => sum + n * (weights[id] ?? 1), 0);
		options.push({
			change,
			label,
			cost,
			before,
			after,
			value: (after - before) / Math.max(1, weight),
			expectedBuild: adviceBuildKeyV4(state)
		});
	};
	for (const id of state.team) {
		const card = state.account.cards.find((c) => c.cardId === id);
		add({
			kind: "level",
			cardId: card.id
		}, `Raise ${CAT_BY_ID[id].name} to level ${card.level + 1}`);
		add({
			kind: "ascend",
			cardId: card.id
		}, `Raise ${CAT_BY_ID[id].name} to ${card.stars + 1} stars`);
	}
	const worn = new Set(state.team.flatMap((id) => Object.values(state.equipment[id] ?? {})));
	for (const gear of state.gear.filter((item) => worn.has(item.id))) add({
		kind: "enhance",
		gearId: gear.id
	}, `Enhance ${GEAR_BY_ID[gear.templateId].name} to +${gear.enhancement + 1}`);
	return options.sort((a, b) => b.value - a.value || b.after - a.after || a.label.localeCompare(b.label));
}
/** Equip improvements without moving an item away from another active teammate. */
function autoEquipA6(state) {
	if (!atHome(state)) return {
		ok: false,
		state,
		error: "Finish your route before changing gear."
	};
	let next = state;
	for (const id of state.team) for (const slot of EQUIPMENT_SLOTS) {
		const teammateGear = new Set(state.team.filter((other) => other !== id).flatMap((other) => Object.values(next.equipment[other] ?? {})));
		let best, score = teamPowerV4(next);
		for (const gear of next.gear.filter((item) => GEAR_BY_ID[item.templateId].slot === slot && !teammateGear.has(item.id)).sort((a, b) => a.id.localeCompare(b.id))) {
			const candidateScore = teamPowerV4({
				...next,
				equipment: {
					...next.equipment,
					[id]: {
						...next.equipment[id],
						[slot]: gear.id
					}
				}
			});
			if (candidateScore > score) {
				best = gear.id;
				score = candidateScore;
			}
		}
		if (best) {
			const equipped = equipGear(next, id, best);
			if (equipped.ok) next = equipped.state;
		}
	}
	return next === state ? {
		ok: false,
		state,
		error: "Your team already wears its strongest available gear."
	} : {
		ok: true,
		state: next,
		error: ""
	};
}
// packages/game-rules/src/cardrpg/depth/daily-a6.ts
var DAILY_TASKS_A6 = [
	{
		id: "patrol",
		name: "A safe walk home",
		detail: "Win one patrol or Tower floor.",
		reward: {
			stamps: 20,
			fish: 30
		}
	},
	{
		id: "tips",
		name: "Evening tips",
		detail: "Collect passive Night tips.",
		reward: {
			stamps: 20,
			threads: 5
		}
	},
	{
		id: "recruit",
		name: "A new seat",
		detail: "Invite one cat.",
		reward: {
			stamps: 20,
			fish: 30
		}
	},
	{
		id: "train",
		name: "A little stronger",
		detail: "Raise any cat by one level.",
		reward: {
			stamps: 20,
			threads: 5
		}
	},
	{
		id: "gear",
		name: "Ready for the rain",
		detail: "Enhance one piece of gear.",
		reward: {
			stamps: 20,
			fish: 30
		}
	}
];
var WEEKLY_CHESTS_A6 = [
	10,
	20,
	30
];
var LOGIN_GIFTS_A6 = [
	{
		fish: 100,
		stamps: 40
	},
	{
		stamps: 100,
		threads: 15
	},
	{
		fish: 120,
		threads: 20
	},
	{
		stamps: 100,
		essence: 3
	},
	{
		fish: 150,
		threads: 30
	},
	{ stamps: 150 },
	{
		stamps: 180,
		essence: 6
	}
];
/** One calendar-aware preview for both the board and its badge. */
function dailyBoardA6(s, now) {
	const floor = Math.max(s.idle.lastAt, s.v4?.clockWatermark ?? 0, (s.idle.dayKey ?? 0) * 864e5);
	const rollback = !Number.isSafeInteger(now) || now < floor;
	const refreshed = !rollback && Math.floor(now / 864e5) > (s.idle.dayKey ?? Math.floor(s.idle.lastAt / 864e5)) ? syncCalendarDay(s, now) : null;
	const state = refreshed?.ok ? refreshed.state : s, progress = dailyProgressA6(state);
	const blocked = !gameplayA6(s) ? "Open A6 first." : rollback ? "Wait for the cafe clock to catch up." : s.run && !s.run.complete ? "Finish your patrol first." : null;
	const rewardState = (requested, eligible, claimed) => {
		const reward = cappedPreviewV4(state, requested);
		return {
			requested,
			reward,
			reason: blocked ?? (claimed ? "Already collected." : !eligible ? "Keep playing to unlock this gift." : !Object.values(reward).some((n) => n > 0) ? "Today’s supplies are full." : null),
			claimed
		};
	};
	return {
		state,
		progress,
		tasks: DAILY_TASKS_A6.map((t) => ({
			...t,
			complete: progress.completed.includes(t.id),
			...rewardState(t.reward, progress.completed.includes(t.id), progress.claimed.includes(t.id))
		})),
		weekly: WEEKLY_CHESTS_A6.map((points) => ({
			points,
			...rewardState({
				stamps: points * 4,
				threads: points
			}, progress.weeklyPoints >= points, progress.weeklyClaims.includes(points))
		})),
		login: {
			gift: progress.loginGifts + 1,
			...rewardState(LOGIN_GIFTS_A6[progress.loginGifts] ?? {}, progress.loginGifts < 7, progress.loginDay >= state.account.day || progress.loginGifts >= 7)
		},
		rollback,
		weekDaysLeft: 7 - (state.account.day - 1) % 7,
		taskWeeklyPointGain: Math.max(0, Math.min(1, 35 - progress.weeklyPoints))
	};
}
function claimDailyA6(state, now, kind, id) {
	return transactDepth(state, (s) => {
		requireHome(s);
		requireRule([
			"task",
			"weekly",
			"login"
		].includes(kind), "UNKNOWN_ID", "Choose a gift from the board.");
		const board = dailyBoardA6(s, now);
		const selected = kind === "task" ? board.tasks.find((t) => t.id === id) : kind === "weekly" ? board.weekly.find((w) => w.points === id) : board.login;
		requireRule(selected, "UNKNOWN_ID", "Choose a gift from the board.");
		requireRule(!selected.reason, "NOT_READY", selected.reason ?? "");
		Object.assign(s, board.state);
		grantDepth(s, selected.reward);
		const p = dailyProgressA6(s);
		if (kind === "task") {
			p.claimed.push(id);
			p.weeklyPoints = Math.min(35, p.weeklyPoints + 1);
		}
		if (kind === "weekly") p.weeklyClaims.push(id);
		if (kind === "login") {
			p.loginDay = s.account.day;
			p.loginGifts++;
		}
		s.dailyA6 = p;
		s.v4.clockWatermark = now;
	});
}
// packages/game-rules/src/cardrpg/depth/fusion-v3.ts
/** Quality uses normalized affix rolls, not enhancement or browser Power. */
function gearQualityBp(item) {
	if (!item.affixes.length) return 0;
	return Math.round(item.affixes.reduce((sum, id) => {
		const [lo, hi] = AFFIX_BY_ID[id].tiers[item.tier - 1];
		return sum + (hi === lo ? 0 : Math.max(0, Math.min(1, ((item.rolls[id] ?? lo) - lo) / (hi - lo))) * 1e4);
	}, 0) / item.affixes.length);
}
function snapGearQuality(item, bp) {
	const floor = qualityBucket(bp).floorBp;
	return {
		...item,
		enhancement: 0,
		rolls: Object.fromEntries(item.affixes.map((id) => {
			const [lo, hi] = AFFIX_BY_ID[id].tiers[item.tier - 1];
			return [id, lo + Math.floor((hi - lo) * floor / 1e4)];
		}))
	};
}
/** Bound recipes are deterministic. Legendary fees are authorized by the server. */
function fuseBoundV3(state, ids) {
	return transactDepth(state, (s) => {
		requireHome(s);
		requireRule(s.economyV3, "LOCKED", "Economy v3 is disabled.");
		requireRule(new Set(ids).size === ids.length, "INVALID_AMOUNT", "Choose distinct gear.");
		const inputs = ids.map((id) => s.gear.find((g) => g.id === id));
		requireRule(inputs.length > 0 && inputs.every(Boolean), "UNKNOWN_ID", "Choose available gear.");
		const first = GEAR_BY_ID[inputs[0].templateId], target = first.rarity === "common" ? "rare" : first.rarity === "rare" ? "epic" : null;
		requireRule(target, "LOCKED", "Legendary fusion opens in the on-chain forge.");
		requireRule(inputs.length === ECONOMY_V3.fusion[target].count && inputs.every((g) => {
			const t = GEAR_BY_ID[g.templateId];
			return t.setId === first.setId && t.rarity === first.rarity;
		}), "INVALID_AMOUNT", "Use matching rarity and set.");
		requireRule(!Object.values(s.equipment).some((slots) => Object.values(slots).some((id) => ids.includes(id))), "EQUIPPED", "Unequip inputs first.");
		const template = `${first.setId}-${first.slot}-${target}`;
		requireRule(GEAR_BY_ID[template], "UNKNOWN_ID", "Recipe unavailable.");
		const best = Math.max(...inputs.map((g) => qualityBucket(gearQualityBp(g)).offset / 1e3));
		const output = snapGearQuality(makeGear(s, template, 0), ECONOMY_V3.quality[Math.max(0, best - 1)].floorBp);
		s.gear = s.gear.filter((g) => !ids.includes(g.id));
		s.gear.push(output);
	});
}
// packages/game-rules/src/cardrpg/depth/index.ts
var depth_exports = /* @__PURE__ */ __exportAll({
	AFFIXES: () => AFFIXES,
	AFFIX_BY_ID: () => AFFIX_BY_ID,
	AFFIX_TEXT_V4: () => AFFIX_TEXT_V4,
	BALANCE_C2: () => BALANCE_C2,
	BOONS: () => BOONS,
	BOON_BY_ID: () => BOON_BY_ID,
	CATS: () => CATS$1,
	CAT_BY_ID: () => CAT_BY_ID,
	CAT_CREWS: () => CAT_CREWS,
	CAT_SPECIALTIES_V4: () => CAT_SPECIALTIES_V4,
	CHAPTERS: () => CHAPTERS,
	COLLECTION_BONDS_A6: () => COLLECTION_BONDS_A6,
	COMBO_ROLES_V5: () => COMBO_ROLES_V5,
	COMMON_SKILLS: () => COMMON_SKILLS,
	CONTRACT_VERSION: () => CONTRACT_VERSION,
	CORE_STATUS_RULES_V5: () => CORE_STATUS_RULES_V5,
	CREWS_V5: () => CREWS_V5,
	CREW_JOBS: () => CREW_JOBS,
	DAILY_TASKS_A6: () => DAILY_TASKS_A6,
	DEFAULT_PLAN: () => DEFAULT_PLAN,
	DEPTH_CAPS: () => DEPTH_CAPS,
	DEPTH_CAPS_V4: () => DEPTH_CAPS_V4,
	ECONOMY_C2: () => ECONOMY_C2,
	EDITIONS: () => EDITIONS,
	ENEMIES: () => ENEMIES,
	ENEMY_BY_ID: () => ENEMY_BY_ID,
	ENEMY_MECHANICS_V5: () => ENEMY_MECHANICS_V5,
	EVENTS: () => EVENTS,
	FAST_REWARDS_A6: () => 2,
	FLAVOURS: () => FLAVOURS,
	FLAVOUR_RULE: () => FLAVOUR_RULE,
	FORMATION_C2: () => FORMATION_C2,
	FUJI_RELIC_ADDRESS: () => FUJI_RELIC_ADDRESS,
	GEAR: () => GEAR,
	GEAR_BY_ID: () => GEAR_BY_ID,
	GEAR_CAP_V4: () => 240,
	IDLE_CAP_HOURS_A6: () => 12,
	IDLE_RECEIPT_FIXTURE: () => IDLE_RECEIPT_FIXTURE,
	LEGACY_EVENT_KINDS: () => LEGACY_EVENT_KINDS,
	LESSONS_V4: () => LESSONS_V4,
	LOGIN_GIFTS_A6: () => LOGIN_GIFTS_A6,
	MILESTONES_V4: () => MILESTONES_V4,
	MUTATORS: () => MUTATORS,
	NEW_STATUS_RULES_V5: () => NEW_STATUS_RULES_V5,
	PAIR_COMBOS_A6: () => PAIR_COMBOS_A6,
	POWER_REFERENCE_V4: () => POWER_REFERENCE_V4,
	RAGE_COST_A6: () => 100,
	RAGE_GAIN_A6: () => RAGE_GAIN_A6,
	RARITY_MULTIPLIERS_V4: () => RARITY_MULTIPLIERS_V4,
	REACTION_NAMES_V5: () => REACTION_NAMES_V5,
	RELIC_CAP_A6: () => 800,
	RELIC_EFFECTS: () => RELIC_EFFECTS,
	RELIC_FIXTURE: () => RELIC_FIXTURE,
	ROUTE_SKILL_POWER_PER_RANK: () => ROUTE_SKILL_POWER_PER_RANK,
	SAVE_KEY: () => SAVE_KEY,
	SELECTOR_COST_V4: () => 24,
	SETS: () => SETS,
	SET_TEXT_V4: () => SET_TEXT_V4,
	SHAPE_LABELS_V5: () => SHAPE_LABELS_V5,
	SKILLS: () => SKILLS,
	STAR_REWARDS_V4: () => STAR_REWARDS_V4,
	STAR_TIERS_V4: () => STAR_TIERS_V4,
	STATUSES: () => STATUSES,
	STATUS_BY_ID: () => STATUS_BY_ID,
	STATUS_SUBTITLES_V5: () => STATUS_SUBTITLES_V5,
	SUPPLY_IDS_V4: () => SUPPLY_IDS_V4,
	SUPPLY_TEXT_V4: () => SUPPLY_TEXT_V4,
	TEAM_COMBOS: () => TEAM_COMBOS,
	TOWER_CHESTS_A6: () => TOWER_CHESTS_A6,
	TOWER_FLOORS_A6: () => 30,
	UNIQUES: () => UNIQUES,
	UNIQUE_TEXT_V4: () => UNIQUE_TEXT_V4,
	WEEKLY_CHESTS_A6: () => WEEKLY_CHESTS_A6,
	WEEKLY_POINTS_CAP_A6: () => 35,
	abandonRun: () => abandonRun,
	acceptIdleResult: () => acceptIdleResult,
	acceptRelicSnapshot: () => acceptRelicSnapshot,
	acknowledgeDiscoveryV4: () => acknowledgeDiscoveryV4,
	act: () => act,
	activePairCombosA6: () => activePairCombosA6,
	adjacentV5: () => adjacentV5,
	adviceBuildKeyV4: () => adviceBuildKeyV4,
	applyAdviceV4: () => applyAdviceV4,
	applyIssuance: () => applyIssuance,
	applyLoadoutV4: () => applyLoadoutV4,
	applyResultAdviceV4: () => applyResultAdviceV4,
	applyStatus: () => applyStatus,
	applyUpgradeA6: () => applyUpgradeA6,
	autoEquipA6: () => autoEquipA6,
	availableNodes: () => availableNodes,
	availableSkills: () => availableSkills,
	awakenCat: () => awakenCat,
	awakeningCost: () => awakeningCost,
	balancedRowsC2: () => balancedRowsC2,
	battleCats: () => battleCats,
	battleReasons: () => battleReasons,
	beforeActionV5: () => beforeActionV5,
	boardPreviewV4: () => boardPreviewV4,
	boonForMode: () => boonForMode,
	boonValue: () => boonValue,
	cafeShiftV4: () => cafeShiftV4,
	calendarChallenge: () => calendarChallenge,
	campaignEnemyStatsA6: () => campaignEnemyStatsA6,
	campaignPressureA6: () => campaignPressureA6,
	canReactV5: () => canReactV5,
	cappedPreviewV4: () => cappedPreviewV4,
	challengeStatsV4: () => challengeStatsV4,
	changeBuildV4: () => changeBuildV4,
	chooseAction: () => chooseAction,
	chooseReward: () => chooseReward,
	chooseSelectorV4: () => chooseSelectorV4,
	claimCafeShiftV4: () => claimCafeShiftV4,
	claimDailyA6: () => claimDailyA6,
	claimIdleA6: () => claimIdleA6,
	claimIdleService: () => claimIdleService,
	claimMilestoneV4: () => claimMilestoneV4,
	claimStarRewardV4: () => claimStarRewardV4,
	claimTowerChestA6: () => claimTowerChestA6,
	collectionBondsA6: () => collectionBondsA6,
	collectionBonusA6: () => collectionBonusA6,
	combatStarsV4: () => combatStarsV4,
	commitPreparation: () => commitPreparation,
	comparisonV4: () => comparisonV4,
	configurePreparation: () => configurePreparation,
	configureTeam: () => configureTeam,
	consumeDazeV5: () => consumeDazeV5,
	craftGear: () => craftGear,
	createBattle: () => createBattle,
	createDepthAccount: () => createDepthAccount,
	createIssuanceLedger: () => createIssuanceLedger,
	crewHintsV5: () => crewHintsV5,
	crewStats: () => crewStats,
	crewThresholds: () => crewThresholds,
	crumbBurstV5: () => crumbBurstV5,
	currentActor: () => currentActor,
	currentLessonV4: () => currentLessonV4,
	dailyBoardA6: () => dailyBoardA6,
	dailyProgressA6: () => dailyProgressA6,
	defaultSkills: () => defaultSkills,
	defenseV5: () => defenseV5,
	depthCaps: () => depthCaps,
	depthStats: () => depthStats,
	describeSkillV5: () => describeSkillV5,
	designEligibility: () => designEligibility,
	directReactionV5: () => directReactionV5,
	discoveryIdsV4: () => discoveryIdsV4,
	dispel: () => dispel,
	drawInvitationsV4: () => drawInvitationsV4,
	dropGear: () => dropGear,
	editionContextV4: () => editionContextV4,
	editionLedgerV4: () => editionLedgerV4,
	effectTextV4: () => effectTextV4,
	emitGameplayEvent: () => emitGameplayEvent,
	emptyJourneyV4: () => emptyJourneyV4,
	encounterEnemiesV5: () => encounterEnemiesV5,
	enemyAct: () => enemyAct,
	enemyActionV5: () => enemyActionV5,
	enemyGuideV4: () => enemyGuideV4,
	enemyIntentV5: () => enemyIntentV5,
	energyCost: () => energyCost,
	enhanceGear: () => enhanceGear,
	enhancementPreview: () => enhancementPreview,
	enterNode: () => enterNode,
	equipGear: () => equipGear,
	equipmentEffects: () => equipmentEffects,
	equippedItems: () => equippedItems,
	executeShapeV5: () => executeShapeV5,
	exportSave: () => exportSave,
	finishBossV4: () => finishBossV4,
	finishEncounter: () => finishEncounter,
	finishLessonV4: () => finishLessonV4,
	firstWeekV4: () => firstWeekV4,
	forecastKeyV4: () => forecastKeyV4,
	forecastV4: () => forecastV4,
	formationSeatsC2: () => formationSeatsC2,
	fuseBoundV3: () => fuseBoundV3,
	gainRageA6: () => gainRageA6,
	gameplayA6: () => gameplayA6,
	gameplayV4: () => gameplayV4,
	gearAffixRoll: () => gearAffixRoll,
	gearCostV4: () => gearCostV4,
	gearDropPreview: () => gearDropPreview,
	gearMainV4: () => gearMainV4,
	gearQualityBp: () => gearQualityBp,
	gearStoryV4: () => gearStoryV4,
	generateMap: () => generateMap,
	getDrawPoolV4: () => getDrawPoolV4,
	grantDepth: () => grantDepth,
	hasAdvantage: () => hasAdvantage,
	hitRageA6: () => hitRageA6,
	idleChestA6: () => idleChestA6,
	idlePreview: () => idlePreview,
	idleStageA6: () => idleStageA6,
	importSave: () => importSave,
	initializeEquipment: () => initializeEquipment,
	initializeJourneyV4: () => initializeJourneyV4,
	introductionA6: () => introductionA6,
	invitationBannerV4: () => invitationBannerV4,
	invitationOddsV4: () => invitationOddsV4,
	issueEditionV4: () => issueEditionV4,
	itemCatalogueV4: () => itemCatalogueV4,
	itemUtilityV4: () => itemUtilityV4,
	journalV4: () => journalV4,
	kitSkillV5: () => kitSkillV5,
	landingsV5: () => landingsV5,
	legalChoices: () => legalChoices,
	legendaryTailoringRequirements: () => legendaryTailoringRequirements,
	linkShareBps: () => linkShareBps,
	localEditionAccount: () => localEditionAccount,
	makeGear: () => makeGear,
	mergeNodeStarsV4: () => mergeNodeStarsV4,
	metaCommand: () => metaCommand,
	migrateAccount: () => migrateAccount,
	milestonePreviewV4: () => milestonePreviewV4,
	nakedStatsV4: () => nakedStatsV4,
	nextTowerFloor: () => nextTowerFloor,
	nodeClueV4: () => nodeClueV4,
	nodeStarGoalsV4: () => nodeStarGoalsV4,
	nodeStarKeyV4: () => nodeStarKeyV4,
	observeCollectionV4: () => observeCollectionV4,
	observeDailyA6: () => observeDailyA6,
	observeDiscoveriesV4: () => observeDiscoveriesV4,
	openingCrewBonus: () => openingCrewBonus,
	outcomeV4: () => outcomeV4,
	packSupplyV4: () => packSupplyV4,
	partySize: () => partySize,
	passiveDescriptionV4: () => passiveDescriptionV4,
	patrolDefaultsA6: () => patrolDefaultsA6,
	patrolPressureA6: () => patrolPressureA6,
	phaseBossA6: () => phaseBossA6,
	phaseBossV4: () => phaseBossV4,
	phaseHelpersV5: () => phaseHelpersV5,
	placeInSlotC2: () => placeInSlotC2,
	planPreference: () => planPreference,
	playBattle: () => playBattle,
	powerScoreA6: () => powerScoreA6,
	powerV4: () => powerV4,
	prepareBattleA6: () => prepareBattleA6,
	previewLoadoutV4: () => previewLoadoutV4,
	rarityMeaningV4: () => rarityMeaningV4,
	rawPowerV4: () => rawPowerV4,
	receivedV5: () => receivedV5,
	recommendBuildV4: () => recommendBuildV4,
	recordNodeStarsV4: () => recordNodeStarsV4,
	reforgeGear: () => reforgeGear,
	releaseThreadV5: () => releaseThreadV5,
	relicBonusA6: () => relicBonusA6,
	replayBattle: () => replayBattle,
	replayIssuance: () => replayIssuance,
	requireHome: () => requireHome,
	reserveDesignPreview: () => reserveDesignPreviewV4Guard,
	reserveDesignPreviewV4Guard: () => reserveDesignPreviewV4Guard,
	resolveNode: () => resolveNode,
	resultAdviceStateV4: () => resultAdviceStateV4,
	rewardOptions: () => rewardOptions,
	routeSkillPowerBonusPercent: () => routeSkillPowerBonusPercent,
	salvageGear: () => salvageGear,
	saveChecksum: () => saveChecksum,
	saveLoadoutV4: () => saveLoadoutV4,
	scoutingV4: () => scoutingV4,
	selectRelic: () => selectRelic,
	selectorCostV4: () => selectorCostV4,
	selectorEligibilityV4: () => selectorEligibilityV4,
	selectorMarksV4: () => selectorMarksV4,
	setFormationC2: () => setFormationC2,
	setGameplayA6: () => setGameplayA6,
	setGameplayV4: () => setGameplayV4,
	setSkillsV5: () => setSkillsV5,
	setTextV4: () => setTextV4,
	settleBoardV4: () => settleBoardV4,
	shapeV5: () => shapeV5,
	shopStock: () => shopStock,
	situationalSkillV5: () => situationalSkillV5,
	skillById: () => skillById,
	skillDescriptionV4: () => skillDescriptionV4,
	skillsV5: () => skillsV5,
	snapGearQuality: () => snapGearQuality,
	spendSealProofsV4: () => spendSealProofsV4,
	spreadV5: () => spreadV5,
	stackCapV4: () => stackCapV4,
	stacks: () => stacks,
	starCountV4: () => starCountV4,
	starRewardPreviewV4: () => starRewardPreviewV4,
	starRoundBudgetV4: () => starRoundBudgetV4,
	startRun: () => startRun,
	startTowerFloorA6: () => startTowerFloorA6,
	statusDamageV5: () => statusDamageV5,
	statusDescriptionV4: () => statusDescriptionV4,
	statusIdV5: () => statusIdV5,
	statusRuleV5: () => statusRuleV5,
	stopStarsV4: () => stopStarsV4,
	syncCalendarDay: () => syncCalendarDay,
	targets: () => targets,
	teamCombos: () => teamCombos,
	teamPowerV4: () => teamPowerV4,
	tickStatuses: () => tickStatuses,
	tickStatusesV5: () => tickStatusesV5,
	towerChestA6: () => towerChestA6,
	towerFloorA6: () => towerFloorA6,
	transactDepth: () => transactDepth,
	triggerPairCombosA6: () => triggerPairCombosA6,
	uniqueTextV4: () => uniqueTextV4,
	upgradeOptionsA6: () => upgradeOptionsA6,
	useTonic: () => useTonic,
	validBattleEventV5: () => validBattleEventV5,
	validPlan: () => validPlan,
	validRowsC2: () => validRowsC2,
	validateDepth: () => validateDepth,
	validateIssuance: () => validateIssuance,
	validateJournalV4: () => validateJournalV4,
	validateJourneyV4: () => validateJourneyV4,
	weakestV5: () => weakestV5
});
// apps/web/src/game/cardrpg/chain/flags.ts
/** Build switches only: a URL cannot activate a feature on the live build. */
function chainFlags(env = {
	"BASE_URL": "/",
	"DEV": false,
	"MODE": "production",
	"PROD": true,
	"SSR": false
}) {
	const demo = env.VITE_CHAIN_DEMO === "1";
	return {
		economyV3: demo || env.VITE_ECONOMY_V3 === "1",
		guestWallet: demo || env.VITE_GUEST_WALLET === "1",
		chainLoop: demo || env.VITE_CHAIN_LOOP === "1",
		itemTrading: demo || env.VITE_ITEM_TRADING === "1",
		yarnToken: demo || env.VITE_YARN_TOKEN === "1",
		yarnCosmetics: env.VITE_YARN_COSMETICS === "1",
		relicForge: env.VITE_RELIC_FORGE === "1",
		campaign: env.VITE_CHAIN_CAMPAIGN === "1",
		campaignRewards: env.VITE_CHAIN_CAMPAIGN_REWARDS === "1"
	};
}
// apps/web/src/game/cardrpg/depth/pacing-a6.ts
/** Bound repeated boss actions while retaining the authored event/beat order. */
function paceActionA6(plan, setup) {
	if (!setup.gameplayA6) return plan;
	const bossEncounter = setup.enemies.some((id) => ENEMY_BY_ID[id]?.tier === "boss");
	const enemyAction = !!plan.presentationId?.startsWith("enemy:");
	const signature = bossEncounter && enemyAction && !plan.presentationId?.endsWith(":basic");
	const basic = enemyAction || plan.skillId.endsWith("-1");
	const budget = plan.ultimate ? 1700 : signature ? 1200 : bossEncounter ? basic ? 650 : 800 : basic ? 650 : 800;
	if (plan.duration <= budget) return plan;
	let start = 0;
	const beats = plan.beats.map((beat) => {
		const next = {
			...beat,
			start,
			duration: Math.floor(beat.duration * budget / plan.duration)
		};
		start += next.duration;
		return next;
	});
	return {
		...plan,
		beats,
		duration: start
	};
}
// packages/game-rules/src/cardrpg/depth/onboarding.ts
function firstInvitation(state, seed) {
	return transactDepth(state, (draft) => {
		requireRule(!draft.freeInvite, "ALREADY_CLAIMED", "Your welcome invitation is already used.");
		const marks = gameplayV4(draft) ? draft.v4?.selectorMarks : void 0;
		draft.account.currencies.stamps += gameplayV4(draft) ? invitationBannerV4("standard", draft).cost.stamps : 150;
		const result = metaCommand(draft, {
			type: "pull",
			bannerId: "standard",
			seed
		});
		requireRule(result.ok, "NOT_READY", "Finish your run before opening the invitation.");
		Object.assign(draft, result.state);
		if (gameplayV4(draft)) {
			if (marks === void 0) delete draft.v4.selectorMarks;
			else draft.v4.selectorMarks = marks;
		}
		draft.freeInvite = true;
	});
}
// packages/game-rules/src/squad/gear/catalog.ts
var all = [
	"guardian",
	"witch",
	"alchemist"
];
var line = (stat, value) => ({
	stat,
	value
});
var item = (id, name, slot, rarity, fit, main, affixes, property, set, flavor, visual) => ({
	id,
	name,
	slot,
	rarity,
	fit,
	main,
	affixes,
	property,
	set,
	flavor,
	visual
});
var SQUAD_ITEMS = [
	item("g-ladle", "Breakfast Ladle", "weapon", "Common", ["guardian"], line("attack", 5), [], void 0, void 0, "Every brave night starts with soup.", 0),
	item("g-pan", "Copper Crust Pan", "weapon", "Uncommon", ["guardian"], line("attack", 8), [line("defense", 3)], void 0, "hearthloom", "Seasoned by a thousand late dinners.", 1),
	item("g-bell", "Doorbell Bulwark", "weapon", "Rare", ["guardian"], line("attack", 10), [line("shield", .08)], "neighborShield", "hearthloom", "A familiar ring. A friend at your shoulder.", 2),
	item("g-sun", "Sunspoon Standard", "weapon", "Legendary", ["guardian"], line("attack", 16), [line("crit", .04), line("initiative", 1)], "break", "hearthloom", "Raised when the last lamp refuses to go out.", 3),
	item("g-apron", "Flour-Dusted Apron", "outfit", "Common", ["guardian"], line("hp", 35), [], void 0, void 0, "A pocket for each crumb of courage.", 4),
	item("g-quilt", "Quilted Doorwarden", "outfit", "Rare", ["guardian"], line("defense", 7), [line("hp", 30)], "thorns", "hearthloom", "Soft patches hide a stubborn stitch.", 5),
	item("g-mantle", "Second-Chair Mantle", "outfit", "Epic", ["guardian"], line("hp", 65), [line("shield", .1), line("defense", 4)], "cleanseGuard", "hearthloom", "No one sits alone under this roof.", 6),
	item("g-coat", "Golden Hour Coat", "outfit", "Legendary", ["guardian"], line("defense", 12), [line("hp", 50), line("initiative", 1)], "firstStep", "hearthloom", "The first pawstep opens the cafe.", 7),
	item("w-twig", "Cinder-Tipped Twig", "weapon", "Common", ["witch"], line("attack", 5), [], void 0, void 0, "Still warm from yesterday’s story.", 8),
	item("w-whisk", "Moonmilk Whisk", "weapon", "Uncommon", ["witch", "alchemist"], line("attack", 7), [line("crit", .02)], void 0, "moonwick", "Stirs a small constellation into every cup.", 9),
	item("w-needle", "Needle Lantern", "weapon", "Rare", ["witch"], line("attack", 10), [line("crit", .03)], "chain", "moonwick", "One spark finds a second window.", 10),
	item("w-orbit", "Orbiting Tealight", "weapon", "Legendary", ["witch"], line("attack", 17), [line("crit", .04), line("statusChance", .15)], "longBurn", "moonwick", "A patient ember remembers its promise.", 11),
	item("w-shawl", "Ash-Cotton Shawl", "outfit", "Common", ["witch"], line("hp", 35), [], void 0, void 0, "A soft place for a spark to land.", 12),
	item("w-cape", "Inkpetal Cape", "outfit", "Rare", ["witch"], line("defense", 6), [line("hp", 25)], "vampiric", "moonwick", "A little dusk returns as a little life.", 13),
	item("w-robe", "Margin-Note Robe", "outfit", "Epic", ["witch"], line("hp", 55), [line("cooldown", 1), line("defense", 3)], "efficient", "moonwick", "The best spell leaves room for another.", 14),
	item("w-cloak", "Starry Closing Cloak", "outfit", "Legendary", ["witch"], line("hp", 75), [line("crit", .03), line("initiative", 1)], "charge", "moonwick", "She carries the lights home with her.", 15),
	item("a-bottle", "Breakfast Bottle", "weapon", "Common", ["alchemist"], line("healing", .05), [], void 0, void 0, "A reassuring clink in a canvas pocket.", 16),
	item("a-spout", "Rainspout Flask", "weapon", "Uncommon", ["alchemist", "witch"], line("attack", 7), [line("healing", .05)], void 0, "mossbrew", "Bottled rain for a dry evening.", 17),
	item("a-kettle", "Last-Light Pourer", "weapon", "Rare", ["alchemist"], line("healing", .12), [line("attack", 5)], "afterheal", "mossbrew", "There is always one warm sip left.", 18),
	item("a-garden", "Pocket Conservatory", "weapon", "Legendary", ["alchemist"], line("healing", .18), [line("shield", .1), line("attack", 9)], "renew", "mossbrew", "A whole garden travels in this bottle.", 19),
	item("a-vest", "Cork-Pocket Vest", "outfit", "Common", ["alchemist"], line("hp", 35), [], void 0, void 0, "Made to survive small spills.", 20),
	item("a-smock", "Cloverleaf Smock", "outfit", "Rare", ["alchemist"], line("defense", 7), [line("healing", .06)], "cleanseGuard", "mossbrew", "Leaves sewn over every old worry.", 21),
	item("a-cape", "Dewdrop Capelet", "outfit", "Epic", ["alchemist"], line("hp", 60), [line("shield", .1), line("initiative", 1)], "neighborShield", "mossbrew", "A leaf is an umbrella for a smaller friend.", 22),
	item("a-coat", "Spring Again Coat", "outfit", "Legendary", ["alchemist"], line("hp", 75), [line("healing", .08), line("cooldown", 1)], "renew", "mossbrew", "Even the oldest patch can bloom.", 23),
	item("c-button", "Pocket Button", "charm", "Common", all, line("defense", 3), [], void 0, void 0, "Found beneath the third chair.", 24),
	item("c-bell", "First-Customer Bell", "charm", "Rare", all, line("initiative", 1), [line("hp", 20)], "firstStep", "hearthloom", "Someone is always happy you arrived.", 25),
	item("c-leaf", "Pressed Promise", "charm", "Epic", all, line("healing", .08), [line("shield", .06)], "afterheal", "mossbrew", "A leaf saved inside a favorite book.", 26),
	item("r-wick", "Borrowed Starlight Relic", "relic", "Rare", all, line("crit", .03), [line("attack", 4)], "charge", "moonwick", "A small light, carried with permission.", 27),
	item("r-cup", "Unbroken Saucer Relic", "relic", "Epic", all, line("hp", 45), [line("defense", 4)], "neighborShield", "hearthloom", "The cup broke. The promise did not.", 28),
	item("r-snow", "Snowmelt Hearth Relic", "relic", "Legendary", all, line("shield", .12), [line("healing", .08), line("initiative", 1)], "efficient", "mossbrew", "Avalanche Relic · a flavor label, locally imagined.", 29)
];
Object.fromEntries(SQUAD_ITEMS.map((i) => [i.id, i]));
Object.freeze({
	sealBps: 1e3,
	saleBps: 500,
	burnShareBps: 4e3,
	sealsPerDay: 3,
	minLevel: 2,
	relistSeconds: 600
});
var setCodes = {
	hearthloom: 0,
	moonwick: 1,
	mossbrew: 2,
	rainlace: 3,
	crumbweave: 4,
	bellsteel: 5,
	emberfelt: 6,
	velvetrim: 7
};
function equipmentTokenId(item) {
	const set = Object.hasOwn(setCodes, item.setId) ? setCodes[item.setId] : void 0;
	const slot = EQUIPMENT_SLOTS.indexOf(item.slot), tier = RARITY_ORDER.indexOf(item.rarity);
	return set !== void 0 && slot >= 0 && tier >= 2 && item.id === `${item.setId}-${item.slot}-${item.rarity}` ? 2e4 + set * 100 + tier * 10 + slot : void 0;
}
var TRADE_RULES = [
	...GEAR.map((item) => {
		const tokenId = equipmentTokenId(item);
		return {
			id: item.id,
			name: item.name,
			kind: "equipment",
			rarity: item.rarity,
			tradable: tokenId !== void 0,
			tokenId,
			referenceYarn: tokenId ? item.rarity === "legendary" ? 300 : 100 : 0,
			reason: tokenId ? "Epic+ catalog eligibility; authoritative source required. Canonical unenhanced template, minimum affix rolls; rarity alone does not prove scarcity." : "Repeatable ordinary gear; keep routine progression bound."
		};
	}),
	...STACK_ITEMS.map((item) => ({
		id: item.id,
		name: item.name,
		kind: "bound",
		rarity: item.rarity,
		tradable: false,
		referenceYarn: 0,
		reason: item.id === "boss-proof" ? "Achievement evidence, not a transferable substitute for boss completion." : item.id === "cafe-ribbon" ? "Repeatable permanent collection unlock, not a scarce issue." : "Repeatable consumable/key; routine farming must not mint supply."
	})),
	...CARDS.map((card) => ({
		id: `cat:${card.id}`,
		name: card.name,
		kind: "bound",
		rarity: card.rarity,
		tradable: false,
		referenceYarn: 0,
		reason: "Cats and their XP/shards are account progression; never sold."
	})),
	...[
		"fish",
		"threads",
		"essence",
		"stamps",
		"xp",
		"shards",
		"materials",
		"seals",
		"selector-marks",
		"route-points"
	].map((id) => ({
		id,
		name: id,
		kind: "bound",
		rarity: "common",
		tradable: false,
		referenceYarn: 0,
		reason: "Soft currency, common material or progression; never a transferable earning receipt."
	})),
	{
		id: "star-thread",
		name: "Star Thread",
		kind: "material",
		rarity: "rare",
		tradable: true,
		tokenId: 10001,
		referenceYarn: 20,
		reason: "One authoritative judge boss drop/account; reserved rare-material fixture, no combat power."
	},
	...[
		"Paw Charm",
		"Star Bell",
		"Moon Collar",
		"Golden Maneki"
	].map((name, i) => ({
		id: [
			"relic:1",
			"relic:2",
			"moon-collar",
			"golden-maneki"
		][i],
		name,
		kind: "relic",
		rarity: RARITY_ORDER[i],
		tradable: true,
		tokenId: i + 1,
		referenceYarn: [
			50,
			100,
			200,
			400
		][i],
		reason: "Existing signed-voucher collection; cosmetic Treasure only. Judge mints are free test allocations."
	}))
];
Object.fromEntries(TRADE_RULES.map((r) => [r.id, r]));
Object.fromEntries(TRADE_RULES.filter((r) => r.tokenId !== void 0).map((r) => [r.tokenId, r]));
TRADE_RULES.filter((r) => r.tradable).map((r) => BigInt(r.tokenId));
TRADE_RULES.filter((r) => r.kind === "equipment" && r.tokenId !== void 0).flatMap((r) => [BigInt(r.tokenId + 1e3), BigInt(r.tokenId + 2e3)]);
// apps/web/src/game/squad/turn3d/choreography.ts
var motion = (travel = 0, arc = 0, float = 0, side = 0, hold = 0) => ({
	travel,
	arc,
	float,
	side,
	hold
});
var SKILL_MOTION = {
	guardianBasic: motion(.52, .03, 0, -.1, 45),
	shieldBash: motion(.7, 0, 0, 0, 75),
	rally: motion(0, 0, .02),
	hearthwall: motion(0, .12, 0, 0, 85),
	witchBasic: motion(0, 0, .08),
	threadSnare: motion(0, 0, .16, .06),
	emberOrb: motion(0, 0, .23, -.08, 60),
	lanternstorm: motion(0, 0, .3, 0, 80),
	alchemistBasic: motion(0, .08, 0, .07),
	milkFlask: motion(0, .04, 0, -.04),
	mossFlask: motion(0, .12, 0, .12),
	nineLives: motion(0, .18, .06, 0, 40),
	guardAttack: motion(.48, 0, 0, .05, 45),
	flankerAttack: motion(.74, .27, 0, .35, 40),
	rangerAttack: motion(0, 0, .18, -.08),
	healerAttack: motion(0, 0, .09, .04),
	chargerAttack: motion(.72, .06, 0, 0, 80),
	eliteAttack: motion(.6, .2, 0, -.15, 85),
	yarnAttack: motion(.15, 0, 0, .1, 90),
	bindThread: motion(0, 0, .03),
	crossSweep: motion(.12, .08, 0, -.12, 90),
	threadAttack: motion(.38, .15, 0, .18, 40),
	dummyAttack: motion(.3, .18, 0, 0, 40)
};
// apps/web/src/game/squad/turn3d/card-motion-data.ts
/** Hand-authored gestures follow the existing catalogue and its actual four slots. */
var STARTER_SKILL_CLIPS = {
	mochi: [
		{
			id: "mochi-1",
			duration: 1.08,
			travel: {
				travel: .48,
				arc: .02,
				float: 0,
				side: -.06,
				hold: 65
			},
			keys: [
				[0, {}],
				[.2, {
					motion: [
						.1,
						-.16,
						-.07
					],
					armR: [
						-.35,
						.1,
						-.55
					],
					armL: [
						-.3,
						-.1,
						.2
					],
					shift: [
						0,
						-.05,
						-.06
					],
					stretch: [
						1.04,
						.93,
						1.03
					]
				}],
				[.43, {
					motion: [
						-.1,
						.18,
						.05
					],
					armR: [
						-1.35,
						-.18,
						-.12
					],
					armL: [
						-.45,
						-.2,
						.3
					],
					head: [
						-.08,
						.08,
						0
					],
					shift: [
						0,
						.025,
						.1
					]
				}],
				[.5, {
					armR: [
						-.72,
						.05,
						-.3
					],
					motion: [
						.04,
						-.04,
						-.02
					],
					shift: [
						0,
						-.02,
						.04
					]
				}],
				[.57, {
					armR: [
						-1.52,
						-.12,
						-.07
					],
					motion: [
						-.13,
						.15,
						.06
					],
					shift: [
						0,
						.04,
						.13
					],
					stretch: [
						.98,
						1.04,
						.98
					]
				}],
				[.78, {
					armR: [
						.18,
						.03,
						.12
					],
					motion: [
						.06,
						-.08,
						-.03
					],
					head: [
						.04,
						-.03,
						0
					]
				}],
				[1, {}]
			]
		},
		{
			id: "mochi-2",
			duration: 1.38,
			travel: {
				travel: .08,
				arc: 0,
				float: .015,
				side: .07,
				hold: 0
			},
			keys: [
				[0, {}],
				[.23, {
					motion: [
						.12,
						-.12,
						.07
					],
					armL: [
						-.5,
						.4,
						.22
					],
					armR: [
						-.2,
						-.1,
						-.15
					],
					head: [
						.14,
						-.12,
						.06
					],
					shift: [
						0,
						-.035,
						-.03
					]
				}],
				[.43, {
					motion: [
						-.04,
						.18,
						-.08
					],
					armL: [
						-.65,
						-.45,
						1.05
					],
					armR: [
						-.65,
						.25,
						-.65
					],
					head: [
						-.12,
						.16,
						-.05
					],
					shift: [
						.05,
						.04,
						.03
					]
				}],
				[.61, {
					motion: [
						-.07,
						.22,
						-.04
					],
					armL: [
						-.9,
						-.2,
						.95
					],
					armR: [
						-.45,
						.2,
						-.72
					],
					head: [
						-.08,
						.1,
						-.03
					],
					shift: [
						.03,
						.055,
						.04
					]
				}],
				[.81, {
					motion: [
						.025,
						-.05,
						.02
					],
					armL: [
						-.32,
						.12,
						.25
					],
					armR: [
						.08,
						-.08,
						-.12
					],
					head: [
						.03,
						-.04,
						.025
					]
				}],
				[1, {}]
			]
		},
		{
			id: "mochi-3",
			duration: 1.46,
			travel: {
				travel: .12,
				arc: .03,
				float: 0,
				side: -.28,
				hold: 45
			},
			keys: [
				[0, {}],
				[.18, {
					motion: [
						.08,
						-.28,
						.13
					],
					armL: [
						-.8,
						-.6,
						-.32
					],
					armR: [
						-.8,
						.6,
						.32
					],
					head: [
						.08,
						.18,
						-.05
					],
					shift: [
						-.09,
						-.045,
						-.03
					]
				}],
				[.4, {
					motion: [
						-.05,
						.32,
						-.15
					],
					armL: [
						-1.1,
						-.28,
						.15
					],
					armR: [
						-.6,
						.75,
						.52
					],
					footL: [
						.3,
						-.12,
						-.08
					],
					footR: [
						-.22,
						.12,
						.09
					],
					shift: [
						.12,
						.025,
						.08
					]
				}],
				[.56, {
					motion: [
						.12,
						.12,
						-.08
					],
					armL: [
						-.48,
						-.4,
						.65
					],
					armR: [
						-1,
						-.15,
						-.7
					],
					shift: [
						.03,
						-.045,
						.09
					],
					stretch: [
						1.05,
						.91,
						1.04
					]
				}],
				[.8, {
					motion: [
						-.03,
						-.1,
						.04
					],
					armL: [
						-.25,
						.1,
						.2
					],
					armR: [
						-.35,
						-.08,
						-.1
					],
					shift: [
						-.02,
						.03,
						-.01
					]
				}],
				[1, {}]
			]
		},
		{
			id: "mochi-4",
			duration: 1.72,
			travel: {
				travel: 0,
				arc: 0,
				float: .035,
				side: 0,
				hold: 95
			},
			keys: [
				[0, {}],
				[.19, {
					motion: [
						.18,
						0,
						0
					],
					armL: [
						-.55,
						-.35,
						-.15
					],
					armR: [
						-.55,
						.35,
						.15
					],
					head: [
						.18,
						0,
						0
					],
					shift: [
						0,
						-.1,
						-.02
					],
					stretch: [
						1.08,
						.86,
						1.07
					]
				}],
				[.4, {
					motion: [
						-.1,
						-.08,
						-.03
					],
					armL: [
						-2,
						-.15,
						.55
					],
					armR: [
						-1.5,
						.15,
						-.7
					],
					head: [
						-.18,
						.04,
						0
					],
					shift: [
						0,
						.14,
						.02
					],
					stretch: [
						.94,
						1.1,
						.95
					]
				}],
				[.56, {
					motion: [
						-.03,
						.06,
						.02
					],
					armL: [
						-1.2,
						-.3,
						1.15
					],
					armR: [
						-1.1,
						.3,
						-1.15
					],
					shift: [
						0,
						.045,
						.04
					],
					head: [
						-.1,
						0,
						0
					]
				}],
				[.78, {
					motion: [
						.06,
						0,
						0
					],
					armL: [
						-.7,
						-.1,
						.8
					],
					armR: [
						-.7,
						.1,
						-.8
					],
					shift: [
						0,
						-.02,
						0
					],
					stretch: [
						1.03,
						.95,
						1.02
					]
				}],
				[1, {}]
			]
		}
	],
	soot: [
		{
			id: "soot-1",
			duration: 1.02,
			travel: {
				travel: 0,
				arc: 0,
				float: .045,
				side: .06,
				hold: 35
			},
			keys: [
				[0, {}],
				[.23, {
					motion: [
						.06,
						.2,
						-.1
					],
					armL: [
						-.45,
						-.4,
						.22
					],
					armR: [
						-.25,
						.2,
						-.15
					],
					head: [
						.05,
						-.16,
						.05
					],
					wand: [
						.15,
						0,
						-.12
					],
					shift: [
						-.035,
						-.03,
						-.04
					]
				}],
				[.46, {
					motion: [
						-.08,
						-.22,
						.1
					],
					armL: [
						-1.45,
						.3,
						.55
					],
					armR: [
						.18,
						.1,
						-.35
					],
					head: [
						-.1,
						.12,
						-.04
					],
					wand: [
						-.35,
						.1,
						.2
					],
					shift: [
						.04,
						.07,
						.04
					]
				}],
				[.58, {
					motion: [
						-.02,
						-.1,
						.05
					],
					armL: [
						-1.1,
						.1,
						.8
					],
					armR: [
						.05,
						-.15,
						-.15
					],
					head: [
						-.02,
						.08,
						0
					],
					shift: [
						.02,
						.03,
						.02
					]
				}],
				[.8, {
					motion: [
						.03,
						.05,
						-.035
					],
					armL: [
						.12,
						-.05,
						-.12
					],
					wand: [
						.12,
						0,
						-.08
					],
					shift: [
						0,
						-.02,
						0
					]
				}],
				[1, {}]
			]
		},
		{
			id: "soot-2",
			duration: 1.44,
			travel: {
				travel: 0,
				arc: 0,
				float: .08,
				side: -.09,
				hold: 0
			},
			keys: [
				[0, {}],
				[.22, {
					motion: [
						.15,
						-.08,
						0
					],
					armL: [
						-.7,
						-.55,
						-.25
					],
					armR: [
						-.7,
						.55,
						.25
					],
					head: [
						.2,
						0,
						.03
					],
					shift: [
						0,
						-.07,
						0
					],
					lantern: [
						.05,
						0,
						-.1
					]
				}],
				[.41, {
					motion: [
						-.03,
						.2,
						.07
					],
					armL: [
						-1,
						-.25,
						-.08
					],
					armR: [
						-.6,
						.75,
						.2
					],
					head: [
						-.04,
						.12,
						-.05
					],
					shift: [
						.04,
						.04,
						.025
					]
				}],
				[.57, {
					motion: [
						-.08,
						-.22,
						-.07
					],
					armL: [
						-.7,
						-.7,
						.2
					],
					armR: [
						-1.15,
						.18,
						-.12
					],
					head: [
						-.09,
						-.12,
						.04
					],
					shift: [
						-.04,
						.07,
						.05
					]
				}],
				[.8, {
					motion: [
						.04,
						.07,
						.025
					],
					armL: [
						-.32,
						-.1,
						.18
					],
					armR: [
						-.2,
						.1,
						-.16
					],
					head: [
						.06,
						.04,
						0
					]
				}],
				[1, {}]
			]
		},
		{
			id: "soot-3",
			duration: 1.5,
			travel: {
				travel: .04,
				arc: 0,
				float: .1,
				side: .04,
				hold: 80
			},
			keys: [
				[0, {}],
				[.19, {
					motion: [
						.1,
						-.18,
						-.1
					],
					armR: [
						-.45,
						.2,
						-.35
					],
					armL: [
						-.2,
						-.2,
						.15
					],
					head: [
						.14,
						.1,
						.07
					],
					lantern: [
						0,
						0,
						.15
					],
					shift: [
						-.05,
						-.05,
						-.06
					]
				}],
				[.38, {
					motion: [
						-.16,
						-.05,
						.09
					],
					armR: [
						-2,
						.12,
						-.25
					],
					armL: [
						-.6,
						-.18,
						.65
					],
					head: [
						-.2,
						.04,
						-.04
					],
					lantern: [
						-.3,
						0,
						-.25
					],
					shift: [
						.02,
						.12,
						0
					]
				}],
				[.52, {
					motion: [
						.18,
						.15,
						-.03
					],
					armR: [
						-.55,
						-.1,
						-.8
					],
					armL: [
						-1.25,
						.2,
						.25
					],
					head: [
						.08,
						-.02,
						0
					],
					lantern: [
						.25,
						.1,
						.15
					],
					shift: [
						0,
						-.055,
						.06
					],
					stretch: [
						1.06,
						.91,
						1.03
					]
				}],
				[.73, {
					motion: [
						-.05,
						-.06,
						.035
					],
					armR: [
						-.15,
						.1,
						-.2
					],
					armL: [
						-.4,
						-.15,
						.25
					],
					lantern: [
						-.1,
						0,
						-.07
					],
					shift: [
						0,
						.045,
						-.01
					]
				}],
				[1, {}]
			]
		},
		{
			id: "soot-4",
			duration: 1.78,
			travel: {
				travel: 0,
				arc: 0,
				float: .18,
				side: 0,
				hold: 95
			},
			keys: [
				[0, {}],
				[.18, {
					motion: [
						.12,
						.2,
						.12
					],
					armL: [
						-.65,
						-.55,
						-.2
					],
					armR: [
						-.65,
						.55,
						.2
					],
					head: [
						.16,
						-.15,
						-.05
					],
					shift: [
						0,
						-.07,
						0
					]
				}],
				[.36, {
					motion: [
						-.08,
						-.3,
						-.12
					],
					armL: [
						-2.2,
						.1,
						.45
					],
					armR: [
						-.8,
						.2,
						-1.2
					],
					head: [
						-.16,
						.18,
						.05
					],
					lantern: [
						-.12,
						.2,
						-.24
					],
					shift: [
						-.05,
						.16,
						0
					]
				}],
				[.52, {
					motion: [
						-.12,
						.28,
						.1
					],
					armL: [
						-.8,
						-.2,
						1.25
					],
					armR: [
						-2.1,
						-.15,
						-.55
					],
					head: [
						-.12,
						-.15,
						-.035
					],
					lantern: [
						.12,
						-.15,
						.22
					],
					shift: [
						.05,
						.2,
						.02
					],
					stretch: [
						.95,
						1.09,
						.96
					]
				}],
				[.68, {
					motion: [
						.1,
						0,
						0
					],
					armL: [
						-1.1,
						-.15,
						.45
					],
					armR: [
						-1.1,
						.15,
						-.45
					],
					head: [
						.1,
						0,
						0
					],
					shift: [
						0,
						-.025,
						.045
					],
					stretch: [
						1.06,
						.92,
						1.04
					]
				}],
				[.86, {
					motion: [
						-.025,
						-.04,
						-.02
					],
					armL: [
						-.25,
						.1,
						.18
					],
					armR: [
						-.25,
						-.1,
						-.18
					],
					shift: [
						0,
						.025,
						0
					]
				}],
				[1, {}]
			]
		}
	],
	clover: [
		{
			id: "clover-1",
			duration: 1.1,
			travel: {
				travel: .42,
				arc: .16,
				float: 0,
				side: .16,
				hold: 35
			},
			keys: [
				[0, {}],
				[.2, {
					motion: [
						.18,
						-.12,
						.12
					],
					armL: [
						.15,
						.1,
						.35
					],
					armR: [
						.35,
						-.2,
						-.4
					],
					head: [
						.1,
						.08,
						-.05
					],
					shift: [
						-.04,
						-.09,
						-.04
					],
					stretch: [
						1.07,
						.87,
						1.04
					]
				}],
				[.42, {
					motion: [
						-.22,
						.18,
						-.12
					],
					armL: [
						-.35,
						-.15,
						.6
					],
					armR: [
						-1.35,
						.12,
						-.55
					],
					footL: [
						.5,
						0,
						-.12
					],
					footR: [
						-.35,
						0,
						.1
					],
					shift: [
						.04,
						.2,
						.08
					],
					stretch: [
						.94,
						1.1,
						.95
					]
				}],
				[.56, {
					motion: [
						.12,
						.06,
						-.04
					],
					armL: [
						-.5,
						-.1,
						.25
					],
					armR: [
						-1.1,
						-.25,
						-.15
					],
					shift: [
						0,
						-.035,
						.1
					],
					stretch: [
						1.05,
						.91,
						1.04
					]
				}],
				[.8, {
					motion: [
						-.035,
						-.06,
						.025
					],
					armL: [
						.1,
						.05,
						-.05
					],
					armR: [
						.18,
						.08,
						.12
					],
					shift: [
						0,
						.04,
						0
					]
				}],
				[1, {}]
			]
		},
		{
			id: "clover-2",
			duration: 1.42,
			travel: {
				travel: .05,
				arc: 0,
				float: .025,
				side: -.06,
				hold: 0
			},
			keys: [
				[0, {}],
				[.24, {
					motion: [
						.1,
						-.12,
						.04
					],
					armL: [
						-.75,
						-.42,
						-.22
					],
					armR: [
						-.7,
						.45,
						.2
					],
					head: [
						.16,
						-.1,
						.04
					],
					shift: [
						0,
						-.035,
						-.02
					]
				}],
				[.45, {
					motion: [
						.02,
						.15,
						-.035
					],
					armL: [
						-.85,
						-.15,
						.15
					],
					armR: [
						-1.1,
						.25,
						-.25
					],
					head: [
						.08,
						.1,
						-.02
					],
					shift: [
						.035,
						.015,
						.07
					]
				}],
				[.63, {
					motion: [
						.04,
						.2,
						-.04
					],
					armL: [
						-.95,
						-.1,
						.2
					],
					armR: [
						-.9,
						.1,
						-.18
					],
					head: [
						.1,
						.1,
						-.03
					],
					shift: [
						.045,
						-.01,
						.1
					]
				}],
				[.82, {
					motion: [
						-.025,
						-.04,
						.02
					],
					armL: [
						-.3,
						-.15,
						.1
					],
					armR: [
						-.35,
						.15,
						-.12
					],
					head: [
						-.025,
						-.03,
						.015
					]
				}],
				[1, {}]
			]
		},
		{
			id: "clover-3",
			duration: 1.48,
			travel: {
				travel: 0,
				arc: 0,
				float: .045,
				side: .12,
				hold: 0
			},
			keys: [
				[0, {}],
				[.18, {
					motion: [
						.08,
						-.3,
						.12
					],
					armL: [
						-.55,
						-.2,
						.3
					],
					armR: [
						-.75,
						.8,
						.2
					],
					head: [
						.08,
						.18,
						-.05
					],
					shift: [
						-.08,
						-.035,
						0
					]
				}],
				[.39, {
					motion: [
						-.05,
						-.12,
						-.06
					],
					armL: [
						-1.4,
						-.2,
						.7
					],
					armR: [
						-.4,
						.3,
						-.45
					],
					head: [
						-.1,
						.08,
						.025
					],
					shift: [
						-.025,
						.06,
						.02
					]
				}],
				[.58, {
					motion: [
						-.03,
						.35,
						-.12
					],
					armL: [
						-.5,
						-.3,
						.6
					],
					armR: [
						-1.4,
						.2,
						-.95
					],
					head: [
						-.06,
						-.18,
						.04
					],
					shift: [
						.08,
						.035,
						.04
					]
				}],
				[.78, {
					motion: [
						.04,
						-.06,
						.045
					],
					armL: [
						-.2,
						.1,
						.15
					],
					armR: [
						-.4,
						-.1,
						-.2
					],
					shift: [
						-.025,
						-.025,
						0
					]
				}],
				[1, {}]
			]
		},
		{
			id: "clover-4",
			duration: 1.76,
			travel: {
				travel: 0,
				arc: 0,
				float: .1,
				side: 0,
				hold: 55
			},
			keys: [
				[0, {}],
				[.22, {
					motion: [
						.22,
						0,
						0
					],
					armL: [
						-.7,
						-.55,
						-.22
					],
					armR: [
						-.7,
						.55,
						.22
					],
					head: [
						.22,
						0,
						0
					],
					shift: [
						0,
						-.13,
						.04
					],
					stretch: [
						1.1,
						.83,
						1.08
					]
				}],
				[.41, {
					motion: [
						-.08,
						-.06,
						-.04
					],
					armL: [
						-1.5,
						-.12,
						.5
					],
					armR: [
						-1.5,
						.12,
						-.5
					],
					head: [
						-.2,
						.04,
						.02
					],
					shift: [
						0,
						.16,
						.015
					],
					stretch: [
						.92,
						1.13,
						.94
					]
				}],
				[.57, {
					motion: [
						-.05,
						.06,
						.04
					],
					armL: [
						-.55,
						-.15,
						1.45
					],
					armR: [
						-.55,
						.15,
						-1.45
					],
					head: [
						-.08,
						-.04,
						-.02
					],
					footL: [
						.16,
						0,
						-.04
					],
					footR: [
						.16,
						0,
						.04
					],
					shift: [
						0,
						.22,
						0
					]
				}],
				[.74, {
					motion: [
						.09,
						0,
						0
					],
					armL: [
						-.3,
						.05,
						.72
					],
					armR: [
						-.3,
						-.05,
						-.72
					],
					shift: [
						0,
						-.065,
						0
					],
					stretch: [
						1.06,
						.91,
						1.04
					]
				}],
				[.88, {
					motion: [
						-.03,
						0,
						0
					],
					armL: [
						.04,
						0,
						.14
					],
					armR: [
						.04,
						0,
						-.14
					],
					shift: [
						0,
						.035,
						0
					]
				}],
				[1, {}]
			]
		}
	]
};
// apps/web/src/game/squad/turn3d/card-roster-motion.ts
var clip$1 = (id, duration, poses, travel) => ({
	id,
	duration,
	keys: [
		[0, {}],
		...poses,
		[1, {}]
	],
	travel
});
var still = {
	travel: 0,
	arc: 0,
	float: 0,
	side: 0,
	hold: 70
};
var ROSTER_SKILL_CLIPS = {
	panko: [
		clip$1("panko-1", 1.1, [
			[.18, {
				motion: [
					.08,
					.27,
					-.14
				],
				armR: [
					-.3,
					.1,
					-1
				],
				armL: [
					-.65,
					-.2,
					.3
				],
				shift: [
					-.04,
					-.07,
					-.05
				]
			}],
			[.39, {
				motion: [
					-.05,
					-.3,
					.13
				],
				armR: [
					-1.25,
					-.4,
					-.2
				],
				armL: [
					-.8,
					-.1,
					.15
				],
				footR: [
					.25,
					.1,
					0
				],
				shift: [
					.07,
					.03,
					.12
				]
			}],
			[.57, {
				motion: [
					.12,
					.1,
					-.06
				],
				armR: [
					-.5,
					.35,
					-.85
				],
				head: [
					.06,
					-.1,
					.03
				],
				shift: [
					-.015,
					-.04,
					.035
				],
				stretch: [
					1.06,
					.91,
					1.04
				]
			}],
			[.79, {
				armR: [
					-.35,
					.1,
					-.25
				],
				armL: [
					-.35,
					-.1,
					.2
				],
				shift: [
					0,
					.02,
					0
				]
			}]
		], {
			...still,
			travel: .34,
			side: .1,
			arc: .025
		}),
		clip$1("panko-2", 1.42, [
			[.2, {
				motion: [
					.22,
					0,
					.03
				],
				head: [
					.14,
					0,
					-.03
				],
				armL: [
					-.5,
					-.2,
					.4
				],
				armR: [
					-.5,
					.2,
					-.4
				],
				shift: [
					0,
					-.1,
					-.03
				],
				stretch: [
					1.1,
					.83,
					1.06
				]
			}],
			[.43, {
				motion: [
					.08,
					-.06,
					0
				],
				armL: [
					-1.9,
					-.45,
					.3
				],
				armR: [
					-1.9,
					.45,
					-.3
				],
				head: [
					-.08,
					.03,
					0
				],
				shift: [
					0,
					-.03,
					.01
				]
			}],
			[.64, {
				motion: [
					.12,
					.06,
					-.03
				],
				armL: [
					-1.65,
					-.3,
					.42
				],
				armR: [
					-1.65,
					.3,
					-.42
				],
				shift: [
					0,
					-.055,
					0
				],
				stretch: [
					1.04,
					.93,
					1.03
				]
			}],
			[.83, {
				armL: [
					-.45,
					-.2,
					.15
				],
				armR: [
					-.45,
					.2,
					-.15
				],
				head: [
					.04,
					0,
					0
				]
			}]
		], still),
		clip$1("panko-3", 1.6, [
			[.17, {
				motion: [
					.05,
					-.22,
					.09
				],
				armL: [
					-.7,
					-.3,
					.22
				],
				armR: [
					-.3,
					.15,
					-.2
				],
				head: [
					.07,
					.16,
					0
				],
				shift: [
					-.08,
					-.035,
					0
				]
			}],
			[.36, {
				motion: [
					-.04,
					.12,
					-.08
				],
				armL: [
					-.85,
					-.7,
					1.35
				],
				armR: [
					-.55,
					.2,
					-.3
				],
				shift: [
					.02,
					.035,
					.025
				]
			}],
			[.57, {
				motion: [
					-.04,
					-.12,
					.08
				],
				armL: [
					-.65,
					-.2,
					.3
				],
				armR: [
					-.85,
					.7,
					-1.35
				],
				head: [
					-.05,
					-.15,
					0
				],
				shift: [
					-.02,
					.035,
					.025
				]
			}],
			[.76, {
				armL: [
					-.5,
					-.25,
					.9
				],
				armR: [
					-.5,
					.25,
					-.9
				],
				shift: [
					0,
					-.035,
					.02
				]
			}]
		], still),
		clip$1("panko-4", 1.76, [
			[.19, {
				motion: [
					.3,
					0,
					0
				],
				armL: [
					-.7,
					-.2,
					.15
				],
				armR: [
					-.7,
					.2,
					-.15
				],
				head: [
					.2,
					0,
					0
				],
				shift: [
					0,
					-.14,
					.04
				],
				stretch: [
					1.12,
					.8,
					1.08
				]
			}],
			[.4, {
				motion: [
					-.17,
					0,
					0
				],
				armL: [
					-2.1,
					-.1,
					.1
				],
				armR: [
					-2.1,
					.1,
					-.1
				],
				head: [
					-.16,
					0,
					0
				],
				shift: [
					0,
					.15,
					-.03
				],
				stretch: [
					.96,
					1.08,
					.98
				]
			}],
			[.56, {
				motion: [
					.17,
					0,
					.03
				],
				armL: [
					-1.1,
					-.1,
					.26
				],
				armR: [
					-1.1,
					.1,
					-.26
				],
				shift: [
					0,
					-.13,
					.1
				],
				stretch: [
					1.1,
					.84,
					1.05
				]
			}],
			[.78, {
				motion: [
					.04,
					.03,
					-.02
				],
				armL: [
					-.95,
					-.12,
					.3
				],
				armR: [
					-.95,
					.12,
					-.3
				],
				head: [
					-.08,
					.02,
					0
				],
				shift: [
					0,
					.02,
					.04
				]
			}]
		], {
			...still,
			hold: 105
		})
	],
	mallow: [
		clip$1("mallow-1", 1.08, [
			[.18, {
				motion: [
					.08,
					-.18,
					.12
				],
				armR: [
					-1.6,
					.5,
					-.8
				],
				armL: [
					.1,
					-.2,
					.4
				],
				head: [
					.08,
					.1,
					-.04
				],
				shift: [
					-.04,
					-.04,
					-.03
				]
			}],
			[.38, {
				motion: [
					-.13,
					.18,
					-.12
				],
				armR: [
					-2.15,
					-.2,
					.15
				],
				armL: [
					-.4,
					-.2,
					.55
				],
				shift: [
					.04,
					.11,
					.05
				]
			}],
			[.54, {
				motion: [
					.12,
					.1,
					-.06
				],
				armR: [
					-.65,
					-.65,
					-.4
				],
				armL: [
					.12,
					.1,
					.2
				],
				shift: [
					.06,
					-.04,
					.09
				],
				stretch: [
					1.04,
					.92,
					1.02
				]
			}],
			[.77, {
				armR: [
					-.2,
					.1,
					-.2
				],
				motion: [
					-.025,
					-.06,
					.04
				],
				shift: [
					0,
					.03,
					0
				]
			}]
		], {
			...still,
			travel: .23,
			arc: .08,
			side: -.06
		}),
		clip$1("mallow-2", 1.46, [
			[.22, {
				armL: [
					-1.1,
					-.5,
					-.15
				],
				armR: [
					-1.1,
					.5,
					.15
				],
				motion: [
					.15,
					0,
					0
				],
				head: [
					.13,
					0,
					0
				],
				shift: [
					0,
					-.065,
					0
				]
			}],
			[.44, {
				armL: [
					-.8,
					-.2,
					1.7
				],
				armR: [
					-.8,
					.2,
					-1.7
				],
				motion: [
					-.12,
					0,
					0
				],
				head: [
					-.12,
					0,
					0
				],
				shift: [
					0,
					.12,
					.04
				],
				stretch: [
					.94,
					1.12,
					.95
				]
			}],
			[.62, {
				armL: [
					-.5,
					-.5,
					1.15
				],
				armR: [
					-.5,
					.5,
					-1.15
				],
				motion: [
					.04,
					-.1,
					.05
				],
				shift: [
					0,
					-.025,
					.03
				]
			}],
			[.82, {
				armL: [
					.1,
					-.1,
					.32
				],
				armR: [
					.1,
					.1,
					-.32
				],
				head: [
					.03,
					0,
					0
				]
			}]
		], still),
		clip$1("mallow-3", 1.62, [
			[.2, {
				armL: [
					-.5,
					-.2,
					.2
				],
				armR: [
					-2.35,
					.1,
					-.25
				],
				motion: [
					-.11,
					-.2,
					-.1
				],
				footR: [
					.65,
					0,
					0
				],
				head: [
					-.18,
					.1,
					.05
				],
				shift: [
					-.05,
					.12,
					-.04
				]
			}],
			[.43, {
				armR: [
					-.8,
					-.3,
					-.5
				],
				armL: [
					-.35,
					-.2,
					.65
				],
				motion: [
					.25,
					.22,
					.12
				],
				footR: [
					-.25,
					0,
					0
				],
				shift: [
					.08,
					-.12,
					.11
				],
				stretch: [
					1.1,
					.83,
					1.06
				]
			}],
			[.6, {
				armR: [
					-1.2,
					.1,
					-.1
				],
				motion: [
					-.08,
					.06,
					-.04
				],
				shift: [
					.025,
					.085,
					.04
				],
				stretch: [
					.96,
					1.07,
					.98
				]
			}],
			[.81, {
				armR: [
					-.25,
					.1,
					-.2
				],
				motion: [
					.03,
					-.03,
					.02
				],
				shift: [
					0,
					-.015,
					0
				]
			}]
		], {
			...still,
			travel: .12,
			arc: .06,
			hold: 105
		}),
		clip$1("mallow-4", 1.78, [
			[.16, {
				motion: [
					.17,
					-.3,
					.14
				],
				armL: [
					-.4,
					-.3,
					.3
				],
				armR: [
					-.8,
					.7,
					-.4
				],
				head: [
					.1,
					.16,
					-.06
				],
				shift: [
					-.1,
					-.06,
					0
				]
			}],
			[.35, {
				motion: [
					-.16,
					.3,
					-.14
				],
				armL: [
					-2.1,
					-.1,
					.3
				],
				armR: [
					-2.4,
					.1,
					-.25
				],
				footL: [
					.4,
					.1,
					-.1
				],
				shift: [
					.09,
					.23,
					.02
				],
				stretch: [
					.92,
					1.14,
					.94
				]
			}],
			[.55, {
				motion: [
					-.08,
					-.26,
					.1
				],
				armL: [
					-.8,
					-.6,
					1.45
				],
				armR: [
					-1.5,
					-.4,
					-.15
				],
				head: [
					-.06,
					.13,
					.03
				],
				shift: [
					-.08,
					.13,
					.08
				]
			}],
			[.73, {
				motion: [
					.13,
					.16,
					-.07
				],
				armL: [
					-.5,
					-.1,
					.25
				],
				armR: [
					-.7,
					.4,
					-1.35
				],
				shift: [
					.05,
					-.065,
					.04
				],
				stretch: [
					1.05,
					.91,
					1.04
				]
			}],
			[.89, {
				armR: [
					-.2,
					.1,
					-.3
				],
				shift: [
					0,
					.025,
					0
				]
			}]
		], {
			...still,
			float: .12,
			hold: 110
		})
	],
	sorrel: [
		clip$1("sorrel-1", 1.1, [
			[.24, {
				motion: [
					.09,
					.14,
					-.06
				],
				armL: [
					-.8,
					-.4,
					.15
				],
				armR: [
					-.2,
					.1,
					-.35
				],
				head: [
					.15,
					-.1,
					.04
				],
				shift: [
					.025,
					-.025,
					-.015
				]
			}],
			[.45, {
				armL: [
					-1.25,
					.3,
					.65
				],
				armR: [
					-.4,
					.2,
					-.2
				],
				motion: [
					-.04,
					-.16,
					.07
				],
				head: [
					-.07,
					.1,
					-.03
				],
				shift: [
					-.025,
					.04,
					.07
				]
			}],
			[.65, {
				armL: [
					-.85,
					-.1,
					.9
				],
				motion: [
					.02,
					.07,
					-.03
				],
				shift: [
					.015,
					.01,
					.025
				]
			}],
			[.83, {
				armL: [
					-.2,
					-.1,
					.12
				],
				head: [
					.02,
					-.025,
					0
				]
			}]
		], {
			...still,
			travel: .08,
			side: .02
		}),
		clip$1("sorrel-2", 1.52, [
			[.2, {
				armR: [
					-.7,
					.2,
					-.1
				],
				armL: [
					-.8,
					-.2,
					.2
				],
				head: [
					.1,
					-.14,
					-.04
				],
				shift: [
					0,
					-.025,
					0
				]
			}],
			[.4, {
				armR: [
					-1.45,
					-.35,
					-1.1
				],
				armL: [
					-.45,
					-.2,
					.4
				],
				motion: [
					-.06,
					.25,
					-.13
				],
				head: [
					-.06,
					-.14,
					.08
				],
				shift: [
					.08,
					.045,
					.03
				]
			}],
			[.64, {
				armR: [
					-1.65,
					.15,
					-.5
				],
				armL: [
					-1,
					-.1,
					.8
				],
				motion: [
					-.02,
					.12,
					-.05
				],
				shift: [
					.045,
					.025,
					.02
				]
			}],
			[.84, {
				armR: [
					-.3,
					.1,
					-.1
				],
				armL: [
					-.4,
					-.1,
					.2
				],
				motion: [
					.02,
					-.04,
					.02
				]
			}]
		], still),
		clip$1("sorrel-3", 1.62, [
			[.19, {
				armL: [
					-1.3,
					-.5,
					.85
				],
				armR: [
					-.4,
					.1,
					-.2
				],
				motion: [
					-.04,
					-.15,
					.04
				],
				head: [
					-.08,
					.13,
					-.04
				],
				shift: [
					-.045,
					.045,
					0
				]
			}],
			[.4, {
				armL: [
					-1.1,
					.4,
					.25
				],
				armR: [
					-1.1,
					-.4,
					-.25
				],
				motion: [
					.03,
					0,
					0
				],
				head: [
					.12,
					0,
					0
				],
				shift: [
					0,
					0,
					.045
				]
			}],
			[.62, {
				armL: [
					-.45,
					-.1,
					.2
				],
				armR: [
					-1.5,
					.2,
					-.8
				],
				motion: [
					.12,
					.12,
					-.045
				],
				head: [
					.16,
					-.09,
					.02
				],
				shift: [
					.05,
					-.025,
					.09
				]
			}],
			[.82, {
				armR: [
					-.55,
					.1,
					-.3
				],
				motion: [
					-.035,
					-.03,
					.015
				],
				head: [
					-.04,
					0,
					0
				],
				shift: [
					0,
					.025,
					.015
				]
			}]
		], still),
		clip$1("sorrel-4", 1.76, [
			[.19, {
				armL: [
					-.8,
					-.2,
					.1
				],
				armR: [
					-.8,
					.2,
					-.1
				],
				motion: [
					.2,
					0,
					0
				],
				head: [
					.16,
					0,
					0
				],
				shift: [
					0,
					-.07,
					.04
				]
			}],
			[.38, {
				armL: [
					-1.7,
					-.15,
					.65
				],
				armR: [
					-1.7,
					.15,
					-.65
				],
				motion: [
					-.1,
					-.16,
					.06
				],
				head: [
					-.12,
					.12,
					-.02
				],
				shift: [
					-.045,
					.12,
					0
				]
			}],
			[.56, {
				armL: [
					-1.15,
					-.4,
					.95
				],
				armR: [
					-1.25,
					-.2,
					-.3
				],
				motion: [
					-.04,
					.25,
					-.09
				],
				head: [
					-.05,
					-.15,
					.03
				],
				shift: [
					.065,
					.07,
					.04
				]
			}],
			[.74, {
				armL: [
					-.65,
					-.1,
					.2
				],
				armR: [
					-.65,
					.1,
					-.2
				],
				motion: [
					.17,
					.02,
					0
				],
				head: [
					.12,
					0,
					0
				],
				shift: [
					0,
					-.045,
					.08
				]
			}],
			[.88, {
				armL: [
					-.2,
					0,
					.2
				],
				armR: [
					-.2,
					0,
					-.2
				],
				shift: [
					0,
					.02,
					.015
				]
			}]
		], {
			...still,
			hold: 90
		})
	]
};
// apps/web/src/game/squad/turn3d/card-roster-batch2-motion.ts
var clip = (id, duration, keys, motion = {}) => ({
	id,
	duration,
	keys: [
		[0, {}],
		...keys,
		[1, {}]
	],
	travel: {
		travel: 0,
		arc: 0,
		side: 0,
		float: 0,
		hold: 75,
		...motion
	}
});
var BATCH2_SKILL_CLIPS = {
	biscuit: [
		clip("biscuit-1", 1.12, [
			[.18, {
				armL: [
					-.4,
					-.25,
					.65
				],
				armR: [
					-.4,
					.25,
					-.65
				],
				motion: [
					.28,
					0,
					0
				],
				head: [
					.12,
					0,
					0
				],
				shift: [
					0,
					-.13,
					-.08
				],
				stretch: [
					1.12,
					.82,
					1.07
				]
			}],
			[.4, {
				armL: [
					-1.6,
					-.05,
					.55
				],
				armR: [
					-1.6,
					.05,
					-.55
				],
				motion: [
					.35,
					0,
					0
				],
				head: [
					-.07,
					0,
					0
				],
				shift: [
					0,
					-.06,
					.24
				]
			}],
			[.61, {
				armL: [
					-.5,
					-.3,
					.7
				],
				armR: [
					-.5,
					.3,
					-.7
				],
				motion: [
					.06,
					-.08,
					0
				],
				footL: [
					.25,
					.1,
					0
				],
				shift: [
					0,
					.09,
					-.035
				],
				stretch: [
					.96,
					1.08,
					.98
				]
			}],
			[.82, {
				armL: [
					-.2,
					-.1,
					.15
				],
				armR: [
					-.2,
					.1,
					-.15
				],
				shift: [
					0,
					-.025,
					.02
				]
			}]
		], {
			travel: .37,
			arc: .015
		}),
		clip("biscuit-2", 1.46, [
			[.18, {
				footL: [
					.4,
					.3,
					-.25
				],
				footR: [
					-.15,
					-.15,
					.13
				],
				motion: [
					0,
					-.28,
					.22
				],
				armL: [
					-.4,
					-.25,
					1.05
				],
				head: [
					0,
					.16,
					-.08
				],
				shift: [
					-.16,
					.04,
					0
				]
			}],
			[.4, {
				footL: [
					-.2,
					-.2,
					-.1
				],
				footR: [
					.55,
					-.25,
					.25
				],
				motion: [
					-.08,
					.3,
					-.2
				],
				armR: [
					-.45,
					.3,
					-1.4
				],
				armL: [
					-.25,
					-.1,
					.25
				],
				shift: [
					.2,
					.12,
					.06
				]
			}],
			[.64, {
				motion: [
					.07,
					.18,
					-.1
				],
				armR: [
					-.8,
					.15,
					-.9
				],
				armL: [
					-.55,
					-.2,
					.4
				],
				head: [
					.05,
					-.16,
					.05
				],
				footR: [
					-.18,
					.1,
					0
				],
				shift: [
					.11,
					-.06,
					.04
				]
			}],
			[.84, {
				motion: [
					0,
					-.06,
					.04
				],
				shift: [
					-.035,
					.02,
					0
				]
			}]
		], {
			side: .3,
			arc: .06,
			travel: .04
		}),
		clip("biscuit-3", 1.65, [
			[.18, {
				motion: [
					-.12,
					-.34,
					.17
				],
				armR: [
					-2.35,
					.25,
					-.6
				],
				armL: [
					-1.3,
					-.35,
					.1
				],
				head: [
					-.16,
					.15,
					-.06
				],
				shift: [
					-.09,
					.13,
					-.08
				]
			}],
			[.44, {
				motion: [
					.35,
					.27,
					-.15
				],
				armR: [
					-.6,
					-.4,
					-.1
				],
				armL: [
					-.45,
					.35,
					.65
				],
				head: [
					.12,
					-.1,
					.02
				],
				shift: [
					.1,
					-.18,
					.21
				],
				stretch: [
					1.13,
					.78,
					1.1
				]
			}],
			[.6, {
				armR: [
					-.7,
					-.3,
					-.05
				],
				armL: [
					-.4,
					.2,
					.55
				],
				motion: [
					.23,
					.18,
					-.08
				],
				shift: [
					.06,
					-.1,
					.15
				]
			}],
			[.82, {
				motion: [
					-.06,
					-.08,
					.04
				],
				head: [
					-.04,
					.05,
					0
				],
				shift: [
					-.02,
					.06,
					-.03
				]
			}]
		], {
			travel: .47,
			hold: 110
		}),
		clip("biscuit-4", 1.79, [
			[.17, {
				footL: [
					.9,
					.05,
					-.1
				],
				armR: [
					-1.65,
					.2,
					-.3
				],
				armL: [
					.25,
					-.1,
					.4
				],
				motion: [
					-.06,
					.2,
					-.08
				],
				shift: [
					.06,
					.16,
					-.04
				]
			}],
			[.35, {
				footL: [
					-.2,
					0,
					0
				],
				footR: [
					.85,
					-.05,
					.1
				],
				armL: [
					-1.6,
					-.2,
					.4
				],
				armR: [
					.25,
					.1,
					-.3
				],
				motion: [
					-.06,
					-.24,
					.1
				],
				shift: [
					-.08,
					.15,
					.07
				]
			}],
			[.52, {
				footL: [
					.7,
					.1,
					-.08
				],
				footR: [
					-.2,
					0,
					0
				],
				armR: [
					-2,
					.1,
					-.3
				],
				armL: [
					-.3,
					-.1,
					.4
				],
				motion: [
					.08,
					.2,
					-.06
				],
				shift: [
					.08,
					.13,
					.16
				]
			}],
			[.7, {
				armL: [
					-.9,
					-.1,
					1
				],
				armR: [
					-.9,
					.1,
					-1
				],
				motion: [
					.16,
					0,
					0
				],
				shift: [
					0,
					-.12,
					.12
				],
				stretch: [
					1.08,
					.84,
					1.08
				]
			}],
			[.88, {
				head: [
					-.08,
					0,
					0
				],
				armL: [
					-.25,
					0,
					.25
				],
				armR: [
					-.25,
					0,
					-.25
				],
				shift: [
					0,
					.04,
					.03
				]
			}]
		], {
			travel: .28,
			side: -.1,
			hold: 105
		})
	],
	inkcap: [
		clip("inkcap-1", 1.13, [
			[.19, {
				armL: [
					-1,
					-.5,
					1.1
				],
				armR: [
					-1,
					.5,
					-1.1
				],
				motion: [
					-.1,
					.14,
					-.05
				],
				head: [
					.08,
					-.1,
					.03
				],
				shift: [
					.06,
					.06,
					-.03
				]
			}],
			[.4, {
				armL: [
					-.75,
					-.7,
					1.5
				],
				armR: [
					-1.5,
					-.45,
					.2
				],
				motion: [
					.06,
					-.32,
					.12
				],
				head: [
					-.08,
					.14,
					-.02
				],
				shift: [
					-.13,
					-.035,
					.07
				]
			}],
			[.62, {
				armR: [
					-.4,
					.45,
					-1.5
				],
				armL: [
					-.8,
					-.3,
					.6
				],
				motion: [
					-.1,
					.22,
					-.08
				],
				shift: [
					.11,
					.05,
					.03
				]
			}],
			[.83, {
				armR: [
					-.2,
					.1,
					-.25
				],
				armL: [
					-.3,
					-.1,
					.2
				],
				shift: [
					-.02,
					.015,
					0
				]
			}]
		], {
			side: -.15,
			travel: .05
		}),
		clip("inkcap-2", 1.49, [
			[.21, {
				armL: [
					-1.8,
					-.3,
					.15
				],
				armR: [
					-.4,
					.1,
					-.4
				],
				head: [
					.2,
					-.13,
					-.03
				],
				motion: [
					.18,
					-.12,
					.05
				],
				shift: [
					-.04,
					-.06,
					-.02
				]
			}],
			[.42, {
				armL: [
					-1.6,
					-.15,
					.3
				],
				armR: [
					-1,
					.3,
					-1.5
				],
				head: [
					.07,
					.18,
					.04
				],
				motion: [
					.04,
					.24,
					-.1
				],
				shift: [
					.09,
					.035,
					.12
				]
			}],
			[.63, {
				armL: [
					-.8,
					-.3,
					.8
				],
				armR: [
					-.75,
					-.2,
					-1.05
				],
				head: [
					-.05,
					-.1,
					0
				],
				shift: [
					-.06,
					.07,
					.035
				]
			}],
			[.84, {
				armL: [
					-.35,
					-.1,
					.25
				],
				motion: [
					-.03,
					0,
					0
				],
				shift: [
					0,
					.02,
					0
				]
			}]
		]),
		clip("inkcap-3", 1.64, [
			[.2, {
				armL: [
					-.9,
					.5,
					-.3
				],
				armR: [
					-.9,
					-.5,
					.3
				],
				motion: [
					.27,
					0,
					0
				],
				head: [
					.25,
					0,
					0
				],
				shift: [
					0,
					-.13,
					.08
				],
				stretch: [
					1.08,
					.84,
					1.04
				]
			}],
			[.41, {
				armL: [
					-1.1,
					-.4,
					.8
				],
				armR: [
					-1.1,
					.4,
					-.8
				],
				motion: [
					.35,
					.1,
					-.05
				],
				head: [
					.13,
					-.08,
					0
				],
				shift: [
					.09,
					-.17,
					.17
				]
			}],
			[.64, {
				armL: [
					-1.75,
					-.2,
					1.2
				],
				armR: [
					-1.75,
					.2,
					-1.2
				],
				motion: [
					-.15,
					0,
					0
				],
				head: [
					-.13,
					0,
					0
				],
				shift: [
					0,
					.17,
					-.06
				],
				stretch: [
					.96,
					1.11,
					.97
				]
			}],
			[.84, {
				armL: [
					-.7,
					-.1,
					.4
				],
				armR: [
					-.7,
					.1,
					-.4
				],
				motion: [
					.04,
					0,
					0
				],
				shift: [
					0,
					-.025,
					0
				]
			}]
		], { hold: 90 }),
		clip("inkcap-4", 1.78, [
			[.18, {
				armL: [
					-1,
					.8,
					-.3
				],
				armR: [
					-1,
					-.8,
					.3
				],
				motion: [
					.1,
					.12,
					0
				],
				head: [
					.12,
					-.1,
					0
				],
				shift: [
					.02,
					-.065,
					0
				]
			}],
			[.39, {
				armL: [
					-2.5,
					.6,
					.3
				],
				armR: [
					-2.5,
					-.6,
					-.3
				],
				motion: [
					-.18,
					0,
					0
				],
				head: [
					-.18,
					0,
					0
				],
				shift: [
					0,
					.23,
					-.04
				],
				stretch: [
					.9,
					1.16,
					.94
				]
			}],
			[.59, {
				armL: [
					-2.2,
					-.4,
					1
				],
				armR: [
					-2.2,
					.4,
					-1
				],
				motion: [
					.08,
					-.15,
					.05
				],
				head: [
					.08,
					.12,
					-.02
				],
				shift: [
					-.07,
					.07,
					.03
				]
			}],
			[.77, {
				armL: [
					-1.35,
					-.3,
					1.4
				],
				armR: [
					-1.35,
					.3,
					-1.4
				],
				motion: [
					.17,
					.12,
					-.03
				],
				shift: [
					.06,
					-.14,
					.04
				],
				stretch: [
					1.05,
					.85,
					1.04
				]
			}],
			[.89, {
				armL: [
					-.4,
					-.1,
					.35
				],
				armR: [
					-.4,
					.1,
					-.35
				],
				shift: [
					0,
					.035,
					0
				]
			}]
		], {
			float: .07,
			hold: 105
		})
	],
	cinnamon: [
		clip("cinnamon-1", 1.11, [
			[.2, {
				armL: [
					-2,
					-.3,
					.35
				],
				armR: [
					-.3,
					.1,
					-.6
				],
				head: [
					.08,
					-.18,
					-.1
				],
				motion: [
					.04,
					-.15,
					.08
				],
				shift: [
					-.05,
					.045,
					-.02
				]
			}],
			[.43, {
				armL: [
					-1.5,
					.2,
					1.35
				],
				armR: [
					-.5,
					.3,
					-.5
				],
				head: [
					-.05,
					.15,
					.06
				],
				motion: [
					-.1,
					.2,
					-.08
				],
				shift: [
					.09,
					.12,
					.06
				]
			}],
			[.64, {
				armL: [
					-.7,
					-.6,
					.65
				],
				motion: [
					.12,
					-.1,
					.06
				],
				head: [
					.08,
					0,
					-.03
				],
				shift: [
					-.06,
					-.045,
					.11
				]
			}],
			[.83, {
				armL: [
					-.35,
					-.1,
					.15
				],
				armR: [
					-.2,
					.1,
					-.2
				],
				shift: [
					.015,
					.025,
					0
				]
			}]
		], {
			travel: .13,
			side: .06,
			arc: .03
		}),
		clip("cinnamon-2", 1.48, [
			[.19, {
				armL: [
					-.7,
					.35,
					.1
				],
				armR: [
					-.7,
					-.35,
					-.1
				],
				head: [
					.14,
					0,
					0
				],
				motion: [
					.1,
					0,
					0
				],
				shift: [
					0,
					-.05,
					-.03
				]
			}],
			[.41, {
				armL: [
					-1.15,
					-.25,
					.4
				],
				armR: [
					-1.15,
					.25,
					-.4
				],
				head: [
					.16,
					-.14,
					.05
				],
				motion: [
					.28,
					.12,
					-.06
				],
				shift: [
					.08,
					-.12,
					.23
				]
			}],
			[.65, {
				armL: [
					-1,
					-.2,
					.6
				],
				armR: [
					-.55,
					.15,
					-.2
				],
				head: [
					.08,
					.12,
					-.03
				],
				motion: [
					.12,
					-.08,
					.03
				],
				shift: [
					-.04,
					-.04,
					.12
				]
			}],
			[.84, {
				armL: [
					-.3,
					-.1,
					.2
				],
				armR: [
					-.25,
					.1,
					-.2
				],
				head: [
					-.04,
					0,
					0
				],
				shift: [
					0,
					.04,
					0
				]
			}]
		], { travel: .1 }),
		clip("cinnamon-3", 1.61, [
			[.18, {
				armR: [
					-2.1,
					.3,
					-.7
				],
				armL: [
					-.65,
					-.4,
					.6
				],
				motion: [
					-.08,
					-.2,
					.15
				],
				head: [
					-.12,
					.1,
					-.06
				],
				shift: [
					-.09,
					.09,
					-.02
				]
			}],
			[.39, {
				armR: [
					-1.2,
					-.65,
					.4
				],
				armL: [
					-.9,
					-.1,
					.4
				],
				motion: [
					.08,
					.25,
					-.15
				],
				head: [
					.05,
					-.16,
					.04
				],
				shift: [
					.11,
					-.04,
					.09
				]
			}],
			[.61, {
				armR: [
					-.4,
					.5,
					-1.1
				],
				armL: [
					-.5,
					-.3,
					.8
				],
				motion: [
					.18,
					-.25,
					.14
				],
				head: [
					.12,
					.12,
					-.04
				],
				shift: [
					-.13,
					-.09,
					.05
				]
			}],
			[.81, {
				armR: [
					-1,
					.1,
					-.3
				],
				motion: [
					-.06,
					.1,
					-.04
				],
				head: [
					-.04,
					-.05,
					0
				],
				shift: [
					.04,
					.07,
					0
				]
			}]
		], { side: .13 }),
		clip("cinnamon-4", 1.78, [
			[.18, {
				motion: [
					.3,
					0,
					0
				],
				head: [
					.2,
					0,
					0
				],
				armL: [
					-.8,
					-.1,
					.3
				],
				armR: [
					-.8,
					.1,
					-.3
				],
				footL: [
					.3,
					.1,
					0
				],
				shift: [
					0,
					-.22,
					.11
				],
				stretch: [
					1.12,
					.76,
					1.07
				]
			}],
			[.38, {
				motion: [
					.18,
					-.14,
					.05
				],
				armL: [
					-1.25,
					-.35,
					.7
				],
				armR: [
					-.45,
					.15,
					-.25
				],
				head: [
					.12,
					.1,
					0
				],
				shift: [
					-.07,
					-.12,
					.18
				]
			}],
			[.58, {
				motion: [
					-.13,
					.17,
					-.06
				],
				armL: [
					-2.15,
					-.1,
					.45
				],
				armR: [
					-.8,
					.25,
					-.9
				],
				head: [
					-.18,
					-.12,
					.05
				],
				shift: [
					.08,
					.2,
					.02
				],
				stretch: [
					.93,
					1.13,
					.97
				]
			}],
			[.77, {
				armL: [
					-1.7,
					-.35,
					1.1
				],
				armR: [
					-1,
					.15,
					-.6
				],
				motion: [
					-.06,
					0,
					0
				],
				head: [
					-.1,
					0,
					0
				],
				shift: [
					0,
					.09,
					.08
				]
			}],
			[.89, {
				armL: [
					-.5,
					-.1,
					.3
				],
				armR: [
					-.3,
					.1,
					-.3
				],
				shift: [
					0,
					-.025,
					0
				]
			}]
		], { hold: 110 })
	]
};
// apps/web/src/game/squad/turn3d/card-roster-batch3-motion.ts
var c$4 = (id, duration, keys, motion = {}) => ({
	id,
	duration,
	keys: [
		[0, {}],
		...keys,
		[1, {}]
	],
	travel: {
		travel: 0,
		arc: 0,
		float: 0,
		side: 0,
		hold: 75,
		...motion
	}
});
var BATCH3_SKILL_CLIPS = {
	brioche: [
		c$4("brioche-1", 1.13, [
			[.19, {
				armR: [
					-.15,
					.2,
					-1.35
				],
				armL: [
					-.6,
					-.3,
					.35
				],
				head: [
					.05,
					.12,
					-.03
				],
				motion: [
					.04,
					-.18,
					.14
				],
				shift: [
					-.09,
					-.04,
					-.02
				]
			}],
			[.39, {
				armR: [
					-.75,
					-.15,
					-.4
				],
				motion: [
					-.06,
					.14,
					-.09
				],
				head: [
					-.03,
					-.08,
					.04
				],
				shift: [
					.08,
					.05,
					.08
				]
			}],
			[.57, {
				armR: [
					-.25,
					.4,
					-1.6
				],
				armL: [
					-.7,
					-.1,
					.2
				],
				motion: [
					.08,
					-.23,
					.12
				],
				shift: [
					-.12,
					-.02,
					.04
				]
			}],
			[.78, {
				armR: [
					-.65,
					-.1,
					-.45
				],
				motion: [
					-.03,
					.1,
					-.06
				],
				shift: [
					.035,
					.035,
					.02
				]
			}]
		], {
			travel: .18,
			side: -.08
		}),
		c$4("brioche-2", 1.48, [
			[.2, {
				armL: [
					-1.2,
					.2,
					.2
				],
				armR: [
					-1.2,
					-.2,
					-.2
				],
				head: [
					.18,
					0,
					0
				],
				motion: [
					.12,
					0,
					0
				],
				shift: [
					0,
					-.07,
					.02
				]
			}],
			[.41, {
				armL: [
					-1.1,
					-.8,
					1.8
				],
				armR: [
					-1.1,
					.8,
					-1.8
				],
				head: [
					-.08,
					-.05,
					.02
				],
				motion: [
					-.07,
					.14,
					-.06
				],
				shift: [
					.04,
					.12,
					.02
				],
				stretch: [
					.96,
					1.08,
					.98
				]
			}],
			[.62, {
				armL: [
					-1.4,
					.1,
					.7
				],
				armR: [
					-.45,
					-.5,
					.3
				],
				head: [
					.1,
					.14,
					-.05
				],
				motion: [
					.25,
					-.22,
					.1
				],
				shift: [
					-.14,
					-.09,
					.18
				]
			}],
			[.83, {
				armL: [
					-.6,
					-.1,
					.3
				],
				armR: [
					-.4,
					.1,
					-.2
				],
				motion: [
					-.02,
					.05,
					0
				],
				shift: [
					.025,
					.035,
					0
				]
			}]
		], {
			travel: .07,
			side: -.09
		}),
		c$4("brioche-3", 1.63, [
			[.21, {
				armL: [
					-1.7,
					.65,
					-.35
				],
				armR: [
					-1.7,
					-.65,
					.35
				],
				head: [
					.15,
					0,
					0
				],
				motion: [
					.08,
					0,
					0
				],
				shift: [
					0,
					-.06,
					-.06
				]
			}],
			[.42, {
				armL: [
					-.4,
					-.6,
					1.65
				],
				armR: [
					-.4,
					.6,
					-1.65
				],
				motion: [
					-.18,
					.1,
					-.03
				],
				head: [
					-.13,
					-.08,
					0
				],
				shift: [
					.04,
					.18,
					.12
				],
				stretch: [
					.94,
					1.12,
					.98
				]
			}],
			[.6, {
				armL: [
					-.65,
					-.35,
					1
				],
				armR: [
					-.65,
					.35,
					-1
				],
				motion: [
					.16,
					-.15,
					.05
				],
				shift: [
					-.05,
					-.1,
					.07
				]
			}],
			[.82, {
				armL: [
					-.3,
					-.1,
					.35
				],
				armR: [
					-.3,
					.1,
					-.35
				],
				head: [
					.03,
					0,
					0
				],
				shift: [
					.01,
					.04,
					.02
				]
			}]
		], {
			travel: .14,
			hold: 100
		}),
		c$4("brioche-4", 1.79, [
			[.16, {
				armR: [
					-2.2,
					-.2,
					-.35
				],
				armL: [
					-.5,
					-.1,
					.3
				],
				head: [
					-.2,
					.12,
					.03
				],
				motion: [
					-.08,
					-.2,
					.1
				],
				shift: [
					-.08,
					.09,
					-.03
				]
			}],
			[.34, {
				armR: [
					-1.8,
					.4,
					-1.15
				],
				armL: [
					-1.6,
					-.3,
					.75
				],
				head: [
					-.12,
					-.15,
					-.03
				],
				motion: [
					-.1,
					.23,
					-.12
				],
				shift: [
					.1,
					.14,
					.03
				]
			}],
			[.53, {
				armR: [
					-.7,
					-.5,
					.15
				],
				armL: [
					-2.1,
					-.2,
					.3
				],
				head: [
					-.17,
					.08,
					.04
				],
				motion: [
					-.04,
					-.12,
					.05
				],
				shift: [
					-.06,
					.2,
					.06
				]
			}],
			[.72, {
				armL: [
					-.75,
					.35,
					.15
				],
				armR: [
					-.75,
					-.35,
					-.15
				],
				motion: [
					.22,
					0,
					0
				],
				head: [
					.15,
					0,
					0
				],
				shift: [
					0,
					-.13,
					.11
				],
				stretch: [
					1.08,
					.86,
					1.06
				]
			}],
			[.89, {
				armL: [
					-.45,
					-.1,
					.4
				],
				armR: [
					-.45,
					.1,
					-.4
				],
				head: [
					-.05,
					0,
					0
				],
				shift: [
					0,
					.045,
					0
				]
			}]
		], {
			float: .05,
			hold: 100
		})
	],
	velvet: [
		c$4("velvet-1", 1.1, [
			[.18, {
				armL: [
					-.25,
					-.8,
					.3
				],
				armR: [
					.3,
					.4,
					-.9
				],
				motion: [
					.06,
					.4,
					-.18
				],
				head: [
					0,
					-.17,
					.06
				],
				footL: [
					.25,
					.1,
					-.12
				],
				shift: [
					.13,
					-.05,
					-.06
				]
			}],
			[.4, {
				armL: [
					-1.45,
					.3,
					.15
				],
				armR: [
					-.15,
					.2,
					-1.1
				],
				motion: [
					.18,
					-.45,
					.16
				],
				head: [
					-.04,
					.18,
					-.05
				],
				shift: [
					-.18,
					-.11,
					.26
				],
				stretch: [
					1.08,
					.86,
					1.04
				]
			}],
			[.62, {
				armL: [
					-.5,
					-.6,
					.7
				],
				armR: [
					.15,
					.1,
					-.6
				],
				motion: [
					-.06,
					.25,
					-.1
				],
				shift: [
					.09,
					.06,
					-.02
				]
			}],
			[.83, {
				armL: [
					-.2,
					-.1,
					.15
				],
				motion: [
					.015,
					-.06,
					.03
				],
				shift: [
					-.02,
					-.015,
					.015
				]
			}]
		], {
			travel: .49,
			side: -.18,
			arc: .035
		}),
		c$4("velvet-2", 1.47, [
			[.17, {
				armR: [
					-1.1,
					.25,
					-.85
				],
				armL: [
					-.25,
					-.2,
					.2
				],
				motion: [
					-.1,
					-.22,
					.1
				],
				head: [
					-.13,
					.14,
					-.03
				],
				shift: [
					-.1,
					.08,
					-.02
				]
			}],
			[.35, {
				armL: [
					-1.85,
					-.2,
					.65
				],
				armR: [
					-.45,
					.1,
					-.3
				],
				motion: [
					-.14,
					.2,
					-.1
				],
				head: [
					-.16,
					-.13,
					.04
				],
				shift: [
					.11,
					.2,
					.02
				]
			}],
			[.55, {
				armL: [
					-.65,
					.4,
					.3
				],
				armR: [
					-1.75,
					-.35,
					-.35
				],
				motion: [
					.18,
					-.12,
					.05
				],
				head: [
					.08,
					.08,
					-.02
				],
				shift: [
					-.07,
					-.065,
					.17
				]
			}],
			[.78, {
				armL: [
					-.15,
					-.1,
					.45
				],
				armR: [
					-.5,
					.2,
					-.5
				],
				motion: [
					-.04,
					.1,
					-.03
				],
				shift: [
					.035,
					.06,
					.015
				]
			}]
		], {
			side: .12,
			arc: .08
		}),
		c$4("velvet-3", 1.62, [
			[.2, {
				armR: [
					-1.75,
					-.55,
					.25
				],
				armL: [
					.25,
					-.2,
					.8
				],
				motion: [
					.28,
					-.24,
					.12
				],
				head: [
					.1,
					.15,
					-.05
				],
				shift: [
					-.12,
					-.08,
					.22
				]
			}],
			[.42, {
				armR: [
					-1.6,
					.55,
					-.85
				],
				armL: [
					-.35,
					-.5,
					.55
				],
				motion: [
					-.18,
					.32,
					-.17
				],
				head: [
					-.12,
					-.12,
					.04
				],
				shift: [
					.15,
					.13,
					-.08
				]
			}],
			[.63, {
				armR: [
					-1.1,
					-.65,
					.2
				],
				armL: [
					-1.2,
					.6,
					-.15
				],
				motion: [
					.06,
					-.12,
					.04
				],
				head: [
					.13,
					0,
					0
				],
				shift: [
					-.035,
					-.04,
					.03
				]
			}],
			[.83, {
				armR: [
					-.3,
					.1,
					-.4
				],
				armL: [
					-.2,
					-.1,
					.4
				],
				motion: [
					-.03,
					.05,
					-.02
				],
				shift: [
					.02,
					.03,
					0
				]
			}]
		], {
			travel: .2,
			side: -.15,
			hold: 90
		}),
		c$4("velvet-4", 1.79, [
			[.18, {
				armL: [
					-2.35,
					-.3,
					1.2
				],
				armR: [
					-.25,
					.4,
					-1.4
				],
				motion: [
					-.13,
					.28,
					-.2
				],
				head: [
					-.12,
					-.15,
					.05
				],
				shift: [
					.12,
					.19,
					-.05
				],
				stretch: [
					.93,
					1.12,
					.96
				]
			}],
			[.39, {
				armL: [
					-.9,
					.6,
					-.3
				],
				armR: [
					-1.8,
					-.65,
					.3
				],
				motion: [
					.35,
					-.32,
					.2
				],
				head: [
					.2,
					.17,
					-.06
				],
				shift: [
					-.17,
					-.24,
					.17
				],
				stretch: [
					1.15,
					.74,
					1.1
				]
			}],
			[.6, {
				armL: [
					-1.9,
					-.7,
					1.5
				],
				armR: [
					-.7,
					.5,
					-1.1
				],
				motion: [
					-.12,
					.38,
					-.14
				],
				head: [
					-.1,
					-.18,
					.03
				],
				footR: [
					.7,
					.1,
					.1
				],
				shift: [
					.16,
					.24,
					.1
				]
			}],
			[.79, {
				armL: [
					-.5,
					-.2,
					.7
				],
				armR: [
					-1,
					.3,
					-.6
				],
				motion: [
					.12,
					-.17,
					.07
				],
				head: [
					.05,
					.1,
					0
				],
				shift: [
					-.065,
					-.07,
					.035
				]
			}],
			[.9, {
				head: [
					-.05,
					0,
					-.03
				],
				shift: [
					0,
					.035,
					0
				]
			}]
		], {
			travel: .4,
			side: .2,
			arc: .1,
			hold: 110
		})
	],
	marigold: [
		c$4("marigold-1", 1.13, [
			[.2, {
				armL: [
					-.6,
					-.1,
					.3
				],
				armR: [
					-.75,
					.25,
					-.5
				],
				motion: [
					.33,
					.1,
					-.05
				],
				head: [
					.22,
					-.08,
					.02
				],
				shift: [
					.07,
					-.18,
					.12
				],
				stretch: [
					1.1,
					.8,
					1.06
				]
			}],
			[.42, {
				armR: [
					-1.15,
					-.2,
					-.1
				],
				armL: [
					-.8,
					-.3,
					.5
				],
				motion: [
					.18,
					-.17,
					.08
				],
				head: [
					.08,
					.12,
					-.03
				],
				shift: [
					-.08,
					-.06,
					.21
				]
			}],
			[.64, {
				armR: [
					-1.75,
					.3,
					-.75
				],
				armL: [
					-.4,
					-.1,
					.3
				],
				motion: [
					-.12,
					.13,
					-.06
				],
				head: [
					-.14,
					-.1,
					.04
				],
				shift: [
					.055,
					.14,
					.02
				]
			}],
			[.83, {
				armR: [
					-.45,
					.1,
					-.35
				],
				motion: [
					.04,
					-.04,
					.02
				],
				shift: [
					0,
					-.015,
					.015
				]
			}]
		], { travel: .09 }),
		c$4("marigold-2", 1.48, [
			[.17, {
				armL: [
					-2.3,
					-.2,
					.85
				],
				armR: [
					-.35,
					.1,
					-.35
				],
				head: [
					-.22,
					-.12,
					-.08
				],
				motion: [
					-.12,
					-.15,
					.12
				],
				shift: [
					-.11,
					.15,
					0
				]
			}],
			[.39, {
				armL: [
					-1.2,
					.4,
					.25
				],
				armR: [
					-.6,
					.25,
					-.5
				],
				head: [
					.02,
					.18,
					.09
				],
				motion: [
					.1,
					.23,
					-.13
				],
				shift: [
					.12,
					-.055,
					.12
				]
			}],
			[.62, {
				armL: [
					-.9,
					-.25,
					1
				],
				armR: [
					-.2,
					.1,
					-.25
				],
				head: [
					-.08,
					-.18,
					-.1
				],
				motion: [
					-.03,
					-.1,
					.06
				],
				shift: [
					-.04,
					.075,
					.02
				]
			}],
			[.84, {
				armL: [
					-.35,
					-.1,
					.3
				],
				head: [
					.03,
					.03,
					.02
				],
				shift: [
					.015,
					.015,
					0
				]
			}]
		], { side: .08 }),
		c$4("marigold-3", 1.63, [
			[.18, {
				armL: [
					-.45,
					-.5,
					1
				],
				armR: [
					-.45,
					.5,
					-1
				],
				motion: [
					.12,
					.3,
					-.1
				],
				head: [
					.1,
					-.15,
					.04
				],
				shift: [
					.1,
					-.05,
					-.03
				]
			}],
			[.37, {
				armL: [
					-1.35,
					.3,
					.15
				],
				armR: [
					-1,
					-.5,
					.15
				],
				motion: [
					.2,
					-.25,
					.1
				],
				head: [
					.05,
					.15,
					-.04
				],
				shift: [
					-.12,
					-.12,
					.17
				]
			}],
			[.54, {
				armL: [
					-.7,
					-.6,
					1.25
				],
				armR: [
					-.8,
					.6,
					-1.1
				],
				motion: [
					-.08,
					.22,
					-.09
				],
				shift: [
					.11,
					.12,
					.04
				]
			}],
			[.7, {
				armL: [
					-1.45,
					.25,
					.2
				],
				armR: [
					-1.1,
					-.3,
					-.1
				],
				motion: [
					.16,
					-.18,
					.07
				],
				shift: [
					-.08,
					-.065,
					.15
				]
			}],
			[.87, {
				armL: [
					-.35,
					-.1,
					.3
				],
				armR: [
					-.35,
					.1,
					-.3
				],
				shift: [
					.015,
					.025,
					0
				]
			}]
		], {
			travel: .16,
			side: .06
		}),
		c$4("marigold-4", 1.78, [
			[.19, {
				armR: [
					-2.2,
					.55,
					-.8
				],
				armL: [
					-1.1,
					-.4,
					.6
				],
				motion: [
					-.15,
					-.3,
					.16
				],
				head: [
					-.15,
					.18,
					-.06
				],
				shift: [
					-.13,
					.16,
					-.04
				]
			}],
			[.4, {
				armR: [
					-1.8,
					-.3,
					-1.5
				],
				armL: [
					-.6,
					-.2,
					1.25
				],
				motion: [
					-.08,
					.3,
					-.18
				],
				head: [
					-.05,
					-.14,
					.08
				],
				shift: [
					.16,
					.19,
					.09
				]
			}],
			[.61, {
				armR: [
					-1.5,
					.3,
					-.8
				],
				armL: [
					-1.4,
					-.4,
					.5
				],
				motion: [
					.1,
					-.2,
					.08
				],
				head: [
					.08,
					.12,
					-.04
				],
				shift: [
					-.1,
					.05,
					.15
				]
			}],
			[.78, {
				armL: [
					-.65,
					-.1,
					.35
				],
				armR: [
					-.65,
					.1,
					-.35
				],
				motion: [
					.3,
					0,
					0
				],
				head: [
					.2,
					0,
					0
				],
				shift: [
					0,
					-.16,
					.11
				],
				stretch: [
					1.08,
					.84,
					1.05
				]
			}],
			[.9, {
				motion: [
					-.04,
					0,
					0
				],
				head: [
					-.04,
					0,
					0
				],
				shift: [
					0,
					.045,
					0
				]
			}]
		], {
			float: .03,
			hold: 100
		})
	]
};
// apps/web/src/game/squad/turn3d/card-enemy-batch1-motion.ts
var c$3 = (id, keys, motion = {}) => ({
	id,
	duration: 1.3,
	keys: [
		[0, {}],
		...keys,
		[1, {}]
	],
	travel: {
		travel: 0,
		arc: 0,
		float: 0,
		side: 0,
		hold: 60,
		...motion
	}
});
/** Each basic and signature has its own centre of gravity and hand action. */
var ENEMY_BATCH1_CLIPS = {
	"button-guard": [c$3("enemy:button-guard:basic", [
		[.19, {
			motion: [
				.06,
				-.28,
				.08
			],
			head: [
				.08,
				.1,
				-.03
			],
			armR: [
				-.45,
				.2,
				-1.1
			],
			armL: [
				-.8,
				-.2,
				.3
			],
			shift: [
				-.05,
				-.04,
				-.04
			]
		}],
		[.42, {
			motion: [
				-.06,
				.32,
				-.11
			],
			armR: [
				-1.4,
				-.15,
				-.15
			],
			armL: [
				-.7,
				-.3,
				.2
			],
			shift: [
				.08,
				.05,
				.16
			]
		}],
		[.56, {
			motion: [
				.1,
				-.12,
				.03
			],
			armR: [
				-.3,
				.3,
				-.8
			],
			head: [
				.07,
				-.07,
				0
			],
			shift: [
				-.04,
				-.03,
				.04
			]
		}],
		[.79, {
			armR: [
				-.2,
				0,
				-.25
			],
			armL: [
				-.2,
				0,
				.2
			],
			shift: [
				0,
				.025,
				0
			]
		}]
	], {
		travel: .2,
		side: .08
	}), c$3("enemy:button-guard", [
		[.21, {
			motion: [
				.24,
				.02,
				0
			],
			head: [
				.17,
				0,
				0
			],
			armL: [
				-1.05,
				.65,
				-.25
			],
			armR: [
				-1.05,
				-.65,
				.25
			],
			shift: [
				0,
				-.16,
				-.06
			],
			stretch: [
				1.12,
				.8,
				1.08
			]
		}],
		[.43, {
			motion: [
				-.14,
				0,
				0
			],
			head: [
				-.09,
				0,
				0
			],
			armL: [
				-1.45,
				-.3,
				.65
			],
			armR: [
				-1.45,
				.3,
				-.65
			],
			shift: [
				0,
				.14,
				.1
			],
			stretch: [
				.96,
				1.1,
				1.02
			]
		}],
		[.61, {
			motion: [
				.13,
				0,
				0
			],
			armL: [
				-.7,
				-.5,
				1.05
			],
			armR: [
				-.7,
				.5,
				-1.05
			],
			shift: [
				0,
				-.1,
				.03
			]
		}],
		[.82, {
			motion: [
				-.04,
				0,
				0
			],
			head: [
				-.03,
				0,
				0
			],
			armL: [
				-.3,
				-.1,
				.35
			],
			armR: [
				-.3,
				.1,
				-.35
			],
			shift: [
				0,
				.04,
				0
			]
		}]
	], { hold: 95 })],
	"sock-skipper": [c$3("enemy:sock-skipper:basic", [
		[.18, {
			motion: [
				.12,
				-.38,
				-.16
			],
			head: [
				0,
				.16,
				.05
			],
			footR: [
				-.8,
				0,
				.12
			],
			armL: [
				.3,
				-.3,
				.8
			],
			armR: [
				-.4,
				.2,
				-.2
			],
			shift: [
				-.1,
				-.06,
				-.02
			]
		}],
		[.41, {
			motion: [
				-.18,
				.27,
				.22
			],
			head: [
				-.05,
				-.1,
				-.06
			],
			footR: [
				1.2,
				.1,
				-.12
			],
			armL: [
				-.6,
				-.2,
				.35
			],
			armR: [
				.6,
				.1,
				-.7
			],
			shift: [
				.13,
				.11,
				.16
			]
		}],
		[.59, {
			motion: [
				.12,
				-.1,
				-.08
			],
			footR: [
				.25,
				0,
				0
			],
			footL: [
				-.3,
				0,
				0
			],
			shift: [
				-.03,
				-.035,
				.04
			]
		}],
		[.8, {
			motion: [
				-.03,
				.05,
				.04
			],
			armL: [
				-.2,
				0,
				.25
			],
			armR: [
				-.2,
				0,
				-.25
			],
			shift: [
				0,
				.025,
				0
			]
		}]
	], {
		travel: .32,
		side: -.14
	}), c$3("enemy:sock-skipper", [
		[.16, {
			motion: [
				.25,
				.2,
				-.2
			],
			head: [
				.13,
				-.1,
				.04
			],
			armL: [
				-1.2,
				.4,
				-.3
			],
			armR: [
				-1.2,
				-.4,
				.3
			],
			shift: [
				0,
				-.18,
				-.08
			],
			stretch: [
				1.12,
				.78,
				1.06
			]
		}],
		[.36, {
			motion: [
				-.15,
				-.55,
				.32
			],
			head: [
				-.08,
				.2,
				-.08
			],
			armL: [
				-1.6,
				-.3,
				1.4
			],
			armR: [
				.4,
				.25,
				-1.1
			],
			footL: [
				.9,
				0,
				-.15
			],
			footR: [
				-.7,
				0,
				.2
			],
			shift: [
				-.16,
				.34,
				.12
			],
			stretch: [
				.92,
				1.13,
				.96
			]
		}],
		[.55, {
			motion: [
				.18,
				.35,
				-.18
			],
			armL: [
				-1.6,
				.65,
				-.25
			],
			armR: [
				-.45,
				-.1,
				-.2
			],
			shift: [
				.14,
				-.14,
				.19
			],
			stretch: [
				1.08,
				.84,
				1.04
			]
		}],
		[.76, {
			motion: [
				-.06,
				-.13,
				.06
			],
			head: [
				-.04,
				.05,
				0
			],
			armL: [
				-.4,
				.1,
				.3
			],
			shift: [
				-.035,
				.08,
				.02
			]
		}]
	], {
		travel: .6,
		arc: .2,
		side: -.26,
		hold: 40
	})],
	"spool-ram": [c$3("enemy:spool-ram:basic", [
		[.2, {
			motion: [
				.12,
				.34,
				-.16
			],
			armL: [
				-.2,
				-.6,
				1.1
			],
			armR: [
				-.65,
				.2,
				-.3
			],
			head: [
				.12,
				-.12,
				.04
			],
			shift: [
				.1,
				-.05,
				-.06
			]
		}],
		[.43, {
			motion: [
				-.14,
				-.32,
				.18
			],
			armL: [
				-1.2,
				.3,
				.35
			],
			armR: [
				-.6,
				.1,
				-.45
			],
			head: [
				-.1,
				.1,
				-.04
			],
			shift: [
				-.12,
				.06,
				.17
			]
		}],
		[.61, {
			motion: [
				.1,
				.15,
				-.08
			],
			armL: [
				-.4,
				-.2,
				.8
			],
			shift: [
				.05,
				-.04,
				.06
			]
		}],
		[.82, {
			motion: [
				-.035,
				-.05,
				.02
			],
			head: [
				-.025,
				0,
				0
			],
			armL: [
				-.2,
				0,
				.3
			],
			shift: [
				0,
				.025,
				0
			]
		}]
	], {
		travel: .28,
		side: .15,
		hold: 65
	}), c$3("enemy:spool-ram", [
		[.22, {
			motion: [
				.42,
				0,
				0
			],
			head: [
				.3,
				0,
				0
			],
			armL: [
				.5,
				-.1,
				.35
			],
			armR: [
				.5,
				.1,
				-.35
			],
			shift: [
				0,
				-.18,
				-.24
			],
			stretch: [
				1.13,
				.79,
				1.12
			]
		}],
		[.42, {
			motion: [
				-.32,
				0,
				0
			],
			head: [
				-.2,
				0,
				0
			],
			armL: [
				-1.15,
				-.2,
				.25
			],
			armR: [
				-1.15,
				.2,
				-.25
			],
			shift: [
				0,
				.13,
				.33
			],
			stretch: [
				.92,
				1.08,
				1.13
			]
		}],
		[.56, {
			motion: [
				.22,
				.16,
				-.07
			],
			head: [
				.16,
				-.08,
				.02
			],
			armL: [
				.2,
				0,
				.4
			],
			armR: [
				-.6,
				0,
				-.6
			],
			shift: [
				.08,
				-.13,
				.07
			]
		}],
		[.69, {
			motion: [
				-.2,
				-.18,
				.08
			],
			head: [
				-.12,
				.08,
				-.02
			],
			armL: [
				-.8,
				-.2,
				.7
			],
			armR: [
				-.95,
				.2,
				-.25
			],
			shift: [
				-.06,
				.09,
				.23
			]
		}],
		[.86, {
			motion: [
				.06,
				0,
				0
			],
			shift: [
				0,
				.03,
				-.03
			]
		}]
	], {
		travel: .58,
		hold: 100
	})]
};
// apps/web/src/game/squad/turn3d/card-enemy-batch2-motion.ts
var c$2 = (id, keys, travel = {}) => ({
	id,
	duration: 1.34,
	keys: [
		[0, {}],
		...keys,
		[1, {}]
	],
	travel: {
		travel: 0,
		arc: 0,
		float: 0,
		side: 0,
		hold: 60,
		...travel
	}
});
/** Pinch, pour and polish: three different sources of force and release. */
var ENEMY_BATCH2_CLIPS = {
	"needle-moth": [c$2("enemy:needle-moth:basic", [
		[.18, {
			motion: [
				.1,
				-.28,
				.1
			],
			head: [
				.08,
				.12,
				-.04
			],
			armL: [
				-1.1,
				-.5,
				.8
			],
			armR: [
				-1.8,
				.5,
				-.2
			],
			wingL: [
				0,
				-.5,
				.2
			],
			wingR: [
				0,
				.5,
				-.2
			],
			shift: [
				-.08,
				-.05,
				-.04
			]
		}],
		[.39, {
			motion: [
				-.12,
				.2,
				-.12
			],
			armL: [
				-1.1,
				-.3,
				1.2
			],
			armR: [
				-.7,
				-.3,
				-1.3
			],
			head: [
				-.06,
				-.1,
				.02
			],
			wingL: [
				0,
				.4,
				-.12
			],
			wingR: [
				0,
				-.4,
				.12
			],
			shift: [
				.1,
				.13,
				.1
			]
		}],
		[.62, {
			motion: [
				.08,
				-.08,
				.05
			],
			armR: [
				-.25,
				.3,
				-.4
			],
			shift: [
				-.025,
				.06,
				.02
			]
		}],
		[.83, {
			motion: [
				-.02,
				0,
				0
			],
			armL: [
				-.25,
				0,
				.2
			],
			shift: [
				0,
				.025,
				0
			]
		}]
	], {
		float: .1,
		side: .12
	}), c$2("enemy:needle-moth", [
		[.2, {
			motion: [
				.18,
				0,
				0
			],
			head: [
				.16,
				0,
				0
			],
			armL: [
				-1.8,
				.6,
				-.3
			],
			armR: [
				-1.8,
				-.6,
				.3
			],
			wingL: [
				0,
				-.9,
				.25
			],
			wingR: [
				0,
				.9,
				-.25
			],
			shift: [
				0,
				-.1,
				-.06
			]
		}],
		[.4, {
			motion: [
				-.24,
				0,
				0
			],
			head: [
				-.17,
				0,
				0
			],
			armL: [
				-2.3,
				-.4,
				1.3
			],
			armR: [
				-2.3,
				.4,
				-1.3
			],
			wingL: [
				0,
				.7,
				-.2
			],
			wingR: [
				0,
				-.7,
				.2
			],
			shift: [
				0,
				.3,
				.06
			],
			stretch: [
				.94,
				1.12,
				.96
			]
		}],
		[.57, {
			motion: [
				.27,
				.1,
				-.05
			],
			head: [
				.13,
				-.07,
				.025
			],
			armL: [
				-.5,
				-.35,
				.4
			],
			armR: [
				-.5,
				.35,
				-.4
			],
			wingL: [
				0,
				-.65,
				.15
			],
			wingR: [
				0,
				.65,
				-.15
			],
			shift: [
				.04,
				-.05,
				.18
			]
		}],
		[.79, {
			motion: [
				-.08,
				-.06,
				.025
			],
			armL: [
				-.4,
				0,
				.3
			],
			armR: [
				-.4,
				0,
				-.3
			],
			wingL: [
				0,
				.15,
				0
			],
			wingR: [
				0,
				-.15,
				0
			],
			shift: [
				-.02,
				.1,
				0
			]
		}]
	], {
		float: .19,
		hold: 80
	})],
	"teacup-healer": [c$2("enemy:teacup-healer:basic", [
		[.2, {
			motion: [
				.12,
				-.2,
				.18
			],
			head: [
				.05,
				.14,
				-.08
			],
			armL: [
				-.55,
				-.1,
				.5
			],
			armR: [
				-1,
				.45,
				-.1
			],
			shift: [
				-.08,
				-.06,
				-.04
			]
		}],
		[.43, {
			motion: [
				-.1,
				.25,
				-.24
			],
			head: [
				-.05,
				-.12,
				.08
			],
			armL: [
				-.9,
				-.1,
				.6
			],
			armR: [
				-.6,
				-.4,
				-1.1
			],
			shift: [
				.14,
				.08,
				.14
			]
		}],
		[.63, {
			motion: [
				.06,
				-.1,
				.1
			],
			armR: [
				-.8,
				.2,
				-.4
			],
			shift: [
				-.03,
				-.035,
				.045
			]
		}],
		[.82, {
			head: [
				-.04,
				0,
				0
			],
			motion: [
				-.03,
				0,
				0
			],
			shift: [
				0,
				.025,
				0
			]
		}]
	], {
		travel: .14,
		side: .16
	}), c$2("enemy:teacup-healer", [
		[.22, {
			motion: [
				.12,
				.18,
				-.08
			],
			head: [
				.17,
				-.12,
				.04
			],
			armL: [
				-.7,
				.35,
				.1
			],
			armR: [
				-.7,
				-.35,
				-.1
			],
			shift: [
				.04,
				-.08,
				-.04
			],
			stretch: [
				1.04,
				.94,
				1.02
			]
		}],
		[.44, {
			motion: [
				.1,
				-.12,
				.35
			],
			head: [
				.03,
				.1,
				-.14
			],
			armL: [
				-1.15,
				-.15,
				.8
			],
			armR: [
				-1.45,
				.1,
				-.6
			],
			shift: [
				-.16,
				.06,
				.13
			]
		}],
		[.63, {
			motion: [
				.02,
				-.05,
				.2
			],
			head: [
				-.08,
				.04,
				-.08
			],
			armL: [
				-1,
				-.1,
				.6
			],
			armR: [
				-1.2,
				0,
				-.4
			],
			shift: [
				-.1,
				.04,
				.09
			]
		}],
		[.82, {
			motion: [
				-.08,
				.08,
				-.08
			],
			head: [
				-.1,
				-.04,
				.04
			],
			armL: [
				-.4,
				-.1,
				.3
			],
			armR: [
				-.4,
				.1,
				-.3
			],
			shift: [
				.035,
				.055,
				0
			]
		}]
	], {
		travel: .04,
		hold: 20
	})],
	"kettle-knight": [c$2("enemy:kettle-knight:basic", [
		[.18, {
			motion: [
				.14,
				.35,
				-.1
			],
			head: [
				.1,
				-.15,
				.04
			],
			armL: [
				-.9,
				-.35,
				.55
			],
			armR: [
				.3,
				.2,
				-.75
			],
			shift: [
				.09,
				-.06,
				-.08
			]
		}],
		[.4, {
			motion: [
				-.12,
				-.28,
				.12
			],
			head: [
				-.08,
				.1,
				-.04
			],
			armL: [
				-.8,
				-.2,
				.35
			],
			armR: [
				-1.5,
				-.35,
				-.2
			],
			shift: [
				-.12,
				.08,
				.19
			]
		}],
		[.61, {
			motion: [
				.1,
				.12,
				-.05
			],
			armR: [
				-.4,
				.2,
				-.6
			],
			shift: [
				.035,
				-.025,
				.04
			]
		}],
		[.82, {
			motion: [
				-.035,
				0,
				0
			],
			head: [
				-.02,
				0,
				0
			],
			armL: [
				-.3,
				0,
				.2
			],
			shift: [
				0,
				.03,
				0
			]
		}]
	], {
		travel: .26,
		hold: 75
	}), c$2("enemy:kettle-knight", [
		[.21, {
			motion: [
				.19,
				-.16,
				.08
			],
			head: [
				.14,
				.1,
				-.03
			],
			armL: [
				-1.1,
				-.2,
				1.1
			],
			armR: [
				-1.5,
				.7,
				.15
			],
			shift: [
				-.08,
				-.13,
				-.04
			],
			stretch: [
				1.08,
				.85,
				1.06
			]
		}],
		[.42, {
			motion: [
				-.19,
				.1,
				-.05
			],
			head: [
				-.13,
				-.07,
				.03
			],
			armL: [
				-1.9,
				-.3,
				.8
			],
			armR: [
				-1.25,
				-.5,
				-.4
			],
			shift: [
				.05,
				.2,
				.07
			],
			stretch: [
				.94,
				1.14,
				.96
			]
		}],
		[.61, {
			motion: [
				.08,
				.15,
				-.08
			],
			head: [
				-.03,
				-.1,
				.03
			],
			armL: [
				-1.4,
				-.2,
				1.2
			],
			armR: [
				-.6,
				.3,
				-.9
			],
			shift: [
				.08,
				-.05,
				.02
			]
		}],
		[.81, {
			motion: [
				-.06,
				-.05,
				.02
			],
			armL: [
				-.45,
				-.1,
				.35
			],
			armR: [
				-.35,
				.1,
				-.25
			],
			shift: [
				-.02,
				.04,
				0
			]
		}]
	], { hold: 100 })]
};
// apps/web/src/game/squad/turn3d/card-enemy-batch3-motion.ts
var c$1 = (id, keys, travel = {}) => ({
	id,
	duration: 1.32,
	keys: [
		[0, {}],
		...keys,
		[1, {}]
	],
	travel: {
		travel: 0,
		arc: 0,
		float: 0,
		side: 0,
		hold: 60,
		...travel
	}
});
var ENEMY_BATCH3_CLIPS = {
	"binding-thread": [c$1("enemy:binding-thread:basic", [
		[.2, {
			motion: [
				.15,
				-.25,
				-.12
			],
			head: [
				.1,
				.16,
				.04
			],
			armL: [
				-1.3,
				-.3,
				1
			],
			armR: [
				-.4,
				.3,
				-.4
			],
			shift: [
				-.11,
				-.06,
				.1
			]
		}],
		[.43, {
			motion: [
				-.18,
				.38,
				.18
			],
			head: [
				-.1,
				-.14,
				-.05
			],
			armL: [
				-1.8,
				.6,
				-.3
			],
			armR: [
				-.9,
				-.3,
				.2
			],
			shift: [
				.15,
				.12,
				-.13
			]
		}],
		[.64, {
			motion: [
				.1,
				-.13,
				-.07
			],
			armL: [
				-.6,
				-.1,
				.4
			],
			head: [
				.07,
				.08,
				.02
			],
			shift: [
				-.035,
				-.04,
				.04
			]
		}],
		[.83, {
			motion: [
				-.03,
				.03,
				.02
			],
			shift: [
				0,
				.025,
				0
			]
		}]
	], {
		travel: .16,
		side: -.18
	}), c$1("enemy:binding-thread", [
		[.18, {
			motion: [
				.08,
				.16,
				-.08
			],
			armL: [
				-1.5,
				.65,
				-.2
			],
			armR: [
				-.7,
				-.45,
				.3
			],
			shift: [
				.06,
				.04,
				-.04
			]
		}],
		[.38, {
			motion: [
				-.16,
				-.2,
				.11
			],
			armL: [
				-.7,
				-.45,
				.9
			],
			armR: [
				-1.9,
				.5,
				-.15
			],
			head: [
				-.08,
				.14,
				-.04
			],
			shift: [
				-.1,
				.18,
				.02
			]
		}],
		[.57, {
			motion: [
				.28,
				0,
				0
			],
			armL: [
				-.9,
				-.5,
				1.35
			],
			armR: [
				-.9,
				.5,
				-1.35
			],
			head: [
				.18,
				0,
				0
			],
			shift: [
				0,
				-.18,
				.19
			],
			stretch: [
				1.1,
				.8,
				1.06
			]
		}],
		[.78, {
			motion: [
				-.09,
				.08,
				-.04
			],
			armL: [
				-.4,
				-.1,
				.3
			],
			armR: [
				-.4,
				.1,
				-.3
			],
			shift: [
				.04,
				.07,
				0
			]
		}]
	], {
		travel: .1,
		hold: 85
	})],
	"practice-cushion": [c$1("enemy:practice-cushion:basic", [
		[.2, {
			motion: [
				.08,
				.1,
				-.2
			],
			head: [
				.1,
				-.05,
				.08
			],
			armL: [
				-.3,
				-.1,
				1
			],
			armR: [
				-.3,
				.1,
				-1
			],
			footL: [
				.5,
				0,
				-.1
			],
			shift: [
				-.12,
				-.12,
				-.03
			],
			stretch: [
				1.1,
				.82,
				1.08
			]
		}],
		[.43, {
			motion: [
				-.12,
				-.1,
				.18
			],
			head: [
				-.07,
				.05,
				-.05
			],
			footL: [
				-.4,
				0,
				0
			],
			footR: [
				.7,
				0,
				.12
			],
			shift: [
				.13,
				.27,
				.14
			],
			stretch: [
				.92,
				1.15,
				.94
			]
		}],
		[.61, {
			motion: [
				.08,
				.04,
				-.07
			],
			shift: [
				-.03,
				-.1,
				.04
			],
			stretch: [
				1.08,
				.85,
				1.05
			]
		}],
		[.82, {
			motion: [
				-.025,
				0,
				.02
			],
			armL: [
				-.2,
				0,
				.2
			],
			armR: [
				-.2,
				0,
				-.2
			],
			shift: [
				0,
				.06,
				0
			]
		}]
	], {
		travel: .23,
		arc: .06,
		side: .1,
		hold: 20
	}), c$1("enemy:practice-cushion", [
		[.2, {
			motion: [
				.3,
				0,
				0
			],
			head: [
				.2,
				0,
				0
			],
			armL: [
				-.8,
				.5,
				-.2
			],
			armR: [
				-.8,
				-.5,
				.2
			],
			shift: [
				0,
				-.22,
				-.08
			],
			stretch: [
				1.2,
				.67,
				1.16
			]
		}],
		[.39, {
			motion: [
				-.18,
				0,
				0
			],
			head: [
				-.1,
				0,
				0
			],
			armL: [
				-1.6,
				-.35,
				1.4
			],
			armR: [
				-1.6,
				.35,
				-1.4
			],
			shift: [
				0,
				.35,
				.12
			],
			stretch: [
				.86,
				1.24,
				.9
			]
		}],
		[.55, {
			motion: [
				.15,
				0,
				0
			],
			armL: [
				-.6,
				-.1,
				.7
			],
			armR: [
				-.6,
				.1,
				-.7
			],
			shift: [
				0,
				-.19,
				.22
			],
			stretch: [
				1.15,
				.73,
				1.12
			]
		}],
		[.71, {
			motion: [
				-.1,
				0,
				0
			],
			head: [
				-.08,
				0,
				0
			],
			shift: [
				0,
				.17,
				.08
			],
			stretch: [
				.95,
				1.08,
				.95
			]
		}],
		[.86, {
			shift: [
				0,
				-.05,
				0
			],
			stretch: [
				1.03,
				.94,
				1.02
			]
		}]
	], {
		travel: .35,
		arc: .09,
		hold: 30
	})],
	"pollen-scout": [c$1("enemy:pollen-scout:basic", [
		[.18, {
			motion: [
				.16,
				.26,
				.12
			],
			armR: [
				-.3,
				.5,
				-1.2
			],
			armL: [
				-.7,
				-.15,
				.3
			],
			head: [
				.12,
				-.12,
				-.04
			],
			shift: [
				.1,
				-.08,
				-.04
			]
		}],
		[.4, {
			motion: [
				-.17,
				-.22,
				-.15
			],
			armR: [
				-2.1,
				-.2,
				-.4
			],
			armL: [
				-.5,
				-.3,
				.7
			],
			head: [
				-.12,
				.1,
				.05
			],
			shift: [
				-.12,
				.18,
				.09
			]
		}],
		[.59, {
			motion: [
				.12,
				.12,
				.05
			],
			armR: [
				-.8,
				.3,
				-.8
			],
			shift: [
				.045,
				-.05,
				.14
			]
		}],
		[.8, {
			motion: [
				-.04,
				-.05,
				-.02
			],
			armR: [
				-.25,
				.1,
				-.2
			],
			shift: [
				-.02,
				.04,
				0
			]
		}]
	], {
		float: .06,
		side: .12
	}), c$1("enemy:pollen-scout", [
		[.21, {
			motion: [
				.35,
				0,
				0
			],
			head: [
				.26,
				0,
				0
			],
			armL: [
				-.85,
				-.1,
				.3
			],
			armR: [
				-.9,
				.1,
				-.3
			],
			footL: [
				.4,
				0,
				0
			],
			shift: [
				0,
				-.24,
				.14
			],
			stretch: [
				1.08,
				.78,
				1.05
			]
		}],
		[.41, {
			motion: [
				.22,
				-.16,
				.05
			],
			head: [
				.15,
				.1,
				-.02
			],
			armL: [
				-1.3,
				.3,
				.1
			],
			armR: [
				-1.15,
				-.3,
				-.1
			],
			shift: [
				-.06,
				-.16,
				.22
			]
		}],
		[.62, {
			motion: [
				-.22,
				.12,
				-.06
			],
			head: [
				-.17,
				-.08,
				.03
			],
			armL: [
				-2,
				-.3,
				1.05
			],
			armR: [
				-2,
				.3,
				-1.05
			],
			shift: [
				.05,
				.24,
				.01
			],
			stretch: [
				.91,
				1.16,
				.94
			]
		}],
		[.83, {
			motion: [
				-.05,
				0,
				0
			],
			head: [
				-.04,
				0,
				0
			],
			armL: [
				-.6,
				-.1,
				.4
			],
			armR: [
				-.6,
				.1,
				-.4
			],
			shift: [
				0,
				.07,
				0
			]
		}]
	], { hold: 100 })]
};
// apps/web/src/game/squad/turn3d/card-enemy-batch4-motion.ts
var ENEMY_BATCH4_CLIPS = { "crumb-sentinel": [{
	id: "enemy:crumb-sentinel:basic",
	duration: 1.27,
	travel: {
		travel: .18,
		arc: 0,
		float: 0,
		side: .12,
		hold: 65
	},
	keys: [
		[0, {}],
		[.2, {
			motion: [
				.13,
				-.3,
				.1
			],
			head: [
				.1,
				.16,
				-.04
			],
			armL: [
				-.7,
				-.4,
				.7
			],
			armR: [
				-1.1,
				.5,
				-.1
			],
			shift: [
				-.08,
				-.06,
				-.06
			]
		}],
		[.43, {
			motion: [
				-.12,
				.3,
				-.12
			],
			head: [
				-.08,
				-.1,
				.04
			],
			armR: [
				-1.5,
				-.3,
				-.9
			],
			armL: [
				-.6,
				-.1,
				.35
			],
			shift: [
				.12,
				.09,
				.17
			]
		}],
		[.63, {
			motion: [
				.1,
				-.15,
				.05
			],
			armR: [
				-.6,
				.2,
				-.4
			],
			shift: [
				-.04,
				-.04,
				.04
			]
		}],
		[.83, {
			motion: [
				-.03,
				.04,
				0
			],
			head: [
				-.03,
				0,
				0
			],
			shift: [
				0,
				.03,
				0
			]
		}],
		[1, {}]
	]
}, {
	id: "enemy:crumb-sentinel",
	duration: 1.36,
	travel: {
		travel: .06,
		arc: 0,
		float: 0,
		side: 0,
		hold: 100
	},
	keys: [
		[0, {}],
		[.18, {
			motion: [
				.23,
				-.2,
				.06
			],
			head: [
				.14,
				.12,
				-.03
			],
			armL: [
				-.7,
				-.6,
				1.2
			],
			armR: [
				-.7,
				.6,
				-1.2
			],
			shift: [
				-.07,
				-.12,
				.04
			],
			stretch: [
				1.08,
				.87,
				1.06
			]
		}],
		[.37, {
			motion: [
				-.17,
				.1,
				-.04
			],
			head: [
				-.12,
				-.05,
				.02
			],
			armL: [
				-2.1,
				.4,
				-.15
			],
			armR: [
				-2.1,
				-.4,
				.15
			],
			shift: [
				.03,
				.2,
				-.04
			],
			stretch: [
				.94,
				1.12,
				.97
			]
		}],
		[.52, {
			motion: [
				.28,
				0,
				0
			],
			head: [
				.15,
				0,
				0
			],
			armL: [
				-.85,
				.2,
				.2
			],
			armR: [
				-.85,
				-.2,
				-.2
			],
			shift: [
				0,
				-.16,
				.2
			],
			stretch: [
				1.13,
				.81,
				1.08
			]
		}],
		[.68, {
			motion: [
				-.14,
				.12,
				-.06
			],
			armL: [
				-1.25,
				-.3,
				1.45
			],
			armR: [
				-1.25,
				.3,
				-1.45
			],
			head: [
				-.1,
				-.08,
				.03
			],
			shift: [
				.05,
				.13,
				.03
			]
		}],
		[.86, {
			motion: [
				.05,
				0,
				0
			],
			armL: [
				-.35,
				-.1,
				.3
			],
			armR: [
				-.35,
				.1,
				-.3
			],
			shift: [
				0,
				-.03,
				0
			]
		}],
		[1, {}]
	]
}] };
// apps/web/src/game/squad/turn3d/card-boss-motion.ts
var c = (id, keys, travel = {}) => ({
	id,
	duration: 1.38,
	keys: [
		[0, {}],
		...keys,
		[1, {}]
	],
	travel: {
		travel: 0,
		arc: 0,
		float: 0,
		side: 0,
		hold: 100,
		...travel
	}
});
var BOSS_SKILL_CLIPS = {
	"yarn-giant": [c("enemy:yarn-giant:basic", [
		[.19, {
			motion: [
				.13,
				-.33,
				.12
			],
			head: [
				.1,
				.12,
				-.03
			],
			armL: [
				-1.15,
				-.5,
				1
			],
			armR: [
				-.6,
				.2,
				-.3
			],
			shift: [
				-.1,
				-.07,
				-.07
			]
		}],
		[.42, {
			motion: [
				-.14,
				.32,
				-.14
			],
			head: [
				-.08,
				-.13,
				.04
			],
			armL: [
				-.6,
				.55,
				-.25
			],
			armR: [
				-1.3,
				.1,
				-.8
			],
			shift: [
				.14,
				.1,
				.2
			]
		}],
		[.62, {
			motion: [
				.1,
				-.13,
				.06
			],
			armL: [
				-.9,
				-.15,
				.6
			],
			shift: [
				-.05,
				-.04,
				.04
			]
		}],
		[.83, {
			motion: [
				-.03,
				.04,
				0
			],
			shift: [
				0,
				.04,
				0
			]
		}]
	], {
		travel: .16,
		side: .1
	}), c("enemy:yarn-giant", [
		[.18, {
			motion: [
				.22,
				0,
				0
			],
			head: [
				.15,
				0,
				0
			],
			armL: [
				-.65,
				-.45,
				1.1
			],
			armR: [
				-.65,
				.45,
				-1.1
			],
			shift: [
				0,
				-.18,
				-.1
			],
			stretch: [
				1.1,
				.84,
				1.07
			]
		}],
		[.38, {
			motion: [
				-.26,
				0,
				0
			],
			head: [
				-.18,
				0,
				0
			],
			armL: [
				-2.55,
				-.2,
				.65
			],
			armR: [
				-2.55,
				.2,
				-.65
			],
			shift: [
				0,
				.28,
				-.05
			],
			stretch: [
				.93,
				1.15,
				.96
			]
		}],
		[.54, {
			motion: [
				.38,
				0,
				0
			],
			head: [
				.23,
				0,
				0
			],
			armL: [
				-.8,
				-.25,
				.35
			],
			armR: [
				-.8,
				.25,
				-.35
			],
			shift: [
				0,
				-.24,
				.3
			],
			stretch: [
				1.16,
				.73,
				1.12
			]
		}],
		[.73, {
			motion: [
				-.12,
				.08,
				-.03
			],
			head: [
				-.09,
				-.05,
				.02
			],
			armL: [
				-.6,
				-.1,
				.6
			],
			armR: [
				-.6,
				.1,
				-.6
			],
			shift: [
				.04,
				.1,
				.035
			]
		}],
		[.88, {
			motion: [
				.035,
				0,
				0
			],
			shift: [
				0,
				-.025,
				0
			]
		}]
	], {
		travel: .1,
		hold: 110
	})],
	"rain-spool": [c("enemy:rain-spool:basic", [
		[.19, {
			motion: [
				.13,
				.25,
				-.12
			],
			head: [
				.09,
				-.12,
				.04
			],
			armL: [
				-.8,
				-.1,
				.4
			],
			armR: [
				-.45,
				.6,
				-1
			],
			shift: [
				.09,
				-.08,
				-.05
			]
		}],
		[.43, {
			motion: [
				-.19,
				-.3,
				.15
			],
			head: [
				-.12,
				.12,
				-.04
			],
			armR: [
				-1.65,
				-.4,
				-.25
			],
			armL: [
				-.65,
				-.25,
				.65
			],
			shift: [
				-.13,
				.16,
				.17
			]
		}],
		[.63, {
			motion: [
				.08,
				.12,
				-.06
			],
			armR: [
				-.7,
				.2,
				-.65
			],
			shift: [
				.04,
				-.04,
				.06
			]
		}],
		[.83, {
			motion: [
				-.04,
				0,
				0
			],
			armR: [
				-.25,
				0,
				-.2
			],
			shift: [
				0,
				.035,
				0
			]
		}]
	], {
		travel: .12,
		side: -.16
	}), c("enemy:rain-spool", [
		[.19, {
			motion: [
				.16,
				-.38,
				-.18
			],
			head: [
				.1,
				.18,
				.07
			],
			armL: [
				-1.6,
				.6,
				-.3
			],
			armR: [
				-1,
				-.45,
				.2
			],
			shift: [
				-.16,
				-.12,
				-.1
			]
		}],
		[.39, {
			motion: [
				-.25,
				.43,
				.24
			],
			head: [
				-.16,
				-.2,
				-.06
			],
			armL: [
				-2.3,
				-.35,
				1.25
			],
			armR: [
				-2,
				.2,
				-.75
			],
			shift: [
				.18,
				.27,
				.05
			],
			stretch: [
				.9,
				1.18,
				.95
			]
		}],
		[.55, {
			motion: [
				.28,
				-.22,
				-.12
			],
			head: [
				.15,
				.14,
				.04
			],
			armL: [
				-.9,
				-.25,
				.6
			],
			armR: [
				-1.2,
				.3,
				-.55
			],
			shift: [
				-.11,
				-.16,
				.28
			],
			stretch: [
				1.13,
				.79,
				1.1
			]
		}],
		[.72, {
			motion: [
				-.13,
				.13,
				.08
			],
			armL: [
				-.6,
				-.1,
				.7
			],
			armR: [
				-.8,
				.2,
				-.6
			],
			shift: [
				.06,
				.13,
				.1
			]
		}],
		[.87, {
			motion: [
				.04,
				-.04,
				-.02
			],
			shift: [
				-.02,
				-.025,
				0
			]
		}]
	], {
		travel: .18,
		side: .22,
		hold: 105
	})],
	"pantry-crown": [c("enemy:pantry-crown:basic", [
		[.18, {
			motion: [
				.12,
				-.18,
				.08
			],
			head: [
				.14,
				.1,
				-.03
			],
			armL: [
				-1.1,
				-.25,
				.7
			],
			armR: [
				-1.7,
				.6,
				.1
			],
			shift: [
				-.07,
				-.05,
				-.02
			]
		}],
		[.4, {
			motion: [
				-.13,
				.16,
				-.09
			],
			head: [
				-.08,
				-.08,
				.03
			],
			armL: [
				-1.2,
				-.2,
				.75
			],
			armR: [
				-.9,
				-.4,
				-1
			],
			shift: [
				.09,
				.12,
				.13
			]
		}],
		[.6, {
			motion: [
				.08,
				-.12,
				.04
			],
			armR: [
				-1.25,
				.4,
				.1
			],
			head: [
				.05,
				.06,
				-.02
			],
			shift: [
				-.045,
				-.025,
				.03
			]
		}],
		[.81, {
			motion: [
				-.035,
				0,
				0
			],
			armL: [
				-.4,
				-.1,
				.3
			],
			shift: [
				0,
				.03,
				0
			]
		}]
	], { side: .08 }), c("enemy:pantry-crown", [
		[.19, {
			motion: [
				.29,
				0,
				0
			],
			head: [
				.2,
				0,
				0
			],
			armL: [
				-1,
				-.3,
				1
			],
			armR: [
				-1,
				.3,
				-1
			],
			shift: [
				0,
				-.17,
				.17
			],
			stretch: [
				1.08,
				.84,
				1.05
			]
		}],
		[.39, {
			motion: [
				-.27,
				0,
				0
			],
			head: [
				-.18,
				0,
				0
			],
			armL: [
				-1.8,
				.6,
				-.2
			],
			armR: [
				-1.8,
				-.6,
				.2
			],
			shift: [
				0,
				.21,
				-.2
			],
			stretch: [
				.92,
				1.13,
				.94
			]
		}],
		[.56, {
			motion: [
				-.1,
				-.15,
				.06
			],
			head: [
				-.12,
				.1,
				-.025
			],
			armL: [
				-2.45,
				-.3,
				1.25
			],
			armR: [
				-2.45,
				.3,
				-1.25
			],
			shift: [
				-.06,
				.18,
				.04
			]
		}],
		[.75, {
			motion: [
				.34,
				.1,
				-.04
			],
			head: [
				.22,
				-.06,
				.02
			],
			armL: [
				-.6,
				-.2,
				.4
			],
			armR: [
				-.6,
				.2,
				-.4
			],
			shift: [
				.04,
				-.17,
				.18
			],
			stretch: [
				1.06,
				.87,
				1.03
			]
		}],
		[.88, {
			motion: [
				-.06,
				0,
				0
			],
			head: [
				-.04,
				0,
				0
			],
			shift: [
				0,
				.04,
				0
			]
		}]
	], { hold: 110 })]
};
c("boss-intro", [
	[.2, {
		motion: [
			.16,
			0,
			0
		],
		head: [
			.12,
			0,
			0
		],
		armL: [
			-.7,
			.3,
			.1
		],
		armR: [
			-.7,
			-.3,
			-.1
		],
		shift: [
			0,
			-.12,
			0
		]
	}],
	[.48, {
		motion: [
			-.18,
			0,
			0
		],
		head: [
			-.12,
			0,
			0
		],
		armL: [
			-1.8,
			-.3,
			1.2
		],
		armR: [
			-1.8,
			.3,
			-1.2
		],
		shift: [
			0,
			.16,
			0
		]
	}],
	[.75, {
		motion: [
			.06,
			0,
			0
		],
		head: [
			.04,
			0,
			0
		],
		armL: [
			-.45,
			-.1,
			.45
		],
		armR: [
			-.45,
			.1,
			-.45
		],
		shift: [
			0,
			-.035,
			0
		]
	}]
]), c("boss-phase", [
	[.18, {
		motion: [
			.16,
			-.18,
			.06
		],
		head: [
			.1,
			.1,
			-.03
		],
		armL: [
			-1.4,
			.7,
			-.2
		],
		armR: [
			-1.4,
			-.7,
			.2
		],
		shift: [
			-.05,
			-.09,
			0
		]
	}],
	[.48, {
		motion: [
			-.18,
			.2,
			-.07
		],
		head: [
			-.1,
			-.1,
			.03
		],
		armL: [
			-1.7,
			-.4,
			1.4
		],
		armR: [
			-1.7,
			.4,
			-1.4
		],
		shift: [
			.06,
			.16,
			.05
		]
	}],
	[.78, {
		motion: [
			.06,
			0,
			0
		],
		shift: [
			0,
			-.035,
			0
		]
	}]
]), c("boss-intro", [
	[.22, {
		motion: [
			.13,
			-.28,
			-.12
		],
		head: [
			.08,
			.15,
			.04
		],
		armL: [
			-.5,
			-.4,
			.8
		],
		armR: [
			-1.1,
			.45,
			-.2
		],
		shift: [
			-.1,
			-.07,
			0
		]
	}],
	[.49, {
		motion: [
			-.17,
			.3,
			.14
		],
		head: [
			-.1,
			-.14,
			-.04
		],
		armL: [
			-2,
			-.2,
			1
		],
		armR: [
			-1.3,
			.2,
			-.9
		],
		shift: [
			.11,
			.2,
			0
		]
	}],
	[.76, {
		motion: [
			.07,
			-.1,
			-.04
		],
		armL: [
			-.45,
			-.1,
			.4
		],
		armR: [
			-.45,
			.1,
			-.4
		],
		shift: [
			-.035,
			-.04,
			0
		]
	}]
]), c("boss-phase", [
	[.2, {
		motion: [
			.24,
			0,
			0
		],
		head: [
			.16,
			0,
			0
		],
		armL: [
			-1.4,
			.5,
			-.2
		],
		armR: [
			-1.4,
			-.5,
			.2
		],
		shift: [
			0,
			-.14,
			-.04
		]
	}],
	[.49, {
		motion: [
			-.24,
			0,
			0
		],
		head: [
			-.16,
			0,
			0
		],
		armL: [
			-2.35,
			-.3,
			1.25
		],
		armR: [
			-2.35,
			.3,
			-1.25
		],
		shift: [
			0,
			.23,
			.06
		]
	}],
	[.78, {
		motion: [
			.08,
			0,
			0
		],
		armL: [
			-.7,
			-.1,
			.6
		],
		armR: [
			-.7,
			.1,
			-.6
		],
		shift: [
			0,
			-.04,
			0
		]
	}]
]), c("boss-intro", [
	[.2, {
		motion: [
			-.09,
			0,
			0
		],
		head: [
			-.06,
			0,
			0
		],
		armL: [
			-1.2,
			-.3,
			.85
		],
		armR: [
			-1.2,
			.3,
			-.85
		],
		shift: [
			0,
			.07,
			0
		]
	}],
	[.48, {
		motion: [
			.35,
			0,
			0
		],
		head: [
			.22,
			0,
			0
		],
		armL: [
			-.75,
			.4,
			-.15
		],
		armR: [
			-.75,
			-.4,
			.15
		],
		shift: [
			0,
			-.16,
			.1
		]
	}],
	[.76, {
		motion: [
			-.1,
			0,
			0
		],
		head: [
			-.07,
			0,
			0
		],
		armL: [
			-.6,
			-.1,
			.5
		],
		armR: [
			-.6,
			.1,
			-.5
		],
		shift: [
			0,
			.08,
			0
		]
	}]
]), c("boss-phase", [
	[.18, {
		motion: [
			.12,
			.2,
			-.07
		],
		head: [
			.08,
			-.12,
			.03
		],
		armL: [
			-1.5,
			-.2,
			.9
		],
		armR: [
			-.75,
			.3,
			-.3
		],
		shift: [
			.07,
			-.06,
			0
		]
	}],
	[.47, {
		motion: [
			-.17,
			-.2,
			.08
		],
		head: [
			-.1,
			.12,
			-.03
		],
		armL: [
			-2.4,
			-.2,
			.9
		],
		armR: [
			-1.7,
			.3,
			-1.3
		],
		shift: [
			-.07,
			.2,
			.05
		]
	}],
	[.76, {
		motion: [
			.13,
			0,
			0
		],
		head: [
			.09,
			0,
			0
		],
		armL: [
			-.8,
			-.1,
			.5
		],
		armR: [
			-.8,
			.1,
			-.5
		],
		shift: [
			0,
			-.06,
			.03
		]
	}]
]);
// apps/web/src/game/squad/turn3d/card-impact.ts
var holds = new Map([
	STARTER_SKILL_CLIPS,
	ROSTER_SKILL_CLIPS,
	BATCH2_SKILL_CLIPS,
	BATCH3_SKILL_CLIPS,
	ENEMY_BATCH1_CLIPS,
	ENEMY_BATCH2_CLIPS,
	ENEMY_BATCH3_CLIPS,
	ENEMY_BATCH4_CLIPS,
	BOSS_SKILL_CLIPS
].flatMap((group) => Object.values(group).flatMap((clips) => clips.map((clip) => [clip.id, clip.travel?.hold]))));
/** Undefined preserves the previous presenter behavior for unrelated battle modes. */
var cardImpactHold = (presentationId) => presentationId ? holds.get(presentationId) : void 0;
// apps/web/src/game/squad/turn3d/effects.ts
var gold = "#ffd48a";
var violet = "#c49aff";
var teal = "#86ebc7";
var red = "#ff8b9e";
var recipe$3 = (name, color, shape, options = {}) => ({
	name,
	color,
	accent: "#fff3d4",
	shape,
	ultimate: false,
	duration: [
		300,
		260,
		80,
		210,
		310
	],
	clip: "attack",
	motifs: [
		"glow",
		"ribbon",
		"ring",
		"sparks",
		"afterglow"
	],
	shake: 1,
	...options
});
/** Authored choreography, not damage logic. Milliseconds here never advance rules. */
var EFFECT_REGISTRY = {
	bossIntro: recipe$3("The knot awakens", red, "thread", {
		ultimate: true,
		clip: "telegraph",
		duration: [
			1200,
			250,
			110,
			330,
			400
		],
		shake: 1.7,
		motifs: [
			"woven-crown",
			"red-spokes",
			"knot-eye",
			"thread-tension",
			"dust-fall"
		]
	}),
	healTonic: recipe$3("Warm Milk Tonic", "#ffe4bd", "mend", {
		clip: "cast",
		shake: 0,
		motifs: [
			"cork-pop",
			"cream-helix",
			"milk-crown",
			"heart-rise",
			"cream-drops"
		]
	}),
	shieldBiscuit: recipe$3("Shield Biscuit", "#eebc6e", "wall", {
		clip: "guard",
		shake: .2,
		motifs: [
			"biscuit-sigil",
			"crumb-spiral",
			"honey-facets",
			"warm-shell",
			"crumb-dust"
		]
	}),
	quickenYarn: recipe$3("Quicken Yarn", "#b7d6ff", "thread", {
		clip: "cast",
		shake: 0,
		motifs: [
			"unspool",
			"sky-loop",
			"forward-chevron",
			"step-lights",
			"blue-fibres"
		]
	}),
	cleanseTea: recipe$3("Clearleaf Tea", "#bcecc9", "patch", {
		clip: "heal-receive",
		shake: 0,
		motifs: [
			"tea-steam",
			"leaf-helix",
			"clear-ripple",
			"veil-lift",
			"mint-dew"
		]
	}),
	ultimateTreat: recipe$3("Starlight Treat", "#ffcaee", "storm", {
		clip: "cast",
		shake: .1,
		motifs: [
			"treat-glint",
			"sugar-orbit",
			"five-star",
			"charge-rings",
			"sugar-stars"
		]
	}),
	relicProc: recipe$3("Relic Resonance", "#edc888", "rally", {
		clip: "cast",
		shake: 0,
		duration: [
			160,
			140,
			70,
			180,
			250
		],
		motifs: [
			"engraved-sigil",
			"relic-orbit",
			"diamond-crown",
			"brass-echo",
			"fine-sparks"
		]
	}),
	thorns: recipe$3("Quilted Return", "#dcb080", "arrow", {
		shake: .4,
		motifs: [
			"stitch-tense",
			"return-needles",
			"sewn-cross",
			"thread-snap",
			"cotton-dust"
		]
	}),
	guardianBasic: recipe$3("Hearthblade", gold, "slash", { motifs: [
		"ladle-glint",
		"crescent",
		"star",
		"recoil",
		"gold-dust"
	] }),
	shieldBash: recipe$3("Shield Bash", gold, "bash", {
		clip: "special",
		duration: [
			360,
			230,
			100,
			240,
			330
		],
		shake: 1.5,
		motifs: [
			"shield-charge",
			"shield-rush",
			"hexagon",
			"stagger",
			"shield-shards"
		]
	}),
	rally: recipe$3("Rally", gold, "rally", {
		clip: "cast",
		motifs: [
			"paw-sigil",
			"gold-ribbons",
			"shield",
			"salute",
			"guard-dome"
		],
		shake: .3
	}),
	hearthwall: recipe$3("Hearthwall", gold, "wall", {
		ultimate: true,
		clip: "special",
		duration: [
			1200,
			250,
			100,
			240,
			450
		],
		shake: 1.3,
		motifs: [
			"sunrise",
			"three-pillars",
			"hexagon-wall",
			"guard",
			"gold-canopy"
		]
	}),
	witchBasic: recipe$3("Wick Spark", violet, "orb", {
		clip: "cast",
		motifs: [
			"wick",
			"ember-trail",
			"four-star",
			"recoil",
			"embers"
		]
	}),
	threadSnare: recipe$3("Thread Snare", violet, "thread", {
		clip: "special",
		motifs: [
			"spindle",
			"looping-thread",
			"woven-star",
			"tether",
			"thread-loops"
		],
		shake: .4
	}),
	emberOrb: recipe$3("Ember Orb", violet, "orb", {
		clip: "cast",
		accent: "#ffb27c",
		duration: [
			400,
			350,
			100,
			250,
			400
		],
		shake: 1.5,
		motifs: [
			"lantern-pulse",
			"comet",
			"ember-flower",
			"stagger",
			"embers"
		]
	}),
	lanternstorm: recipe$3("Lanternstorm", violet, "storm", {
		ultimate: true,
		clip: "special",
		duration: [
			1220,
			230,
			100,
			300,
			450
		],
		shake: 2,
		motifs: [
			"three-lanterns",
			"falling-ribbons",
			"triple-star",
			"stagger",
			"violet-cinders"
		]
	}),
	alchemistBasic: recipe$3("Sour Drop", teal, "flask", {
		clip: "cast",
		motifs: [
			"flask-tilt",
			"potion-arc",
			"splash",
			"recoil",
			"bubbles"
		]
	}),
	milkFlask: recipe$3("Milk Flask", teal, "flask", {
		clip: "cast",
		accent: "#fff6dc",
		duration: [
			300,
			360,
			60,
			220,
			400
		],
		shake: 0,
		motifs: [
			"milk-glow",
			"flask-arc",
			"cream-splash",
			"heal",
			"soft-bubbles"
		]
	}),
	mossFlask: recipe$3("Moss Flask", teal, "patch", {
		clip: "special",
		duration: [
			350,
			320,
			70,
			250,
			420
		],
		shake: 0,
		motifs: [
			"leaf-swirl",
			"green-arc",
			"petal-ring",
			"heal",
			"moss-garden"
		]
	}),
	nineLives: recipe$3("Nine-Lives Shelter", teal, "shelter", {
		ultimate: true,
		clip: "special",
		duration: [
			1200,
			250,
			90,
			280,
			480
		],
		shake: .4,
		motifs: [
			"nine-seeds",
			"spiral-leaves",
			"petal-dome",
			"heal",
			"leaf-canopy"
		]
	}),
	steadfast: recipe$3("Steadfast", gold, "wall", {
		duration: [
			200,
			140,
			60,
			180,
			280
		],
		clip: "cast",
		shake: 0
	}),
	warmWick: recipe$3("Warm Wick", violet, "orb", {
		duration: [
			200,
			140,
			60,
			180,
			280
		],
		clip: "cast",
		shake: 0
	}),
	lastSip: recipe$3("Last Sip", teal, "shelter", {
		duration: [
			200,
			140,
			60,
			180,
			280
		],
		clip: "cast",
		shake: 0
	}),
	lastLight: recipe$3("Last Light", gold, "wall", {
		duration: [
			200,
			140,
			60,
			180,
			280
		],
		clip: "cast",
		shake: 0
	}),
	needleLantern: recipe$3("Needle Lantern", violet, "arrow"),
	guardAttack: recipe$3("Button Cut", "#e4bd8e", "slash"),
	flankerAttack: recipe$3("Sock Skip", "#efaec6", "slash", {
		duration: [
			250,
			240,
			60,
			220,
			260
		],
		clip: "special"
	}),
	rangerAttack: recipe$3("Needle Shot", "#d1c1ff", "arrow", {
		clip: "cast",
		motifs: [
			"wing-glint",
			"needle-ribbon",
			"pin-star",
			"recoil",
			"thread-dust"
		]
	}),
	healerAttack: recipe$3("Teacup Mend", "#a3dfc1", "mend", {
		clip: "cast",
		shake: 0
	}),
	chargerAttack: recipe$3("Spool Charge", "#edbb88", "charge", {
		duration: [
			900,
			230,
			110,
			260,
			360
		],
		clip: "special",
		shake: 1.8
	}),
	eliteAttack: recipe$3("Kettle Crush", "#bed4ed", "bash", {
		duration: [
			850,
			240,
			110,
			260,
			360
		],
		clip: "special",
		shake: 1.7
	}),
	yarnAttack: recipe$3("Spindle Sweep", red, "sweep", {
		duration: [
			1e3,
			260,
			110,
			280,
			400
		],
		clip: "telegraph",
		shake: 2,
		motifs: [
			"red-arm",
			"sweep-ribbon",
			"thread-fan",
			"knockback",
			"red-fibres"
		]
	}),
	bindThread: recipe$3("Loose End", red, "thread", {
		duration: [
			850,
			330,
			90,
			220,
			430
		],
		clip: "cast",
		motifs: [
			"launcher",
			"red-helix",
			"knot",
			"bound",
			"binding-loop"
		]
	}),
	crossSweep: recipe$3("Cross Stitch", red, "cross", {
		ultimate: true,
		duration: [
			1e3,
			250,
			110,
			280,
			400
		],
		clip: "telegraph",
		shake: 2,
		motifs: [
			"crossed-arms",
			"cross-ribbons",
			"red-cross",
			"stagger",
			"loose-threads"
		]
	}),
	threadAttack: recipe$3("Tighten", red, "thread", {
		duration: [
			250,
			220,
			60,
			200,
			280
		],
		shake: .4
	}),
	dummyAttack: recipe$3("Cushion Nudge", "#e4c3ad", "bash", { shake: 0 }),
	burn: recipe$3("Burn", "#ffad7d", "orb", {
		duration: [
			120,
			100,
			60,
			150,
			230
		],
		shake: .2
	}),
	status_apply: recipe$3("Status applied", violet, "thread", {
		duration: [
			180,
			120,
			60,
			180,
			300
		],
		shake: 0,
		clip: "cast"
	}),
	status_expire: recipe$3("Status faded", teal, "mend", {
		duration: [
			120,
			120,
			40,
			150,
			230
		],
		shake: 0,
		clip: "idle"
	}),
	death: recipe$3("Down", red, "cross", {
		duration: [
			150,
			120,
			60,
			300,
			380
		],
		shake: 0,
		clip: "down"
	}),
	wave_clear: recipe$3("A breath between waves", gold, "rally", {
		duration: [
			200,
			200,
			80,
			230,
			400
		],
		shake: 0,
		clip: "victory"
	}),
	victory: recipe$3("The cafe is safe", gold, "storm", {
		ultimate: true,
		duration: [
			800,
			220,
			80,
			350,
			550
		],
		shake: 0,
		clip: "victory"
	}),
	defeat: recipe$3("A lesson for tomorrow", red, "mend", {
		duration: [
			300,
			150,
			60,
			300,
			500
		],
		shake: 0,
		clip: "down"
	})
};
var kinds = [
	"anticipation",
	"travel",
	"impact",
	"reaction",
	"residue"
];
function createActionPlan(events, override) {
	const first = events.find((e) => e.type === "action_start") ?? [
		"victory",
		"defeat",
		"wave_clear"
	].map((type) => events.find((e) => e.type === type)).find(Boolean) ?? events.find((e) => [
		"boss_phase",
		"passive",
		"damage",
		"status_apply",
		"status_expire",
		"death",
		"gear_proc",
		"shield"
	].includes(e.type)) ?? events[0];
	const key = first?.type === "boss_phase" ? "bossIntro" : first?.type === "action_start" || first?.type === "damage" || first?.type === "shield" || first?.type === "passive" || first?.type === "gear_proc" ? first.skillId : first?.type ?? "status_apply";
	const data = override ?? EFFECT_REGISTRY[key] ?? EFFECT_REGISTRY.status_apply;
	let at = 0;
	const beats = kinds.map((kind, i) => {
		const duration = Math.max(i === 0 && events.some((e) => e.type === "action_start") ? 600 : 0, Math.round(data.duration[i] * (i === 3 && (data.ultimate || events.some((e) => e.type === "death")) ? 1.4 : 1) * (!data.ultimate && i !== 2 ? .73 : 1)));
		const beat = {
			kind,
			start: at,
			duration,
			camera: data.ultimate ? i === 0 ? 1.2 : i < 3 ? .8 : .2 : i === 0 ? .12 : 0,
			shake: kind === "impact" ? data.shake : kind === "reaction" ? data.shake * .2 : 0,
			flash: kind === "impact" ? data.ultimate ? .055 : .025 : 0,
			clip: data.clip === "down" || data.clip === "victory" ? data.clip : i === 0 ? data.clip : i === 1 && [
				"slash",
				"bash",
				"charge"
			].includes(data.shape) ? "step" : i >= 3 ? "idle" : data.clip,
			vfx: data.motifs[i] ?? "glow",
			soundCue: `${key}.${kind}`
		};
		at += duration;
		return beat;
	});
	const targetIds = [...new Set(events.find((e) => e.type === "action_start")?.targetIds ?? events.flatMap((e) => [
		"damage",
		"heal",
		"shield",
		"status_apply",
		"passive",
		"death",
		"fizzle"
	].includes(e.type) ? e.targetIds : []))];
	return {
		id: events[0]?.actionId ?? 0,
		actorId: (first?.type === "death" ? first.targetIds[0] : first?.actorId) || first?.actors?.find((a) => a.side === "party" && a.hp > 0)?.id || "guardian",
		skillId: key,
		targetIds,
		color: data.color,
		accent: data.accent,
		shape: data.shape,
		duration: at,
		ultimate: data.ultimate,
		beats,
		events: [...events],
		name: data.name,
		motifs: data.motifs
	};
}
function sampleActionPlan(plan, elapsed, reducedMotion = false) {
	const t = Math.max(0, Math.min(plan.duration, elapsed));
	const beat = plan.beats.find((b) => t < b.start + b.duration) ?? plan.beats[4];
	const hold = beat.kind === "impact" && !reducedMotion ? Math.min(beat.duration * .8, cardImpactHold(plan.presentationId) ?? SKILL_MOTION[plan.skillId]?.hold ?? 0) : 0;
	const progress = Math.max(0, Math.min(1, (t - beat.start - hold) / (beat.duration - hold)));
	return {
		plan,
		beat,
		progress,
		actionProgress: t / plan.duration,
		elapsed: t,
		color: plan.color,
		camera: reducedMotion ? 0 : beat.camera,
		shake: reducedMotion ? 0 : beat.shake * (1 - progress),
		flash: reducedMotion ? 0 : beat.flash * (1 - progress),
		clip: beat.clip,
		intensity: beat.kind === "impact" ? 1 : Math.sin(progress * Math.PI) * .7 + .3
	};
}
// apps/web/src/game/squad/turn3d/card-status-data.ts
/** Original 16px line drawings, authored on a 24-unit grid; no imported artwork. */
var STATUS_IDENTITIES = {
	scald: {
		name: "Burn",
		subtitle: "Scald",
		color: "#efaa73",
		order: 0,
		path: "M12 2C14 8 20 9 19 15A7 7 0 0 1 5 15C5 11 8 9 9 7C9 12 13 12 12 2ZM12 14L10 18L14 18Z"
	},
	snag: {
		name: "Bleed",
		subtitle: "Snag",
		color: "#d9616b",
		order: 0,
		path: "M4 3L15 17M10 2L21 16M3 12L14 4M9 20L20 12M6 16C2 20 4 23 6 23C9 23 10 20 6 16Z"
	},
	bitter: {
		name: "Bitter",
		subtitle: "Bitter tea",
		color: "#8d7aa6",
		order: 0,
		path: "M4 12H17V17Q16 22 11 22Q5 22 4 17ZM17 13H21V17H17M7 2Q3 5 8 8M13 2Q9 5 14 8M3 22L21 3"
	},
	scent: {
		name: "Mark",
		subtitle: "Scented",
		color: "#f4db95",
		order: 0,
		path: "M5 8H16V12A5 5 0 0 1 6 12ZM16 9H19V13H16M3 19Q12 22 21 19M9 3V5M13 2V5"
	},
	brittle: {
		name: "Shred",
		subtitle: "Brittle sugar",
		color: "#9fd3e0",
		order: 0,
		path: "M12 2L21 6L19 15L12 22L5 15L3 6ZM13 3L10 9L14 12L9 17L12 22M14 12L19 11"
	},
	tangle: {
		name: "Shred",
		subtitle: "Tangle",
		color: "#9fd3e0",
		order: 0,
		path: "M4 5L11 3L20 6L18 17L12 21L5 17ZM13 4L9 10L15 13L11 20M4 11Q10 7 17 17"
	},
	drowsy: {
		name: "Daze",
		subtitle: "Drowsy",
		color: "#c19ada",
		order: 0,
		path: "M4 16A4 4 0 0 1 2 9A6 6 0 0 1 13 7A5 5 0 0 1 18 16ZM17 2L18 5L21 6L18 7L17 10L16 7L13 6L16 5M7 10H11L7 13H11"
	},
	hush: {
		name: "Daze",
		subtitle: "Hush",
		color: "#c19ada",
		order: 0,
		path: "M4 17A4 4 0 0 1 3 9A6 6 0 0 1 14 7A5 5 0 0 1 20 17ZM8 12H15M19 2L20 4L22 5L20 6L19 8"
	},
	rattled: {
		name: "Daze",
		subtitle: "Rattled",
		color: "#c19ada",
		order: 0,
		path: "M4 17A4 4 0 0 1 3 9A6 6 0 0 1 14 7A5 5 0 0 1 20 17ZM7 11L9 13L11 11L13 13L15 11M18 2L16 5L20 5L18 8"
	},
	steep: {
		name: "Regen",
		subtitle: "Steep",
		color: "#a3dba3",
		order: 1,
		path: "M5 18C1 10 9 3 19 3C21 13 14 21 5 18ZM5 18L16 6M10 13V8M10 13H16M3 22L5 18"
	},
	cozy: {
		name: "Warm",
		subtitle: "Cozy",
		color: "#efbc73",
		order: 1,
		path: "M12 2L21 6L19 15L12 22L5 15L3 6ZM6 10L9 13L12 10L15 13L18 10M8 15L12 18L16 15"
	},
	crumb: {
		name: "Crumb",
		subtitle: "Crumb trail",
		color: "#e6c392",
		order: 2,
		path: "M3 5L9 3L11 8L6 11L2 9ZM14 12L20 10L22 16L18 21L12 18ZM14 3L17 4L16 7ZM4 17L7 16L8 20L5 22Z"
	},
	riposte: {
		name: "Riposte",
		subtitle: "Saucer riposte",
		color: "#efbc73",
		order: 2,
		path: "M3 15Q12 22 21 15M5 12Q12 17 19 12M5 8C9 2 17 3 20 8M16 8H20V4M7 19L4 22"
	},
	link: {
		name: "Link",
		subtitle: "Apron link",
		color: "#9fd3e0",
		order: 2,
		path: "M10 8L7 5C2 2 0 9 4 12L7 15M14 16L17 19C22 22 24 15 20 12L17 9M7 8L17 16M9 3L12 6M12 18L15 21"
	},
	sprout: {
		name: "Sprout",
		subtitle: "Second sprout",
		color: "#a3dba3",
		order: 2,
		path: "M12 22V10M12 15C3 16 2 9 3 5C10 5 13 10 12 15ZM12 11C12 3 18 1 22 2C22 8 18 12 12 11M7 22H17"
	},
	decoy: {
		name: "Decoy",
		subtitle: "Yarn decoy",
		color: "#e6c392",
		order: 2,
		path: "M4 10L3 3L9 7L15 7L21 3L20 10C24 22 0 24 4 10ZM5 13L19 17M6 18L18 11M9 9L12 21"
	},
	glaze: {
		name: "Glaze",
		subtitle: "Glaze",
		color: "#b7e1df",
		order: 2,
		path: "M12 2C9 7 5 11 5 15A7 7 0 0 0 19 15C19 11 15 7 12 2ZM8 15Q8 19 12 19M18 3L19 6L22 7L19 8L18 11"
	},
	shelter: {
		name: "Shelter",
		subtitle: "Shelter",
		color: "#f4db95",
		order: 2,
		path: "M2 11L12 2L22 11M5 10V21H19V10M9 21V14H15V21M8 7H16"
	}
};
// apps/web/src/game/squad/turn3d/card-status-looks.ts
function mark(primitive, motion, options = {}) {
	return {
		primitive,
		motion,
		anchor: "target",
		start: 0,
		end: 1,
		count: 1,
		size: .36,
		spread: .46,
		height: 0,
		turns: .35,
		offset: [
			0,
			0,
			0
		],
		aspect: [
			1,
			1,
			1
		],
		ground: false,
		accent: false,
		opacity: .74,
		...options
	};
}
var layers = {
	scald: mark("flame", "hold", {
		size: .3,
		spread: 0,
		opacity: .8
	}),
	snag: mark("seam", "hold", {
		count: 3,
		size: .4,
		spread: .2,
		opacity: .78
	}),
	bitter: mark("steam", "orbit", {
		count: 3,
		size: .34,
		spread: .58,
		height: .06,
		opacity: .76
	}),
	scent: mark("cup", "orbit", {
		size: .4,
		spread: .1,
		turns: .16
	}),
	brittle: mark("seam", "cross", {
		count: 2,
		size: .52,
		spread: .3,
		turns: 0
	}),
	tangle: mark("knot", "orbit", {
		count: 2,
		size: .3,
		spread: .46
	}),
	drowsy: mark("steam", "orbit", {
		count: 3,
		size: .25,
		spread: .35
	}),
	hush: mark("steam", "orbit", {
		count: 3,
		size: .23,
		spread: .35
	}),
	rattled: mark("star", "orbit", {
		count: 3,
		size: .25,
		spread: .48
	}),
	steep: mark("leaf", "fall", {
		count: 2,
		size: .35,
		height: .7,
		spread: .44
	}),
	cozy: mark("bubble", "hold", {
		size: 1.35,
		opacity: .76
	}),
	crumb: mark("button", "orbit", {
		count: 3,
		size: .18,
		spread: .43
	}),
	riposte: mark("tray", "orbit", {
		size: .42,
		spread: .49
	}),
	link: mark("bow", "hold", {
		size: .43,
		offset: [
			.45,
			0,
			0
		]
	}),
	sprout: mark("sprout", "hold", {
		size: .48,
		offset: [
			-.45,
			0,
			0
		]
	}),
	decoy: mark("knot", "hold", {
		size: .5,
		offset: [
			.48,
			0,
			0
		]
	}),
	glaze: mark("bubble", "hold", {
		size: 1.4,
		opacity: .76
	}),
	shelter: mark("roof", "hold", { size: .45 })
};
Object.fromEntries(Object.entries(layers).map(([id, layer]) => [id, {
	color: STATUS_IDENTITIES[id].color,
	layer,
	crown: [
		"scent",
		"drowsy",
		"hush",
		"rattled",
		"shelter"
	].includes(id),
	apply: {
		...layer,
		primitive: id === "snag" ? "seam" : id === "bitter" ? "droplet" : layer.primitive,
		motion: "projectile",
		count: 1,
		size: .36,
		height: .5,
		opacity: .8
	},
	flight: {
		...layer,
		motion: "projectile",
		count: 1,
		size: .34,
		height: .95,
		spread: .25,
		turns: .65,
		opacity: .8
	},
	tick: {
		...layer,
		primitive: id === "snag" ? "droplet" : layer.primitive,
		motion: id === "snag" ? "fall" : "expand",
		count: id === "snag" ? 3 : 1,
		size: id === "snag" ? .22 : .65,
		height: id === "snag" ? .6 : layer.height,
		opacity: .8
	},
	expire: {
		...layer,
		motion: "fall",
		count: 1,
		size: .3,
		height: .28,
		opacity: .65
	}
}]));
mark("button", "burst", {
	count: 9,
	size: .25,
	spread: 1,
	height: .4,
	opacity: .8
});
mark("flame", "projectile", {
	size: .48,
	height: .08,
	spread: .5,
	opacity: .78
}), mark("spark", "projectile", {
	size: .16,
	height: .3,
	spread: .48,
	opacity: .75
}), mark("seam", "hold", {
	size: .58,
	aspect: [
		1.8,
		.5,
		1
	],
	height: .2,
	spread: .18,
	opacity: .8
}), mark("droplet", "burst", {
	count: 4,
	size: .19,
	height: .28,
	spread: .95,
	opacity: .8
}), mark("seam", "burst", {
	count: 2,
	size: .55,
	spread: .62,
	opacity: .78
}), mark("droplet", "fall", {
	count: 4,
	size: .2,
	height: .65,
	spread: .48,
	opacity: .78
}), mark("spark", "projectile", {
	size: .28,
	height: .35,
	opacity: .78
}), mark("seam", "cross", {
	count: 2,
	size: .55,
	spread: .32,
	opacity: .78
}), mark("knock-ring", "expand", {
	size: 1.25,
	ground: true,
	height: .08,
	opacity: .76
});
// apps/web/src/game/squad/turn3d/card-boss-effects.ts
var l$6 = (primitive, motion, anchor, o = {}) => ({
	primitive,
	motion,
	anchor,
	start: .34,
	end: .94,
	count: 1,
	size: .8,
	spread: .7,
	height: .18,
	turns: .25,
	offset: [
		0,
		0,
		0
	],
	aspect: [
		1,
		1,
		1
	],
	ground: false,
	accent: false,
	opacity: .8,
	...o
});
var r$5 = (name, color, accent, element, shot, layers) => ({
	name,
	color,
	accent,
	element,
	shot,
	target: "hostile",
	layers,
	ultimate: false,
	durations: [
		640,
		200,
		100,
		220,
		215
	],
	shake: .8
});
var BOSS_EFFECTS = {
	"enemy:yarn-giant:basic": r$5("Weaver sweep", "#bd938f", "#eec48f", "thread", "left", [
		l$6("spool", "sweep", "caster", {
			start: .03,
			end: .43,
			size: .65,
			offset: [
				.7,
				0,
				0
			]
		}),
		l$6("yarn-fan", "projectile", "target", {
			start: .34,
			end: .6,
			size: 1
		}),
		l$6("spindle", "cross", "target", {
			start: .49,
			count: 2,
			size: .7,
			spread: .65
		}),
		l$6("seam", "rise", "target", {
			start: .64,
			count: 3,
			size: .65,
			spread: .8,
			accent: true
		})
	]),
	"enemy:yarn-giant": r$5("Loomfall", "#c38b91", "#f5cb91", "thread", "wide", [
		l$6("spool", "orbit", "caster", {
			start: .03,
			end: .44,
			count: 2,
			size: .75,
			spread: 1.1
		}),
		l$6("seam", "pulse", "all-targets", {
			start: .06,
			end: .34,
			size: 1.15,
			ground: true,
			height: .055,
			opacity: .5
		}),
		l$6("yarn-fan", "fall", "all-targets", {
			start: .34,
			size: 1.6,
			height: 1.3
		}),
		l$6("spool", "cross", "all-targets", {
			start: .48,
			count: 2,
			size: .7,
			spread: .8
		}),
		l$6("knot", "burst", "all-targets", {
			start: .57,
			count: 4,
			size: .5,
			spread: 1.2,
			accent: true
		}),
		l$6("veil", "rise", "all-targets", {
			start: .68,
			size: 1.1,
			height: .4,
			opacity: .45
		})
	]),
	"enemy:rain-spool:basic": r$5("Rain sling", "#83afce", "#cce3ee", "tide", "right", [
		l$6("droplet", "orbit", "caster", {
			start: .03,
			end: .43,
			count: 3,
			size: .35,
			spread: .55
		}),
		l$6("wave", "projectile", "target", {
			start: .34,
			end: .6,
			size: .85
		}),
		l$6("spool", "cross", "target", {
			start: .49,
			size: .8
		}),
		l$6("droplet", "burst", "target", {
			start: .61,
			count: 4,
			size: .3,
			spread: .8,
			accent: true
		})
	]),
	"enemy:rain-spool": r$5("Cloudburst", "#7ca6cf", "#dbecf6", "tide", "wide", [
		l$6("spool", "pulse", "caster", {
			start: .03,
			end: .44,
			size: .85,
			offset: [
				-.7,
				0,
				0
			]
		}),
		l$6("wave", "pulse", "all-targets", {
			start: .06,
			end: .34,
			size: 1.1,
			ground: true,
			height: .055,
			opacity: .55
		}),
		l$6("steam", "cross", "all-targets", {
			start: .34,
			count: 3,
			size: 1,
			spread: .95,
			height: .9
		}),
		l$6("droplet", "fall", "all-targets", {
			start: .42,
			count: 7,
			size: .42,
			spread: 1.2,
			height: 1.25,
			turns: 0
		}),
		l$6("wave", "sweep", "all-targets", {
			start: .54,
			size: 1.6,
			ground: true,
			height: .08
		}),
		l$6("bubble", "burst", "all-targets", {
			start: .66,
			count: 4,
			size: .35,
			spread: 1.2,
			accent: true
		})
	]),
	"enemy:pantry-crown:basic": r$5("Cup tally", "#bdac83", "#eee4b8", "holy", "left", [
		l$6("cup", "pulse", "caster", {
			start: .03,
			end: .43,
			size: .65,
			offset: [
				.7,
				0,
				0
			]
		}),
		l$6("cup", "projectile", "target", {
			start: .34,
			end: .61,
			size: .85,
			turns: .5
		}),
		l$6("serving-bell", "cross", "target", {
			start: .5,
			size: .9
		}),
		l$6("spice-star", "fall", "target", {
			start: .64,
			count: 4,
			size: .3,
			spread: .85,
			height: .7,
			accent: true
		})
	]),
	"enemy:pantry-crown": r$5("Empty banquet", "#c8b67f", "#f9e6ac", "holy", "wide", [
		l$6("crumb-crown", "pulse", "caster", {
			start: .03,
			end: .44,
			size: .85,
			offset: [
				-.7,
				0,
				0
			]
		}),
		l$6("tray", "pulse", "all-targets", {
			start: .06,
			end: .34,
			size: 1.15,
			ground: true,
			height: .055,
			opacity: .5
		}),
		l$6("apron-cloth", "sweep", "all-targets", {
			start: .34,
			size: 1.5,
			height: .08,
			ground: true
		}),
		l$6("cup", "projectile", "caster", {
			start: .45,
			end: .7,
			count: 3,
			size: .65,
			spread: 1,
			height: .6
		}),
		l$6("serving-bell", "cross", "all-targets", {
			start: .53,
			size: 1.2,
			height: .3
		}),
		l$6("crumb-crown", "rise", "caster", {
			start: .65,
			size: 1.3,
			height: .6,
			accent: true
		})
	])
};
// apps/web/src/game/squad/turn3d/card-enemy-batch4-effects.ts
var l$5 = (primitive, motion, anchor, o = {}) => ({
	primitive,
	motion,
	anchor,
	start: .34,
	end: .94,
	count: 1,
	size: .8,
	spread: .7,
	height: .18,
	turns: .25,
	offset: [
		0,
		0,
		0
	],
	aspect: [
		1,
		1,
		1
	],
	ground: false,
	accent: false,
	opacity: .8,
	...o
});
var ENEMY_BATCH4_EFFECTS = {
	"enemy:crumb-sentinel:basic": {
		name: "Sugar pinch",
		color: "#c6a786",
		accent: "#f8dfad",
		element: "blunt",
		shot: "left",
		target: "hostile",
		ultimate: false,
		durations: [
			610,
			200,
			85,
			230,
			250
		],
		shake: .35,
		layers: [
			l$5("spice-star", "orbit", "caster", {
				start: .04,
				end: .43,
				count: 2,
				size: .4,
				spread: .4
			}),
			l$5("bread", "projectile", "target", {
				start: .34,
				end: .6,
				size: .75
			}),
			l$5("spice-star", "burst", "target", {
				start: .49,
				count: 4,
				size: .35,
				spread: .8
			}),
			l$5("crumb-crown", "fall", "target", {
				start: .65,
				size: .6,
				height: .6,
				accent: true
			})
		]
	},
	"enemy:crumb-sentinel": {
		name: "Sugar burst",
		color: "#d7b48e",
		accent: "#fff1b5",
		element: "ember",
		shot: "wide",
		target: "hostile",
		ultimate: false,
		durations: [
			650,
			170,
			95,
			220,
			240
		],
		shake: .8,
		layers: [
			l$5("crumb-crown", "pulse", "caster", {
				start: .03,
				end: .44,
				size: .8,
				offset: [
					.6,
					0,
					0
				]
			}),
			l$5("spice-star", "pulse", "all-targets", {
				start: .08,
				end: .34,
				size: .9,
				ground: true,
				height: .055,
				opacity: .5
			}),
			l$5("bread", "fall", "all-targets", {
				start: .34,
				count: 3,
				size: .6,
				spread: .8,
				height: .9
			}),
			l$5("crumb-crown", "cross", "all-targets", {
				start: .48,
				size: 1.25
			}),
			l$5("spice-star", "burst", "all-targets", {
				start: .56,
				count: 6,
				size: .4,
				spread: 1.3,
				accent: true
			}),
			l$5("steam", "rise", "all-targets", {
				start: .68,
				count: 2,
				size: .65,
				spread: .8,
				height: .5
			})
		]
	}
};
// apps/web/src/game/squad/turn3d/card-enemy-batch3-effects.ts
var l$4 = (primitive, motion, anchor, o = {}) => ({
	primitive,
	motion,
	anchor,
	start: .34,
	end: .94,
	count: 1,
	size: .8,
	spread: .7,
	height: .18,
	turns: .25,
	offset: [
		0,
		0,
		0
	],
	aspect: [
		1,
		1,
		1
	],
	ground: false,
	accent: false,
	opacity: .8,
	...o
});
var r$4 = (name, color, accent, element, shot, target, layers) => ({
	name,
	color,
	accent,
	element,
	shot,
	target,
	layers,
	ultimate: false,
	durations: [
		610,
		200,
		85,
		230,
		250
	],
	shake: target === "friendly" ? 0 : .4
});
var ENEMY_BATCH3_EFFECTS = {
	"enemy:binding-thread:basic": r$4("Shoulder tug", "#b69dce", "#e2c7ed", "thread", "left", "hostile", [
		l$4("spindle", "sweep", "caster", {
			start: .04,
			end: .43,
			size: .55,
			offset: [
				-.6,
				0,
				0
			]
		}),
		l$4("wick", "projectile", "target", {
			start: .34,
			end: .6,
			size: .85,
			turns: 0
		}),
		l$4("knot", "sweep", "target", {
			start: .49,
			size: .85,
			turns: .5
		}),
		l$4("seam", "fall", "target", {
			start: .63,
			count: 3,
			size: .5,
			spread: .6,
			height: .7,
			accent: true
		})
	]),
	"enemy:binding-thread": r$4("Woven snare", "#b49ccf", "#e9bfda", "thread", "right", "hostile", [
		l$4("knot", "orbit", "caster", {
			start: .03,
			end: .44,
			count: 2,
			size: .55,
			spread: .55
		}),
		l$4("spindle", "cross", "target", {
			start: .34,
			count: 2,
			size: .8,
			spread: .6
		}),
		l$4("wick", "orbit", "target", {
			start: .46,
			count: 4,
			size: .7,
			spread: .8,
			height: .3
		}),
		l$4("knot", "pulse", "target", {
			start: .57,
			size: 1.1,
			ground: true,
			height: .055,
			accent: true
		}),
		l$4("veil", "fall", "target", {
			start: .66,
			size: .6,
			height: .6
		})
	]),
	"enemy:practice-cushion:basic": r$4("Soft hop", "#d9b8a2", "#f6d9ba", "blunt", "left", "hostile", [
		l$4("cushion", "sweep", "caster", {
			start: .05,
			end: .43,
			size: .55,
			height: .1
		}),
		l$4("cushion", "cross", "target", {
			start: .34,
			count: 2,
			size: .65,
			spread: .5
		}),
		l$4("bubble", "expand", "target", {
			start: .5,
			size: 1.1,
			ground: true,
			height: .055
		}),
		l$4("petal", "rise", "caster", {
			start: .65,
			count: 3,
			size: .25,
			spread: .7,
			accent: true
		})
	]),
	"enemy:practice-cushion": r$4("Cushion tumble", "#dcb39b", "#f4e2bd", "blunt", "push", "hostile", [
		l$4("cushion", "pulse", "caster", {
			start: .04,
			end: .44,
			size: .85,
			height: .1
		}),
		l$4("cushion", "projectile", "target", {
			start: .34,
			end: .6,
			size: 1.3,
			turns: .5
		}),
		l$4("blanket", "cross", "target", {
			start: .48,
			size: 1.1,
			height: .2
		}),
		l$4("bubble", "burst", "target", {
			start: .58,
			count: 6,
			size: .3,
			spread: 1.1,
			height: .35,
			accent: true
		}),
		l$4("petal", "fall", "target", {
			start: .69,
			count: 3,
			size: .4,
			spread: .9,
			height: .8
		})
	]),
	"enemy:pollen-scout:basic": r$4("Seedbrush flick", "#b3ca75", "#f2dc91", "garden", "right", "hostile", [
		l$4("seed-pod", "sweep", "caster", {
			start: .04,
			end: .43,
			size: .6,
			offset: [
				.6,
				0,
				0
			]
		}),
		l$4("seed-pod", "projectile", "target", {
			start: .34,
			end: .61,
			count: 3,
			size: .45,
			spread: .6
		}),
		l$4("flower-bell", "cross", "target", {
			start: .5,
			count: 2,
			size: .6,
			spread: .65
		}),
		l$4("leaf", "rise", "target", {
			start: .64,
			count: 4,
			size: .28,
			spread: .9,
			accent: true
		})
	]),
	"enemy:pollen-scout": r$4("Thread garden", "#9bbb79", "#eddc98", "garden", "rise", "friendly", [
		l$4("seed-pod", "pulse", "caster", {
			start: .03,
			end: .44,
			size: .8,
			offset: [
				-.6,
				0,
				0
			]
		}),
		l$4("seed-pod", "fall", "caster", {
			start: .34,
			size: .9,
			height: .8
		}),
		l$4("sprout", "rise", "caster", {
			start: .46,
			count: 3,
			size: .8,
			spread: 1
		}),
		l$4("spindle", "rise", "caster", {
			start: .56,
			size: 1,
			height: .3
		}),
		l$4("leaf", "orbit", "caster", {
			start: .63,
			count: 5,
			size: .35,
			spread: 1.1,
			accent: true
		})
	])
};
// apps/web/src/game/squad/turn3d/card-enemy-batch2-effects.ts
var l$3 = (primitive, motion, anchor, o = {}) => ({
	primitive,
	motion,
	anchor,
	start: .34,
	end: .94,
	count: 1,
	size: .8,
	spread: .7,
	height: .18,
	turns: .25,
	offset: [
		0,
		0,
		0
	],
	aspect: [
		1,
		1,
		1
	],
	ground: false,
	accent: false,
	opacity: .8,
	...o
});
var r$3 = (name, color, accent, element, shot, target, layers) => ({
	name,
	color,
	accent,
	element,
	shot,
	target,
	layers,
	ultimate: false,
	durations: [
		610,
		200,
		85,
		230,
		250
	],
	shake: target === "friendly" ? 0 : .45
});
var ENEMY_BATCH2_EFFECTS = {
	"enemy:needle-moth:basic": r$3("Running stitch", "#83bbd6", "#e6e4fb", "pierce", "left", "hostile", [
		l$3("needle", "sweep", "caster", {
			start: .04,
			end: .43,
			size: .65,
			offset: [
				-.6,
				0,
				0
			]
		}),
		l$3("needle", "projectile", "target", {
			start: .34,
			end: .62,
			size: 1.1,
			turns: 0
		}),
		l$3("seam", "cross", "target", {
			start: .52,
			count: 2,
			size: .9,
			spread: .6
		}),
		l$3("wing", "fall", "target", {
			start: .65,
			count: 2,
			size: .35,
			spread: .8,
			height: .5,
			accent: true
		})
	]),
	"enemy:needle-moth": r$3("Needle canopy", "#75bad2", "#dbeafc", "pierce", "rise", "hostile", [
		l$3("wing", "cross", "caster", {
			start: .03,
			end: .44,
			count: 2,
			size: .65,
			spread: .65
		}),
		l$3("needle", "fall", "all-targets", {
			start: .34,
			count: 7,
			size: .7,
			spread: 1.3,
			height: 1.1,
			turns: -.5
		}),
		l$3("seam", "expand", "all-targets", {
			start: .5,
			size: 1.3,
			ground: true,
			height: .055
		}),
		l$3("droplet", "rise", "all-targets", {
			start: .63,
			count: 4,
			size: .3,
			spread: .8,
			height: .5,
			accent: true
		})
	]),
	"enemy:teacup-healer:basic": r$3("Saucer flick", "#91c8b8", "#f1e1a8", "blunt", "right", "hostile", [
		l$3("tray", "orbit", "caster", {
			start: .05,
			end: .43,
			size: .5,
			spread: .45
		}),
		l$3("tray", "projectile", "target", {
			start: .34,
			end: .59,
			size: .85,
			turns: .9
		}),
		l$3("steam", "cross", "target", {
			start: .5,
			count: 2,
			size: .65,
			spread: .55
		}),
		l$3("bubble", "fall", "target", {
			start: .64,
			count: 4,
			size: .2,
			spread: .8,
			height: .5,
			accent: true
		})
	]),
	"enemy:teacup-healer": r$3("Careful refill", "#9dd3ba", "#ffedb5", "tide", "rise", "friendly", [
		l$3("cup", "pulse", "caster", {
			start: .03,
			end: .44,
			size: .65,
			offset: [
				.65,
				0,
				0
			]
		}),
		l$3("wave", "projectile", "target", {
			start: .34,
			end: .61,
			size: .9,
			height: .5
		}),
		l$3("cup", "rise", "target", {
			start: .47,
			size: .9,
			height: .3
		}),
		l$3("steam", "orbit", "target", {
			start: .55,
			count: 3,
			size: .55,
			spread: .8,
			height: .4,
			accent: true
		}),
		l$3("leaf", "fall", "target", {
			start: .67,
			count: 3,
			size: .3,
			spread: .85,
			height: .8
		})
	]),
	"enemy:kettle-knight:basic": r$3("Spout jab", "#a7b7c8", "#f0cc8c", "blunt", "push", "hostile", [
		l$3("teapot", "pulse", "caster", {
			start: .04,
			end: .43,
			size: .55,
			offset: [
				.6,
				0,
				0
			]
		}),
		l$3("teapot", "projectile", "target", {
			start: .34,
			end: .6,
			size: .85
		}),
		l$3("steam", "burst", "target", {
			start: .51,
			count: 3,
			size: .5,
			spread: .85
		}),
		l$3("handle", "fall", "target", {
			start: .64,
			count: 2,
			size: .4,
			spread: .7,
			height: .55,
			accent: true
		})
	]),
	"enemy:kettle-knight": r$3("Mirror polish", "#b1c7dc", "#ffe6a1", "hearth", "left", "friendly", [
		l$3("handle", "sweep", "caster", {
			start: .04,
			end: .43,
			size: .75,
			offset: [
				-.6,
				0,
				0
			]
		}),
		l$3("teapot", "rise", "caster", {
			start: .34,
			size: 1.2,
			height: .2
		}),
		l$3("shield-facet", "cross", "caster", {
			start: .46,
			count: 3,
			size: .7,
			spread: 1,
			height: .25
		}),
		l$3("star", "orbit", "caster", {
			start: .58,
			count: 4,
			size: .3,
			spread: .95,
			accent: true
		}),
		l$3("light-pool", "expand", "caster", {
			start: .68,
			size: 1.2,
			ground: true,
			height: .05
		})
	])
};
// apps/web/src/game/squad/turn3d/card-enemy-batch1-effects.ts
var l$2 = (primitive, motion, anchor, o = {}) => ({
	primitive,
	motion,
	anchor,
	start: .32,
	end: .94,
	count: 1,
	size: .8,
	spread: .7,
	height: .18,
	turns: .25,
	offset: [
		0,
		0,
		0
	],
	aspect: [
		1,
		1,
		1
	],
	ground: false,
	accent: false,
	opacity: .8,
	...o
});
var r$2 = (name, color, accent, element, shot, target, layers) => ({
	name,
	color,
	accent,
	element,
	shot,
	target,
	layers,
	ultimate: false,
	durations: [
		600,
		200,
		85,
		240,
		250
	],
	shake: target === "friendly" ? 0 : .5
});
var ENEMY_BATCH1_EFFECTS = {
	"enemy:button-guard:basic": r$2("Button tap", "#d4ab77", "#fff0bc", "blunt", "left", "hostile", [
		l$2("button", "sweep", "caster", {
			start: .04,
			end: .42,
			size: .5,
			offset: [
				.55,
				0,
				0
			]
		}),
		l$2("button", "projectile", "target", {
			start: .34,
			end: .6,
			size: .75,
			turns: .7
		}),
		l$2("collar", "cross", "target", {
			start: .49,
			count: 2,
			size: .6,
			spread: .55
		}),
		l$2("seam", "fall", "target", {
			start: .62,
			count: 3,
			size: .26,
			spread: .6,
			height: .5,
			accent: true
		})
	]),
	"enemy:button-guard": r$2("Button barricade", "#d8bc8a", "#f7e6af", "hearth", "push", "friendly", [
		l$2("collar", "pulse", "caster", {
			start: .04,
			end: .44,
			size: .75,
			offset: [
				.65,
				0,
				0
			]
		}),
		l$2("button", "cross", "all-targets", {
			start: .34,
			count: 3,
			size: .7,
			spread: .9,
			height: .1
		}),
		l$2("shield-facet", "rise", "all-targets", {
			start: .46,
			count: 2,
			size: 1.1,
			spread: .8,
			height: .15
		}),
		l$2("seam", "orbit", "all-targets", {
			start: .62,
			count: 4,
			size: .32,
			spread: .95,
			height: .12,
			accent: true
		})
	]),
	"enemy:sock-skipper:basic": r$2("Heel scuff", "#d8a1ad", "#f8dcc4", "slash", "right", "hostile", [
		l$2("sock", "sweep", "caster", {
			start: .05,
			end: .44,
			size: .6,
			height: .05
		}),
		l$2("sock", "cross", "target", {
			start: .34,
			count: 2,
			size: .85,
			spread: .55,
			height: .08
		}),
		l$2("comet", "sweep", "target", {
			start: .49,
			size: .8,
			ground: true,
			height: .06
		}),
		l$2("bow", "rise", "caster", {
			start: .62,
			count: 2,
			size: .45,
			spread: .6,
			accent: true
		})
	]),
	"enemy:sock-skipper": r$2("Pocket skip", "#df9fba", "#ffe4ad", "slash", "right", "hostile", [
		l$2("sock", "pulse", "caster", {
			start: .04,
			end: .43,
			size: .7,
			offset: [
				-.6,
				0,
				0
			]
		}),
		l$2("bow", "projectile", "target", {
			start: .34,
			end: .62,
			count: 2,
			size: .7,
			spread: .6
		}),
		l$2("button", "orbit", "target", {
			start: .48,
			count: 3,
			size: .5,
			spread: .75,
			height: .25
		}),
		l$2("sock", "projectile", "caster", {
			start: .59,
			end: .83,
			size: 1
		}),
		l$2("crescent", "cross", "target", {
			start: .66,
			count: 2,
			size: .8,
			spread: .8,
			ground: true,
			height: .055,
			accent: true
		})
	]),
	"enemy:spool-ram:basic": r$2("Bobbin nudge", "#b6a3cf", "#e4d1fa", "blunt", "left", "hostile", [
		l$2("spool", "orbit", "caster", {
			start: .05,
			end: .43,
			size: .55,
			spread: .5,
			height: .1
		}),
		l$2("spool", "sweep", "target", {
			start: .34,
			size: .95,
			height: .08,
			turns: .75
		}),
		l$2("knot", "cross", "target", {
			start: .51,
			count: 2,
			size: .5,
			spread: .65
		}),
		l$2("wick", "burst", "target", {
			start: .63,
			count: 3,
			size: .3,
			spread: .8,
			accent: true
		})
	]),
	"enemy:spool-ram": r$2("Spring-loaded sweep", "#b9a2d0", "#f4cf92", "blunt", "push", "hostile", [
		l$2("spool", "pulse", "caster", {
			start: .03,
			end: .44,
			size: .8,
			offset: [
				.65,
				0,
				0
			]
		}),
		l$2("seam", "cross", "caster", {
			start: .15,
			end: .45,
			count: 3,
			size: .8,
			spread: .7,
			height: .1
		}),
		l$2("spool", "projectile", "all-targets", {
			start: .34,
			end: .61,
			size: 1.2
		}),
		l$2("yarn-fan", "sweep", "all-targets", {
			start: .46,
			size: 1.5,
			height: .1,
			turns: .6
		}),
		l$2("knock-ring", "expand", "all-targets", {
			start: .59,
			size: 1.2,
			ground: true,
			height: .055,
			accent: true
		}),
		l$2("knot", "fall", "all-targets", {
			start: .67,
			count: 3,
			size: .35,
			spread: 1,
			height: .7
		})
	])
};
// apps/web/src/game/squad/turn3d/card-roster-batch3-effects.ts
var l$1 = (primitive, motion, anchor, o = {}) => ({
	primitive,
	motion,
	anchor,
	start: .32,
	end: .94,
	count: 1,
	size: .8,
	spread: .7,
	height: .25,
	turns: .25,
	offset: [
		0,
		0,
		0
	],
	aspect: [
		1,
		1,
		1
	],
	ground: false,
	accent: false,
	opacity: .85,
	...o
});
var r$1 = (name, color, accent, element, shot, target, layers, ultimate = false) => ({
	name,
	color,
	accent,
	element,
	shot,
	target,
	layers,
	ultimate,
	durations: ultimate ? [
		670,
		250,
		105,
		280,
		280
	] : [
		600,
		240,
		90,
		260,
		320
	],
	shake: target === "friendly" ? 0 : ultimate ? 1 : .4
});
var BATCH3_EFFECT_RECIPES = {
	"brioche-1": r$1("Bell patrol", "#b3acd7", "#fff1bc", "moon", "right", "hostile", [
		l$1("night-bell", "sweep", "caster", {
			start: .05,
			end: .43,
			size: .6,
			offset: [
				.6,
				0,
				0
			]
		}),
		l$1("night-bell", "projectile", "target", {
			start: .34,
			end: .63,
			size: .9
		}),
		l$1("collar", "cross", "target", {
			start: .49,
			count: 2,
			size: .85,
			spread: .7
		}),
		l$1("star", "orbit", "caster", {
			start: .6,
			count: 4,
			size: .28,
			spread: .7,
			height: .08,
			accent: true
		})
	]),
	"brioche-2": r$1("Borrowed blanket", "#aca6d7", "#e8e4ff", "moon", "left", "friendly", [
		l$1("blanket", "hold", "caster", {
			start: .05,
			end: .44,
			size: .6,
			offset: [
				-.65,
				0,
				0
			]
		}),
		l$1("blanket", "projectile", "target", {
			start: .34,
			end: .64,
			size: 1.3
		}),
		l$1("collar", "rise", "target", {
			start: .49,
			size: .9,
			height: .16,
			offset: [
				.7,
				0,
				0
			]
		}),
		l$1("crescent", "pour", "target", {
			start: .58,
			count: 5,
			size: .3,
			height: .8,
			spread: .8,
			accent: true
		})
	]),
	"brioche-3": r$1("Starched collar", "#b7afdb", "#f8eed2", "moon", "push", "hostile", [
		l$1("collar", "pulse", "caster", {
			start: .06,
			end: .43,
			size: .6,
			offset: [
				.6,
				0,
				0
			]
		}),
		l$1("collar", "expand", "target", {
			start: .34,
			size: 1.5,
			ground: true,
			height: .06
		}),
		l$1("shield-facet", "cross", "target", {
			start: .46,
			count: 3,
			size: .75,
			spread: 1
		}),
		l$1("night-bell", "burst", "target", {
			start: .59,
			count: 3,
			size: .5,
			spread: 1.05,
			accent: true
		})
	]),
	"brioche-4": r$1("Constellation apron", "#b2a2d4", "#fff3c6", "moon", "wide", "friendly", [
		l$1("constellation", "rise", "caster", {
			start: .04,
			end: .46,
			size: .8,
			offset: [
				-.7,
				0,
				0
			]
		}),
		l$1("constellation", "hold", "all-targets", {
			start: .32,
			size: 1.45,
			height: .2,
			offset: [
				.65,
				0,
				0
			]
		}),
		l$1("blanket", "cross", "all-targets", {
			start: .44,
			count: 2,
			size: .8,
			spread: 1
		}),
		l$1("night-bell", "orbit", "all-targets", {
			start: .55,
			count: 3,
			size: .4,
			spread: .9,
			height: .13,
			accent: true
		}),
		l$1("apron", "pulse", "all-targets", {
			start: .64,
			size: 1.5,
			ground: true,
			height: .05
		})
	], true),
	"velvet-1": r$1("Silk nick", "#b18dce", "#ecd6ff", "slash", "left", "hostile", [
		l$1("spindle", "hold", "caster", {
			start: .05,
			end: .43,
			size: .65,
			offset: [
				-.6,
				0,
				0
			]
		}),
		l$1("spindle", "projectile", "target", {
			start: .34,
			end: .58,
			size: 1,
			turns: -.45
		}),
		l$1("veil", "sweep", "target", {
			start: .47,
			size: 1.05,
			height: .12,
			turns: .65
		}),
		l$1("ink-drop", "burst", "target", {
			start: .59,
			count: 5,
			size: .3,
			spread: .9,
			accent: true
		})
	]),
	"velvet-2": r$1("Candle bounce", "#af98d9", "#ffe2b5", "tide", "right", "hostile", [
		l$1("wick", "rise", "caster", {
			start: .04,
			end: .44,
			size: .65,
			offset: [
				.6,
				0,
				0
			]
		}),
		l$1("night-bell", "projectile", "all-targets", {
			start: .34,
			end: .66,
			size: .8
		}),
		l$1("flame", "fall", "all-targets", {
			start: .44,
			count: 3,
			size: .5,
			spread: .65,
			height: .7
		}),
		l$1("spindle", "cross", "all-targets", {
			start: .58,
			count: 2,
			size: .7,
			spread: .8,
			accent: true
		}),
		l$1("wave", "pulse", "all-targets", {
			start: .65,
			size: 1.15,
			ground: true,
			height: .05
		})
	]),
	"velvet-3": r$1("Stolen flame", "#a695d7", "#e5d9f8", "tide", "push", "hostile", [
		l$1("veil", "pulse", "caster", {
			start: .06,
			end: .42,
			size: .65,
			offset: [
				.6,
				0,
				0
			]
		}),
		l$1("spindle", "orbit", "target", {
			start: .34,
			count: 3,
			size: .6,
			spread: .9,
			height: .14
		}),
		l$1("flame", "projectile", "caster", {
			start: .49,
			end: .74,
			count: 2,
			size: .6,
			spread: .45
		}),
		l$1("collar", "burst", "target", {
			start: .55,
			count: 3,
			size: .5,
			spread: .95
		}),
		l$1("crescent", "expand", "caster", {
			start: .66,
			size: 1.1,
			ground: true,
			height: .055,
			accent: true
		})
	]),
	"velvet-4": r$1("Velvet curtain", "#ac8bc6", "#f8d9ee", "slash", "wide", "hostile", [
		l$1("spindle", "cross", "caster", {
			start: .05,
			end: .45,
			count: 2,
			size: .6,
			spread: .65
		}),
		l$1("veil", "fall", "target", {
			start: .33,
			end: .8,
			count: 2,
			size: 1.35,
			spread: .9,
			height: .7
		}),
		l$1("spindle", "sweep", "target", {
			start: .47,
			size: 1.4,
			turns: -.7,
			height: .14
		}),
		l$1("paper-cat", "rise", "caster", {
			start: .56,
			size: 1,
			offset: [
				.75,
				0,
				0
			]
		}),
		l$1("constellation", "burst", "target", {
			start: .64,
			count: 3,
			size: .6,
			spread: 1.1,
			accent: true
		})
	], true),
	"marigold-1": r$1("Seed stitch", "#b1c98b", "#f9e8a9", "garden", "push", "hostile", [
		l$1("seed-pod", "hold", "caster", {
			start: .05,
			end: .43,
			size: .55,
			offset: [
				.6,
				0,
				0
			]
		}),
		l$1("seed-pod", "projectile", "target", {
			start: .34,
			end: .62,
			size: .95
		}),
		l$1("needle", "cross", "target", {
			start: .48,
			count: 3,
			size: .8,
			spread: .8,
			ground: true,
			height: .055
		}),
		l$1("flower-bell", "rise", "caster", {
			start: .59,
			count: 2,
			size: .5,
			spread: .65,
			height: .13,
			accent: true
		})
	]),
	"marigold-2": r$1("Garden bell", "#b4ce8e", "#ffe9ac", "garden", "rise", "friendly", [
		l$1("flower-bell", "sweep", "caster", {
			start: .05,
			end: .45,
			size: .65,
			offset: [
				-.6,
				0,
				0
			]
		}),
		l$1("flower-bell", "rise", "all-targets", {
			start: .34,
			size: 1,
			offset: [
				.65,
				0,
				0
			],
			height: .12
		}),
		l$1("petal", "fall", "all-targets", {
			start: .45,
			count: 5,
			size: .35,
			spread: .9,
			height: .85
		}),
		l$1("seed-pod", "orbit", "all-targets", {
			start: .59,
			count: 3,
			size: .4,
			spread: .8,
			height: .1,
			accent: true
		})
	]),
	"marigold-3": r$1("Spring pruning", "#9eb987", "#f0d9a2", "garden", "left", "hostile", [
		l$1("shears", "pulse", "caster", {
			start: .05,
			end: .43,
			size: .65,
			offset: [
				.6,
				0,
				0
			]
		}),
		l$1("shears", "cross", "target", {
			start: .34,
			count: 2,
			size: 1.05,
			spread: .75
		}),
		l$1("leaf", "burst", "target", {
			start: .47,
			count: 5,
			size: .45,
			spread: 1.05
		}),
		l$1("seed-pod", "pour", "target", {
			start: .56,
			count: 3,
			size: .4,
			spread: .7,
			height: .75,
			accent: true
		}),
		l$1("stem", "sweep", "target", {
			start: .64,
			size: 1.25,
			ground: true,
			height: .06
		})
	]),
	"marigold-4": r$1("First tea blossom", "#bad49a", "#fff1bc", "garden", "wide", "friendly", [
		l$1("watering-can", "rise", "caster", {
			start: .05,
			end: .45,
			size: .75,
			offset: [
				.65,
				0,
				0
			]
		}),
		l$1("watering-can", "pour", "all-targets", {
			start: .33,
			end: .75,
			size: 1,
			height: .65,
			offset: [
				.8,
				0,
				0
			]
		}),
		l$1("flower-bell", "rise", "all-targets", {
			start: .45,
			count: 2,
			size: .85,
			spread: .9,
			height: .18
		}),
		l$1("droplet", "fall", "all-targets", {
			start: .52,
			count: 5,
			size: .28,
			spread: .65,
			height: .9
		}),
		l$1("seed-pod", "cross", "all-targets", {
			start: .61,
			count: 3,
			size: .5,
			spread: 1,
			accent: true
		}),
		l$1("wreath", "pulse", "all-targets", {
			start: .67,
			size: 1.8,
			ground: true,
			height: .055
		})
	], true),
	"brioche-passive": r$1("Night watch", "#b3aad7", "#fbe7bb", "moon", "push", "friendly", [
		l$1("night-bell", "rise", "caster", {
			start: .1,
			size: .65,
			offset: [
				.65,
				0,
				0
			]
		}),
		l$1("constellation", "expand", "caster", {
			start: .25,
			size: .95,
			ground: true,
			height: .055
		}),
		l$1("collar", "orbit", "caster", {
			start: .39,
			count: 3,
			size: .4,
			spread: .75,
			height: .13,
			accent: true
		})
	]),
	"velvet-passive": r$1("Lost flame", "#b096d1", "#f8dced", "tide", "right", "friendly", [
		l$1("spindle", "fall", "caster", {
			start: .1,
			size: .65,
			offset: [
				-.6,
				0,
				0
			],
			height: .6
		}),
		l$1("veil", "orbit", "caster", {
			start: .24,
			count: 2,
			size: .5,
			spread: .75,
			height: .13
		}),
		l$1("wick", "cross", "caster", {
			start: .38,
			count: 3,
			size: .4,
			spread: .8,
			accent: true
		})
	]),
	"marigold-passive": r$1("First leaf", "#abc68c", "#fff0b8", "garden", "rise", "friendly", [
		l$1("seed-pod", "pulse", "caster", {
			start: .1,
			size: .65,
			offset: [
				.6,
				0,
				0
			]
		}),
		l$1("flower-bell", "orbit", "caster", {
			start: .25,
			count: 2,
			size: .55,
			spread: .75,
			height: .1
		}),
		l$1("watering-can", "expand", "caster", {
			start: .39,
			size: .9,
			ground: true,
			height: .055,
			accent: true
		})
	])
};
// apps/web/src/game/squad/turn3d/card-roster-batch2-effects.ts
var l = (primitive, motion, anchor, o = {}) => ({
	primitive,
	motion,
	anchor,
	start: .32,
	end: .94,
	count: 1,
	size: .8,
	spread: .7,
	height: .25,
	turns: .25,
	offset: [
		0,
		0,
		0
	],
	aspect: [
		1,
		1,
		1
	],
	ground: false,
	accent: false,
	opacity: .85,
	...o
});
var r = (name, color, accent, element, shot, target, layers, ultimate = false) => ({
	name,
	color,
	accent,
	element,
	shot,
	target,
	layers,
	ultimate,
	durations: ultimate ? [
		670,
		250,
		110,
		280,
		275
	] : [
		600,
		240,
		90,
		260,
		320
	],
	shake: target === "friendly" ? 0 : ultimate ? .9 : .4
});
var BATCH2_EFFECT_RECIPES = {
	"biscuit-1": r("Rolling pin", "#dca56d", "#fff0bd", "blunt", "push", "hostile", [
		l("roller", "hold", "caster", {
			start: .06,
			end: .41,
			size: .75,
			offset: [
				.55,
				0,
				0
			]
		}),
		l("roller", "sweep", "target", {
			start: .34,
			end: .64,
			size: 1.35,
			turns: .7,
			height: .12
		}),
		l("seam", "cross", "target", {
			start: .46,
			count: 3,
			size: .75,
			spread: .9,
			ground: true,
			height: .05
		}),
		l("bread", "burst", "target", {
			start: .59,
			count: 5,
			size: .25,
			spread: 1.1,
			accent: true
		})
	]),
	"biscuit-2": r("Sideboard step", "#e1b67c", "#f9e9c8", "hearth", "left", "friendly", [
		l("tray", "pulse", "caster", {
			start: .05,
			end: .44,
			size: .65,
			ground: true,
			height: .04
		}),
		l("roller", "cross", "all-targets", {
			start: .34,
			count: 2,
			size: .9,
			spread: .8,
			height: .1
		}),
		l("apron-cloth", "sweep", "target", {
			start: .48,
			size: 1.1,
			offset: [
				.65,
				0,
				0
			],
			turns: -.3
		}),
		l("button", "fall", "all-targets", {
			start: .56,
			count: 4,
			size: .3,
			ground: true,
			height: .055,
			spread: .8,
			accent: true
		})
	]),
	"biscuit-3": r("Last crumb", "#d99259", "#ffe7a0", "blunt", "right", "hostile", [
		l("crumb-crown", "rise", "caster", {
			start: .07,
			end: .43,
			size: .6,
			offset: [
				-.6,
				0,
				0
			]
		}),
		l("roller", "fall", "target", {
			start: .33,
			end: .57,
			size: 1.35,
			height: 1.2,
			turns: -.35
		}),
		l("crumb-crown", "burst", "target", {
			start: .5,
			count: 3,
			size: .7,
			spread: 1.05
		}),
		l("shield-facet", "sweep", "target", {
			start: .6,
			count: 2,
			size: 1.1,
			ground: true,
			height: .05,
			accent: true
		})
	]),
	"biscuit-4": r("Bakers procession", "#e5b57b", "#fff4c5", "hearth", "wide", "hostile", [
		l("roller", "rise", "caster", {
			start: .06,
			end: .45,
			count: 2,
			size: .6,
			spread: .7
		}),
		l("crumb-crown", "projectile", "all-targets", {
			start: .33,
			end: .66,
			count: 2,
			size: .85,
			spread: .75
		}),
		l("bread", "cross", "all-targets", {
			start: .43,
			count: 3,
			size: .65,
			spread: 1.1
		}),
		l("roller", "orbit", "all-targets", {
			start: .58,
			count: 2,
			size: .7,
			spread: .9,
			height: .14
		}),
		l("button", "pulse", "all-targets", {
			start: .65,
			count: 4,
			size: .38,
			spread: 1,
			ground: true,
			height: .05,
			accent: true
		})
	], true),
	"inkcap-1": r("Ink thread", "#aa91c8", "#e5d4fa", "thread", "left", "hostile", [
		l("ink-cap", "hold", "caster", {
			start: .05,
			end: .43,
			size: .5,
			offset: [
				-.6,
				0,
				0
			]
		}),
		l("knot", "projectile", "target", {
			start: .34,
			end: .6,
			count: 3,
			size: .5,
			spread: .4
		}),
		l("ink-cap", "sweep", "target", {
			start: .48,
			size: 1.05,
			height: .12
		}),
		l("yarn-fan", "cross", "target", {
			start: .58,
			count: 3,
			size: 1,
			spread: .7,
			ground: true,
			height: .07,
			accent: true
		})
	]),
	"inkcap-2": r("Quiet spores", "#b59bce", "#ecdfed", "ink", "rise", "hostile", [
		l("ink-cap", "pulse", "caster", {
			start: .06,
			end: .45,
			size: .65,
			offset: [
				.6,
				0,
				0
			]
		}),
		l("ink-drop", "pour", "target", {
			start: .33,
			count: 7,
			size: .3,
			height: .8,
			spread: .9
		}),
		l("ink-cap", "fall", "target", {
			start: .45,
			count: 2,
			size: .65,
			spread: .6,
			height: .65
		}),
		l("crescent", "hold", "target", {
			start: .58,
			size: .9,
			offset: [
				.65,
				0,
				0
			],
			accent: true
		}),
		l("ink-stain", "expand", "target", {
			start: .62,
			size: 1.15,
			ground: true,
			height: .055
		})
	]),
	"inkcap-3": r("Paper decoy", "#c1a3d4", "#fff0d0", "thread", "push", "friendly", [
		l("apron-cloth", "cross", "caster", {
			start: .06,
			end: .43,
			count: 2,
			size: .5,
			spread: .5
		}),
		l("paper-cat", "rise", "target", {
			start: .35,
			size: 1.4,
			offset: [
				.75,
				0,
				0
			],
			height: .15
		}),
		l("knot", "orbit", "target", {
			start: .49,
			count: 3,
			size: .4,
			spread: .85,
			height: .12
		}),
		l("seam", "fall", "target", {
			start: .6,
			count: 5,
			size: .35,
			height: .8,
			spread: .7,
			accent: true
		})
	]),
	"inkcap-4": r("Dreaming canopy", "#a694cf", "#eae3ff", "moon", "wide", "hostile", [
		l("paper-cat", "rise", "caster", {
			start: .05,
			end: .45,
			count: 2,
			size: .5,
			spread: .75
		}),
		l("ink-cap", "hold", "all-targets", {
			start: .32,
			end: .82,
			size: 1.5,
			height: .55,
			offset: [
				0,
				0,
				-.65
			]
		}),
		l("crescent", "fall", "all-targets", {
			start: .43,
			count: 3,
			size: .5,
			spread: .8,
			height: 1
		}),
		l("paper-cat", "orbit", "all-targets", {
			start: .53,
			count: 2,
			size: .6,
			spread: .95,
			height: .1
		}),
		l("yarn-fan", "pulse", "all-targets", {
			start: .65,
			size: 1.7,
			ground: true,
			height: .055,
			accent: true
		})
	], true),
	"cinnamon-1": r("Spice pinch", "#e1a07f", "#ffe6bb", "hearth", "right", "hostile", [
		l("spice-star", "pulse", "caster", {
			start: .05,
			end: .43,
			size: .5,
			offset: [
				-.55,
				0,
				0
			]
		}),
		l("spice-star", "projectile", "target", {
			start: .34,
			end: .62,
			count: 3,
			size: .5,
			spread: .6
		}),
		l("ember", "pour", "target", {
			start: .46,
			count: 6,
			size: .2,
			height: .75,
			spread: .65
		}),
		l("droplet", "projectile", "caster", {
			start: .62,
			count: 2,
			size: .3,
			accent: true
		})
	]),
	"cinnamon-2": r("Comfort cup", "#e7b58a", "#fff4cd", "hearth", "push", "friendly", [
		l("serving-bell", "hold", "caster", {
			start: .06,
			end: .42,
			size: .6,
			offset: [
				.6,
				0,
				0
			]
		}),
		l("cup", "rise", "target", {
			start: .35,
			size: 1.15,
			offset: [
				.75,
				0,
				0
			]
		}),
		l("spice-star", "fall", "target", {
			start: .46,
			count: 4,
			size: .35,
			spread: .8,
			height: .7
		}),
		l("handle", "cross", "target", {
			start: .55,
			count: 2,
			size: .9,
			spread: .75,
			height: .15,
			accent: true
		}),
		l("tray", "pulse", "target", {
			start: .64,
			size: 1.45,
			ground: true,
			height: .05
		})
	]),
	"cinnamon-3": r("Clean apron", "#d7ad8c", "#f7f1db", "hearth", "left", "friendly", [
		l("apron-cloth", "hold", "caster", {
			start: .06,
			end: .45,
			size: .65,
			offset: [
				.6,
				0,
				0
			]
		}),
		l("apron-cloth", "sweep", "target", {
			start: .34,
			end: .68,
			size: 1.35,
			height: .16,
			turns: -.55
		}),
		l("wave", "cross", "target", {
			start: .48,
			count: 3,
			size: .8,
			spread: .75,
			ground: true,
			height: .06
		}),
		l("spice-star", "rise", "target", {
			start: .6,
			count: 5,
			size: .3,
			spread: .85,
			height: .3,
			accent: true
		})
	]),
	"cinnamon-4": r("Second serving", "#e6b27a", "#fff7d5", "holy", "rise", "friendly", [
		l("spice-star", "orbit", "caster", {
			start: .05,
			end: .45,
			count: 3,
			size: .4,
			spread: .7
		}),
		l("serving-bell", "rise", "target", {
			start: .33,
			end: .72,
			size: 1.6,
			offset: [
				.85,
				0,
				0
			],
			height: .45
		}),
		l("apron-cloth", "cross", "target", {
			start: .47,
			count: 2,
			size: .8,
			spread: 1
		}),
		l("spice-star", "burst", "target", {
			start: .56,
			count: 7,
			size: .4,
			spread: 1.25,
			accent: true
		}),
		l("sprout", "expand", "target", {
			start: .65,
			size: 1.45,
			ground: true,
			height: .07
		})
	], true),
	"biscuit-passive": r("Bakers resolve", "#d9ae77", "#fff0bb", "hearth", "push", "friendly", [
		l("crumb-crown", "rise", "caster", {
			start: .1,
			size: .7,
			offset: [
				.6,
				0,
				0
			]
		}),
		l("roller", "orbit", "caster", {
			start: .25,
			count: 2,
			size: .5,
			spread: .65,
			height: .12
		}),
		l("bread", "pulse", "caster", {
			start: .4,
			size: .95,
			ground: true,
			height: .055,
			accent: true
		})
	]),
	"inkcap-passive": r("Soft landing", "#ab92c4", "#e8dff3", "thread", "left", "friendly", [
		l("paper-cat", "fall", "caster", {
			start: .1,
			size: .75,
			offset: [
				.65,
				0,
				0
			],
			height: .4
		}),
		l("ink-cap", "expand", "caster", {
			start: .26,
			size: .95,
			ground: true,
			height: .06
		}),
		l("knot", "cross", "caster", {
			start: .4,
			count: 3,
			size: .4,
			spread: .75,
			accent: true
		})
	]),
	"cinnamon-passive": r("Ground spice", "#dba17d", "#fff0c2", "hearth", "rise", "friendly", [
		l("spice-star", "sweep", "caster", {
			start: .1,
			size: .8,
			height: .12
		}),
		l("serving-bell", "pulse", "caster", {
			start: .26,
			size: .7,
			offset: [
				.65,
				0,
				0
			]
		}),
		l("apron-cloth", "orbit", "caster", {
			start: .39,
			count: 2,
			size: .4,
			spread: .75,
			height: .1,
			accent: true
		})
	])
};
// apps/web/src/game/squad/turn3d/card-roster-effects.ts
var layer$2 = (primitive, motion, anchor, options = {}) => ({
	primitive,
	motion,
	anchor,
	start: .32,
	end: .94,
	count: 1,
	size: .8,
	spread: .7,
	height: .25,
	turns: .25,
	offset: [
		0,
		0,
		0
	],
	aspect: [
		1,
		1,
		1
	],
	ground: false,
	accent: false,
	opacity: .85,
	...options
});
var recipe$2 = (name, color, accent, element, shot, target, layers, ultimate = false) => ({
	name,
	color,
	accent,
	element,
	shot,
	target,
	layers,
	ultimate,
	durations: ultimate ? [
		670,
		250,
		105,
		280,
		280
	] : [
		600,
		240,
		90,
		260,
		320
	],
	shake: target === "friendly" ? 0 : ultimate ? 1 : .45
});
var ROSTER_EFFECT_RECIPES = {
	"panko-1": recipe$2("Pan reply", "#e4aa65", "#fff0ba", "blunt", "right", "hostile", [
		layer$2("pan", "pulse", "caster", {
			start: .06,
			end: .42,
			size: .65,
			offset: [
				.6,
				0,
				0
			]
		}),
		layer$2("pan", "sweep", "target", {
			start: .35,
			end: .67,
			size: 1.05,
			turns: -.4,
			height: .18
		}),
		layer$2("tray", "expand", "caster", {
			start: .53,
			size: 1.1,
			ground: true,
			height: .06
		}),
		layer$2("spark", "cross", "target", {
			start: .5,
			count: 4,
			size: .25,
			spread: .8,
			accent: true
		})
	]),
	"panko-2": recipe$2("Bread cover", "#d7a56c", "#ffebaa", "hearth", "push", "friendly", [
		layer$2("bread", "rise", "caster", {
			start: .06,
			end: .5,
			size: .6,
			offset: [
				-.6,
				0,
				0
			]
		}),
		layer$2("bread", "hold", "target", {
			start: .36,
			size: 1.5,
			height: .4,
			offset: [
				0,
				0,
				-.5
			]
		}),
		layer$2("shield-facet", "cross", "target", {
			start: .49,
			count: 2,
			size: .6,
			height: .2,
			spread: .9
		}),
		layer$2("ember", "orbit", "target", {
			start: .56,
			count: 5,
			size: .16,
			height: .12,
			spread: .8,
			accent: true
		})
	]),
	"panko-3": recipe$2("Crust return", "#e3b780", "#fff3ca", "blunt", "wide", "friendly", [
		layer$2("pan", "orbit", "caster", {
			start: .06,
			end: .46,
			count: 2,
			size: .45,
			spread: .8
		}),
		layer$2("tray", "cross", "all-targets", {
			start: .34,
			count: 2,
			size: .8,
			spread: .8,
			height: .2
		}),
		layer$2("bread", "orbit", "all-targets", {
			start: .48,
			count: 3,
			size: .45,
			spread: .75,
			height: .1
		}),
		layer$2("seam", "burst", "all-targets", {
			start: .62,
			count: 4,
			size: .25,
			spread: .9,
			accent: true
		})
	]),
	"panko-4": recipe$2("Oven door", "#e7a34f", "#fff0b1", "hearth", "push", "friendly", [
		layer$2("handle", "fall", "caster", {
			start: .06,
			end: .45,
			count: 2,
			size: .55,
			spread: .7
		}),
		layer$2("oven", "rise", "caster", {
			start: .33,
			size: 1.8,
			height: .5,
			offset: [
				0,
				0,
				-.7
			]
		}),
		layer$2("pan", "orbit", "caster", {
			start: .47,
			count: 3,
			size: .6,
			spread: .95,
			height: .14
		}),
		layer$2("flame", "pulse", "caster", {
			start: .56,
			count: 4,
			size: .45,
			spread: .85,
			height: .1,
			accent: true
		}),
		layer$2("tray", "expand", "caster", {
			start: .5,
			size: 1.9,
			ground: true,
			height: .05
		})
	], true),
	"mallow-1": recipe$2("Whisk flare", "#f59571", "#ffe4a3", "ember", "left", "hostile", [
		layer$2("whisk", "orbit", "caster", {
			start: .04,
			end: .45,
			size: .7,
			height: .3,
			spread: .55,
			turns: .65
		}),
		layer$2("whisk", "projectile", "target", {
			start: .36,
			end: .6,
			size: .85,
			turns: -.5
		}),
		layer$2("flame", "sweep", "target", {
			start: .49,
			count: 3,
			size: .55,
			spread: .9
		}),
		layer$2("ember", "fall", "target", {
			start: .62,
			count: 5,
			size: .17,
			height: .65,
			accent: true
		})
	]),
	"mallow-2": recipe$2("Split ember", "#f49c80", "#fff2bc", "ember", "wide", "hostile", [
		layer$2("ember", "hold", "caster", {
			start: .07,
			end: .42,
			size: .5,
			offset: [
				.55,
				0,
				0
			]
		}),
		layer$2("flame", "cross", "all-targets", {
			start: .35,
			count: 2,
			size: 1.05,
			spread: 1.1,
			height: .18
		}),
		layer$2("shield-facet", "burst", "all-targets", {
			start: .5,
			count: 5,
			size: .32,
			spread: .9
		}),
		layer$2("whisk", "expand", "all-targets", {
			start: .59,
			size: .7,
			ground: true,
			height: .06,
			accent: true
		})
	]),
	"mallow-3": recipe$2("Burnt sugar", "#e87a5d", "#ffdb96", "ember", "push", "hostile", [
		layer$2("shield-facet", "pour", "caster", {
			start: .05,
			end: .44,
			count: 4,
			size: .35,
			height: .9,
			spread: .4
		}),
		layer$2("ember", "fall", "target", {
			start: .34,
			end: .61,
			size: 1.25,
			height: 1.2
		}),
		layer$2("ink-stain", "pulse", "target", {
			start: .48,
			size: 1.45,
			ground: true,
			height: .055
		}),
		layer$2("whisk", "burst", "target", {
			start: .52,
			count: 3,
			size: .5,
			spread: 1.1
		}),
		layer$2("spark", "rise", "target", {
			start: .61,
			count: 7,
			size: .2,
			height: .45,
			spread: .8,
			accent: true
		})
	]),
	"mallow-4": recipe$2("Closing blaze", "#f79070", "#fff1b2", "ember", "right", "hostile", [
		layer$2("whisk", "rise", "caster", {
			start: .05,
			end: .48,
			count: 3,
			size: .6,
			spread: .8
		}),
		layer$2("oven", "fall", "all-targets", {
			start: .34,
			end: .74,
			size: 1.2,
			height: 1,
			offset: [
				0,
				0,
				-.5
			]
		}),
		layer$2("flame", "cross", "all-targets", {
			start: .46,
			count: 3,
			size: .8,
			spread: 1.05,
			height: .25
		}),
		layer$2("ember", "orbit", "all-targets", {
			start: .55,
			count: 5,
			size: .26,
			height: .15,
			spread: 1,
			turns: .8,
			accent: true
		}),
		layer$2("wick", "sweep", "all-targets", {
			start: .62,
			count: 2,
			size: 1,
			ground: true,
			height: .06
		})
	], true),
	"sorrel-1": recipe$2("Moon spoon", "#9abbdc", "#edf2ff", "moon", "left", "hostile", [
		layer$2("spoon", "rise", "caster", {
			start: .05,
			end: .44,
			size: .55,
			offset: [
				-.6,
				0,
				0
			]
		}),
		layer$2("spoon", "projectile", "target", {
			start: .36,
			end: .63,
			size: .8,
			turns: .35
		}),
		layer$2("crescent", "sweep", "target", {
			start: .5,
			size: 1.1,
			height: .13,
			ground: true
		}),
		layer$2("droplet", "projectile", "caster", {
			start: .65,
			count: 3,
			size: .2,
			spread: .45,
			accent: true
		})
	]),
	"sorrel-2": recipe$2("Cold brew", "#7ecbd8", "#dbf2ff", "tide", "right", "hostile", [
		layer$2("teapot", "pulse", "caster", {
			start: .05,
			end: .43,
			size: .65,
			offset: [
				.6,
				0,
				0
			]
		}),
		layer$2("wave", "projectile", "target", {
			start: .34,
			end: .64,
			count: 2,
			size: .7,
			spread: .35
		}),
		layer$2("droplet", "fall", "target", {
			start: .45,
			count: 7,
			size: .32,
			spread: .8,
			height: .9
		}),
		layer$2("crescent", "cross", "target", {
			start: .55,
			count: 2,
			size: .65,
			spread: .6,
			accent: true
		}),
		layer$2("bubble", "pulse", "target", {
			start: .64,
			size: 1.25,
			ground: true,
			height: .06
		})
	]),
	"sorrel-3": recipe$2("Decanted moon", "#a0b8e6", "#fff4c7", "moon", "rise", "friendly", [
		layer$2("crescent", "hold", "caster", {
			start: .05,
			end: .48,
			size: .65,
			offset: [
				-.6,
				0,
				0
			]
		}),
		layer$2("teapot", "pour", "target", {
			start: .35,
			end: .7,
			size: .9,
			height: .8,
			offset: [
				.6,
				0,
				0
			]
		}),
		layer$2("crescent", "projectile", "target", {
			start: .4,
			end: .66,
			size: .75
		}),
		layer$2("shield-facet", "expand", "target", {
			start: .53,
			size: 1.3,
			height: .07,
			ground: true
		}),
		layer$2("spoon", "orbit", "target", {
			start: .63,
			count: 3,
			size: .36,
			spread: .75,
			height: .16,
			accent: true
		})
	]),
	"sorrel-4": recipe$2("Shared pot", "#91c5d7", "#f1eecc", "tide", "wide", "friendly", [
		layer$2("spoon", "cross", "caster", {
			start: .06,
			end: .46,
			count: 2,
			size: .65,
			spread: .6
		}),
		layer$2("teapot", "rise", "caster", {
			start: .32,
			end: .8,
			size: 1.4,
			height: .5,
			offset: [
				.8,
				0,
				0
			]
		}),
		layer$2("cup", "rise", "all-targets", {
			start: .41,
			size: .8,
			height: .25,
			offset: [
				.65,
				0,
				0
			]
		}),
		layer$2("wave", "pour", "all-targets", {
			start: .48,
			count: 3,
			size: .5,
			height: .7,
			spread: .4
		}),
		layer$2("crescent", "orbit", "all-targets", {
			start: .57,
			count: 3,
			size: .45,
			spread: .85,
			height: .15,
			accent: true
		}),
		layer$2("tray", "pulse", "all-targets", {
			start: .63,
			size: 1.3,
			ground: true,
			height: .06
		})
	], true),
	"panko-passive": recipe$2("Warm crust", "#dfad70", "#ffe7b1", "hearth", "push", "friendly", [
		layer$2("bread", "orbit", "caster", {
			start: .1,
			count: 2,
			size: .35,
			spread: .7,
			height: .15
		}),
		layer$2("pan", "pulse", "caster", {
			start: .24,
			size: .8,
			ground: true,
			height: .06
		}),
		layer$2("spark", "fall", "caster", {
			start: .36,
			count: 4,
			size: .12,
			height: .5,
			accent: true
		})
	]),
	"mallow-passive": recipe$2("Hot whisk", "#ed916c", "#ffebb5", "ember", "left", "friendly", [
		layer$2("whisk", "sweep", "caster", {
			start: .1,
			size: .65,
			height: .15
		}),
		layer$2("flame", "orbit", "caster", {
			start: .22,
			count: 3,
			size: .3,
			spread: .7,
			height: .1
		}),
		layer$2("comet", "rise", "caster", {
			start: .35,
			count: 4,
			size: .2,
			height: .4,
			accent: true
		})
	]),
	"sorrel-passive": recipe$2("Measured pour", "#94bedc", "#f7eec9", "tide", "rise", "friendly", [
		layer$2("teapot", "orbit", "caster", {
			start: .1,
			size: .45,
			height: .2,
			spread: .6
		}),
		layer$2("spoon", "pulse", "caster", {
			start: .24,
			size: .65,
			ground: true,
			height: .07
		}),
		layer$2("droplet", "cross", "caster", {
			start: .36,
			count: 4,
			size: .2,
			height: .15,
			accent: true
		})
	])
};
// apps/web/src/game/squad/turn3d/card-effect-data.ts
function layer$1(primitive, motion, anchor, options = {}) {
	return {
		primitive,
		motion,
		anchor,
		start: .32,
		end: .94,
		count: 1,
		size: .8,
		spread: .7,
		height: .25,
		turns: .25,
		offset: [
			0,
			0,
			0
		],
		aspect: [
			1,
			1,
			1
		],
		ground: false,
		accent: false,
		opacity: .85,
		...options
	};
}
function recipe$1(name, color, accent, element, shot, target, layers, options = {}) {
	return {
		name,
		color,
		accent,
		element,
		shot,
		target,
		layers,
		ultimate: false,
		durations: [
			600,
			240,
			90,
			260,
			320
		],
		shake: target === "friendly" ? 0 : .5,
		...options
	};
}
layer$1("flame", "rise", "target", {
	count: 3,
	size: .24,
	spread: .46,
	height: .08,
	opacity: .5
}), layer$1("knot", "orbit", "target", {
	count: 2,
	size: .35,
	spread: .48,
	height: .13,
	opacity: .5
}), layer$1("knock-ring", "pulse", "target", {
	size: .95,
	height: .06,
	ground: true,
	opacity: .45
}), layer$1("ink-stain", "pulse", "target", {
	count: 3,
	size: .17,
	spread: .44,
	height: .05,
	ground: true,
	opacity: .45
}), layer$1("sprout", "rise", "target", {
	count: 2,
	size: .3,
	spread: .51,
	height: .1,
	opacity: .45
}), layer$1("shield-facet", "orbit", "target", {
	count: 3,
	size: .28,
	spread: .59,
	height: .17,
	opacity: .35
});
/** Each composition is authored from the existing skill's cafe action and intent. */
var CARD_EFFECT_RECIPES = {
	...ROSTER_EFFECT_RECIPES,
	...BATCH2_EFFECT_RECIPES,
	...BATCH3_EFFECT_RECIPES,
	"mochi-1": recipe$1("Door knock", "#efba65", "#fff1bb", "blunt", "push", "hostile", [
		layer$1("handle", "pulse", "caster", {
			start: .04,
			end: .42,
			size: .42,
			height: .35,
			offset: [
				.6,
				0,
				0
			]
		}),
		layer$1("door", "rise", "target", {
			size: 1.35,
			height: .42,
			offset: [
				.65,
				0,
				.25
			]
		}),
		layer$1("knock-ring", "expand", "target", {
			start: .44,
			end: .71,
			count: 2,
			size: .85,
			height: .2,
			spread: .18
		}),
		layer$1("seam", "burst", "target", {
			start: .54,
			count: 5,
			size: .22,
			spread: 1,
			accent: true
		})
	]),
	"mochi-2": recipe$1("Warm welcome", "#ffc777", "#fff3c6", "hearth", "rise", "friendly", [
		layer$1("lantern", "pulse", "caster", {
			start: .05,
			end: .44,
			size: .55,
			height: .55,
			offset: [
				-.6,
				0,
				0
			]
		}),
		layer$1("lantern", "projectile", "target", {
			start: .34,
			end: .62,
			size: .65,
			height: .4
		}),
		layer$1("light-pool", "expand", "target", {
			start: .47,
			end: .97,
			size: 1.6,
			ground: true,
			height: .05
		}),
		layer$1("spark", "rise", "target", {
			start: .54,
			count: 7,
			size: .12,
			spread: .85,
			height: .4,
			accent: true
		})
	]),
	"mochi-3": recipe$1("Apron crossing", "#e6bb8b", "#ffe8b4", "thread", "right", "friendly", [
		layer$1("seam", "pulse", "caster", {
			start: .06,
			end: .42,
			size: .8,
			ground: true,
			height: .06
		}),
		layer$1("apron", "cross", "target", {
			size: .85,
			count: 2,
			spread: .65,
			height: .25
		}),
		layer$1("bow", "rise", "target", {
			start: .56,
			size: .8,
			height: .25,
			offset: [
				.65,
				0,
				0
			],
			accent: true
		}),
		layer$1("seam", "sweep", "target", {
			start: .49,
			size: .6,
			count: 3,
			ground: true,
			height: .07,
			spread: 1.2
		})
	]),
	"mochi-4": recipe$1("Last light shelter", "#f6c46a", "#fff4cf", "holy", "wide", "friendly", [
		layer$1("window", "orbit", "caster", {
			start: .06,
			end: .48,
			size: .4,
			count: 3,
			spread: .85,
			height: .3
		}),
		layer$1("roof", "rise", "all-targets", {
			start: .36,
			end: .95,
			size: 1.2,
			height: .4,
			offset: [
				0,
				0,
				-.45
			]
		}),
		layer$1("lantern", "hold", "all-targets", {
			start: .45,
			size: .45,
			height: .4,
			offset: [
				.65,
				0,
				0
			]
		}),
		layer$1("shield-facet", "orbit", "all-targets", {
			start: .49,
			count: 3,
			size: .48,
			spread: .7,
			height: .18,
			accent: true
		}),
		layer$1("light-pool", "expand", "all-targets", {
			start: .45,
			size: 1.4,
			ground: true,
			height: .06
		})
	], {
		ultimate: true,
		durations: [
			650,
			250,
			105,
			280,
			280
		]
	}),
	"soot-1": recipe$1("Cocoa spark", "#cd875f", "#ffd5a0", "ember", "left", "hostile", [
		layer$1("ember", "pulse", "caster", {
			start: .06,
			end: .42,
			size: .4,
			height: .3,
			offset: [
				-.5,
				0,
				0
			]
		}),
		layer$1("ember", "projectile", "target", {
			start: .36,
			end: .59,
			size: .5,
			height: .5
		}),
		layer$1("spark", "burst", "target", {
			start: .48,
			count: 9,
			size: .25,
			spread: 1.1,
			height: .22,
			accent: true
		}),
		layer$1("ink-stain", "expand", "target", {
			start: .58,
			size: .6,
			ground: true,
			height: .055,
			opacity: .4
		})
	]),
	"soot-2": recipe$1("Black cup", "#9a81cb", "#d7b5f0", "ink", "right", "hostile", [
		layer$1("crescent", "pulse", "caster", {
			start: .05,
			end: .4,
			size: .6,
			height: .3,
			offset: [
				.6,
				0,
				0
			]
		}),
		layer$1("cup", "projectile", "target", {
			start: .32,
			end: .62,
			size: .85,
			height: .5
		}),
		layer$1("ink-drop", "pour", "target", {
			start: .44,
			count: 5,
			size: .24,
			spread: .45,
			height: .9
		}),
		layer$1("ink-stain", "expand", "target", {
			start: .5,
			size: 1.25,
			ground: true,
			height: .06
		}),
		layer$1("steam", "rise", "target", {
			start: .64,
			size: .55,
			height: .25,
			offset: [
				.65,
				0,
				0
			],
			accent: true
		})
	]),
	"soot-3": recipe$1("Lantern wick", "#dc8d70", "#ffe0a1", "ember", "push", "hostile", [
		layer$1("wick", "rise", "caster", {
			start: .03,
			end: .45,
			size: .7,
			height: .5,
			offset: [
				-.6,
				0,
				0
			]
		}),
		layer$1("flame", "projectile", "target", {
			start: .35,
			end: .6,
			size: .65,
			height: .25
		}),
		layer$1("lantern", "expand", "target", {
			start: .47,
			end: .78,
			size: 1.2,
			height: .35,
			offset: [
				.7,
				0,
				0
			]
		}),
		layer$1("flame", "rise", "target", {
			start: .53,
			count: 4,
			size: .55,
			spread: .85,
			height: .4
		}),
		layer$1("comet", "burst", "target", {
			start: .52,
			count: 6,
			size: .25,
			spread: 1.3,
			accent: true
		})
	], {
		shake: .9,
		durations: [
			630,
			230,
			105,
			270,
			340
		]
	}),
	"soot-4": recipe$1("Midnight service", "#b396eb", "#ffe5ad", "moon", "left", "hostile", [
		layer$1("tray", "rise", "caster", {
			start: .04,
			end: .49,
			size: 1.25,
			height: .4,
			offset: [
				-.6,
				0,
				0
			]
		}),
		layer$1("star", "orbit", "caster", {
			start: .1,
			end: .52,
			count: 5,
			size: .25,
			spread: 1,
			height: .4,
			accent: true
		}),
		layer$1("lantern", "fall", "all-targets", {
			start: .35,
			end: .78,
			count: 3,
			size: .58,
			spread: .95,
			height: 1.1
		}),
		layer$1("crescent", "expand", "all-targets", {
			start: .5,
			size: 1.2,
			height: .15,
			ground: true
		}),
		layer$1("comet", "burst", "all-targets", {
			start: .53,
			count: 7,
			size: .25,
			spread: 1.1,
			accent: true
		})
	], {
		ultimate: true,
		durations: [
			680,
			250,
			110,
			280,
			280
		],
		shake: 1.1
	}),
	"clover-1": recipe$1("Leaf tap", "#89c99a", "#e8efb7", "garden", "right", "hostile", [
		layer$1("stem", "rise", "caster", {
			start: .06,
			end: .42,
			size: .65,
			height: .3,
			offset: [
				.55,
				0,
				0
			]
		}),
		layer$1("leaf", "projectile", "target", {
			start: .32,
			end: .61,
			count: 2,
			size: .55,
			spread: .3,
			height: .38
		}),
		layer$1("leaf", "burst", "target", {
			start: .5,
			count: 5,
			size: .37,
			spread: .9,
			accent: true
		}),
		layer$1("sprout", "rise", "caster", {
			start: .63,
			size: .5,
			height: .16,
			offset: [
				-.5,
				0,
				0
			]
		})
	]),
	"clover-2": recipe$1("Patient steep", "#92cba9", "#f5e6b8", "tide", "rise", "friendly", [
		layer$1("cup", "pulse", "caster", {
			start: .03,
			end: .44,
			size: .65,
			height: .3,
			offset: [
				.6,
				0,
				0
			]
		}),
		layer$1("droplet", "pour", "target", {
			start: .34,
			end: .68,
			count: 5,
			size: .3,
			spread: .35,
			height: .8
		}),
		layer$1("cup", "hold", "target", {
			start: .42,
			size: .9,
			height: .27,
			offset: [
				.65,
				0,
				0
			]
		}),
		layer$1("steam", "rise", "target", {
			start: .52,
			size: .65,
			height: .4,
			offset: [
				.65,
				0,
				0
			],
			accent: true
		}),
		layer$1("bubble", "orbit", "target", {
			start: .59,
			count: 4,
			size: .22,
			spread: .7,
			height: .16
		})
	]),
	"clover-3": recipe$1("Clearleaf rinse", "#8ed6c4", "#e6f1c3", "tide", "left", "friendly", [
		layer$1("wreath", "pulse", "caster", {
			start: .04,
			end: .45,
			size: .8,
			ground: true,
			height: .07
		}),
		layer$1("wave", "sweep", "all-targets", {
			start: .34,
			count: 2,
			size: 1,
			spread: 1.1,
			height: .18
		}),
		layer$1("wreath", "expand", "all-targets", {
			start: .52,
			size: 1.5,
			ground: true,
			height: .07
		}),
		layer$1("droplet", "burst", "all-targets", {
			start: .5,
			count: 6,
			size: .24,
			spread: .9,
			accent: true
		}),
		layer$1("petal", "rise", "all-targets", {
			start: .64,
			count: 4,
			size: .25,
			spread: .7,
			height: .3
		})
	]),
	"clover-4": recipe$1("Greenhouse morning", "#91c990", "#fff0b6", "garden", "rise", "friendly", [
		layer$1("stem", "rise", "caster", {
			start: .05,
			end: .48,
			count: 3,
			size: .7,
			spread: .8,
			height: .18
		}),
		layer$1("greenhouse", "rise", "all-targets", {
			start: .34,
			size: 1.4,
			height: .35,
			offset: [
				0,
				0,
				-.5
			]
		}),
		layer$1("sprout", "rise", "all-targets", {
			start: .47,
			count: 4,
			size: .6,
			spread: .8,
			height: .13
		}),
		layer$1("petal", "orbit", "all-targets", {
			start: .54,
			count: 7,
			size: .27,
			spread: 1,
			height: .36,
			accent: true
		}),
		layer$1("window", "expand", "all-targets", {
			start: .42,
			size: 1.4,
			ground: true,
			height: .06,
			opacity: .4
		})
	], {
		ultimate: true,
		durations: [
			670,
			250,
			90,
			280,
			280
		]
	}),
	"enemy:button-guard": recipe$1("Button brace", "#d9b47c", "#f7e4aa", "hearth", "push", "friendly", [
		layer$1("button", "pulse", "caster", {
			start: .04,
			end: .45,
			size: .8,
			height: .35,
			offset: [
				.6,
				0,
				0
			]
		}),
		layer$1("button", "expand", "all-targets", {
			start: .4,
			size: 1.2,
			height: .18,
			ground: true
		}),
		layer$1("shield-facet", "rise", "all-targets", {
			start: .48,
			count: 3,
			size: .52,
			spread: .7,
			height: .22
		}),
		layer$1("seam", "orbit", "all-targets", {
			start: .56,
			count: 4,
			size: .3,
			spread: .8,
			height: .16,
			accent: true
		})
	]),
	"enemy:sock-skipper": recipe$1("Pocket skip", "#dca2b1", "#ffe1bc", "slash", "right", "hostile", [
		layer$1("sock", "pulse", "caster", {
			start: .04,
			end: .44,
			size: .6,
			height: .25,
			offset: [
				-.6,
				0,
				0
			]
		}),
		layer$1("sock", "cross", "target", {
			start: .35,
			count: 2,
			size: .65,
			height: .25,
			spread: 1
		}),
		layer$1("bow", "burst", "target", {
			start: .5,
			count: 4,
			size: .3,
			spread: .8
		}),
		layer$1("comet", "sweep", "caster", {
			start: .65,
			count: 3,
			size: .28,
			spread: .9,
			height: .16,
			accent: true
		})
	]),
	"enemy:spool-ram": recipe$1("Spool charge", "#cba7ce", "#f6d7af", "blunt", "push", "hostile", [
		layer$1("spool", "pulse", "caster", {
			start: .02,
			end: .45,
			size: .85,
			height: .3,
			offset: [
				.6,
				0,
				0
			]
		}),
		layer$1("spool", "projectile", "target", {
			start: .36,
			end: .6,
			size: 1.1,
			height: .2,
			turns: 1
		}),
		layer$1("seam", "sweep", "target", {
			start: .48,
			count: 5,
			size: .6,
			spread: 1.4,
			height: .07,
			ground: true
		}),
		layer$1("knock-ring", "burst", "target", {
			start: .54,
			count: 3,
			size: .35,
			spread: 1.1,
			accent: true
		})
	], {
		shake: 1,
		durations: [
			700,
			250,
			105,
			270,
			320
		]
	}),
	"enemy:needle-moth": recipe$1("Needle rain", "#86c7dd", "#dce8fb", "pierce", "left", "hostile", [
		layer$1("wing", "pulse", "caster", {
			start: .03,
			end: .44,
			size: .8,
			height: .35,
			offset: [
				-.65,
				0,
				0
			]
		}),
		layer$1("needle", "fall", "target", {
			start: .35,
			count: 7,
			size: .55,
			spread: 1,
			height: 1.2,
			turns: -.3
		}),
		layer$1("spark", "expand", "target", {
			start: .51,
			count: 3,
			size: .45,
			spread: .6,
			height: .14,
			ground: true
		}),
		layer$1("wing", "rise", "target", {
			start: .64,
			count: 3,
			size: .3,
			spread: .85,
			height: .25,
			accent: true
		})
	]),
	"enemy:teacup-healer": recipe$1("Teacup refill", "#a9d9b7", "#fff1cc", "tide", "rise", "friendly", [
		layer$1("steam", "pulse", "caster", {
			start: .04,
			end: .42,
			size: .75,
			height: .35,
			offset: [
				.6,
				0,
				0
			]
		}),
		layer$1("cup", "orbit", "target", {
			start: .34,
			count: 2,
			size: .58,
			spread: .8,
			height: .3
		}),
		layer$1("droplet", "rise", "target", {
			start: .46,
			count: 6,
			size: .25,
			spread: .7,
			height: .7,
			accent: true
		}),
		layer$1("bubble", "expand", "target", {
			start: .52,
			size: 1.6,
			ground: true,
			height: .06
		})
	]),
	"enemy:yarn-giant": recipe$1("Loomfall", "#c29491", "#f2ca9b", "thread", "wide", "hostile", [
		layer$1("spool", "orbit", "caster", {
			start: .03,
			end: .46,
			count: 2,
			size: .8,
			spread: 1.1,
			height: .4
		}),
		layer$1("yarn-fan", "fall", "all-targets", {
			start: .35,
			size: 1.7,
			height: 1.2
		}),
		layer$1("knot", "cross", "all-targets", {
			start: .48,
			count: 2,
			size: .65,
			spread: .8,
			height: .16
		}),
		layer$1("seam", "expand", "all-targets", {
			start: .54,
			size: 1.8,
			ground: true,
			height: .07,
			accent: true
		})
	], {
		shake: 1.1,
		durations: [
			780,
			260,
			110,
			290,
			330
		]
	}),
	"enemy:binding-thread": recipe$1("Tightening knot", "#ba9bd1", "#eccee7", "thread", "right", "hostile", [
		layer$1("knot", "pulse", "caster", {
			start: .05,
			end: .43,
			size: .6,
			height: .18,
			offset: [
				.55,
				0,
				0
			]
		}),
		layer$1("wick", "projectile", "target", {
			start: .35,
			end: .59,
			size: .7,
			height: .18
		}),
		layer$1("knot", "orbit", "target", {
			start: .48,
			count: 3,
			size: .48,
			spread: .65,
			height: .15
		}),
		layer$1("seam", "cross", "target", {
			start: .56,
			count: 2,
			size: 1,
			spread: .55,
			ground: true,
			height: .08,
			accent: true
		})
	]),
	"enemy:practice-cushion": recipe$1("Cushion bump", "#d9b4a1", "#f8e2bf", "blunt", "push", "hostile", [
		layer$1("cushion", "pulse", "caster", {
			start: .05,
			end: .44,
			size: .8,
			height: .15,
			offset: [
				-.6,
				0,
				0
			]
		}),
		layer$1("cushion", "projectile", "target", {
			start: .35,
			end: .61,
			size: .85,
			height: .15
		}),
		layer$1("bubble", "burst", "target", {
			start: .51,
			count: 7,
			size: .23,
			spread: .85,
			height: .3,
			accent: true
		}),
		layer$1("petal", "fall", "target", {
			start: .63,
			count: 4,
			size: .28,
			spread: .7,
			height: .5
		})
	], { shake: .18 }),
	"mochi-passive": recipe$1("Door keeper", "#e8b565", "#fff0bf", "hearth", "push", "friendly", [
		layer$1("handle", "rise", "caster", {
			start: .12,
			end: .93,
			size: .52,
			height: .25,
			offset: [
				.6,
				0,
				0
			]
		}),
		layer$1("shield-facet", "pulse", "caster", {
			start: .2,
			size: .65,
			ground: true,
			height: .07
		}),
		layer$1("spark", "orbit", "caster", {
			start: .3,
			count: 3,
			size: .16,
			spread: .6,
			height: .16,
			accent: true
		})
	]),
	"soot-passive": recipe$1("Ash reader", "#ad8fd5", "#f7d9a9", "ember", "left", "friendly", [
		layer$1("ember", "rise", "caster", {
			start: .1,
			end: .94,
			count: 4,
			size: .2,
			spread: .6,
			height: .35
		}),
		layer$1("wick", "orbit", "caster", {
			start: .22,
			count: 2,
			size: .48,
			spread: .7,
			height: .2
		}),
		layer$1("crescent", "pulse", "caster", {
			start: .28,
			size: .8,
			ground: true,
			height: .07,
			accent: true
		})
	]),
	"clover-passive": recipe$1("Second steep", "#91cfa5", "#ecf4c9", "garden", "rise", "friendly", [
		layer$1("leaf", "sweep", "caster", {
			start: .1,
			count: 3,
			size: .3,
			spread: .7,
			height: .22
		}),
		layer$1("bubble", "rise", "caster", {
			start: .22,
			count: 4,
			size: .18,
			spread: .6,
			height: .4,
			accent: true
		}),
		layer$1("stem", "pulse", "caster", {
			start: .29,
			size: .5,
			height: .25,
			offset: [
				-.65,
				0,
				0
			]
		})
	])
};
for (const [owner, name, primary, residue] of [
	[
		"button-guard",
		"Button tap",
		"button",
		"seam"
	],
	[
		"sock-skipper",
		"Sock kick",
		"sock",
		"comet"
	],
	[
		"spool-ram",
		"Spool bump",
		"spool",
		"spark"
	],
	[
		"needle-moth",
		"Needle stitch",
		"needle",
		"wing"
	],
	[
		"teacup-healer",
		"Saucer tap",
		"tray",
		"droplet"
	],
	[
		"yarn-giant",
		"Yarn sweep",
		"yarn-fan",
		"knot"
	],
	[
		"binding-thread",
		"Thread tug",
		"knot",
		"wick"
	],
	[
		"practice-cushion",
		"Soft nudge",
		"cushion",
		"petal"
	]
]) {
	const signature = CARD_EFFECT_RECIPES[`enemy:${owner}`];
	CARD_EFFECT_RECIPES[`enemy:${owner}:basic`] = {
		...signature,
		name,
		target: "hostile",
		durations: [
			600,
			200,
			80,
			220,
			250
		],
		shake: .3,
		layers: [
			layer$1(primary, "pulse", "caster", {
				start: .08,
				end: .45,
				size: .45,
				height: .2,
				offset: [
					.55,
					0,
					0
				]
			}),
			layer$1(primary, "projectile", "target", {
				start: .4,
				end: .66,
				size: .6,
				height: .2
			}),
			layer$1(residue, "expand", "target", {
				start: .55,
				end: .92,
				size: .7,
				height: .08,
				ground: true,
				accent: true
			})
		]
	};
}
Object.assign(CARD_EFFECT_RECIPES, ENEMY_BATCH1_EFFECTS);
Object.assign(CARD_EFFECT_RECIPES, ENEMY_BATCH2_EFFECTS);
Object.assign(CARD_EFFECT_RECIPES, ENEMY_BATCH3_EFFECTS);
Object.assign(CARD_EFFECT_RECIPES, ENEMY_BATCH4_EFFECTS);
Object.assign(CARD_EFFECT_RECIPES, BOSS_EFFECTS);
// apps/web/src/game/cardrpg/depth/card-action-plan.ts
/** A preparation is resolved by its own event, never inferred from a skill name. */
function chargeEvent(plan) {
	if (plan.events.some((event) => event.type === "damage" && event.actorId === plan.actorId)) return void 0;
	return plan.events.find((event) => event.type === "charge" && event.actorId === plan.actorId);
}
/** Presentation identities preserve the rules' skill IDs and existing mixer clips. */
function createCardActionPlan(events, presentationId) {
	const effect = CARD_EFFECT_RECIPES[presentationId];
	if (!effect) return paceCardAction(createActionPlan(events), presentationId);
	const plan = createActionPlan(events, {
		...EFFECT_REGISTRY[events.find((event) => event.type === "action_start")?.skillId ?? presentationId] ?? EFFECT_REGISTRY.status_apply,
		name: effect.name,
		color: effect.color,
		accent: effect.accent,
		duration: effect.durations,
		shake: effect.shake,
		ultimate: effect.ultimate,
		motifs: effect.layers.map((layer) => layer.primitive)
	});
	plan.presentationId = presentationId;
	return paceCardAction(plan, presentationId);
}
/** Keep the anticipation readable and fit all hit-stop/settle time inside the budget. */
function paceCardAction(plan, identity) {
	const charge = chargeEvent(plan);
	if (charge) plan.name = charge.note || "Charging the next strike";
	if (plan.events.some((event) => event.note === "Clutch heal")) {
		plan.beats[3].duration += 90;
		plan.duration += 90;
	}
	const authoredBudget = (identity.startsWith("enemy:") ? 1400 : plan.ultimate ? 2800 : identity.endsWith("-1") ? 1200 : 1800) - 25;
	const fixed = plan.beats[0].duration + plan.beats[2].duration;
	const flexible = plan.duration - fixed;
	const scale = Math.min(1, (authoredBudget - fixed) / Math.max(1, flexible));
	let start = 0;
	for (const beat of plan.beats) {
		beat.start = start;
		if (beat.kind !== "anticipation" && beat.kind !== "impact") beat.duration = Math.floor(beat.duration * scale);
		start += beat.duration;
	}
	plan.duration = start;
	return plan;
}
// apps/web/src/game/cardrpg/depth/battle-presentation.ts
var damageKinds = /* @__PURE__ */ new Set([
	"reaction-damage",
	"damage",
	"dot",
	"detonate",
	"shared",
	"reflect"
]);
var eventTypes = {
	"reaction-damage": "damage",
	damage: "damage",
	dot: "damage",
	detonate: "damage",
	shared: "damage",
	reflect: "damage",
	heal: "heal",
	revive: "heal",
	survive: "heal",
	shield: "shield",
	defeat: "death",
	status: "status_apply",
	expire: "status_expire",
	dispel: "status_expire",
	resist: "fizzle",
	immune: "fizzle",
	phase: "boss_phase",
	summon: "spawn",
	charge: "charge"
};
/** Copy only presentation-owned mutable fields. Rules keep their authoritative battle. */
function snapshotBattle(battle) {
	return {
		...battle,
		...battle.initial.skillsV5 && battle.v4 ? { v4: {
			...battle.v4,
			events: [...battle.v4.events]
		} } : {},
		actors: structuredClone(battle.actors),
		intents: structuredClone(battle.intents),
		queue: [...battle.queue],
		acted: [...battle.acted],
		log: [...battle.log]
	};
}
function presentationEvents(log, battle, skillId) {
	return log.flatMap((event, index) => {
		const type = eventTypes[event.kind];
		if (!type) return [];
		return [{
			version: 3,
			seq: index + 1,
			turn: 0,
			round: event.round,
			actionId: battle.log.length,
			beat: 2,
			type,
			actorId: event.actorId,
			skillId,
			targetIds: [event.targetId],
			amount: event.amount,
			note: event.text
		}];
	});
}
/** The action marker precedes round ticks in the existing rules log. */
function splitPresentation(before, after, skillId) {
	const log = after.log.slice(before.log.length);
	const boundary = log.findIndex((event) => event.kind === "action" || event.kind === "enemy-action") + 1;
	const actionLog = log.slice(0, boundary);
	const roundLog = log.slice(boundary);
	const impact = snapshotBattle(after);
	impact.round = before.round;
	impact.queue = [...before.queue];
	impact.intents = structuredClone(before.intents);
	impact.log = [...before.log, ...actionLog];
	if (after.initial.skillsV5 && impact.v4) impact.v4.events = impact.v4.events.filter((e) => e.version === 1 || e.logIndex <= before.log.length || e.logIndex <= impact.log.length && e.stage !== "round-end");
	const roundSummons = new Set(roundLog.filter((event) => event.kind === "summon").map((event) => event.targetId));
	impact.actors = impact.actors.filter((actor) => !roundSummons.has(actor.id) || before.actors.some((previous) => previous.id === actor.id));
	const deferredPhases = (after.v4?.events.slice(before.v4?.events.length ?? 0).filter((event) => event.kind === "boss-phase" && event.version === 2 && (event.stage === "round-end" || event.logIndex > impact.log.length)) ?? []).reverse();
	for (const actor of impact.actors) {
		const previous = before.actors.find((candidate) => candidate.id === actor.id);
		if (!previous) continue;
		for (const event of deferredPhases) {
			if (event.kind !== "boss-phase" || event.actorId !== actor.id) continue;
			if (after.initial.gameplayA6) {
				if (event.from > 1) actor.bonuses.a6FirstPhase = 1;
				else delete actor.bonuses.a6FirstPhase;
				actor.phase = Math.max(1, event.from - 1);
			} else actor.phase = event.from;
		}
		if (!after.initial.skillsV5 && roundLog.some((event) => event.kind === "phase" && event.targetId === actor.id)) actor.phase = previous.phase;
		actor.hp = previous.hp;
		for (const event of actionLog) {
			if (event.targetId !== actor.id) continue;
			if (damageKinds.has(event.kind)) actor.hp -= event.amount;
			if (event.kind === "heal") actor.hp += event.amount;
			if (event.kind === "revive" || event.kind === "survive") actor.hp = event.amount;
		}
		actor.shield -= roundLog.filter((event) => event.kind === "shield" && event.targetId === actor.id).reduce((sum, event) => sum + event.amount, 0);
	}
	const roundEvents = presentationEvents(roundLog, after, "round-status");
	const roundPlan = roundLog.length || after.round !== before.round ? createActionPlan(roundEvents, {
		...EFFECT_REGISTRY.status_apply,
		name: `Round ${after.round}`,
		duration: [
			0,
			0,
			70,
			100,
			130
		],
		ultimate: false,
		shake: 0
	}) : null;
	if (roundPlan) {
		roundPlan.actorId = "";
		roundPlan.skillId = "round-status";
		roundPlan.name = roundLog.find((event) => event.kind === "phase")?.text || `Round ${after.round} · recovery and status`;
		let start = 0;
		for (const [index, beat] of roundPlan.beats.entries()) {
			beat.start = start;
			beat.duration = [
				0,
				0,
				70,
				100,
				130
			][index];
			start += beat.duration;
		}
		roundPlan.duration = start;
	}
	return {
		impact,
		events: presentationEvents(actionLog, after, skillId),
		roundPlan
	};
}
// apps/web/src/game/cardrpg/depth/feel-lab.ts
/** Isolated presentation fixtures. Previewing never grants items or alters the account. */
var GALLERY_ACTIONS = [
	...CATS$1.flatMap((cat) => cat.skills.map((skill) => ({
		id: skill.id,
		owner: cat.id,
		name: `${cat.name} · ${skill.name}`,
		ultimate: skill.type === "ultimate",
		enemy: false
	}))),
	...CATS$1.filter((cat) => CARD_EFFECT_RECIPES[cat.passive.id]).map((cat) => ({
		id: cat.passive.id,
		owner: cat.id,
		name: `${cat.name} · ${cat.passive.name}`,
		ultimate: false,
		enemy: false
	})),
	...ENEMIES.filter((enemy) => CARD_EFFECT_RECIPES[`enemy:${enemy.id}:basic`]).map((enemy) => ({
		id: `enemy:${enemy.id}:basic`,
		owner: enemy.id,
		name: `${enemy.name} · ${CARD_EFFECT_RECIPES[`enemy:${enemy.id}:basic`].name}`,
		ultimate: false,
		enemy: true
	})),
	...ENEMIES.map((enemy) => ({
		id: `enemy:${enemy.id}`,
		owner: enemy.id,
		name: `${enemy.name} · ${enemy.intent}`,
		ultimate: false,
		enemy: true
	}))
];
function galleryFixture(id, preparation = false) {
	const action = GALLERY_ACTIONS.find((item) => item.id === id);
	if (!action) throw new Error(`Unknown gallery action ${id}`);
	const account = createDepthAccount(71);
	account.account.cards = CARDS.map((card) => ({
		id: card.id,
		cardId: card.id,
		level: 10,
		stars: 3,
		shards: 0,
		soulbound: true
	}));
	account.team = [.../* @__PURE__ */ new Set([
		action.enemy ? "mochi" : action.owner,
		"mochi",
		"soot",
		"clover"
	])].slice(0, 3);
	for (const cat of CATS$1) {
		account.rows[cat.id] = cat.row;
		account.skills[cat.id] = cat.skills.slice(0, 3).map((skill) => skill.id);
	}
	const enemy = ENEMY_BY_ID[action.owner];
	const battle = createBattle({
		seed: 71,
		chapter: enemy?.chapter ?? 1,
		cats: battleCats(account),
		enemies: [action.enemy ? action.owner : "button-guard"]
	});
	const caster = battle.actors.find((actor) => actor.catalogId === action.owner);
	const skill = skillById(id);
	const passive = action.id.endsWith("-passive");
	const enemySupport = action.enemy && !id.endsWith(":basic") && ["heal", "shield"].includes(enemy.mechanic);
	const friendly = passive || enemySupport || skill && [
		"ally",
		"allies",
		"self",
		"fallen"
	].includes(skill.target);
	const targets = battle.actors.filter((actor) => actor.side === (friendly ? caster.side : caster.side === "party" ? "enemy" : "party"));
	const targetIds = (skill?.target === "self" ? [caster] : [
		"allies",
		"foes",
		"row"
	].includes(skill?.target ?? "") ? targets : targets.slice(0, 1)).map((actor) => actor.id);
	const skillId = action.enemy ? `${enemy.role}Attack` : id;
	const start = {
		version: 3,
		seq: 0,
		turn: 1,
		round: 1,
		actionId: 1,
		beat: 0,
		type: "action_start",
		actorId: caster.id,
		skillId,
		targetIds,
		amount: 0
	};
	if (!action.enemy && !passive) {
		const actual = createBattle({
			...battle.initial,
			gameplayV4: true,
			skillsV5: true,
			gameplayA6: true
		});
		const cat = actual.actors.find((actor) => actor.catalogId === action.owner);
		cat.skills = CAT_BY_ID[action.owner].skills.map((skill) => skill.id);
		cat.charge = 100;
		cat.turns = 3;
		cat.shield = 45;
		for (const ally of actual.actors.filter((actor) => actor.side === cat.side)) ally.hp = Math.floor(ally.maxHp * (ally.id === cat.id ? .8 : .4));
		const patient = actual.actors.find((actor) => actor.side === cat.side && actor.id !== cat.id);
		patient.hp = id === "cinnamon-4" ? 0 : Math.floor(patient.maxHp * .15);
		actual.queue = [cat.id, ...actual.queue.filter((actorId) => actorId !== cat.id)];
		actual.v4.committed = true;
		const choice = legalChoices(actual).find((choice) => choice.skillId === id);
		if (!choice) throw new Error(`No legal gallery action ${id}`);
		const before = snapshotBattle(actual);
		if (!act(actual, choice)) throw new Error(`Gallery action rejected ${id}`);
		const resolved = splitPresentation(before, actual, id);
		const targets = [...new Set(resolved.events.flatMap((event) => event.targetIds))];
		if (!targets.length) targets.push(choice.targetId);
		return {
			battle: resolved.impact,
			plan: createCardActionPlan([{
				...start,
				targetIds: targets
			}, ...resolved.events], id),
			action
		};
	}
	if (preparation && action.owner === "spool-ram") {
		const actual = createBattle({
			...battle.initial,
			gameplayV4: true,
			skillsV5: true,
			gameplayA6: true
		});
		const ram = actual.actors.find((actor) => actor.catalogId === "spool-ram");
		ram.turns = 2;
		ram.charge = id.endsWith(":basic") ? 0 : 100;
		actual.queue = [ram.id, ...actual.queue.filter((actorId) => actorId !== ram.id)];
		actual.v4.committed = true;
		const before = snapshotBattle(actual);
		enemyAct(actual);
		const resolved = splitPresentation(before, actual, skillId);
		const targets = [...new Set(resolved.events.flatMap((event) => event.targetIds))];
		return {
			battle: resolved.impact,
			plan: createCardActionPlan([{
				...start,
				actorId: ram.id,
				targetIds: targets
			}, ...resolved.events], id),
			action
		};
	}
	const effect = enemySupport && enemy?.mechanic === "heal" || passive && action.owner === "clover" || skill?.effects.some((item) => item.kind === "heal") ? "heal" : friendly ? "shield" : "damage";
	return {
		battle,
		plan: createCardActionPlan([start, {
			...start,
			seq: 1,
			beat: 2,
			type: effect,
			amount: 42
		}], id),
		action
	};
}
Object.fromEntries([
	"mochi",
	"soot",
	"clover",
	"panko",
	"mallow",
	"sorrel",
	"biscuit",
	"inkcap",
	"cinnamon",
	"brioche",
	"velvet",
	"marigold"
].map((cat, i) => [cat, {
	pitch: 2 ** ((-9 + i % 6 * 4) / 12),
	speed: .085 + i % 3 * .022,
	brightness: i < 6 ? 750 + i * 200 : 2400 + (i - 6) * 350,
	timbre: i < 6 ? "warm" : "bright"
}]));
var EVENT_CUES = {
	round_start: "ui.turn",
	turn_start: "ui.turn",
	action_start: "kit.magic.charge",
	travel: "kit.slash.release",
	damage: "hit.blunt",
	heal: "ui.heal",
	shield: "status.shield.on",
	status_apply: "status.burn.on",
	status_expire: "status.burn.off",
	interrupt: "ui.block",
	passive: "ui.heal",
	death: "ui.death",
	intent: "ui.turn",
	wave_clear: "ui.reward",
	wave_start: "ui.open",
	boss_phase: "kit.heavy.charge",
	victory: "music.victory",
	defeat: "music.defeat",
	loot: "ui.coin",
	rest: "ui.heal",
	gear_proc: "ui.reward",
	turn_end: "ui.turn",
	charge: "kit.magic.charge",
	delay: "ui.hover",
	spawn: "ui.open",
	fizzle: "ui.fail",
	snapshot: "ui.turn",
	hit: "hit.blunt",
	"status-tick": "status.burn.tick",
	"status-on": "status.shield.on",
	"status-off": "status.shield.off",
	crit: "ui.crit",
	block: "ui.block",
	cleanse: "status.shield.off",
	rage: "ui.reward",
	supply: "ui.heal"
};
function eventCue(event) {
	if (event.critical) return "ui.crit";
	if (event.status && [
		"status_apply",
		"status_expire",
		"status-tick"
	].includes(event.type)) return `status.${event.status}.${event.type === "status_apply" ? "on" : event.type === "status_expire" ? "off" : "tick"}`;
	return EVENT_CUES[event.type] ?? "hit.magic";
}
// apps/web/src/audio/events.ts
function playFrame(audio, frame) {
	const p = frame.plan, unit = p.actorId.replace(/^(party|cat)[-:]/, ""), phase = {
		anticipation: "charge",
		travel: "release",
		impact: "impact",
		reaction: "tail",
		residue: "tail"
	}[frame.beat.kind];
	const element = ["slash", "arrow"].includes(p.shape) ? "slash" : [
		"bash",
		"charge",
		"sweep"
	].includes(p.shape) ? "heavy" : "magic";
	audio.play(p.ultimate ? `ult.${unit}.${phase}` : `skill.${unit}.1.${phase === "charge" ? "cast" : "impact"}`, { element });
	if (phase === "charge") audio.play(`voice.${unit}.${p.ultimate ? "ult" : "skill"}`);
	if (phase === "impact") for (const event of p.events) audio.play(eventCue(event), { element });
}
// apps/web/src/game/squad/turn3d/card-lab-effects.ts
var layer = (primitive, motion, options) => ({
	primitive,
	motion,
	anchor: "target",
	start: 0,
	end: 1,
	count: 1,
	size: .6,
	spread: .6,
	height: .2,
	turns: .2,
	offset: [
		0,
		0,
		0
	],
	aspect: [
		1,
		1,
		1
	],
	ground: false,
	accent: false,
	opacity: .65,
	...options
});
var recipe = (name, color, accent, element, layers) => ({
	name,
	color,
	accent,
	element,
	layers,
	shot: "rise",
	target: "friendly",
	ultimate: false,
	durations: [
		600,
		200,
		80,
		220,
		200
	],
	shake: 0
});
/** Additive cues share the existing bounded pool; no new materials or geometry. */
var LAB_EFFECT_RECIPES = {
	"auto-extra:tea-cloud": recipe("Tea cloud", "#9fded1", "#fae5aa", "tide", [layer("steam", "rise", {
		count: 3,
		spread: .6,
		height: .15,
		size: .6
	}), layer("shield-facet", "orbit", {
		start: .12,
		count: 3,
		size: .3,
		spread: .7,
		height: .12,
		accent: true
	})]),
	"auto-extra:front-relay": recipe("Front relay", "#f0cf83", "#c2edb2", "garden", [layer("seam", "rise", {
		count: 2,
		size: .75,
		spread: .45,
		height: .1,
		aspect: [
			.3,
			1,
			1
		]
	}), layer("spark", "pulse", {
		start: .15,
		count: 2,
		size: .25,
		spread: .45,
		height: .7,
		accent: true
	})])
};
// apps/web/src/game/squad/turn3d/card-audio-score.ts
var cache = /* @__PURE__ */ new Map();
function cardSoundScore(id) {
	const cached = cache.get(id);
	if (cached) return cached;
	let seed = 2166136261;
	for (let i = 0; i < id.length; i++) {
		seed ^= id.charCodeAt(i);
		seed = Math.imul(seed, 16777619);
	}
	seed >>>= 0;
	const recipe = CARD_EFFECT_RECIPES[id] ?? LAB_EFFECT_RECIPES[id];
	const element = recipe?.element ?? (id.includes("heal") ? "garden" : id.includes("Attack") ? "blunt" : "hearth");
	const palettes = {
		hearth: [
			261.63,
			"sine",
			.025
		],
		moon: [
			220,
			"sine",
			.018
		],
		garden: [
			349.23,
			"triangle",
			.02
		],
		tide: [
			293.66,
			"sine",
			.06
		],
		ember: [
			196,
			"triangle",
			.12
		],
		blunt: [
			110,
			"sine",
			.09
		],
		slash: [
			329.63,
			"triangle",
			.11
		],
		pierce: [
			440,
			"sine",
			.07
		],
		thread: [
			246.94,
			"triangle",
			.04
		],
		ink: [
			164.81,
			"triangle",
			.055
		],
		holy: [
			523.25,
			"sine",
			.01
		]
	};
	const [root, wave, noise] = palettes[element] ?? palettes.hearth;
	const score = {
		element,
		root: root * 2 ** ((seed % 7 - 3) / 12),
		notes: [
			seed % 12,
			(seed >>> 5) % 17,
			(seed >>> 10) % 19
		],
		gap: .048 + seed % 9 * .009,
		tail: .16 + seed % 5 * .035,
		wave,
		noise,
		ultimate: !!recipe?.ultimate
	};
	cache.set(id, score);
	return score;
}
// apps/web/src/game/squad/turn3d/audio-startup.ts
/** A blocked device must release the sound control even if resume never settles. */
function resumeAudioContext(context, signal) {
	return new Promise((resolve, reject) => {
		if (signal.aborted) {
			reject(/* @__PURE__ */ new Error("Sound startup cancelled"));
			return;
		}
		const finish = (error) => {
			clearTimeout(timeout);
			signal.removeEventListener("abort", cancel);
			if (error) reject(error);
			else resolve();
		};
		const cancel = () => finish(/* @__PURE__ */ new Error("Sound startup cancelled"));
		const timeout = setTimeout(() => finish(/* @__PURE__ */ new Error("Sound output did not start")), 4e3);
		signal.addEventListener("abort", cancel, { once: true });
		try {
			context.resume().then(() => finish(), (error) => finish(error));
		} catch (error) {
			finish(error);
		}
	});
}
/** Open the output device asynchronously after a real sound gesture. */
async function warmAudioDevice(signal) {
	const noop = () => {};
	if (signal.aborted || typeof Audio === "undefined" || typeof URL.createObjectURL !== "function") return noop;
	const rate = 44100, bytes = /* @__PURE__ */ new ArrayBuffer(88244), view = new DataView(bytes);
	const text = (at, value) => [...value].forEach((char, i) => view.setUint8(at + i, char.charCodeAt(0)));
	text(0, "RIFF");
	view.setUint32(4, 88236, true);
	text(8, "WAVEfmt ");
	view.setUint32(16, 16, true);
	view.setUint16(20, 1, true);
	view.setUint16(22, 1, true);
	view.setUint32(24, rate, true);
	view.setUint32(28, rate * 2, true);
	view.setUint16(32, 2, true);
	view.setUint16(34, 16, true);
	text(36, "data");
	view.setUint32(40, rate * 2, true);
	const url = URL.createObjectURL(new Blob([bytes], { type: "audio/wav" })), media = new Audio(url);
	media.volume = 1;
	media.preload = "auto";
	let released = false;
	const release = () => {
		if (released) return;
		released = true;
		signal.removeEventListener("abort", release);
		media.pause();
		media.removeAttribute("src");
		media.load();
		URL.revokeObjectURL(url);
	};
	signal.addEventListener("abort", release, { once: true });
	try {
		await new Promise((resolve, reject) => {
			const finish = (error) => {
				clearInterval(poll);
				clearTimeout(timeout);
				signal.removeEventListener("abort", cancel);
				if (error) reject(error);
				else resolve();
			};
			const cancel = () => finish(/* @__PURE__ */ new Error("Sound startup cancelled"));
			const poll = setInterval(() => {
				if (media.currentTime >= .02) finish();
			}, 5);
			const timeout = setTimeout(() => finish(/* @__PURE__ */ new Error("Sound output did not advance")), 1500);
			signal.addEventListener("abort", cancel, { once: true });
			media.play().catch((error) => finish(error));
		});
		return release;
	} catch {
		release();
		return noop;
	}
}
// apps/web/src/game/squad/turn3d/audio.ts
var AUDIO_SETTINGS = {
	master: .14,
	ambient: .018,
	cue: .14,
	peakCeiling: .72,
	notes: [
		196,
		246.94,
		293.66,
		369.99,
		293.66,
		246.94,
		220,
		261.63
	],
	sampleRate: 44100
};
var noiseBuffers = /* @__PURE__ */ new WeakMap();
function noiseBuffer(ctx) {
	let buffer = noiseBuffers.get(ctx);
	if (buffer) return buffer;
	buffer = ctx.createBuffer(1, Math.ceil(ctx.sampleRate * .6), ctx.sampleRate);
	const samples = buffer.getChannelData(0);
	let seed = 7919;
	for (let i = 0; i < samples.length; i++) {
		seed ^= seed << 13;
		seed ^= seed >>> 17;
		seed ^= seed << 5;
		samples[i] = (seed >>> 0) / 2147483648 - 1;
	}
	noiseBuffers.set(ctx, buffer);
	return buffer;
}
function tone(ctx, destination, when, frequency, end, duration, volume, wave) {
	const gain = ctx.createGain(), oscillator = ctx.createOscillator();
	gain.gain.setValueAtTime(0, when);
	gain.gain.linearRampToValueAtTime(volume, when + .009);
	gain.gain.exponentialRampToValueAtTime(1e-4, when + duration);
	oscillator.type = wave;
	oscillator.frequency.setValueAtTime(frequency, when);
	oscillator.frequency.exponentialRampToValueAtTime(Math.max(30, end), when + duration);
	oscillator.connect(gain).connect(destination);
	oscillator.start(when);
	oscillator.stop(when + duration + .02);
	oscillator.onended = () => {
		oscillator.disconnect();
		gain.disconnect();
	};
}
function noise(ctx, destination, when, duration, volume, frequency) {
	const source = ctx.createBufferSource(), filter = ctx.createBiquadFilter(), gain = ctx.createGain();
	source.buffer = noiseBuffer(ctx);
	filter.type = "bandpass";
	filter.frequency.value = frequency;
	filter.Q.value = .8;
	gain.gain.setValueAtTime(0, when);
	gain.gain.linearRampToValueAtTime(volume, when + .012);
	gain.gain.exponentialRampToValueAtTime(1e-4, when + duration);
	source.connect(filter).connect(gain).connect(destination);
	source.start(when);
	source.stop(when + duration + .02);
	source.onended = () => {
		source.disconnect();
		filter.disconnect();
		gain.disconnect();
	};
}
function synthCue(ctx, destination, family, beat, when, variant = 0) {
	const duration = beat === 2 ? .18 : beat === 0 ? .12 : .24;
	const base = {
		swish: 170,
		thud: 84,
		chime: 587,
		flame: 210,
		glass: 1046,
		whoosh: 330
	}[family] * 2 ** (variant % 19 / 19);
	const volume = beat === 2 ? .26 : .1;
	tone(ctx, destination, when, base * (beat === 0 ? .75 : 1.5), base * (family === "thud" ? .35 : .7), duration, volume, family === "flame" ? "triangle" : "sine");
	if ([
		"swish",
		"flame",
		"whoosh",
		"glass"
	].includes(family)) noise(ctx, destination, when, duration, volume * .3, family === "glass" ? 4e3 : 1200);
}
function synthCardCue(ctx, destination, id, beat, when) {
	const score = cardSoundScore(id);
	if (beat === 0) for (let i = 0; i < 3; i++) {
		const frequency = score.root * 2 ** (score.notes[i] / 12);
		tone(ctx, destination, when + i * score.gap, frequency * .94, frequency, score.tail, .045, score.wave);
	}
	else if (beat === 2) {
		tone(ctx, destination, when, score.root * 1.5, score.root * .7, score.ultimate ? .36 : .2, score.ultimate ? .2 : .15, score.wave);
		noise(ctx, destination, when, .2, score.noise, score.root * 7);
		if (score.ultimate) for (let i = 0; i < 3; i++) tone(ctx, destination, when + .04 + i * .06, score.root * [
			1,
			1.25,
			1.5
		][i], score.root, .34, .045, "sine");
	} else if (beat === 4 && score.ultimate) tone(ctx, destination, when, score.root * 2, score.root, .32, .04, "sine");
}
function synthCardKill(ctx, destination, id, when) {
	const root = cardSoundScore(id).root;
	tone(ctx, destination, when + .02, root * 2, root, .32, .08, "sine");
	tone(ctx, destination, when + .1, root * 3, root * 2, .3, .055, "sine");
}
var PREFERENCE_KEY = "tbh-card-audio-v1";
var CafeAudio = class {
	enabled = false;
	blocked = false;
	volume = .7;
	persist = false;
	startup = null;
	starting = null;
	get pending() {
		return this.startup !== null;
	}
	ctx = null;
	master = null;
	compressor = null;
	key = "";
	round = 0;
	actor = "";
	note = 0;
	nextNote = 0;
	useBrowserPreferences(enabled) {
		if (!enabled || this.persist) return;
		this.persist = true;
		try {
			const saved = JSON.parse(localStorage.getItem(PREFERENCE_KEY) ?? "null");
			if (saved?.version === 1 && Number.isFinite(saved.volume)) this.volume = Math.max(0, Math.min(1, saved.volume));
		} catch {}
	}
	remember() {
		if (this.persist) try {
			localStorage.setItem(PREFERENCE_KEY, JSON.stringify({
				version: 1,
				volume: this.volume,
				muted: !this.enabled
			}));
		} catch {}
	}
	setVolume(volume) {
		window.__thAudio?.setBus("master", volume);
		if (!Number.isFinite(volume)) return;
		this.volume = Math.max(0, Math.min(1, volume));
		if (this.ctx && this.master) this.master.gain.setTargetAtTime(this.enabled ? AUDIO_SETTINGS.master * this.volume : 0, this.ctx.currentTime, .025);
		this.remember();
	}
	async toggle() {
		if (typeof window !== "undefined" && window.__thAudio) {
			await window.__thAudio.unlock();
			this.enabled = !this.enabled;
			window.__thAudio.mute(!this.enabled);
			return;
		}
		if (this.starting) return this.starting;
		if (this.enabled) {
			this.enabled = false;
			this.master?.gain.setTargetAtTime(0, this.ctx.currentTime, .04);
			this.remember();
			return;
		}
		const controller = new AbortController();
		this.startup = controller;
		this.blocked = false;
		const task = this.enable(controller.signal);
		this.starting = task;
		try {
			await task;
		} finally {
			if (this.startup === controller) {
				this.startup = null;
				this.starting = null;
			}
		}
	}
	async enable(signal) {
		let release = () => {};
		try {
			if (!this.ctx) release = await warmAudioDevice(signal);
			if (signal.aborted) return;
			this.ctx ??= new AudioContext({ sampleRate: AUDIO_SETTINGS.sampleRate });
			if (!this.master) {
				this.master = this.ctx.createGain();
				this.master.gain.value = 0;
				this.compressor = this.ctx.createDynamicsCompressor();
				this.compressor.threshold.value = -8;
				this.compressor.knee.value = 5;
				this.compressor.ratio.value = 8;
				this.compressor.attack.value = .004;
				this.compressor.release.value = .12;
				this.master.connect(this.compressor).connect(this.ctx.destination);
				noiseBuffer(this.ctx);
			}
			await resumeAudioContext(this.ctx, signal);
			if (signal.aborted || !this.ctx || !this.master) return;
			this.enabled = this.ctx.state === "running";
			this.blocked = !this.enabled;
			this.master.gain.setTargetAtTime(this.enabled ? AUDIO_SETTINGS.master * this.volume : 0, this.ctx.currentTime, .04);
			this.nextNote = this.ctx.currentTime;
			this.key = "";
			this.ui();
			this.remember();
		} catch {
			if (!signal.aborted) {
				this.blocked = true;
				this.enabled = false;
			}
		} finally {
			release();
		}
	}
	ui() {
		if (typeof window !== "undefined" && window.__thAudio) {
			window.__thAudio.play("ui.click");
			return;
		}
		if (this.enabled && this.ctx && this.master) synthCue(this.ctx, this.master, "chime", 0, this.ctx.currentTime, 4);
	}
	update(frame, round, actor, quiet, ambienceScale = 1) {
		if (typeof window !== "undefined" && window.__thAudio) {
			const audio = window.__thAudio;
			const key = frame ? `${frame.plan.id}/${frame.beat.kind}` : "";
			if (key && key !== this.key) {
				this.key = key;
				playFrame(audio, frame);
			}
			return;
		}
		if (!this.enabled || !this.ctx || !this.master || this.ctx.state !== "running") return;
		const now = this.ctx.currentTime, id = frame?.plan.presentationId || frame?.plan.skillId || "";
		const key = frame ? `${frame.plan.id}/${id}/${frame.beat.kind}` : "";
		if (key && key !== this.key) {
			this.key = key;
			const beat = [
				"anticipation",
				"travel",
				"impact",
				"reaction",
				"residue"
			].indexOf(frame.beat.kind);
			synthCardCue(this.ctx, this.master, id, beat, now);
			if (beat === 2) {
				for (const cue of frame.plan.presentationCues ?? []) if (cue.startsWith("auto-extra:")) synthCardCue(this.ctx, this.master, cue, 0, now + .045);
			}
			if (beat === 2 && frame.plan.events.some((event) => event.type === "death")) synthCardKill(this.ctx, this.master, id, now);
			if (beat === 0 && ["victory", "defeat"].includes(id)) for (let i = 0; i < 4; i++) synthCue(this.ctx, this.master, id === "victory" ? "chime" : "thud", 0, now + i * .16, i * 2);
		}
		if (round !== this.round) {
			this.round = round;
			synthCue(this.ctx, this.master, "chime", 0, now, 2);
		}
		if (actor && actor !== this.actor) {
			this.actor = actor;
			synthCue(this.ctx, this.master, "glass", 0, now, 1);
		}
		if (!quiet && now >= this.nextNote) {
			this.nextNote = now + .65;
			const frequency = AUDIO_SETTINGS.notes[this.note++ % AUDIO_SETTINGS.notes.length] * ambienceScale;
			tone(this.ctx, this.master, now, frequency, frequency, 1.2, AUDIO_SETTINGS.ambient, "sine");
		}
	}
	dispose() {
		this.startup?.abort();
		this.startup = null;
		this.starting = null;
		this.enabled = false;
		this.master?.disconnect();
		this.compressor?.disconnect();
		this.ctx?.close();
		this.ctx = null;
		this.master = null;
		this.compressor = null;
	}
};
// apps/web/src/game/cardrpg/depth/passive-presentation.ts
/** Read only the resolved action (or grouped round), never invent a passive cast. */
function passivePresentation(before, after) {
	const log = after.log.slice(before.log.length);
	const targets = {};
	for (const actor of after.actors.filter((a) => a.side === "party")) {
		const previous = before.actors.find((a) => a.id === actor.id);
		if (!previous) continue;
		const events = log.filter((e) => e.actorId === actor.id);
		const ownShield = events.filter((e) => e.kind === "shield" && e.targetId === actor.id).reduce((n, e) => n + e.amount, 0);
		let target;
		if (actor.catalogId === "mochi" && actor.shield - previous.shield > ownShield && events.some((e) => e.kind === "shield" && e.targetId !== actor.id)) target = actor.id;
		if (actor.catalogId === "soot" && events.some((e) => e.kind === "detonate" && e.amount > 0) && ownShield > 0) target = actor.id;
		if (actor.catalogId === "clover" && !previous.passiveUsed && actor.passiveUsed) {
			const heal = events.findIndex((e) => e.kind === "heal");
			const cleanse = events[heal + 1];
			if (heal >= 0 && cleanse?.kind === "dispel" && cleanse.targetId === events[heal].targetId) target = cleanse.targetId;
		}
		if (actor.catalogId === "panko" && events.some((e) => e.kind === "action" && e.skillId === "defend") && events.some((e) => e.kind === "status" && e.text === "Saucer riposte")) target = actor.id;
		if (target) targets[`${actor.catalogId}-passive`] = target;
	}
	return Object.keys(targets).length ? {
		presentationCues: Object.keys(targets),
		presentationCueTargets: targets
	} : {};
}
[...new Set(CATS$1.map((cat) => cat.role))];
var TEAM_PRESETS_KEY = "taskbar-hero:cardrpg-team-presets:v1";
/** UI preferences are validated before the rules validate current ownership. */
function readTeamPresets(raw) {
	const empty = [
		null,
		null,
		null
	];
	if (!raw) return empty;
	try {
		const value = JSON.parse(raw);
		if (value?.version !== 1 || !Array.isArray(value.slots)) return empty;
		return empty.map((_, index) => {
			const slot = value.slots[index];
			if (!slot || typeof slot.name !== "string" || !Array.isArray(slot.team) || slot.team.length !== 3 || new Set(slot.team).size !== 3 || !slot.rows || typeof slot.rows !== "object" || !slot.team.every((id) => typeof id === "string" && Object.hasOwn(CAT_BY_ID, id) && ["front", "rear"].includes(slot.rows[id])) || !slot.team.some((id) => slot.rows[id] === "front")) return null;
			return {
				name: slot.name.slice(0, 40),
				team: [...slot.team],
				rows: Object.fromEntries(slot.team.map((id) => [id, slot.rows[id]]))
			};
		});
	} catch {
		return empty;
	}
}
// apps/web/src/game/cardrpg/depth/model.ts
var DepthModel = class {
	offline;
	gameplayMode;
	skillsMode;
	a6Mode;
	c2Mode;
	state;
	screen = "hub";
	cardId = "mochi";
	itemId = "";
	inventorySlot = "all";
	notice = "Build your team, press Fight, then watch your companions take the lead.";
	error = false;
	teamPresets = [
		null,
		null,
		null
	];
	galleryBattle = null;
	galleryId = GALLERY_ACTIONS[0].id;
	galleryEffectOnly = false;
	gallerySpeed = 1;
	labOpen = false;
	labPanel = "gallery";
	labPerformance = false;
	galleryReturn;
	galleryActions = GALLERY_ACTIONS;
	watching = false;
	camera = "wide";
	paused = false;
	tutorialBattle = null;
	replay = null;
	replayChoices = [];
	replayIndex = 0;
	replayReturn = "save";
	plan = null;
	animationAt = 0;
	playbackAt = 0;
	playbackFrameAt;
	ultimateBannerUntil = 0;
	comboBanner = "";
	comboBannerUntil = 0;
	ultimateBannersAt = [];
	autoContinue = false;
	momentNote = "";
	beforeImpact = null;
	afterImpact = null;
	roundPlan = null;
	impactApplied = false;
	sceneStarted = false;
	sceneReady = false;
	sceneError = "";
	audio = new CafeAudio();
	liveRelicNote = "Fixture collection";
	revision = 0;
	listeners = /* @__PURE__ */ new Set();
	storageFailed = false;
	cafeClockStart = Date.now();
	cafeClockBase = 0;
	get cafeNow() {
		return this.offline ? this.cafeClockBase + Math.max(0, Date.now() - this.cafeClockStart) : Date.now();
	}
	resetCafeClock() {
		this.cafeClockStart = Date.now();
		this.cafeClockBase = Math.max(this.state.idle.lastAt, this.state.v4?.clockWatermark ?? 0, (this.state.idle.dayKey ?? 0) * 864e5);
	}
	constructor(offline, gameplayMode = false, skillsMode = false, a6Mode = false, c2Mode = false) {
		this.offline = offline;
		this.gameplayMode = gameplayMode;
		this.skillsMode = skillsMode;
		this.a6Mode = a6Mode;
		this.c2Mode = c2Mode;
		this.state = createDepthAccount(11, offline ? 0 : Date.now());
		if (!offline) {
			try {
				const saved = localStorage.getItem(SAVE_KEY);
				if (saved) {
					this.state = importSave(saved, Date.now(), this.c2Mode);
					this.notice = "Welcome back. Your progress is restored.";
				}
			} catch (error) {
				this.storageFailed = true;
				this.notice = `Saved progress needs attention. ${String(error)} Use Export / import before resetting.`;
			}
			this.state = syncCalendarDay(this.state, Date.now()).state;
			this.state.relics = [];
			this.state.selectedRelic = null;
			this.liveRelicNote = "Read connected wallet or choose fixture mode";
		}
		this.state = setGameplayV4(this.state, gameplayMode);
		if (skillsMode) this.state = setSkillsV5(this.state, true);
		this.state = setGameplayA6(this.state, this.a6Mode);
		if (this.c2Mode) this.state = setFormationC2(this.state);
		this.state.economyV3 = chainFlags().economyV3;
		this.resetCafeClock();
		this.itemId = this.state.gear[0]?.id ?? "";
		if (!offline) try {
			this.teamPresets = readTeamPresets(localStorage.getItem(TEAM_PRESETS_KEY));
		} catch {}
		this.restoreEncounter();
		this.consumeFormationNotice();
	}
	consumeFormationNotice() {
		const notice = this.state.formationNoticeC2;
		if (!notice) return;
		delete this.state.formationNoticeC2;
		this.notice = notice === "bench" ? "Strongest four ready. Others benched." : "Four companions ready.";
		this.notify();
	}
	saveTeamPreset(index) {
		if (!Number.isInteger(index) || index < 0 || index >= 3) return;
		this.teamPresets[index] = {
			name: `Shift ${index + 1}`,
			team: [...this.state.team],
			rows: Object.fromEntries(this.state.team.map((id) => [id, this.state.rows[id]]))
		};
		if (this.offline) {
			this.notice = `Shift ${index + 1} saved for this offline visit.`;
			this.error = false;
			this.notify(false);
			return;
		}
		try {
			localStorage.setItem(TEAM_PRESETS_KEY, JSON.stringify({
				version: 1,
				slots: this.teamPresets
			}));
			this.notice = `Shift ${index + 1} saved in this browser.`;
		} catch {
			this.notice = `Shift ${index + 1} saved for this visit. Browser storage is unavailable.`;
		}
		this.error = false;
		this.notify(false);
	}
	loadTeamPreset(index) {
		const preset = this.teamPresets[index];
		if (!preset) return;
		this.apply(configureTeam(this.state, preset.team, preset.rows, this.state.skills), `${preset.name} restored.`);
	}
	snapshot = () => this.revision;
	subscribe = (listener) => {
		this.listeners.add(listener);
		return () => this.listeners.delete(listener);
	};
	async toggleSound() {
		if (this.audio.pending) return;
		const task = this.audio.toggle();
		this.notify(false);
		await task;
		this.state.settings.sound = this.audio.enabled;
		this.notify();
	}
	notify(save = true) {
		if (save && !this.offline && !this.storageFailed) try {
			localStorage.setItem(SAVE_KEY, exportSave(this.state));
		} catch {
			this.storageFailed = true;
			this.notice = "Automatic saving is unavailable. Export a save code to keep this session.";
		}
		this.revision++;
		for (const listener of this.listeners) listener();
	}
	get battle() {
		return this.galleryBattle ?? this.replay ?? this.tutorialBattle ?? this.state.run?.battle ?? null;
	}
	get visualBattle() {
		if (this.galleryBattle || !this.plan || this.plan.skillId === "round-status") return this.battle;
		return (this.impactApplied ? this.afterImpact : this.beforeImpact) ?? this.battle;
	}
	get impactVisible() {
		return !!this.plan && this.animationAt >= this.plan.beats[2].start;
	}
	get showBattle() {
		return !!this.battle && (!!this.galleryBattle || this.watching);
	}
	get saveStatus() {
		return this.offline ? "Export to keep progress" : this.storageFailed ? "Export to keep progress · local saving unavailable" : "Saved locally";
	}
	get busy() {
		return !!this.plan;
	}
	get canAct() {
		return !this.galleryBattle && this.showBattle && !!this.battle && !this.battle.result && !this.busy && !this.paused && (this.sceneReady || !!this.sceneError);
	}
	get frame() {
		return this.plan ? sampleActionPlan(this.plan, this.animationAt, this.state.settings.reducedMotion) : null;
	}
	inspect(id, progress = 0, play = false) {
		const fixture = galleryFixture(id);
		if (!this.galleryBattle) this.galleryReturn = {
			plan: this.plan,
			animationAt: this.animationAt,
			paused: this.paused
		};
		this.galleryId = id;
		this.galleryBattle = fixture.battle;
		this.plan = progress < 0 ? null : fixture.plan;
		this.animationAt = fixture.plan.duration * Math.max(0, Math.min(1, progress));
		this.paused = !play;
		this.sceneStarted = true;
		this.notify(false);
	}
	closeGallery() {
		this.galleryBattle = null;
		this.plan = this.galleryReturn?.plan ?? null;
		this.animationAt = this.galleryReturn?.animationAt ?? 0;
		this.paused = this.galleryReturn?.paused ?? false;
		this.galleryReturn = void 0;
		this.galleryEffectOnly = false;
		this.notify(false);
	}
	apply(result, message = "Saved to your cafe account.") {
		this.error = !result.ok;
		if (result.ok) {
			this.state = result.state;
			this.notice = message;
			this.audio.ui();
		} else this.notice = result.error ?? "That action is unavailable.";
		this.notify();
		return result.ok;
	}
	go(screen, gearSlot = "all") {
		if (this.replay && !this.watching && screen !== "result") this.clearReplay();
		if (screen === "map" && this.battle && !this.watching) screen = this.battle.result ? "result" : "prepare";
		if (screen === "hub" && (!this.state.run || this.state.run.complete)) this.sceneStarted = false;
		this.inventorySlot = screen === "inventory" ? gearSlot : "all";
		this.screen = screen;
		this.error = false;
		this.notify(false);
	}
	command(command) {
		this.apply(metaCommand(this.state, command));
	}
	start(chapter, mode = "campaign", challengeLevel) {
		if (this.apply(startRun(this.state, chapter, this.state.account.seed + this.state.nextRunId * 7919, mode, this.offline ? "2026-11-06" : (/* @__PURE__ */ new Date()).toISOString().slice(0, 10), challengeLevel), "Choose the first stop on your route.")) this.go("map");
	}
	enter(id) {
		if (this.apply(enterNode(this.state, id), "Prepare your companions, then press Fight.")) {
			this.plan = null;
			this.paused = false;
			this.watching = false;
			if (this.battle) this.screen = "prepare";
			this.notify(false);
		}
	}
	tutorial() {
		this.tutorialBattle = createBattle({
			...this.state.formationC2 ? { formationC2: true } : {},
			...gameplayA6(this.state) ? { gameplayA6: true } : {},
			...skillsV5(this.state) ? { skillsV5: true } : {},
			seed: 7,
			chapter: 1,
			cats: battleCats(this.state),
			enemies: ["practice-cushion"],
			tutorial: true,
			...gameplayV4(this.state) ? {
				gameplayV4: true,
				plan: this.state.v4?.plan,
				enemyStats: { "practice-cushion": {
					hp: 300,
					attack: 60,
					defense: 0
				} }
			} : {}
		});
		this.plan = null;
		this.watching = false;
		this.paused = false;
		this.go("prepare");
	}
	fight() {
		if (!this.battle || this.battle.result) return;
		if (this.battle.v4 && !this.replay && !this.galleryBattle) {
			if (this.tutorialBattle) this.tutorialBattle.v4.committed = true;
			else if (!this.apply(commitPreparation(this.state), "Preparation committed. Your crew follows its standing plan.")) return;
		}
		this.comboBanner = "";
		this.comboBannerUntil = 0;
		this.watching = true;
		this.paused = false;
		this.sceneStarted = true;
		this.screen = "map";
		this.notify();
	}
	prepareCrew(team = this.state.team, rows = this.state.rows, plan = this.battle?.v4?.plan ?? DEFAULT_PLAN) {
		if (this.watching || this.replay || this.galleryBattle) return;
		if (this.tutorialBattle?.v4) {
			if (this.tutorialBattle.v4.committed) return;
			const result = configureTeam(this.state, team, rows, this.state.skills);
			if (!result.ok || !validPlan(plan)) {
				this.apply(result);
				return;
			}
			this.state = result.state;
			this.state.v4.plan = { ...plan };
			this.tutorialBattle = createBattle({
				...this.tutorialBattle.initial,
				cats: battleCats(this.state),
				plan: { ...plan }
			});
			this.notice = "Practice formation updated.";
			this.notify();
			return;
		}
		this.apply(configurePreparation(this.state, team, rows, plan), "Preparation updated. Enemy lineup and encounter seed stay fixed.");
	}
	watchNow() {
		if (!this.state.run || this.state.run.complete) {
			this.start(1);
			const node = availableNodes(this.state.run)[0];
			if (node) this.enter(node.id);
		}
		this.go("map");
		this.fight();
	}
	restoreEncounter() {
		this.watching = !!this.battle && !this.battle.result && (this.battle.choices.length > 0 || !!this.battle.v4?.committed);
		this.sceneStarted = this.watching;
		this.screen = this.battle ? this.battle.result ? "result" : this.watching ? "map" : "prepare" : "hub";
	}
	showResult() {
		this.watching = false;
		this.paused = false;
		this.plan = null;
		this.screen = "result";
		this.notify();
	}
	get a6Battle() {
		return !!this.battle?.initial.gameplayA6;
	}
	get canSkip() {
		if (!this.a6Battle) return !this.galleryBattle;
		if (this.replay) return true;
		const run = this.state.run, node = run?.nodes.find((n) => n.id === run.current);
		return !!(run && node && this.state.v4?.journey?.stars[nodeStarKeyV4(run, node)]?.conditions.every(Boolean));
	}
	cycleSpeed() {
		const speeds = this.a6Battle ? [
			1,
			2,
			3
		] : [
			1,
			2,
			4
		];
		this.state.settings.speed = speeds[(speeds.indexOf(this.state.settings.speed) + 1) % speeds.length];
		this.notify();
	}
	get canAutoContinue() {
		return this.autoContinue && this.screen === "result" && this.a6Battle && this.battle?.result === "party" && !!this.state.run && !this.state.run.complete && !this.error && !this.tutorialBattle && !this.replay && !this.galleryBattle;
	}
	continueBattle() {
		if (!this.canAutoContinue || this.state.v4?.journey?.pending.length) return;
		this.finish();
		if (this.error) return;
		const run = this.state.run;
		if (!run) return;
		if (run.complete) {
			if (run.towerA6) this.go("tower");
			return;
		}
		if (run.rewardChoices.length) return;
		const next = availableNodes(run);
		if (next.length === 1 && next[0].enemies.length) {
			this.enter(next[0].id);
			if (!this.error) this.fight();
		}
	}
	skip() {
		if (!this.canSkip) return;
		if (!this.battle || this.galleryBattle) return;
		if (this.replay) {
			this.replay = replayBattle(this.replay.initial, this.replayChoices);
			this.replayIndex = this.replayChoices.length;
		} else playBattle(this.battle, "auto");
		this.showResult();
	}
	act(choice) {
		const battle = this.battle;
		if (!battle || !this.canAct) return;
		const actor = currentActor(battle);
		if (!actor) return;
		const snapshot = snapshotBattle(battle);
		const before = battle.log.length;
		const intent = battle.intents.find((candidate) => candidate.actorId === actor.id);
		const softened = intent?.interrupted || actor.statuses.some((status) => status.id === "drowsy");
		const utility = !battle.v4 && ["heal", "shield"].includes(ENEMY_BY_ID[actor.catalogId]?.mechanic ?? "") && !actor.statuses.some((status) => status.id === "hush");
		const signature = !softened && (intent?.signature || utility);
		const selected = actor.side === "party" ? choice ?? chooseAction(battle, "auto") : null;
		let skillId = selected?.skillId ?? "";
		let accepted = false;
		if (actor.side === "enemy") {
			skillId = `${ENEMY_BY_ID[actor.catalogId].role}Attack`;
			accepted = enemyAct(battle);
		} else accepted = act(battle, selected);
		if (!accepted) {
			this.notice = "This recorded action could not be resolved.";
			this.error = true;
			this.showResult();
			return;
		}
		const presentation = splitPresentation(snapshot, battle, skillId);
		const targets = [...new Set(presentation.events.flatMap((event) => event.targetIds))];
		if (!targets.length) targets.push(selected?.targetId ?? intent?.targetId ?? actor.id);
		const events = [{
			version: 3,
			seq: 0,
			turn: actor.turns,
			round: snapshot.round,
			actionId: battle.log.length,
			beat: 0,
			type: "action_start",
			actorId: actor.id,
			skillId,
			targetIds: targets,
			amount: 0
		}, ...presentation.events];
		this.beforeImpact = snapshot;
		this.afterImpact = presentation.impact;
		this.roundPlan = presentation.roundPlan;
		this.impactApplied = false;
		const identity = actor.side === "enemy" ? battle.log.slice(before).find((event) => event.kind === "enemy-action")?.skillId || `enemy:${actor.catalogId}${signature ? "" : ":basic"}` : skillId;
		const savingHeal = events.find((event) => event.type === "heal" && event.amount > 0 && snapshot.actors.some((target) => event.targetIds.includes(target.id) && target.hp / target.maxHp <= .25) && presentation.impact.actors.some((target) => event.targetIds.includes(target.id) && target.hp / target.maxHp > .25));
		const lastHit = events.some((event) => event.type === "death") && presentation.impact.actors.filter((target) => target.side === "enemy").every((target) => target.hp <= 0);
		this.momentNote = savingHeal ? "Clutch heal" : lastHit ? "Last hit" : "";
		if (savingHeal) savingHeal.note = "Clutch heal";
		this.plan = paceActionA6(createCardActionPlan(events, identity), battle.initial);
		if (this.a6Battle && this.plan.ultimate && actor.side === "party") {
			this.ultimateBannersAt = this.ultimateBannersAt.filter((at) => this.playbackAt - at < 1e4);
			if (this.ultimateBannersAt.length < 2) {
				this.ultimateBannersAt.push(this.playbackAt);
				this.ultimateBannerUntil = this.playbackAt + 800 / this.state.settings.speed;
			} else this.ultimateBannerUntil = 0;
		}
		const combos = battle.log.slice(before).filter((event) => event.kind === "bond.combo");
		if (combos.length) {
			this.comboBanner = combos.map((event) => event.text).join(" · ");
			this.comboBannerUntil = this.playbackAt + 1800;
		}
		Object.assign(this.plan, passivePresentation(snapshot, presentation.impact));
		if (this.roundPlan) Object.assign(this.roundPlan, passivePresentation(presentation.impact, battle));
		this.animationAt = 0;
		this.notify();
	}
	tick(milliseconds, now = performance.now()) {
		const previousFrame = this.playbackFrameAt;
		this.playbackFrameAt = now;
		if (typeof window !== "undefined") window.__thAudio?.speed(this.state.settings.speed);
		if (typeof window !== "undefined") window.__thAudio?.pause(this.paused);
		if (this.paused || !this.showBattle || !this.sceneReady && !this.sceneError) return;
		const elapsed = this.a6Battle && !this.galleryBattle && previousFrame !== void 0 ? Math.max(milliseconds, Math.min(250, Math.max(0, now - previousFrame))) : milliseconds;
		this.playbackAt += elapsed;
		if (!this.plan) {
			if (this.battle?.result && !this.galleryBattle) this.showResult();
			return;
		}
		this.animationAt += elapsed * (this.galleryBattle ? this.gallerySpeed : this.state.settings.speed);
		if (!this.galleryBattle && !this.impactApplied && this.impactVisible) {
			this.impactApplied = true;
			this.notify(false);
		}
		if (this.animationAt >= this.plan.duration) this.finishMoment();
	}
	finishMoment() {
		if (this.galleryBattle) {
			this.plan = null;
			this.notify(false);
			return;
		}
		this.momentNote = "";
		this.plan = this.roundPlan;
		this.roundPlan = null;
		this.animationAt = 0;
		this.beforeImpact = null;
		this.afterImpact = null;
		this.impactApplied = true;
		if (this.battle?.result && !this.plan) this.showResult();
		else this.notify(false);
	}
	step(policy = "auto") {
		if (!this.canAct || !this.battle) return;
		this.act(currentActor(this.battle)?.side === "party" ? chooseAction(this.battle, policy) : void 0);
	}
	finish() {
		if (this.replay) {
			this.clearReplay();
			this.go(this.replayReturn);
			return;
		}
		if (this.tutorialBattle?.result) {
			this.tutorialBattle = null;
			this.sceneStarted = false;
			this.state.tutorial = 3;
			this.notice = gameplayA6(this.state) ? "Welcome a free friend. Then level up a cat in Cats." : "A welcome invitation is ready. Then equip your first piece.";
			this.go("gacha");
			this.notify();
			return;
		}
		if (this.apply(finishEncounter(this.state), "Choose a charm or strengthen one unlocked skill.")) this.go("map");
	}
	applyResultAdvice(advice) {
		if (this.screen !== "result" || this.replay || this.tutorialBattle || this.galleryBattle) return;
		const run = this.state.run;
		if (!run || !this.apply(applyResultAdviceV4(this.state, advice), advice.label)) return;
		this.plan = null;
		this.watching = false;
		this.paused = false;
		if (run.towerA6) {
			if (!this.apply(startTowerFloorA6(this.state, run.floor), "Try the same Tower floor with your upgrade.")) return;
			this.go("map");
		} else this.start(run.chapter, run.mode, run.challengeLevel);
		if (this.state.run && !this.state.run.complete) {
			const first = availableNodes(this.state.run)[0];
			if (first) this.enter(first.id);
		}
	}
	improveTeam() {
		this.finish();
		if (this.state.run && !this.state.run.complete) this.apply(abandonRun(this.state), "Route rewards kept. Improve your team for the next route.");
		this.go("team");
	}
	leave() {
		if (this.galleryBattle) {
			this.closeGallery();
			return;
		}
		if (this.replay) {
			this.finish();
			return;
		}
		this.paused = false;
		this.plan = null;
		this.watching = false;
		if (this.tutorialBattle) {
			this.tutorialBattle = null;
			this.state.tutorial = 3;
		} else this.apply(abandonRun(this.state), "Partial route rewards kept.");
		this.go("hub");
		this.notify();
	}
	invite(free = false) {
		const seed = this.state.account.seed + this.state.account.history.length * 101 + 39;
		this.apply(free ? firstInvitation(this.state, 4) : metaCommand(this.state, {
			type: "pull",
			bannerId: "standard",
			seed
		}), "Your invitation is open. Every companion has their own kit.");
	}
	get replayRecording() {
		const encounter = this.tutorialBattle ?? this.state.run?.battle;
		if (encounter) return encounter.result || encounter.choices.length ? {
			setup: encounter.initial,
			choices: encounter.choices
		} : null;
		return this.state.lastBattle && this.state.lastChoices.length ? {
			setup: this.state.lastBattle,
			choices: this.state.lastChoices
		} : null;
	}
	get canReplay() {
		return !this.replay && !this.galleryBattle && !this.watching && !!this.replayRecording;
	}
	clearReplay() {
		this.replay = null;
		this.plan = null;
		this.watching = false;
		this.paused = false;
		if (!this.battle) this.sceneStarted = false;
	}
	replayLast() {
		if (!this.canReplay) return;
		const recording = this.replayRecording;
		this.replayReturn = this.screen;
		this.replayChoices = [...recording.choices];
		this.replay = createBattle(recording.setup);
		this.replayIndex = 0;
		this.sceneStarted = true;
		this.watching = true;
		this.paused = false;
		this.plan = null;
		this.go("map");
	}
	replayStep() {
		if (!this.replay || !this.canAct) return;
		if (currentActor(this.replay)?.side === "enemy") this.act();
		else {
			const choice = this.replayChoices[this.replayIndex++];
			if (choice) this.act(choice);
			else {
				this.notice = "Replay reached its last recorded action.";
				this.showResult();
			}
		}
	}
	import(code) {
		try {
			const next = importSave(code, this.offline ? 0 : Date.now(), this.c2Mode);
			if (!this.offline) {
				next.relics = [];
				next.selectedRelic = null;
			}
			this.state = setGameplayV4(next, this.gameplayMode);
			if (this.skillsMode) this.state = setSkillsV5(this.state, true);
			this.state = setGameplayA6(this.state, this.a6Mode);
			if (this.c2Mode) this.state = setFormationC2(this.state);
			this.state.economyV3 = chainFlags().economyV3;
			this.resetCafeClock();
			this.tutorialBattle = null;
			this.replay = null;
			this.plan = null;
			this.galleryBattle = null;
			this.restoreEncounter();
			this.paused = false;
			this.cardId = next.team[0];
			this.itemId = next.gear[0]?.id ?? "";
			this.storageFailed = false;
			this.notice = "Save imported and checksum verified.";
			this.error = false;
			this.consumeFormationNotice();
			this.notify();
		} catch (error) {
			this.error = true;
			this.notice = String(error);
			this.notify(false);
		}
	}
	reset() {
		this.state = setGameplayV4(createDepthAccount(11, this.offline ? 0 : Date.now()), this.gameplayMode);
		if (this.skillsMode) this.state = setSkillsV5(this.state, true);
		this.state = setGameplayA6(this.state, this.a6Mode);
		if (this.c2Mode) this.state = setFormationC2(this.state);
		this.state.economyV3 = chainFlags().economyV3;
		this.resetCafeClock();
		this.tutorialBattle = null;
		this.replay = null;
		this.plan = null;
		this.galleryBattle = null;
		this.paused = false;
		this.watching = false;
		this.cardId = this.state.team[0];
		this.itemId = this.state.gear[0]?.id ?? "";
		this.storageFailed = false;
		this.notice = "A fresh cafe is ready.";
		this.consumeFormationNotice();
		this.go("hub");
		this.notify();
	}
	shortcut(kind) {
		if (!this.offline) return;
		this.state.run = null;
		if (kind === "unlock") {
			this.state.account.cards = CARDS.map((c) => ({
				id: c.id,
				cardId: c.id,
				level: 10,
				stars: 3,
				shards: 120,
				soulbound: true
			}));
			for (const cat of CATS$1) {
				this.state.skills[cat.id] = cat.skills.slice(0, 3).map((s) => s.id);
				this.state.rows[cat.id] = cat.row;
			}
			this.state.account.currencies = {
				fish: 8e3,
				threads: 1e3,
				stamps: 600,
				essence: 100
			};
			this.state.materials = 150;
			for (const slot of [
				"weapon",
				"outfit",
				"charm",
				"relic"
			]) this.state.gear.push(makeGear(this.state, `bellsteel-${slot}-epic`, 1));
		}
		if (kind === "stamps") this.state.account.currencies.stamps += 1500;
		if (kind === "chapter") {
			this.state.cleared = [
				1,
				2,
				3
			];
			this.state.account.chapter = 4;
		}
		this.notice = "Demo shortcut applied. This account contains reviewer-granted progress.";
		this.notify();
	}
};
export { DepthModel, depth_exports as R };
