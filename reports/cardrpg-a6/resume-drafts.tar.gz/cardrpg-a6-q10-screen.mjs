import {createRequire} from 'node:module';
import {writeFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
const root='/Users/bao/taskbar-hero-cardrpg-a6',require=createRequire(root+'/apps/web/package.json');
const {chromium,expect}=require('@playwright/test');
const browser=await chromium.launch({headless:true}),errors=[];
async function screenshot(page,name){const file='/tmp/cardrpg-a6-'+name+'.png';await page.screenshot({path:file});execFileSync('cwebp',['-quiet','-q','82',file,'-o',root+'/reports/cardrpg-a6/'+name+'.webp']);}
async function pageAt(url){const page=await browser.newPage({viewport:{width:1440,height:900}});page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});await page.goto('http://127.0.0.1:5960/'+url);await page.getByRole('button',{name:/^Relic Fuji/}).click();return page;}
try{
 const page=await pageAt('?demo=1&squad=1&cardrpg2=1&a6=1');
 await expect(page.getByText('Team bonus +0%',{exact:true})).toBeVisible();
 await screenshot(page,'q10-relic-empty');
 await page.getByRole('button',{name:'Load demo relics',exact:true}).click();
 const before=await page.evaluate(()=>({power:document.querySelector('.uv-identity')?.textContent,gear:JSON.stringify(window.__depthReview.state.equipment)}));
 await page.getByRole('button',{name:'Equip Legendary lantern cup',exact:true}).click();
 await expect(page.getByText('Team bonus +8%',{exact:true})).toBeVisible();
 await page.waitForTimeout(450);
 await screenshot(page,'q10-relic-equipped');
 await page.setViewportSize({width:1280,height:720});
 await screenshot(page,'q10-relic-small');
 const after=await page.evaluate(()=>({power:document.querySelector('.uv-identity')?.textContent,gear:JSON.stringify(window.__depthReview.state.equipment),overflow:document.documentElement.scrollWidth>innerWidth}));
 if(before.gear!==after.gear||before.power===after.power||after.overflow)throw Error('Treasure gear, power or layout check failed.');
 await page.getByRole('button',{name:'Unequip treasure',exact:true}).click();
 await expect(page.getByText('Team bonus +0%',{exact:true})).toBeVisible();
 const product=await pageAt('?squad=1&cardrpg2=1&a6=1');
 await expect(product.getByRole('button',{name:'Load demo relics',exact:true})).toHaveCount(0);
 await product.getByRole('button',{name:'Read connected wallet',exact:true}).click();
 await expect(product.locator('.a6-relic-status')).toContainText('You can keep playing');
 await product.getByRole('button',{name:'Close',exact:true}).click();
 await expect(product.getByRole('button',{name:/^Night Patrol/})).toBeEnabled();
 if(errors.length)throw Error(errors.join('\n'));
 await writeFile(root+'/reports/cardrpg-a6/q10-relic-ui.json',JSON.stringify({before,after,noWalletPlayable:true,errors},null,2)+'\n');
 console.log('Relic fixture equip, unequip, power, gear, small layout and no-wallet fallback PASS.');
}finally{await browser.close();}
