import {spawn,execFileSync} from 'node:child_process';
import {readFile,writeFile} from 'node:fs/promises';
const lease=setTimeout(()=>process.kill(-process.pid,'SIGTERM'),19*60*1000);
const run=(args,env={})=>new Promise((resolve,reject)=>{execFileSync('df',['-h',process.env.HOME],{stdio:'inherit'});const child=spawn(process.execPath,args,{env:{...process.env,...env},stdio:['ignore','pipe','inherit']});let output='';child.stdout.on('data',d=>{output+=d;process.stdout.write(d);});child.on('error',reject);child.on('close',code=>resolve({code,output}));});
try{
 let r=await run(['tools/cardrpg-a6/sim.mjs','--mode=a6','--out=reports/cardrpg-a6/q10-sim.json','--report=reports/cardrpg-a6/Q10-SIM.md']);
 if(r.code!==0)throw Error(`A6 sim exited ${r.code}`);
 const env={BIG_RULES_TMP_PREFIX:'/tmp/cardrpg-a6-q10-rules-',BIG_OFF_OUT:'/tmp/cardrpg-a6-q10-off'};
 r=await run(['tools/cardrpg-big/skills-v5/compat.mjs'],env);if(r.code!==0)throw Error(`A5 check exited ${r.code}`);
 const fallback=JSON.parse(r.output.trim().split('\n').at(-1));
 do{r=await run(['tools/cardrpg-big/skills-v5/off-baseline.mjs','--check'],env);}while(r.code===75);
 if(r.code!==0)throw Error(`OFF check exited ${r.code}`);
 const off=JSON.parse(await readFile('/tmp/cardrpg-a6-q10-off/checks.json','utf8'));
 await writeFile('reports/cardrpg-a6/q10-compatibility.json',JSON.stringify({...off,a5Fallback:{status:fallback.status,routes:fallback.count,sha256:fallback.sha256}},null,2)+'\n');
 console.log('Q10 simulation and existing exact compatibility checks completed.');
}finally{clearTimeout(lease);}
