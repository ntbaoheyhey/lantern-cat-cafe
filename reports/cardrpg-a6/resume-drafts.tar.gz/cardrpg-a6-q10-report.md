# Q10 · One Fuji keepsake for the crew

A6 gives the whole active team one treasure slot. Supported Common, Rare, Epic and Legendary Relics add two, four, six or eight percent to HP, attack and defense. Copies and extra holdings never stack. The slot preserves ordinary cat gear and shows the shared Power increase. The product-default path retains its previous lead-cat effect.

The client reuses the existing Fuji reader and chain ABI for RelicNFT 0xB1a1edb7A75Db6e7067E747ddee32B39c2296f2D. It reads an already connected wallet, checks the network and pins balances and rarity reads to one block. It sends no transaction. Switching or disconnecting the wallet clears the prior selection, including when the collection sheet is closed; stale in-flight reads are ignored.

Offline demo offers four clearly labelled sample holdings. Product mode shows an empty slot when no wallet is available; an eight-second timeout keeps the read from blocking play. The explorer link points to Fuji. Relics can be changed only outside an active route.

Validation is pending application of this draft. No live chain call, payment, server change or contract change is required for the mock demo.
