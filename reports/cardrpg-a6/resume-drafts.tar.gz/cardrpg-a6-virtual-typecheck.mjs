import {createRequire} from 'node:module';
import {readFileSync} from 'node:fs';
import {resolve} from 'node:path';
const root='/Users/bao/taskbar-hero-cardrpg-a6',require=createRequire(root+'/apps/web/package.json'),ts=require('typescript');
const sources=JSON.parse(readFileSync(process.argv[2],'utf8')),staged=new Map(Object.entries(sources).map(([p,text])=>[resolve(root,p),text]));
let failed=false;
for(const project of ['packages/game-rules','apps/web']){
 process.chdir(resolve(root,project));
 const configPath=resolve(root,project,'tsconfig.json');
 const config=ts.readConfigFile(configPath,ts.sys.readFile);
 const parsed=ts.parseJsonConfigFileContent(config.config,ts.sys,resolve(root,project));
 parsed.options.configFilePath=configPath;
 const host=ts.createCompilerHost(parsed.options),read=host.readFile.bind(host),exists=host.fileExists.bind(host);
 host.readFile=path=>staged.get(resolve(path))??read(path);host.fileExists=path=>staged.has(resolve(path))||exists(path);
 host.getSourceFile=(path,languageVersion)=>{const text=host.readFile(path);return text===undefined?undefined:ts.createSourceFile(path,text,languageVersion,true)};
 host.getCurrentDirectory=()=>resolve(root,project);
 const roots=[...new Set([...parsed.fileNames,...[...staged.keys()].filter(p=>p.startsWith(resolve(root,project))&&/\.tsx?$/.test(p))])];
 const program=ts.createProgram(roots,parsed.options,host),diagnostics=ts.getPreEmitDiagnostics(program);
 if(diagnostics.length){failed=true;console.log(ts.formatDiagnosticsWithColorAndContext(diagnostics,{getCanonicalFileName:p=>p,getCurrentDirectory:()=>root,getNewLine:()=> '\n'}));}else console.log(project+': virtual-source typecheck PASS');
}
process.exitCode=failed?1:0;
