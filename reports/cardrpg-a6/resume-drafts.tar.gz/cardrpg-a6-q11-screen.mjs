import {createRequire} from 'node:module';
import {writeFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
const root='/Users/bao/taskbar-hero-cardrpg-a6',require=createRequire(root+'/apps/web/package.json');
const {chromium,expect}=require('@playwright/test');
const browser=await chromium.launch({headless:true}),errors=[];
const page=await browser.newPage({viewport:{width:1440,height:900}});
page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});
async function shot(name){const file='/tmp/cardrpg-a6-'+name+'.png';await page.screenshot({path:file});execFileSync('cwebp',['-quiet','-q','82',file,'-o',root+'/reports/cardrpg-a6/'+name+'.webp']);}
try{
 await page.goto('http://127.0.0.1:5960/?demo=1&squad=1&cardrpg2=1&a6=1');
 const shell=page.locator('.uv-shell');
 await expect(shell).toHaveAttribute('data-a6-guide','patrol');
 await expect(page.getByRole('button',{name:'Team',exact:true})).toBeDisabled();
 await expect(page.getByRole('button',{name:'Recruit',exact:true})).toBeDisabled();
 await shot('q11-first-step');
 await page.getByRole('button',{name:/^Night Patrol/}).click();
 await page.getByRole('button',{name:/^Fight/}).click();
 await page.getByRole('button',{name:/^Next/}).waitFor({timeout:120000});
 await page.getByRole('button',{name:/^Next/}).click();
 await expect(shell).toHaveAttribute('data-a6-guide','recruit');
 await expect(page.getByRole('button',{name:'Team',exact:true})).toBeEnabled();
 await expect(page.getByRole('button',{name:'Bag',exact:true})).toBeDisabled();
 await page.getByRole('button',{name:'Recruit',exact:true}).click();
 await page.getByRole('button',{name:'Welcome a friend',exact:true}).click();
 await page.getByRole('button',{name:'Meet your cats',exact:true}).waitFor({timeout:15000});
 await shot('q11-new-friend');
 await page.getByRole('button',{name:'Meet your cats',exact:true}).click();
 await page.getByRole('button',{name:'Level up',exact:true}).click();
 await page.getByRole('button',{name:'Close',exact:true}).click();
 await expect(shell).not.toHaveAttribute('data-a6-guide','upgrade');
 await expect(page.getByRole('button',{name:'Events',exact:true})).toBeEnabled();
 await page.setViewportSize({width:1280,height:720});
 await shot('q11-next-goal-small');
 const state=await page.evaluate(()=>({tutorial:window.__depthReview.state.tutorial,freeInvite:window.__depthReview.state.freeInvite,levels:window.__depthReview.state.account.cards.map(c=>c.level),goal:document.querySelector('.a6-next-goal')?.textContent,overflow:document.documentElement.scrollWidth>innerWidth}));
 if(errors.length||state.overflow)throw Error(JSON.stringify({errors,state}));
 await writeFile(root+'/reports/cardrpg-a6/q11-onboarding-ui.json',JSON.stringify({state,errors,syntheticGrants:false},null,2)+'\n');
 console.log('First patrol, free friend, cat level, guide progression and small-screen goal PASS.');
}finally{await browser.close();}
